# Create log file directory
mkdir -p /var/log/itd-mb-service-filetransfer

# Create outbox folder
mkdir -p /var/spool/outbox/bdo-cors-itrs

# Create application main installation folder
mkdir -p /usr/local/itd-mb-service-filetransfer

# Copy application artifacts and configurations
cp -r ./itd-mb-service-filetransfer/* /usr/local/itd-mb-service-filetransfer




