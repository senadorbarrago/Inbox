# Create certificate directory
mkdir -p /usr/local/tomcat

# Install certificate
cp -r ./tomcat/* /usr/local/tomcat
