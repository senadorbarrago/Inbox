# Execute pre-installer permissions
chmod +x ./itd-mb-service-filetransfer-pre-installer.sh &&
chmod +x ./itd-mb-service-load-pre-installer.sh &&
chmod +x ./itd-mb-service-report-pre-installer.sh &&
chmod +x ./bdo-cors-pre-installer.sh &&

# Run application pre-installers
./itd-mb-service-filetransfer-pre-installer.sh &&
./itd-mb-service-load-pre-installer.sh &&
./itd-mb-service-report-pre-installer.sh &&
./bdo-cors-pre-installer.sh &&

# Execute certificate installer permissions
chmod +x ./certificate-installer.sh &&

# Run certificate installer
./certificate-installer.sh &&

# Execute installer permissions
chmod +x /usr/local/itd-mb-service-filetransfer/app/run-itd-mb-service-filetransfer-1.0.0.sh &&
chmod +x /usr/local/itd-mb-service-load/app/run-itd-mb-service-load-1.0.0.sh &&
chmod +x /usr/local/itd-mb-service-report/app/run-itd-mb-service-report-2.2.0.sh &&
chmod +x /usr/local/bdo-cors/app/run-bdo-cors-web-1.0.0.sh &&

# Run application installers
/usr/local/itd-mb-service-filetransfer/app/run-itd-mb-service-filetransfer-1.0.0.sh 
/usr/local/itd-mb-service-load/app/run-itd-mb-service-load-1.0.0.sh 
/usr/local/itd-mb-service-report/app/run-itd-mb-service-report-2.2.0.sh 
/usr/local/bdo-cors/app/run-bdo-cors-web-1.0.0.sh 
