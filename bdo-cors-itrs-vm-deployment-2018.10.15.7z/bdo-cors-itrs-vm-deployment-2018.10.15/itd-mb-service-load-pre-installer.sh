# Create log file directory
mkdir -p /var/log/itd-mb-service-load

# Create process staging folders
mkdir -p /var/spool/inbox/bdo-cors-itrs/source
mkdir -p /var/spool/inbox/bdo-cors-itrs/process
mkdir -p /var/spool/inbox/bdo-cors-itrs/archive
mkdir -p /var/spool/inbox/bdo-cors-itrs/error

# Create application main installation folder
mkdir -p /usr/local/itd-mb-service-load

# Copy application artifacts and configurations
cp -r ./itd-mb-service-load/* /usr/local/itd-mb-service-load




