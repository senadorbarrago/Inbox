# Create log file directory
mkdir -p /var/log/itd-mb-service-report

# Create report folders
mkdir -p /var/report/bdo-cors-itrs/RPT-000-ProoflistReport
mkdir -p /var/report/bdo-cors-itrs/RPT-001-BSPExtract
mkdir -p /var/report/bdo-cors-itrs/RPT-002-AuditReport
mkdir -p /var/report/bdo-cors-itrs/RPT-003-BSPExtract-D01
mkdir -p /var/report/bdo-cors-itrs/RPT-004-BSPExtract-D02
mkdir -p /var/report/bdo-cors-itrs/RPT-005-BSPExtract-D03
mkdir -p /var/report/bdo-cors-itrs/RPT-006-BSPExtract-D04
mkdir -p /var/report/bdo-cors-itrs/RPT-007-BSPExtract-D05
mkdir -p /var/report/bdo-cors-itrs/RPT-008-BSPExtract-D06
mkdir -p /var/report/bdo-cors-itrs/RPT-009-BSPExtract-D07
mkdir -p /var/report/bdo-cors-itrs/RPT-010-BSPExtract-D08
mkdir -p /var/report/bdo-cors-itrs/RPT-011-BSPExtract-D09
mkdir -p /var/report/bdo-cors-itrs/RPT-012-BSPExtract-D10
mkdir -p /var/report/bdo-cors-itrs/RPT-013-BSPExtract-D11
mkdir -p /var/report/bdo-cors-itrs/RPT-014-BSPExtract-D12
mkdir -p /var/report/bdo-cors-itrs/RPT-015-BSPExtract-D13
mkdir -p /var/report/bdo-cors-itrs/RPT-016-BSPExtract-D14
mkdir -p /var/report/bdo-cors-itrs/RPT-017-BSPExtract-D15

# Create application main installation folder
mkdir -p /usr/local/itd-mb-service-report

# Copy application artifacts and configurations
cp -r ./itd-mb-service-report/* /usr/local/itd-mb-service-report


