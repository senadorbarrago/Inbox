# Create log file directory
mkdir -p /var/log/bdo-cors

# Create BDO-CORS main installation folder
mkdir -p /usr/local/bdo-cors

# Copy BDO-CORS artifacts and configurations
cp -r ./bdo-cors/* /usr/local/bdo-cors




