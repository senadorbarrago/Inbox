package com.bdo.itdis.bdocas;

import java.io.IOException;
import java.util.Properties;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.annotation.ImportResource;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;

import com.bdo.itd.util.properties.PropertiesLoader;

@SpringBootApplication
@ImportResource({
	"classpath:config/applicationContext.xml", 
	"classpath:config/context/advanceSearchContext.xml",
	"classpath:config/context/auditLoggingContext.xml",
	"classpath:config/context/batchSheetContext.xml", 
	"classpath:config/context/dataCleanUpContext.xml",
	"classpath:config/context/inboundInterfaceContext.xml", 
	"classpath:config/context/inventoryContext.xml",
	"classpath:config/context/journalEntryContext.xml",
	"classpath:config/context/outboundInterfaceContext.xml", 
	"classpath:config/context/remarksContext.xml",
	"classpath:config/context/reportContext.xml", 
	"classpath:config/context/securityContext.xml",
	"classpath:config/context/transactionContext.xml",
	"classpath:config/context/referenceContext.xml"
})
public class BCASApplicationJar{

	public static void main(String[] args){
		new SpringApplicationBuilder(BCASApplicationJar.class)		
			.sources(BCASApplicationJar.class)
				.properties(getProperties(getResourceInitializer()))
					.run(args);	
	}
	
	private static Resource getResourceInitializer() {
		DefaultResourceLoader loader = new DefaultResourceLoader();
		Resource resource = loader.getResource("classpath:config/application.properties");
		return resource;
	}
	
	private static Properties getProperties(Resource resource) {
		Properties properties = new Properties();
		try {
			properties = PropertiesLoader.loadProperties(resource.getInputStream());
		} catch (IOException e) {
			e.printStackTrace();
		}
		return properties;
	}
	
}
