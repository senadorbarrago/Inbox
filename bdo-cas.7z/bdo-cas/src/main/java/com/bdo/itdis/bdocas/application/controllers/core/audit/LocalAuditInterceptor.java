package com.bdo.itdis.bdocas.application.controllers.core.audit;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.bdo.itd.util.audit.AuditDataHandler;
import com.bdo.itd.util.audit.data.AuditData;
import com.bdo.itd.util.audit.data.AuditParam;
import com.bdo.itd.util.persistence.DataAccessInterface;

public class LocalAuditInterceptor extends DefaultAuditInterceptor {
	
	/**
	 * 
	 */
	private static final Logger logger = Logger.getLogger(LocalAuditInterceptor.class);
	
	/**
	 * 
	 */
	@Override
	protected void setUserInformation(AuditData data, HttpServletRequest request) {
		logger.info("Executing [" + this.getClass() +" setUserInformation(AuditData data, HttpServletRequest request)]");
		
		String userID = null;
		String username = null;
		String role = null;
		String position = null;

		HttpSession session = request.getSession(false);
		
		if (null != session) {
			userID = (String) session.getAttribute(AuditParam.USER_ID);
			if(userID == null){
				Object paramUserID = AuditDataHandler.get(AuditParam.USER_ID);
				if(paramUserID !=null){
					userID = (String) paramUserID;	
				}				
			}
			
			username = (String) session.getAttribute(AuditParam.USER_NAME);
			role = (String) session.getAttribute(AuditParam.USER_ROLE);
			position = (String) session.getAttribute(AuditParam.USER_POSITION);
		} else {
			 AuditDataHandler.put(AuditParam.AUDIT_ERROR, new Exception("User session expired.")) ;
			 AuditDataHandler.put(AuditParam.MODIFIED_DATA, "User session expired.") ;
		}
		
		data.setUserId(userID);
		data.setUserName((username));
		data.setRole(role);
		data.setPosition(position);
		
	}
	
	/**
	 * @param dataAccess
	 */
	public void setDataAccess(DataAccessInterface dataAccess){
		this.dataAccess = dataAccess;
	}
}
