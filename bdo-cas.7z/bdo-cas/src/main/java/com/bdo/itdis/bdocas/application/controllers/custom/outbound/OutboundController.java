/**
 * 
 */
package com.bdo.itdis.bdocas.application.controllers.custom.outbound;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.crqs.command.CommandException;
import com.bdo.itd.util.crqs.command.CommandMessage;
import com.bdo.itd.util.crqs.command.ICommandBus;
import com.bdo.itd.util.security.application.UserSession;
import com.bdo.itdis.bdocas.outbound.application.command.CSLOutboundGeneratorCommand;
import com.bdo.itdis.bdocas.outbound.application.command.ICBSGLOutboundGeneratorCommand;
import com.bdo.itdis.bdocas.outbound.application.command.OutboundGeneratorCommand;


/**
 * @author c150819004
 *
 */
@RestController
public class OutboundController {
	
	private ICommandBus commandBus;
	
	@Inject
	public OutboundController(@Named("outboundCommandBus")ICommandBus commandBus) {
		super();
		this.commandBus = commandBus;
	}
	
	@RequestMapping(value="/outbound/create/{outboundInterfaceFileCode}", method=RequestMethod.POST,
			consumes=MediaType.APPLICATION_JSON_VALUE)
	public Object generateOutbound(@PathVariable String outboundInterfaceFileCode, @RequestBody Map<String, Object> parameters,
			HttpServletRequest request){		
		Map<String, Object> outboundParameters = new LinkedHashMap<String, Object>();
		
		System.out.println("Date Generated: " + parameters.get("dateGenerated").toString());
		
		parameters.put("outboundInterfaceFileCode", outboundInterfaceFileCode);
		parameters.put("dateGenerated", parameters.get("dateGenerated").toString());
		
		outboundParameters.put("userName", UserSession.getUsername());
		outboundParameters.put("outboundProfileID", parameters.get("outboundProfileID"));
		outboundParameters.put("processingDate", parameters.get("processingDate"));
		outboundParameters.put("encodingUnit", parameters.get("encodingUnit"));
		outboundParameters.put("reportID", parameters.get("reportID"));
		
		parameters.put("reportParameters", outboundParameters);
		
		CommandMessage message = new CommandMessage();
		
		if(outboundInterfaceFileCode.equals("ICBS-GL")){
			message = this.doGeneratedICBSOutboundInterfaceFile(parameters);
		}else if(outboundInterfaceFileCode.equals("CSL")){
			message = this.doGeneratedCSLOutboundInterfaceFile(parameters);
		}else{
			message = this.doGeneratedOutboundInterfaceFile(parameters);
		}
		
		return message;
	}
	
	private CommandMessage doGeneratedOutboundInterfaceFile(Map<String, Object> parameters){
		OutboundGeneratorCommand command = new OutboundGeneratorCommand();
		command.setOutboundCode(parameters.get("outboundInterfaceFileCode").toString());
		command.setParams(parameters);
		command.setUsername(UserSession.getUsername());
		command.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
		command.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());
		command.setEncodingUnitCode(parameters.get("encodingUnit").toString());
		command.setProcessingDate((parameters.get("processingDate").toString()));

		CommandMessage message = new CommandMessage();
		
		try{
			message = commandBus.doPublish(command);
		}catch(CommandException comex){
			comex.printStackTrace();
		}
		return message;
	}
	
	private CommandMessage doGeneratedICBSOutboundInterfaceFile(Map<String, Object> parameters){
		ICBSGLOutboundGeneratorCommand command = new ICBSGLOutboundGeneratorCommand();
		command.setOutboundCode(parameters.get("outboundInterfaceFileCode").toString());
		command.setParams(parameters);
		command.setUsername(UserSession.getUsername());
		command.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
		command.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());
		command.setEncodingUnitCode(parameters.get("encodingUnit").toString());
		command.setProcessingDate((parameters.get("processingDate").toString()));
		CommandMessage message = new CommandMessage();
		
		try{
			message = commandBus.doPublish(command);
		}catch(CommandException comex){
			comex.printStackTrace();
		}
		return message;
	}
	
	private CommandMessage doGeneratedCSLOutboundInterfaceFile(Map<String, Object> parameters){
		System.out.println("doGeneratedCSLOutboundInterfaceFile()");
		CSLOutboundGeneratorCommand command = new CSLOutboundGeneratorCommand();
		command.setOutboundCode(parameters.get("outboundInterfaceFileCode").toString());
		command.setParams(parameters);
		command.setUsername(UserSession.getUsername());
		command.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
		command.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());;
		command.setEncodingUnitCode(parameters.get("encodingUnit").toString());
		command.setProcessingDate((parameters.get("processingDate").toString()));
		CommandMessage message = new CommandMessage();
		
		try{
			message = commandBus.doPublish(command);
		}catch(CommandException comex){
			comex.printStackTrace();
		}
		return message;
	}
	
}
