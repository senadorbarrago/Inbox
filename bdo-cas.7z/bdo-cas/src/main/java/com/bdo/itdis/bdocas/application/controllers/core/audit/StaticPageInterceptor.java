package com.bdo.itdis.bdocas.application.controllers.core.audit;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;


public class StaticPageInterceptor implements HandlerInterceptor, InitializingBean {
	
	/**
	 * 
	 */
	private static final Logger logger = Logger.getLogger(StaticPageInterceptor.class);
	
	/**
	 * 
	 */
	private List<String> urlList;

	
	/**
	 * @param urlList
	 */
	public StaticPageInterceptor(List<String> urlList) {
		super();
		this.urlList = urlList;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void afterCompletion(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, Exception arg3)
			throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void postHandle(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, ModelAndView arg3)
			throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse arg1, Object arg2) throws Exception {
		logger.info(this.getClass()+" - preHandle()");
		String url = request.getRequestURI();
		System.out.println(url);
		
		for(String str : urlList){
			if(url.contains(str) && !request.getParameterMap().isEmpty()){
				System.out.println("Contains");
				throw new IllegalArgumentException("IllegalArgumentException occured!");
			}
		}
		
		return true;
	}
	
	
	
}
