package com.bdo.itdis.bdocas.application.controllers.custom.reference;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.security.application.UserSession;
import com.bdo.itdis.bdocas.application.controllers.custom.reference.utils.IReferenceService;

@RestController
public class ReferenceTagByDataSetIDQueryController {
	
	private final IReferenceService referenceService;
	
	@Inject
	public ReferenceTagByDataSetIDQueryController(@Named("referenceService")IReferenceService referenceService) {
		super();
		this.referenceService = referenceService;
	}


	@RequestMapping(value="/references/tagging/{dataSetID}/{transactionID}/{encodingUnitCode}", method=RequestMethod.GET)
	public Object doQuery(@PathVariable("dataSetID")Long dataSetID, @PathVariable("transactionID")Long transactionID,
			@PathVariable("encodingUnitCode")String encodingUnitCode, HttpServletRequest request){
		System.out.println("dataSetID: "+dataSetID);
		List<Object> paramList = new ArrayList<>();
		paramList.add(dataSetID);
		paramList.add(UserSession.getActiveAuthority().getRole().getCode());
		paramList.add(transactionID);
		paramList.add(UserSession.getUsername());
		paramList.add(encodingUnitCode);
		
		return referenceService.getReferenceWithAdditionalDetails("dbo.spTRNDisplayTagging ?,?,?,?,?", paramList);
	}
}
