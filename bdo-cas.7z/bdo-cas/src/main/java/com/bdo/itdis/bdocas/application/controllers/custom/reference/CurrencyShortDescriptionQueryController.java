/**
 * 
 */
package com.bdo.itdis.bdocas.application.controllers.custom.reference;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itdis.bdocas.application.controllers.custom.reference.utils.IReferenceService;

/**
 * @author c150819004
 *
 */
@RestController
public class CurrencyShortDescriptionQueryController {

	private final IReferenceService referenceService;

	@Inject
	public CurrencyShortDescriptionQueryController(
			IReferenceService referenceService) {
		super();
		this.referenceService = referenceService;
	}
	
	@RequestMapping(value="/references/currencyShortDesc/{dataSetCode}", 
				method=RequestMethod.GET)
	public Object doQuery(@PathVariable String dataSetCode, HttpServletRequest request){
		
		System.out.println("Dataset Code= " + dataSetCode);
		
		List<Object> paramList = new ArrayList<>();
		paramList.add(dataSetCode);
		
		return referenceService.getReferenceWithCode("dbo.spGetCurrencyShortDescription ?", paramList);
	}
}
