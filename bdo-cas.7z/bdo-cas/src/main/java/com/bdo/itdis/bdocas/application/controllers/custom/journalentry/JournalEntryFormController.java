package com.bdo.itdis.bdocas.application.controllers.custom.journalentry;

import java.util.Set;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.crqs.command.CommandException;
import com.bdo.itd.util.crqs.command.CommandMessage;
import com.bdo.itd.util.crqs.command.ICommandBus;
import com.bdo.itd.util.security.application.UserSession;
import com.bdo.itdis.bdocas.application.controllers.AbstractController;
import com.bdo.itdis.bdocas.journalentry.application.command.AddJournalEntryCommand;
import com.bdo.itdis.bdocas.journalentry.application.command.UpdateJournalEntryCommand;
import com.bdo.itdis.bdocas.journalentry.application.query.dto.form.DTOForm;
import com.bdo.itdis.bdocas.journalentry.application.query.dto.form.DTORecord;
import com.bdo.itdis.bdocas.journalentry.application.query.forms.IJournalEntryFormQueryService;


@RestController
public class JournalEntryFormController extends AbstractController{
	
	private final IJournalEntryFormQueryService journalEntryFormQueryService;
	private ICommandBus commandBus;
	
	@Inject
	public JournalEntryFormController(@Named("journalEntryFormQueryService")IJournalEntryFormQueryService journalEntryFormQueryService,
			@Named("journalEntryManagementCommandBus") ICommandBus commandBus) {
		super();
		this.journalEntryFormQueryService = journalEntryFormQueryService;
		this.commandBus = commandBus;
	}

	@RequestMapping(value="/journalentry/form/{batchID}", method=RequestMethod.GET)
	public Object doQueryExistingFormByBatchID(@PathVariable("batchID")String batchID, HttpServletRequest request){
		System.out.println("doQueryExistingFormByBatchID()");
		System.out.println("journalEntryFormID: "+batchID);
		DTOForm form = new DTOForm();
		
		
		
		
		try{
			form = journalEntryFormQueryService.createExistingJournalEntryFormByBatchID(batchID);
			
			Set<String> keys = form.getHeader().getHeaderFieldMap().keySet();
			
			System.out.println("Header Fields");
			for(String key : keys){
				System.out.println(key+": "+form.getHeader().getHeaderFieldMap().get(key).getDescription());
			}
			
			System.out.println("Start Record Fields==============================");
			keys = form.getRecordList().get(0).getRecordFieldMap().keySet();
			for(DTORecord record : form.getRecordList())
			for(String key : keys){
				System.out.println(key);
				System.out.println(record.getRecordFieldMap().get(key).getValue());
			}
			System.out.println("End Record Fields==============================");
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return form;
	}
	
	@RequestMapping(value="/journalentry/form/new/{dataSetID}", method=RequestMethod.GET)
	public Object doQueryNewFormByDataSetID(@PathVariable("dataSetID")Long dataSetID, HttpServletRequest request){		
		System.out.println("doQueryNewFormByDataSetID()");
		System.out.println("dataSetID: "+dataSetID);
		DTOForm form = new DTOForm();
		try{
			form = journalEntryFormQueryService.createNewJournalEntryForm(dataSetID);
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return form;
	}
	
	@RequestMapping(value="/journalentry/form/save", consumes=MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.POST)
	public Object saveForm(@RequestBody DTOForm form, HttpServletRequest request) throws CommandException{		
		System.out.println("saveForm() called");

		AddJournalEntryCommand command = new AddJournalEntryCommand();
		
		command.setDataSetCode(form.getDataSetCode());
		command.setDataSetID(form.getDataSetID());
		command.setForm(form);
		command.setUsername(UserSession.getUsername());
		command.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
		command.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());
		command.getParams().put("section", UserSession.getActiveAuthority().getGroup().getCode());
		
		CommandMessage message = new CommandMessage();
		
		message = commandBus.doPublish(command);
		
		return message;
	}
	
	@RequestMapping(value="/journalentry/form/update", consumes=MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.PUT)
	public Object updateForm(@RequestBody DTOForm form, HttpServletRequest request)throws CommandException{		
		System.out.println("updateForm() called");
		
		UpdateJournalEntryCommand command = new UpdateJournalEntryCommand();
		
		command.setDataSetCode(form.getDataSetCode());
		command.setDataSetID(form.getDataSetID());
		command.setForm(form);
		command.setUsername(UserSession.getUsername());
		command.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
		command.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());
		
		CommandMessage message = new CommandMessage();
		
		
		message = commandBus.doPublish(command);
		
		
		return message;
	}
}
