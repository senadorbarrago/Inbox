package com.bdo.itdis.bdocas.application.controllers.core.endpoints;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.crqs.command.CommandException;
import com.bdo.itd.util.crqs.command.CommandMessage;
import com.bdo.itd.util.crqs.command.ICommandBus;
import com.bdo.itdis.bdocas.application.controllers.AbstractController;
import com.bdo.itdis.bdocas.datacleanup.application.command.DataArchivalCommand;

/**
 * @author c140618008
 *
 */
@RestController
@RequestMapping("/endpoint/datacleanup")
public class DataArchivingEndPointController extends AbstractController{
	
	/**
	 * 
	 */
	private static final Logger logger = Logger.getLogger(DataArchivingEndPointController.class);
	
	/**
	 * 
	 */
	@Inject
	@Named("dataCleanUpCommandBus")
	private ICommandBus commandBus;
	
	/**
	 * @param interfaceFileCode
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/archival/{dataSetCode}", method=RequestMethod.GET, produces="application/json")
	public Object receiveRequest(@PathVariable(value="dataSetCode") String dataSetCode, 
			HttpServletRequest request, HttpServletResponse response) throws CommandException{
		logger.info(this.getClass()+" - "+"receiveRequest()");
		logger.info(this.getClass()+" - "+"{dataSetCode}: "+dataSetCode);
		
		DataArchivalCommand command = new DataArchivalCommand();
		command.setDataSetCode(dataSetCode);
		command.setUsername("BCAS-AUTOSCHEDULER");
		
		CommandMessage commandMessage = commandBus.doPublish(command);
		
		return "{\"message\":\""+commandMessage.getMessageMap().get("successMsg")+"\"}";
	}
	
}
