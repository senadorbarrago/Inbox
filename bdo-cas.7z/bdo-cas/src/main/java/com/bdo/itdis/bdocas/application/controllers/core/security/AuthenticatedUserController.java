package com.bdo.itdis.bdocas.application.controllers.core.security;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.security.application.UserSession;
import com.bdo.itdis.bdocas.application.controllers.AbstractController;


/**
 * @author c140618008
 *
 */
//@RestController("authenticatedUserController")
public class AuthenticatedUserController extends AbstractController {
	
	/**
	 * 
	 * @param request
	 * @return
	 */
//	@RequestMapping(value="/authenticatedUser", method=RequestMethod.GET, produces="application/json")
//	public Object getAutheticatedUser(){		
//		return UserSession.getUserProfile();
//	}
	
}
