/**
 * 
 */
package com.bdo.itdis.bdocas.application.controllers.custom.reference;

import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.cqrs.query.ResultModel;
import com.bdo.itdis.bdocas.outbound.application.query.IOutboundInterfaceFileQueryService;



/**
 * @author c150819004
 *
 */
@RestController
public class OutboundInterfaceFilesQueryController {
	
	private final IOutboundInterfaceFileQueryService outboundInterfaceFilesQueryService;

	@Inject
	public OutboundInterfaceFilesQueryController(@Named("outboundInterfaceFilesQueryService")IOutboundInterfaceFileQueryService outboundInterfaceFilesQueryController) {
		super();
		this.outboundInterfaceFilesQueryService = outboundInterfaceFilesQueryController;
	}

	@RequestMapping(value="/references/outboundInterfaceFiles/{dataSetID}/{membershipID}", method=RequestMethod.GET)
	public Object doGetOutboundInterfaceFiles(@PathVariable long dataSetID, @PathVariable long membershipID,HttpServletRequest request){
		ResultModel resultModel = null;
		try{
			Map<String, Object> params = new HashMap<>();
			params.put("dataSetID", dataSetID);
			params.put("membershipID", membershipID);
			System.out.println("OutboundInterfaceFilesQueryController: doGetOutboundInterfaceFiles() Parameters: " + params);
			
			resultModel = outboundInterfaceFilesQueryService.doQuery(params);
		} catch(Exception e){
			e.printStackTrace();
		}
		return resultModel;
	}
	
}
