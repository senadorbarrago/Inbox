/**
 * 
 */
package com.bdo.itdis.bdocas.application.controllers.custom.rmf;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.service.client.ServiceClient;
import com.bdo.itd.util.logger.LoggerUtility;
import com.bdo.itd.util.logger.LoggerUtilityFactory;
import com.bdo.itd.util.map.ParameterMap;
import com.bdo.itd.util.map.ParameterMapBuilder;
import com.bdo.itd.util.map.ResultMap;
import com.bdo.itd.util.security.application.UserSession;

/**
 * @author c150819004
 *
 */
@RestController
public class ReferenceMaintenanceController {

	/**
	 * 
	 */
	private static final LoggerUtility logger = 
			LoggerUtilityFactory.createLoggerUtility(ReferenceMaintenanceController.class);
	
	/**
	 * 
	 */
	private ServiceClient referenceServiceClient;
	
	
	@Inject
	public ReferenceMaintenanceController(
			@Named("referenceServiceClient")ServiceClient referenceServiceClient) {
		super();
		this.referenceServiceClient = referenceServiceClient;
	}

	@RequestMapping("/rmf")
	public Map<String, Object> doGet(
			HttpServletRequest request,
			HttpServletResponse response) throws Exception{
		
		logger.info("RMF");
		
		Map<String, Object> authenticationData = new LinkedHashMap<String, Object>();
		
		authenticationData.put("username", UserSession.getUsername());
		authenticationData.put("membershipId", UserSession.getActiveAuthority().getMembershipID());
		authenticationData.put("sessionId", request.getSession().getId());
		authenticationData.put("application", "bcas");
		
		ParameterMap parameters = ParameterMapBuilder
				.instance()
				.add("action", "authenticate")
				.add("authenticationData", authenticationData)
				.build();
		
		ResultMap resultMap = null;
		
		try {
			resultMap = referenceServiceClient.execute(parameters);
			System.out.println("ResultMap: " + resultMap);
//			response.sendRedirect((String) resultMap.get("redirectUrl"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return resultMap.map();
	}
	
}
