package com.bdo.itdis.bdocas.application.controllers.custom.transaction;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.crqs.command.CommandException;
import com.bdo.itd.util.crqs.command.CommandMessage;
import com.bdo.itd.util.crqs.command.ICommandBus;
import com.bdo.itd.util.security.application.UserSession;
import com.bdo.itdis.bdocas.transactions.application.command.BeginOfDayCommand;
import com.bdo.itdis.bdocas.transactions.application.query.values.IBeginOfDayQueryService;


@RestController
public class BeginOfDayController {
	
	
	private final ICommandBus commandBus;
	private final IBeginOfDayQueryService queryService;
	
	@Inject
	public BeginOfDayController(@Named("transactionManagementCommandBus")ICommandBus commandBus,
			@Named("beginOfDayQueryService") IBeginOfDayQueryService queryService) {
		super();
		this.commandBus = commandBus;
		this.queryService = queryService;
	}
	
	@RequestMapping(value="/transactions/beginOfDay/save", consumes=MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.POST)
	public Object doSetBeginOfDay(@RequestBody Map<String, Object> data, HttpServletRequest request)throws Exception{
		System.out.println("doSetBeginOfDay()");
		
		CommandMessage message = new CommandMessage();
		
		BeginOfDayCommand command = new BeginOfDayCommand();
		command.setProcessID(Long.parseLong(data.get("processID").toString()));
		
		SimpleDateFormat sdfGlDate = new SimpleDateFormat("yyyy-MM-dd");
		
		if(data.get("currentProcessingDate").toString().equals(null) || data.get("currentProcessingDate").toString().equals("")){
			throw new Exception("Must set new GL Date first in order to proceed with the Begin of Day.");
		}else{
			Date glDate = sdfGlDate.parse(data.get("currentProcessingDate").toString());
			command.setGlDate(glDate);
		}
		
		SimpleDateFormat sdfPrevGlDate = new SimpleDateFormat("yyyy-MM-dd");
		Date previousGlDate = sdfPrevGlDate.parse(data.get("previousProcessingDate").toString());
		command.setPrevGlDate(previousGlDate);
		command.setDatasetID(Long.parseLong(data.get("dataSetID").toString()));
		command.setUsername(UserSession.getUsername());
		command.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
		command.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());
		command.setMembershipID(UserSession.getActiveAuthority().getMembershipID());
		
		System.out.println("MembershipID: "+command.getMembershipID());
		
		message = commandBus.doPublish(command);
	
		return message;
	}
	
	@RequestMapping(value="/transactions/beginOfDay/currentGlDate/{dataSetID}", method=RequestMethod.GET)
	public Object doGetCurrentGLDate(@PathVariable("dataSetID")Long dataSetID, HttpServletRequest request){
		System.out.println("dataSetID: "+dataSetID);
		String currentGlDate = "";
		try{
			currentGlDate = queryService.doGetCurrentGLDate(dataSetID);
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return "{\"currentGlDate\" : \""+currentGlDate+"\"}";
	}
	
	@RequestMapping(value="/transactions/beginOfDay/currentProcessingDate/{dataSetID}/{costCenterID}", method=RequestMethod.GET)
	public Object doGetCurrentProcessingDate(@PathVariable("dataSetID")Long dataSetID, @PathVariable("costCenterID")Long costCenterID, 
			HttpServletRequest request){
		System.out.println("dataSetID: "+dataSetID);
		String currentProcessingDate = "";
		try{
			currentProcessingDate = queryService.doGetCurrentProcessingDatePerCostCenterQueryModel(dataSetID, costCenterID);
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return "{\"currentProcessingDate\" : \""+currentProcessingDate+"\"}";
	}
	
	@RequestMapping(value="/transactions/beginOfDay/previousProcessingDate/{dataSetID}/{costCenterID}", method=RequestMethod.GET)
	public Object doGetPreviousProcessingDate(@PathVariable("dataSetID")Long dataSetID, @PathVariable("costCenterID")Long costCenterID, 
			HttpServletRequest request){
		System.out.println("dataSetID: "+dataSetID);
		String previousProcessingDate = "";
		try{
			previousProcessingDate = queryService.doGetPreviousProcessingDatePerCostCenter(dataSetID, costCenterID);
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return "{\"previousProcessingDate\" : \""+previousProcessingDate+"\"}";
	}
	
	@RequestMapping(value="/transactions/beginOfDay/processID/{dataSetID}", method=RequestMethod.GET)
	public Object doGetProcessID(@PathVariable("dataSetID")Long dataSetID, HttpServletRequest request){
		System.out.println("dataSetID: "+dataSetID);
		Long processID = 0L;
		try{
			processID = queryService.doGetProcessID(dataSetID);
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return "{\"processID\" : \""+processID+"\"}";
	}
	
	@ExceptionHandler(CommandException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	public Object handleCommandException(HttpServletResponse response, Exception ex){
		Map<String, String> messageMap = new HashMap<>();
		messageMap.put("errorMsg", ex.getMessage());
		
		return  messageMap;
	}
	
	@ExceptionHandler(Exception.class)
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public Object handlegenericException(HttpServletResponse response, Exception ex){
		Map<String, String> messageMap = new HashMap<>();
		messageMap.put("errorMsg", ex.getMessage());
		
		return  messageMap;
	}
	
}
