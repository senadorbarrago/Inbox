package com.bdo.itdis.bdocas.infrastructure.policy;

import java.util.List;

import org.aspectj.lang.JoinPoint;

import com.bdo.itd.util.crqs.command.ICommand;
import com.bdo.itd.util.policy.IPolicy;
import com.bdo.itd.util.policy.PolicyRegistry;

/**
 * 
 * @author a014000098
 *
 */
public class CommandPolicyAspect {
	
	/**
	 * 
	 */
	private final PolicyRegistry policyRegistry;
	
	/**
	 * 
	 * @param policyRegistry
	 */
	public CommandPolicyAspect(PolicyRegistry policyRegistry) {
		super();
		this.policyRegistry = policyRegistry;
	}

	/**
	 * 
	 * @param joinPoint
	 * @throws Throwable
	 */
	public void executePolicies(JoinPoint joinPoint) throws Throwable {				
		ICommand command = (ICommand)joinPoint.getArgs()[0];
		
		List<IPolicy> policyList = policyRegistry.getPolicies(command.getClass().getName());
		
		for(IPolicy policy : policyList){
			policy.validate(command.getParams());
		}
	}
	
}
