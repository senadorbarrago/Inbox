/**
 * 
 */
package com.bdo.itdis.bdocas.application.controllers.custom.reference;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.cqrs.query.ResultModel;
import com.bdo.itdis.bdocas.transactions.application.query.values.IProcessingInfoQueryService;

/**
 * @author c150819004
 *
 */
@RestController
public class ProcessingInfoQueryController {

	private final IProcessingInfoQueryService processingInfoQueryService;
	
	@Inject
	public ProcessingInfoQueryController(IProcessingInfoQueryService processingInfoQueryService) {
		super();
		this.processingInfoQueryService = processingInfoQueryService;
	}
	
	@RequestMapping(value="/references/processingDate/{dataSetID}/{encodingUnitID}",
					method=RequestMethod.GET)
	public Object doQuery(@PathVariable("dataSetID") Long dataSetID, 
							@PathVariable("encodingUnitID") Long encodingUnitID,
							HttpServletRequest request){
		
		System.out.println("Dataset ID: " + dataSetID + " EncodingUnit ID: " + encodingUnitID);
		String processingDate = "";
		
		try{
			processingDate = processingInfoQueryService.getProcessingDate(dataSetID, encodingUnitID);
		} catch(Exception e){
			e.printStackTrace();
		}
		
		return "{\"processingDate\":\""+processingDate+"\"}";
	}
	
	@Deprecated
	@RequestMapping(value="/references/processingInfo/{dataSetCode}/{encodingUnitCode}",
			method=RequestMethod.GET)
	public Object doQuery(@PathVariable("dataSetCode") String dataSetCode, 
					@PathVariable("encodingUnitCode") String encodingUnitCode,
					HttpServletRequest request){
		ResultModel resultModel = null;
		try{
			resultModel = processingInfoQueryService.getProcessingDateAndState(encodingUnitCode, dataSetCode);
		} catch(Exception e){
			e.printStackTrace();
		}
		return resultModel;
	}
}
