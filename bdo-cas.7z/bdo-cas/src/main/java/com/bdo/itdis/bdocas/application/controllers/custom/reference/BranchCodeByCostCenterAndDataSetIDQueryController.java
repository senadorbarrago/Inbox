package com.bdo.itdis.bdocas.application.controllers.custom.reference;

import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itdis.bdocas.journalentry.application.query.references.IBranchCodeByCostCenterAndDataSetIDQueryService;

@RestController
public class BranchCodeByCostCenterAndDataSetIDQueryController {
	
	private final IBranchCodeByCostCenterAndDataSetIDQueryService branchCodeByCostCenterAndDataSetIDQueryService;
	
	@Inject
	public BranchCodeByCostCenterAndDataSetIDQueryController(
			@Named("branchCodeByCostCenterAndDataSetIDQueryService")IBranchCodeByCostCenterAndDataSetIDQueryService branchCodeByCostCenterAndDataSetIDQueryService) {
		super();
		this.branchCodeByCostCenterAndDataSetIDQueryService = branchCodeByCostCenterAndDataSetIDQueryService;
	}


	@RequestMapping(value="/references/branchCodeByCostCenterAndDataSetID/{costCenterCode}/{dataSetID}/{index}", method=RequestMethod.GET)
	public Object doQuery(@PathVariable("costCenterCode")String costCenterCode, 
			@PathVariable("dataSetID")Long dataSetID, @PathVariable("index")Integer index, HttpServletRequest request){
		System.out.println("costCenterCode: "+costCenterCode);
		System.out.println("dataSetID: "+dataSetID);
		String branchCode = "";
		
		try{
			branchCode = branchCodeByCostCenterAndDataSetIDQueryService.getBranchCodeByCostCenterAndDataSetID(costCenterCode, dataSetID);
		}catch(Exception ex){
			ex.printStackTrace();
		}
		
		Map<String, Object> returnMap = new HashMap<>();
		returnMap.put("index", index);
		returnMap.put("branchCode", branchCode);
		return returnMap;
	}

	

	
}
