package com.bdo.itdis.bdocas.application.controllers.custom.datacleanup;

import java.util.Date;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.crqs.command.CommandMessage;
import com.bdo.itd.util.crqs.command.ICommandBus;
import com.bdo.itd.util.security.application.UserSession;
import com.bdo.itdis.bdocas.application.controllers.AbstractController;
import com.bdo.itdis.bdocas.datacleanup.application.command.DataCleanUpCommand;
import com.ibm.icu.text.SimpleDateFormat;

@RestController
public class DataCleanUpController extends AbstractController{
	
	private final ICommandBus commandBus;
	
	@Inject
	public DataCleanUpController(@Named("dataCleanUpCommandBus")ICommandBus commandBus) {
		super();
		this.commandBus = commandBus;
	}
	
	@RequestMapping(value="/datacleanup", consumes=MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.POST)
	public Object doDataCleanUp(@RequestBody Map<String, Object> data, HttpServletRequest request) throws Exception{		
		System.out.println("doDataCleanUp():");
		System.out.println(data);
		
		DataCleanUpCommand command = this.convertToCommand(data);
		
		command.setUsername(UserSession.getUsername());
		command.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
		command.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());
		
		CommandMessage message = new CommandMessage();		
		message = commandBus.doPublish(command);
		
		return message;
	}
	
	private DataCleanUpCommand convertToCommand(Map<String, Object> data) throws Exception{
		String processingDateFrom =  this.isNull(data.get("processingDateFrom"))? "":data.get("processingDateFrom").toString();
		String processingDateTo = this.isNull(data.get("processingDateTo"))? "":data.get("processingDateTo").toString();
		long dataSetID = this.isNull(data.get("dataSetID"))? 0L:Long.parseLong(data.get("dataSetID").toString());
		
		DataCleanUpCommand command = new DataCleanUpCommand();
		
		command.setProcessingDateFrom(this.convertToDate(processingDateFrom));
		command.setProcessingDateTo(this.convertToDate(processingDateTo));
		command.setDatasetID(dataSetID);
		command.setUsername(UserSession.getUsername());
		command.setMembershipID(UserSession.getActiveAuthority().getMembershipID());
		
		return command;
	}
	
	private Date convertToDate(String date) throws Exception{		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date out = null;
		
		if(date != null && !date.isEmpty()){
			out = sdf.parse(date);
		}

		return out; 
	}
	
	private boolean isNull(Object object){
		if(object == null){
			return true;
		}else{
			return false;
		}
	}
	
}
