/**
 * 
 */
package com.bdo.itdis.bdocas.application.controllers.custom.controlcenter;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.cqrs.query.ResultModel;
import com.bdo.itd.util.persistence.DataAccessInterface;
import com.bdo.itdis.bdocas.application.controllers.AbstractController;


/**
 * @author c140618008
 *
 */
@RestController
public class ControlCenterController extends AbstractController{
	
	private final DataAccessInterface dataAccessService;
	
	@Inject
	public ControlCenterController(@Named("dataAccessService")DataAccessInterface dataAccessService) {
		super();
		this.dataAccessService = dataAccessService;
	}

	@RequestMapping(value="/controlcenter/execute",method=RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE)
	public String doExecute(@RequestBody Map<String, Object> data, HttpServletRequest request)
			throws Exception{
		System.out.println("doExecute():  " + data);
		
		String command = data.get("sql") != null? data.get("sql").toString() : "" ;
		dataAccessService.executeSQLUpdate(command);
		
		return "{\"message\": \"Command successfully executed\"}";
	}
	
	@RequestMapping(value="/controlcenter/query", method=RequestMethod.POST)
	public Object doQuery(@RequestBody Map<String, Object> data, HttpServletRequest request)
			throws Exception{		
		System.out.println("doQuery():  " + data);
		
		String query = data.get("sql") != null? data.get("sql").toString() : "" ;
		
		List<LinkedHashMap<String, Object>> resultSet = dataAccessService.executeSQLQuery(query);
		
		ResultModel resultModel = new ResultModel(resultSet, resultSet.size());
		
		return resultModel;
	}
}
