package com.bdo.itdis.bdocas.application.controllers.custom.transaction;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.cqrs.query.QueryException;
import com.bdo.itd.util.cqrs.query.ResultModel;
import com.bdo.itd.util.crqs.command.CommandMessage;
import com.bdo.itd.util.crqs.command.ICommandBus;
import com.bdo.itd.util.security.application.UserSession;
import com.bdo.itdis.bdocas.application.controllers.AbstractController;
import com.bdo.itdis.bdocas.transactions.application.command.AcceptTransactionCommand;
import com.bdo.itdis.bdocas.transactions.application.command.TagTransactionCommand;
import com.bdo.itdis.bdocas.transactions.application.query.values.ITransactionFormQueryService;


@RestController
public class TransactionFormController extends AbstractController{
	
	private final ICommandBus commandBus;
	private final ITransactionFormQueryService queryService;
	
	@Inject
	public TransactionFormController(@Named("transactionManagementCommandBus")ICommandBus commandBus,
			@Named("transactionFormQueryService")ITransactionFormQueryService queryService) {
		super();
		this.queryService = queryService;
		this.commandBus = commandBus;
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value="/transactions/record/save", consumes=MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.POST)
	public Object saveTakeUpRecord(@RequestBody Map<String, Object> form, HttpServletRequest request) throws Exception{		
		System.out.println("saveTakeUpRecord() called");
		AcceptTransactionCommand command = new AcceptTransactionCommand();
		
		command.setTransactionRecordID(Long.parseLong(form.get("transactionID").toString()));
		command.setTagging(form.get("takeUpTag").toString());
		command.setTakeUpRecord((Map)form.get("takeuprecord"));
		command.getParams().put("section", UserSession.getActiveAuthority().getGroup().getCode());
		command.setTakeUpBy(UserSession.getUsername());
		
		command.setUsername(UserSession.getUsername());
		command.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
		command.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());
		
		CommandMessage message = new CommandMessage();
		
		message = commandBus.doPublish(command);
		
		return message;
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value="/transactions/form/save", consumes=MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.POST)
	public Object saveForm(@RequestBody Map<String, Object> form, HttpServletRequest request) throws Exception{		
		System.out.println("saveForm() called");
		
		AcceptTransactionCommand command = new AcceptTransactionCommand();
		
		command.getParams().put("section", UserSession.getActiveAuthority().getGroup().getCode());
		command.setTakeUpBy(UserSession.getUsername());
		command.setTransactionRecordID(Long.parseLong(form.get("transactionID").toString()));
		command.setTagging(form.get("takeUpTag").toString());
		command.setTakeUpList((List)((Map)form.get("takeuprecord")).get("resultData"));
		
		command.setUsername(UserSession.getUsername());
		command.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
		command.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());
		
		CommandMessage message = new CommandMessage();
		
		System.out.println("Take Ups: " + (List)((Map)form.get("takeups")).get("resultData"));
		
		message = commandBus.doPublish(command);
		
		
		return message;
	}
	
	@RequestMapping(value="/transactions/tag", consumes=MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.POST)
	public Object saveTag(@RequestBody Map<String, Object> form, HttpServletRequest request) throws Exception{		
		System.out.println("saveTag() called");
		
		TagTransactionCommand command = new TagTransactionCommand();

		command.getParams().put("section", UserSession.getActiveAuthority().getGroup().getCode());
		command.setTakeUpBy(UserSession.getUsername());
		command.setTransactionRecordID(Long.parseLong(form.get("transactionID").toString()));
		command.setTagging(form.get("takeUpTag").toString());
		
		command.setUsername(UserSession.getUsername());
		command.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
		command.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());
		
		CommandMessage message = new CommandMessage();
		
		message = commandBus.doPublish(command);
		
		
		return message;
	}
	
	@RequestMapping(value="/transactions/form/details/{dataSetID}/{transactionID}/{filtering}", method=RequestMethod.GET)
	public Object doQueryTransactionDetails(@PathVariable("dataSetID")long dataSetID, @PathVariable("transactionID")long transactionID,
			@PathVariable("filtering")String filtering, HttpServletRequest request){
		System.out.println(this.getClass()+": doQueryTransactionDetails()");
		
		ResultModel resultModel = null;
		try{
			Map<String, Object> params = new HashMap<>();
			params.put("userName", UserSession.getUsername());
			params.put("dataset", dataSetID);
			params.put("tranID", transactionID);
			params.put("filtering", "");
			
			resultModel = queryService.findTransactionFormByTransactionID(params);
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return resultModel;
	}
	
	@RequestMapping(value="/transactions/form/takeups/{dataSetID}/{transactionID}", method=RequestMethod.GET)
	public Object doQueryTakeUpDetails(@PathVariable("dataSetID")long dataSetID, 
			@PathVariable("transactionID")long transactionID, HttpServletRequest request){
		System.out.println(this.getClass()+": doQueryTakeUpDetails()");
		
		ResultModel resultModel = null;
		try{
			Map<String, Object> params = new HashMap<>();
			params.put("dataset", dataSetID);
			params.put("tranID", transactionID);
			
			resultModel = queryService.findTakeUpsByTransactionID(params);
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return resultModel;
	}
	
	/**
	 * @param data
	 * @param request
	 * @return
	 * @throws QueryException
	 */
	@RequestMapping(value="/transactions/form/manualtakeup", method=RequestMethod.POST)
	public Object doQueryManualTakeUp(@RequestBody Map<String, Object> data, 
		HttpServletRequest request) throws QueryException{
		System.out.println(this.getClass()+": doQueryManualTakeUp()");
		
		ResultModel resultModel = null;
		
		Map<String, Object> params = new HashMap<>();
		params.put("transactionID", data.get("transactionID"));
		params.put("membershipCode", UserSession.getActiveAuthority().getCode());
		params.put("section", UserSession.getActiveAuthority().getGroup().getCode());
		params.put("username", UserSession.getUsername());
		
		resultModel = queryService.findLatestManualTakeUp(params);
		
		return resultModel;
	}
}
