/**
 * 
 */
package com.bdo.itdis.bdocas.application.controllers.custom.transactionStatus;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.cqrs.query.QueryException;
import com.bdo.itd.util.cqrs.query.ResultModel;
import com.bdo.itd.util.crqs.command.CommandException;
import com.bdo.itd.util.crqs.command.CommandMessage;
import com.bdo.itd.util.crqs.command.ICommandBus;
import com.bdo.itd.util.security.application.UserSession;
import com.bdo.itdis.bdocas.application.controllers.AbstractController;
import com.bdo.itdis.bdocas.report.infrastructure.ReportGeneratorService;
import com.bdo.itdis.bdocas.transactions.application.command.ReassignTransactionCommand;
import com.bdo.itdis.bdocas.transactions.application.query.list.ITransactionStatusQueryService;

/**
 * @author c150819004
 *
 */

@RestController
public class TransactionStatusController extends AbstractController{

	private final ICommandBus commandBus;
	private final ITransactionStatusQueryService queryService;
	private ReportGeneratorService reportGeneratorService;
	
	@Inject
	public TransactionStatusController(@Named("transactionManagementCommandBus")ICommandBus commandBus,
			@Named("transactionStatusQueryService")ITransactionStatusQueryService queryService,
			@Named("reportGeneratorService")ReportGeneratorService reportGeneratorService) {
		super();
		this.commandBus = commandBus;
		this.queryService = queryService;
		this.reportGeneratorService = reportGeneratorService;
	}

	@RequestMapping(value="/status/actionable", method=RequestMethod.POST)
	public Object doQueryTransactionStatus(@RequestBody Map<String, Object> data, 
			HttpServletRequest request) throws QueryException{
		System.out.println("doQueryTransactionStatus()");
		
		try{
			String dataSetCode = data.get("dataSetCode").toString();
			String encodingUnitCode = data.get("encodingUnitCode").toString();
			String selectedUser = data.get("selectedUser").toString();
			int pageIndex = Integer.parseInt(data.get("pageIndex").toString());
			int pageSize = Integer.parseInt(data.get("pageSize").toString());
			
			ResultModel resultModel = queryService.doQueryTransactionStatus(dataSetCode, 
					encodingUnitCode, UserSession.getActiveAuthority().getGroup().getCode(), 
					UserSession.getUsername(), UserSession.getActiveAuthority().getRole().getCode(), 
					selectedUser, pageIndex, pageSize);
				
				return resultModel;
			}catch(Exception ex){
				ex.printStackTrace();
			}
			return null;
	}
	
	@RequestMapping(value="transactions/status/reassignTransaction", consumes=MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.POST)
	public Object doReassignTransaction(@RequestBody Map<String, Object> data, HttpServletRequest request) throws CommandException{
		
		System.out.println("TransactionStatusController : doReassignTransaction()");
		CommandMessage message = new CommandMessage();
		String dataSetCode = data.get("dataSetCode").toString();
		String section = UserSession.getGroupCode();
		String userName = UserSession.getUsername();
		String source = data.get("source") != null ? data.get("source").toString() : ""; 
		String recipient = data.get("recipient") != null ? data.get("recipient").toString() : "";
		
		ReassignTransactionCommand command = new ReassignTransactionCommand(dataSetCode, section, source, recipient);			
		command.setUsername(userName);
		message = commandBus.doPublish(command);
		
		return message;
	}
	
	@RequestMapping(value="/transactions/status/{reportName}/{userName}",
			method=RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE)
	public Object doQueryPrintBatchSheet(@PathVariable String reportName, @PathVariable String userName,
			@RequestBody Map<String, Object> data ,HttpServletRequest request) throws Exception{
		
		System.out.println("Data: " + data);
		
		Map<String, Object> parameters = new LinkedHashMap<String, Object>();
		Map<String, Object> reportParameters = new LinkedHashMap<String, Object>();
		
		parameters = data;
		reportParameters.putAll(data);
		
		parameters.put("userName", userName);
		parameters.put("reportName", reportName);
		parameters.put("reportParameters", reportParameters);
		
		System.out.println("Parameters: " + parameters);
		
		return reportGeneratorService.generate(parameters).map();
	}
}
