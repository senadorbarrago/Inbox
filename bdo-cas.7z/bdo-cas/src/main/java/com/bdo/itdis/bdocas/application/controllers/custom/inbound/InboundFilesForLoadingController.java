package com.bdo.itdis.bdocas.application.controllers.custom.inbound;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.cqrs.query.QueryException;
import com.bdo.itd.util.cqrs.query.ResultModel;
import com.bdo.itd.util.crqs.command.CommandException;
import com.bdo.itd.util.crqs.command.ICommandBus;
import com.bdo.itd.util.security.application.UserSession;
import com.bdo.itdis.bdocas.application.controllers.AbstractController;
import com.bdo.itdis.bdocas.inbound.application.command.handlers.CopyFileToDestinationCommand;
import com.bdo.itdis.bdocas.inbound.application.command.handlers.LoadSourceFileCommand;
import com.bdo.itdis.bdocas.inbound.application.command.handlers.RemoveSelectedFilesCommand;
import com.bdo.itdis.bdocas.inbound.application.query.IInboundQueryService;

/**
 * @author c140618008
 *
 */
@RestController
@RequestMapping("/inboundinterface/forLoading")
public class InboundFilesForLoadingController extends AbstractController{
	
	/**
	 * 
	 */
	@Inject
	@Named("inboundInterfaceCommandBus")
	private ICommandBus commandBus;
	
	/**
	 * 
	 */
	@Inject
	@Named("inboundQueryService")
	private IInboundQueryService inboundQueryService;
	
	/**
	 * @param requestBody
	 * @param request
	 * @return
	 * @throws QueryException
	 */
	@RequestMapping(method=RequestMethod.POST)
	public Object doQuery(@RequestBody Map<String, Object> requestBody, 
			HttpServletRequest request) throws QueryException{
		System.out.println(requestBody);
		
		ResultModel resultModel = inboundQueryService.findFilesForLoading(requestBody);
		
		return resultModel;
	}
	
	/**
	 * @param requestBody
	 * @param request
	 * @return
	 * @throws CommandException
	 */
	@RequestMapping(value="/copy", method=RequestMethod.POST)
	public Object doCopy(@RequestBody Map<String, Object> requestBody, HttpServletRequest request)
		throws CommandException{		
		System.out.println(requestBody);
		
		String sourceFilePath = requestBody.get("selectedFile").toString();
		String dataset = requestBody.get("dataSetCode").toString();
		
		CopyFileToDestinationCommand command = new CopyFileToDestinationCommand("SRC", sourceFilePath, dataset);
	
		return commandBus.doPublish(command);
	}
	
	/**
	 * @param requestBody
	 * @param request
	 * @return
	 * @throws CommandException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value="/loadsourcefile", method=RequestMethod.POST)
	public Object doLoad(@RequestBody Map<String, Object> requestBody, HttpServletRequest request)
			throws CommandException{		
		System.out.println(requestBody);
		String dataSetCode = requestBody.get("dataSetCode").toString();
		List<String> sourceFileList = (ArrayList)requestBody.get("sourceFileList");
		String applicationName = "bcas";
		
		LoadSourceFileCommand command = new LoadSourceFileCommand();
		command.setApplicationName(applicationName);
		command.setDatasetCode(dataSetCode);
		command.setSourceFileList(sourceFileList);
		command.setUsername(UserSession.getUsername());
		command.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
		command.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());
		
		return commandBus.doPublish(command);
	}
	
	/**
	 * @param requestBody
	 * @param request
	 * @return
	 * @throws CommandException
	 */
	@RequestMapping(value="/remove", method=RequestMethod.POST)
	public Object doRemove(@RequestBody Map<String, Object> requestBody, HttpServletRequest request)
			throws CommandException{		
		System.out.println(requestBody);
		String sourceFilePath = requestBody.get("selectedFile").toString();
		
		RemoveSelectedFilesCommand command = new RemoveSelectedFilesCommand(sourceFilePath);
		
		return commandBus.doPublish(command);
	}
}
