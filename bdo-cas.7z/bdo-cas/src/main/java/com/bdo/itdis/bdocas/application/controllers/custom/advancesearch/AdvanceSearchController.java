package com.bdo.itdis.bdocas.application.controllers.custom.advancesearch;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.cqrs.query.QueryException;
import com.bdo.itd.util.cqrs.query.ResultModel;
import com.bdo.itd.util.crqs.command.CommandException;
import com.bdo.itd.util.crqs.command.CommandMessage;
import com.bdo.itd.util.crqs.command.ICommandBus;
import com.bdo.itd.util.security.application.UserSession;
import com.bdo.itdis.bdocas.advancesearch.application.query.IAdvanceSearchQueryService;
import com.bdo.itdis.bdocas.advancesearch.infrastructure.models.SearchCriteria;
import com.bdo.itdis.bdocas.advancesearch.infrastructure.models.SearchField;
import com.bdo.itdis.bdocas.application.controllers.AbstractController;
import com.bdo.itdis.bdocas.report.application.command.ReportGeneratorCommand;
import com.bdo.itdis.bdocas.report.application.query.IReportDownloaderQueryService;

/**
 * @author c140618008
 *
 */
@RestController
@RequestMapping("/advancesearch")
public class AdvanceSearchController extends AbstractController {

	/**
	 * 
	 */
	private final IAdvanceSearchQueryService advanceSearchQueryService;

	/**
	 * 
	 */
	private ICommandBus commandBus;

	/**
	 * 
	 */
	private IReportDownloaderQueryService queryService;

	/**
	 * @param advanceSearchQueryService
	 * @param commandBus
	 * @param queryService
	 */
	@Inject
	public AdvanceSearchController(
			@Named("advanceSearchQueryService") IAdvanceSearchQueryService advanceSearchQueryService,
			@Named("reportCommandBus") ICommandBus commandBus,
			@Named("reportDownloaderQueryService") IReportDownloaderQueryService queryService) {
		super();
		this.advanceSearchQueryService = advanceSearchQueryService;
		this.commandBus = commandBus;
		this.queryService = queryService;
	}

	/**
	 * @param dataSetID
	 * @param advanceSearchProfileCode
	 * @param searchFieldTypeCode
	 * @param request
	 * @return
	 * @throws QueryException
	 * @throws IllegalArgumentException
	 */
	@RequestMapping(value = "/fields/{dataSetID}/{advanceSearchProfileCode}/{searchFieldTypeCode}", method = RequestMethod.GET)
	public List<SearchField> doLoadAdvanceSearchFields(@PathVariable("dataSetID") long dataSetID,
			@PathVariable("advanceSearchProfileCode") String advanceSearchProfileCode,
			@PathVariable("searchFieldTypeCode") String searchFieldTypeCode, HttpServletRequest request)
			throws QueryException, IllegalArgumentException {
		List<SearchField> searchFieldList = new ArrayList<>();
		switch (searchFieldTypeCode) {
		case "DISPLAY_FIELD":
			searchFieldList = this.getDisplayFields(dataSetID, advanceSearchProfileCode, searchFieldTypeCode);
			break;
		case "FILTER_FIELD":
			searchFieldList = this.getFilterFields(dataSetID, advanceSearchProfileCode, searchFieldTypeCode);
			break;
		case "SORT_FIELD":
			searchFieldList = this.getSortFields(dataSetID, advanceSearchProfileCode, searchFieldTypeCode);
			break;
		default:
			throw new IllegalArgumentException(
					"The supplied searchFieldType " + searchFieldTypeCode + " is not supported");
		}

		return searchFieldList;
	}

	/**
	 * @param data
	 * @param request
	 * @return
	 * @throws QueryException
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/result", method = RequestMethod.POST)
	public Object doQuery(@RequestBody Map<String, Object> data, HttpServletRequest request) throws QueryException {
		System.out.println(this.getClass() + "-doQuery()");
		long dataSetID = Long.parseLong(data.get("dataSetID").toString());
		String advanceSearchCode = data.get("advanceSearchCode").toString();
		List<Object> displayFieldValues = (ArrayList<Object>) data.get("displayFieldValues");
		List<Map<String, Object>> filterFieldValues = (ArrayList<Map<String, Object>>) data.get("filterFieldValues");
		List<Map<String, Object>> sortFieldValues = (ArrayList<Map<String, Object>>) data.get("sortFieldValues");
		int pageIndex = Integer.parseInt(data.get("pageIndex").toString());
		int pageSize = Integer.parseInt(data.get("pageSize").toString());

		String username = UserSession.getUsername();
		long membershipID = UserSession.getActiveAuthority().getMembershipID();

		ResultModel resultModel = advanceSearchQueryService.doSearch(displayFieldValues, filterFieldValues,
				sortFieldValues, pageIndex, pageSize, dataSetID, advanceSearchCode, username, membershipID);

		return resultModel;
	}

	/**
	 * @param data
	 * @param request
	 * @return
	 * @throws QueryException
	 * @throws CommandException
	 */
	@RequestMapping(value = "/generate/{reportCode}", method = RequestMethod.POST)
	public Object doGenerateReport(@PathVariable String reportCode, @RequestBody Map<String, Object> data,
			HttpServletRequest request) throws QueryException, CommandException {
		System.out.println(this.getClass() + "-doQuery()");

		long dataSetID = Long.parseLong(data.get("dataSetID").toString());
		String advanceSearchCode = data.get("advanceSearchCode").toString();
		String username = UserSession.getUsername();
		long membershipID = UserSession.getActiveAuthority().getMembershipID();

		SearchCriteria searchCriteria = this.buildSearchCriteria(data);

		Map<String, Object> parameters = new LinkedHashMap<String, Object>();

		parameters.put("dataSetID", dataSetID);
		parameters.put("advanceSearchCode", advanceSearchCode);
		parameters.put("membershipID", membershipID);
		parameters.put("username", username);
		parameters.put("pageIndex", searchCriteria.getPageIndex());
		parameters.put("pageSize", searchCriteria.getPageSize());
		parameters.put("searchCriteria", searchCriteria.convertSearchCriteriaToXML());

		parameters.put("reportName", reportCode);

		ReportGeneratorCommand command = new ReportGeneratorCommand();

		command.setReportCode(reportCode);
		command.setParams(parameters);
		command.setUsername(UserSession.getUsername());
		command.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
		command.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());

		CommandMessage message = new CommandMessage();

		message = commandBus.doPublish(command);

		System.out.println("message: " + message.getMessageMap());

		return message;
	}

	/**
	 * @param reportCode
	 * @param file
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/download/{reportCode}", method = RequestMethod.GET)
	public FileSystemResource downloadReport(@PathVariable String reportCode, @RequestParam String file,
			HttpServletRequest request, HttpServletResponse response) {

		Map<String, Object> parameters = new LinkedHashMap<String, Object>();

		parameters.put("reportName", reportCode);
		parameters.put("filename", file);

		Map<String, Object> resultMap = new LinkedHashMap<String, Object>();
		try {
			resultMap = queryService.doQuery(parameters);
		} catch (Exception e) {
			e.printStackTrace();
		}

		FileSystemResource rsc = (FileSystemResource) resultMap.get("fileSystemResource");
		response.setHeader("Content-Disposition", "attachment; filename=" + resultMap.get("filename"));
		// response.setHeader("Content-Type", (String)
		// resultMap.get("mimeType"));
		response.setHeader("Content-Type", "application/octet-stream");
		response.setStatus(HttpStatus.OK.value());

		return rsc;

	}

	/**
	 * @param dataSetID
	 * @param advanceSearchProfileCode
	 * @param searchFieldTypeCode
	 * @return
	 * @throws QueryException
	 */
	private List<SearchField> getDisplayFields(long dataSetID, String advanceSearchProfileCode,
			String searchFieldTypeCode) throws QueryException {
		return advanceSearchQueryService.getDisplayFields(dataSetID, advanceSearchProfileCode, searchFieldTypeCode);
	}

	/**
	 * @param dataSetID
	 * @param advanceSearchProfileCode
	 * @param searchFieldTypeCode
	 * @return
	 * @throws QueryException
	 */
	private List<SearchField> getFilterFields(long dataSetID, String advanceSearchProfileCode,
			String searchFieldTypeCode) throws QueryException {
		return advanceSearchQueryService.getFilterFields(dataSetID, advanceSearchProfileCode, searchFieldTypeCode);
	}

	/**
	 * @param dataSetID
	 * @param advanceSearchProfileCode
	 * @param searchFieldTypeCode
	 * @return
	 * @throws QueryException
	 */
	private List<SearchField> getSortFields(long dataSetID, String advanceSearchProfileCode, String searchFieldTypeCode)
			throws QueryException {
		return advanceSearchQueryService.getSortFields(dataSetID, advanceSearchProfileCode, searchFieldTypeCode);
	}

	/**
	 * @param displayFields
	 * @param filterFields
	 * @param sortFields
	 * @param pageIndex
	 * @param pageSize
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private SearchCriteria buildSearchCriteria(Map<String, Object> data) {

		List<Object> displayFieldValues = (ArrayList<Object>) data.get("displayFieldValues");
		List<Map<String, Object>> filterFieldValues = (ArrayList<Map<String, Object>>) data.get("filterFieldValues");
		List<Map<String, Object>> sortFieldValues = (ArrayList<Map<String, Object>>) data.get("sortFieldValues");

		int pageIndex = Integer.parseInt(data.get("pageIndex").toString());
		int pageSize = 1; // Default

		return new SearchCriteria(displayFieldValues, filterFieldValues, sortFieldValues, pageIndex, pageSize);
	}
}
