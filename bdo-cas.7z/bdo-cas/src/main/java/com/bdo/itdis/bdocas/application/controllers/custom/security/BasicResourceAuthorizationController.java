package com.bdo.itdis.bdocas.application.controllers.custom.security;

import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.security.application.UserSession;
import com.bdo.itd.util.security.domain.services.IAuthorizationService;
import com.bdo.itd.util.security.domain.services.UserAuthorizationException;

@RestController
public class BasicResourceAuthorizationController {
	
	private final IAuthorizationService basicResourceAuthorizationQueryService;
	
	@Inject
	public BasicResourceAuthorizationController(@Named("basicResourceAuthorizationQueryService")
	IAuthorizationService basicResourceAuthorizationQueryService) {
		super();
		this.basicResourceAuthorizationQueryService = basicResourceAuthorizationQueryService;
	}

	@RequestMapping(value="/security/resource/{resourceCodePattern}", method=RequestMethod.GET)
	public Object doQuery(@PathVariable("resourceCodePattern")String resourceCodePattern, HttpServletRequest request)
		throws UserAuthorizationException{
		
		long membershipID =  UserSession.getActiveAuthority().getMembershipID();
		Map<String, Object> params = new HashMap<>();
		params.put("membershipID", membershipID);
		params.put("resourceCodePattern", resourceCodePattern);

		return basicResourceAuthorizationQueryService.getAuthorizedResources(params);
	}
	
}
