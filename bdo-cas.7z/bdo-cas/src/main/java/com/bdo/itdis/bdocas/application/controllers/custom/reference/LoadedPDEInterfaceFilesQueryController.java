/**
 * 
 */
package com.bdo.itdis.bdocas.application.controllers.custom.reference;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itdis.bdocas.application.controllers.custom.reference.utils.IReferenceService;

/**
 * @author c150819004
 *
 */
@RestController
public class LoadedPDEInterfaceFilesQueryController {

	private final IReferenceService referenceService;

	@Inject
	public LoadedPDEInterfaceFilesQueryController(
			@Named("referenceService")IReferenceService referenceService) {
		super();
		this.referenceService = referenceService;
	}
	
	@RequestMapping(value="references/interfaceFiles/{dataSetCode}",
			method=RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Object doQuery(@PathVariable String dataSetCode, @RequestBody Map<String, Object> requestBody, 
			HttpServletRequest request){
		
		List<Object> paramList = new ArrayList<Object>();
		paramList.add(dataSetCode);
		paramList.add(requestBody.get("dateFrom").toString());
		paramList.add(requestBody.get("dateTo").toString());
		paramList.add(requestBody.get("recordTypeTag").toString());
		
		return referenceService.getReferenceWithCode("dbo.spGetLoadedPDEInterfaceFiles ?, ?, ?, ?", paramList);
	}
	
}
