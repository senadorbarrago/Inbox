package com.bdo.itdis.bdocas.application.controllers.custom.journalentry;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.cqrs.query.QueryException;
import com.bdo.itd.util.cqrs.query.ResultModel;
import com.bdo.itdis.bdocas.application.controllers.AbstractController;
import com.bdo.itdis.bdocas.journalentry.application.query.lists.IJournalEntriesByBatchSheetQueryService;


@RestController
public class JournalEntryByBatchSheetController extends AbstractController {
	
	private final IJournalEntriesByBatchSheetQueryService journalEntriesByBatchSheetQueryService;
	
	@Inject
	public JournalEntryByBatchSheetController(@Named("journalEntriesByBatchSheetQueryService")IJournalEntriesByBatchSheetQueryService journalEntriesByBatchSheetQueryService) {
		super();
		this.journalEntriesByBatchSheetQueryService = journalEntriesByBatchSheetQueryService;
	}
	
	@RequestMapping(value="/journalentries/batchsheet/{batchSheetID}", method=RequestMethod.GET)
	public Object doQueryJournalEntriesByBatchSheetID(@PathVariable("batchSheetID")long batchSheetID,
			HttpServletRequest request) throws QueryException, Exception{
		System.out.println("doQueryJournalEntriesByBatchSheetID()");
		ResultModel resultModel = null;
		
		resultModel = journalEntriesByBatchSheetQueryService.doQuery(batchSheetID);
		
		return resultModel;
	}	
}
