package com.bdo.itdis.bdocas.application.controllers.custom.transaction;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.cqrs.query.QueryException;
import com.bdo.itd.util.cqrs.query.ResultModel;
import com.bdo.itd.util.crqs.command.CommandException;
import com.bdo.itd.util.crqs.command.CommandMessage;
import com.bdo.itd.util.crqs.command.ICommandBus;
import com.bdo.itd.util.map.ParameterMap;
import com.bdo.itd.util.security.application.UserSession;
import com.bdo.itdis.bdocas.application.controllers.AbstractController;
import com.bdo.itdis.bdocas.report.application.command.ReportGeneratorCommand;
import com.bdo.itdis.bdocas.transactions.application.command.ForReferralTransactionCommand;
import com.bdo.itdis.bdocas.transactions.application.command.GrabReferralTransactionCommand;
import com.bdo.itdis.bdocas.transactions.application.command.ReferTransactionCommand;
import com.bdo.itdis.bdocas.transactions.application.command.UpdateReferralDetailsCommand;
import com.bdo.itdis.bdocas.transactions.application.query.list.IReferralQueryService;
import com.bdo.itdis.bdocas.transactions.application.query.list.IViewReferralDetailsQueryService;
import com.bdo.itdis.bdocas.transactions.application.query.list.searchcriteria.SearchCriteria;


/**
 * @author c140618008
 *
 */
@RestController
@RequestMapping("/transactions")
public class ReferralController extends AbstractController{
	
	/**
	 * 
	 */
	private static final Logger logger = Logger.getLogger(ReferralController.class);
	
	/**
	 * 
	 */
	private ICommandBus commandBus;
	
	/**
	 * 
	 */
	private ICommandBus reportCommandBus;
	
	/**
	 * 
	 */
	private final IReferralQueryService queryService;
	
	/**
	 * 
	 */
	private final IViewReferralDetailsQueryService viewReferralQueryService;
	
	/**
	 * @param commandBus
	 * @param queryService
	 * @param viewReferralQueryService
	 */
	@Inject
	public ReferralController(@Named("transactionManagementCommandBus") ICommandBus commandBus,
		@Named("reportCommandBus") ICommandBus reportCommandBus, @Named("referralQueryService")IReferralQueryService queryService, 
			@Named("viewReferralDetailsQueryService")IViewReferralDetailsQueryService viewReferralQueryService) {
		super();
		this.commandBus = commandBus;
		this.reportCommandBus = reportCommandBus;
		this.queryService = queryService;
		this.viewReferralQueryService = viewReferralQueryService;
	}
	
	/**
	 * @param dataSetCode
	 * @param pageIndex
	 * @param pageSize
	 * @param searchCriteria
	 * @param request
	 * @return
	 * @throws QueryException
	 */
	@RequestMapping(value="/forReferral/{dataSetCode}/{pageIndex}/{pageSize}/", method=RequestMethod.POST, consumes="application/json")
	public Object doQueryList(@PathVariable("dataSetCode")String dataSetCode, @PathVariable("pageIndex")int pageIndex, 
			@PathVariable("pageSize")int pageSize, @RequestBody Map<String, Object> searchCriteria, 
				HttpServletRequest request) throws QueryException{
		logger.info(this.getClass()+" - doQueryList()");
		ResultModel resultModel = null;
		
		Map<String, Object> params = new HashMap<>();
		params.put("userName", UserSession.getUsername());
		params.put("membershipCode", UserSession.getActiveAuthority().getCode());
		params.put("dataSetCode", dataSetCode);
		params.put("searchCriteria", convertToXML(searchCriteria, pageIndex, pageSize));
		params.put("pageIndex", pageIndex);
		params.put("pageSize", pageSize);
		
		resultModel = queryService.doQuery(params);
		
		return resultModel;
	}
	
	/**
	 * @param reportCode
	 * @param dataSetCode
	 * @param pageIndex
	 * @param pageSize
	 * @param data
	 * @param request
	 * @return
	 * @throws QueryException
	 * @throws CommandException
	 */
	@RequestMapping(value="/forReferral/generate/{reportCode}/{dataSetCode}/{pageIndex}/{pageSize}/", method=RequestMethod.POST)
	public Object doGenerateReport(@PathVariable String reportCode, @PathVariable("dataSetCode")String dataSetCode,
			@PathVariable("pageIndex")int pageIndex, @PathVariable("pageSize")int pageSize, 
				@RequestBody Map<String, Object> data, HttpServletRequest request) throws QueryException, CommandException{
		logger.info(this.getClass()+" - doGenerateReport()");
		
		Map<String, Object> parameters = new LinkedHashMap<String, Object>();
	
		parameters.put("username", UserSession.getUsername());
		parameters.put("membershipCode", UserSession.getActiveAuthority().getCode());
		parameters.put("dataSetCode", dataSetCode);
		parameters.put("searchCriteria", convertToXML(data, pageIndex, pageSize));
		parameters.put("pageIndex", pageIndex);
		parameters.put("pageSize", pageSize);

		parameters.put("reportName", reportCode);
		
		ReportGeneratorCommand command = new ReportGeneratorCommand();
		
		command.setReportCode(reportCode);
		command.setParams(parameters);
		command.setUsername(UserSession.getUsername());
		command.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
		command.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());
		
		CommandMessage message = new CommandMessage();
		
		message = reportCommandBus.doPublish(command);
		
		System.out.println("message: " + message.getMessageMap());
		
		return message;
	}
	
	/**
	 * @param dataSetCode
	 * @param transID
	 * @param request
	 * @return
	 */
	@RequestMapping(value="/referralDetails/{dataSetCode}/{transID}", method=RequestMethod.GET)
	public Object viewRemarks(@PathVariable String dataSetCode,@PathVariable long transID,
			HttpServletRequest request){
		logger.info(this.getClass()+" - viewRemarks()");
		
		ParameterMap params = ParameterMap.createInstance();
		
		params.add("dataSetCode", dataSetCode);
		params.add("transID", transID);
		
		ResultModel resultModel = null;
		
		try {
			resultModel = viewReferralQueryService.doQuery(params.map());
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return resultModel;
	}
	
	/**
	 * @param command
	 * @param request
	 * @return
	 * @throws CommandException
	 * @throws Exception
	 */
	@RequestMapping(value="/forReferral/tagforreferral", consumes=MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.POST)
	public Object doTagForReferral(@RequestBody ForReferralTransactionCommand command, HttpServletRequest request)throws CommandException, Exception{		
		logger.info(this.getClass()+" - doTagForReferral()");
		
		Map<String, Object> params = new HashMap<String, Object>();
		String action = "TAG";
		params.put("action", action);
		
		command.setUsername(UserSession.getUsername());
		command.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
		command.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());
		command.setParams(params);
		
		CommandMessage message = new CommandMessage();		
		
		message = commandBus.doPublish(command);
		
		return message;
	}
	
	/**
	 * @param command
	 * @param request
	 * @return
	 * @throws CommandException
	 * @throws Exception
	 */
	@RequestMapping(value="/forReferral/update", consumes=MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.POST)
	public Object doUpdateReferralDetails(@RequestBody UpdateReferralDetailsCommand command,
			HttpServletRequest request)throws CommandException, Exception{		
		logger.info(this.getClass()+" - doUpdateReferralDetails()");	
		CommandMessage message = new CommandMessage();		
		command.setUsername(UserSession.getUsername());
		
		message = commandBus.doPublish(command);
		
		return message;
	}
	
	/**
	 * @param command
	 * @param request
	 * @return
	 * @throws CommandException
	 * @throws Exception
	 */
	@RequestMapping(value="/forReferral/refer", consumes=MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.POST)
	public Object doReferTransaction(@RequestBody ReferTransactionCommand command, HttpServletRequest request)throws CommandException, Exception{		
		logger.info(this.getClass()+" - doReferTransaction()");
		
		CommandMessage message = new CommandMessage();		
		command.setUsername(UserSession.getUsername());
		command.setReferredBy(UserSession.getUsername());
		command.setDateReferred(new Date());
		
		message = commandBus.doPublish(command);
		
		return message;
	}
	
	/**
	 * @param command
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/forReferral/grabtransaction", consumes=MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.POST)
	public Object doGrabtransaction(@RequestBody GrabReferralTransactionCommand command, HttpServletRequest request)throws Exception{		
		logger.info(this.getClass()+" - doGrabtransaction()");

		command.setUsername(UserSession.getUsername());
		command.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
		command.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());
		
		CommandMessage message = new CommandMessage();
		
		message = commandBus.doPublish(command);
		
		return message;
	}
	
	/**
	 * @param searchCriteriaData
	 * @param pageIndex
	 * @param pageSize
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private String convertToXML(Map<String, Object> searchCriteriaData, int pageIndex, int pageSize){
		List<Map<String, Object>> filterFields = new ArrayList<>();
		if(searchCriteriaData.get("filterList") != null){
			filterFields = (ArrayList<Map<String, Object>>)searchCriteriaData.get("filterList");
		}
		
		List<Map<String, Object>> sortFields = new ArrayList<>();
		if(searchCriteriaData.get("sortList") != null){
			sortFields = (ArrayList<Map<String, Object>>)searchCriteriaData.get("sortList");
		}
		
		SearchCriteria searchCriteria = new SearchCriteria(filterFields, sortFields, pageIndex, pageSize);		
		
		return searchCriteria.convertSearchCriteriaToXML();
	}
	
	
}
