package com.bdo.itdis.bdocas.application.controllers.custom.reference.utils;

import java.util.List;

/**
 *
 * @author senadorbarrago
 */
public interface IReferenceService {
    
    /**
     * @param query
     * @return
     */
    public List<DTOReferenceHolder> getReference(String query);
    
    /**
     * @param query
     * @param param
     * @return
     */
    public List<DTOReferenceHolder> getReference(String query, List<Object> param);
    
    /**
     * @param query
     * @param param
     * @return
     */
    public List<DTOReferenceHolder> getReferenceWithCode(String query, List<Object> param);
    
    /**
     * @param query
     * @param param
     * @return
     */
    public List<DTOReferenceHolder> getReferenceMultipleCol(String query, List<Object> param);
    
    /**
     * @param query
     * @param param
     * @return
     */
    public List<DTOReferenceHolder> getReferenceWithAdditionalDetails(String query, List<Object> param);
    
}
