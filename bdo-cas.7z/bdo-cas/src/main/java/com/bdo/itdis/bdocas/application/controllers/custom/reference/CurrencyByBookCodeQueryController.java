package com.bdo.itdis.bdocas.application.controllers.custom.reference;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itdis.bdocas.application.controllers.custom.reference.utils.IReferenceService;

@RestController
public class CurrencyByBookCodeQueryController {
	
	private final IReferenceService referenceService;
	
	@Inject
	public CurrencyByBookCodeQueryController(@Named("referenceService")IReferenceService referenceService) {
		super();
		this.referenceService = referenceService;
	}
	
	@RequestMapping(value="/references/currencyByBookCode/{bookCode}", method=RequestMethod.GET)
	public Object doQuery(@PathVariable("bookCode")String bookCode, HttpServletRequest request){
		
		System.out.println("bookCode: "+bookCode);
		
		List<Object> paramList = new ArrayList<>();
		paramList.add(bookCode);
		
		return referenceService.getReferenceWithCode("dbo.spGetCurrencyByBookCode ?", paramList);
	}
	
	@RequestMapping(value="/references/currencyByBookCodeID/{bookCodeID}", method=RequestMethod.GET)
	public Object doQuery(@PathVariable("bookCodeID")long bookCodeID, HttpServletRequest request){
		
		System.out.println("bookCode: "+bookCodeID);
		
		List<Object> paramList = new ArrayList<>();
		paramList.add(bookCodeID);
		
		return referenceService.getReferenceWithCode("dbo.spGetCurrencyByBookCodeID ?", paramList);
	}
}
