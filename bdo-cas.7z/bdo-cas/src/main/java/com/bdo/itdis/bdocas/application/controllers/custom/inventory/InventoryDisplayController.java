/**
 * 
 */
package com.bdo.itdis.bdocas.application.controllers.custom.inventory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.cqrs.query.QueryException;
import com.bdo.itd.util.cqrs.query.ResultModel;
import com.bdo.itd.util.crqs.command.CommandException;
import com.bdo.itd.util.crqs.command.CommandMessage;
import com.bdo.itd.util.crqs.command.ICommandBus;
import com.bdo.itd.util.security.application.UserSession;
import com.bdo.itdis.bdocas.application.controllers.AbstractController;
import com.bdo.itdis.bdocas.inventory.application.query.IBatchSheetInventoryQueryService;
import com.bdo.itdis.bdocas.inventory.application.query.IJournalEntryInventoryQueryService;
import com.bdo.itdis.bdocas.inventory.application.query.ITakeUpInventoryQueryService;
import com.bdo.itdis.bdocas.inventory.application.query.ITransactionInventoryQueryService;
import com.bdo.itdis.bdocas.report.application.command.ReportGeneratorCommand;
import com.bdo.itdis.bdocas.transactions.application.query.list.searchcriteria.SearchCriteria;

/**
 * @author c150819004
 *
 */
@RestController
@RequestMapping("/inventory")
public class InventoryDisplayController extends AbstractController{
	
	/**
	 * 
	 */
	private static final Logger logger = Logger.getLogger(InventoryDisplayController.class);
	
	private final ITransactionInventoryQueryService transactionQueryService;
	private final ITakeUpInventoryQueryService takeUpQueryService;
	private final IJournalEntryInventoryQueryService journalEntryQueryService;
	private final IBatchSheetInventoryQueryService batchSheetQueryService;
	
	private final ICommandBus reportCommandBus;

	@Inject
	public InventoryDisplayController(
			@Named("ncTransactionInventoryQueryService")ITransactionInventoryQueryService transactionQueryService,
			@Named("takeUpInventoryQueryService")ITakeUpInventoryQueryService takeUpQueryService,
			@Named("journalEntryInventoryQueryService")IJournalEntryInventoryQueryService journalEntryQueryService,
			@Named("batchSheetInventoryQueryService")IBatchSheetInventoryQueryService batchSheetQueryService,
			@Named("reportCommandBus")ICommandBus reportCommandBus
			) {
		super();
		this.transactionQueryService = transactionQueryService;
		this.takeUpQueryService = takeUpQueryService;
		this.journalEntryQueryService = journalEntryQueryService;
		this.batchSheetQueryService = batchSheetQueryService;
		this.reportCommandBus = reportCommandBus;
	}
	
	/**
	 * 
	 * @param dataSetCode
	 * @param pageIndex
	 * @param pageSize
	 * @param searchCriteria
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/transactions/{dataSetCode}/{pageIndex}/{pageSize}/", 
			method=RequestMethod.POST, consumes="application/json")
	public Object doQueryTransactions(@PathVariable("dataSetCode")String dataSetCode, @PathVariable("pageIndex")int pageIndex, 
			@PathVariable("pageSize")int pageSize, @RequestBody Map<String, Object> searchCriteria, HttpServletRequest request)
				throws Exception{
		logger.info(this.getClass()+" - doQueryList()");
		
		ResultModel resultModel = null;
		
		Map<String, Object> params = new HashMap<>();
		params.put("userName", UserSession.getUsername());
		params.put("membershipCode", UserSession.getActiveAuthority().getCode());
		params.put("dataSetCode", dataSetCode);
		params.put("searchCriteria", convertToXML(searchCriteria, pageIndex, pageSize));
		params.put("pageIndex", pageIndex);
		params.put("pageSize", pageSize);
		
		resultModel = transactionQueryService.doQuery(params);
		
		return resultModel;
	}
	
	/**
	 * 
	 * @param dataSetCode
	 * @param pageIndex
	 * @param pageSize
	 * @param searchCriteria
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/takeUps/{dataSetCode}/{pageIndex}/{pageSize}/", 
			method=RequestMethod.POST, consumes="application/json")
	public Object doQueryTakeUps(@PathVariable("dataSetCode")String dataSetCode, @PathVariable("pageIndex")int pageIndex, 
			@PathVariable("pageSize")int pageSize, @RequestBody Map<String, Object> searchCriteria, HttpServletRequest request)
				throws Exception{
		logger.info(this.getClass()+" - doQueryList()");
		
		ResultModel resultModel = null;
		
		Map<String, Object> params = new HashMap<>();
		params.put("userName", UserSession.getUsername());
		params.put("membershipCode", UserSession.getActiveAuthority().getCode());
		params.put("dataSetCode", dataSetCode);
		params.put("searchCriteria", convertToXML(searchCriteria, pageIndex, pageSize));
		params.put("pageIndex", pageIndex);
		params.put("pageSize", pageSize);
		
		resultModel = takeUpQueryService.doQuery(params);
		
		return resultModel;
	}
	
	/**
	 * 
	 * @param dataset
	 * @param recordProfileID
	 * @param pageIndex
	 * @param pageSize
	 * @param searchCriteria
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/journalEntries/{dataset}/{recordProfileID}/{pageIndex}/{pageSize}/", 
			method=RequestMethod.POST, consumes="application/json")
	public Object doQueryJournalEntries(@PathVariable("dataset")Long dataset, 
			@PathVariable("recordProfileID")Long recordProfileID, 
			@PathVariable("pageIndex")int pageIndex, @PathVariable("pageSize")int pageSize, 
			@RequestBody Map<String, Object> searchCriteria, HttpServletRequest request)
				throws Exception{
		logger.info(this.getClass()+" - doQueryList()");
		
		ResultModel resultModel = null;
		
		Map<String, Object> params = new HashMap<>();
		params.put("searchCriteria", convertToXML(searchCriteria, pageIndex, pageSize));
		params.put("dataset", dataset);
		params.put("recordProfileID", recordProfileID);
		params.put("userName", UserSession.getUsername());
		params.put("membershipID", UserSession.getActiveAuthority().getMembershipID());
		params.put("pageIndex", pageIndex);
		params.put("pageSize", pageSize);
		
		System.out.println("Params:" + params);
		
		resultModel = journalEntryQueryService.doQuery(params);
		
		return resultModel;
	}
	
	/**
	 * 
	 * @param dataSetCode
	 * @param pageIndex
	 * @param pageSize
	 * @param searchCriteria
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/batchSheet/{dataSetCode}/{pageIndex}/{pageSize}/", 
			method=RequestMethod.POST, consumes="application/json")
	public Object doQueryBatchSheet(@PathVariable("dataSetCode")String dataSetCode, 
			@PathVariable("pageIndex")int pageIndex, 
			@PathVariable("pageSize")int pageSize, @RequestBody Map<String, Object> searchCriteria, HttpServletRequest request)
				throws Exception{
		logger.info(this.getClass()+" - doQueryList()");
		
		ResultModel resultModel = null;
		
		Map<String, Object> params = new HashMap<>();
		params.put("dataSetCode", dataSetCode);
		params.put("userName", UserSession.getUsername());
		params.put("roleCode", UserSession.getActiveAuthority().getRole().getCode());
		params.put("groupCode", UserSession.getActiveAuthority().getGroup().getCode());
		params.put("encodingUnitCode", searchCriteria.get("encodingUnitCode"));
		params.put("selectedUserName", searchCriteria.get("selectedUser"));
		params.put("processDateFrom", searchCriteria.get("processingDateFrom"));
		params.put("processDateTo", searchCriteria.get("processingDateTo"));
		params.put("pageIndex", pageIndex);
		params.put("pageSize", pageSize);
		
		resultModel = batchSheetQueryService.doQuery(params);
		
		return resultModel;
	}
	
	/**
	 * 
	 * @param reportCode
	 * @param dataSetCode
	 * @param pageIndex
	 * @param pageSize
	 * @param data
	 * @param request
	 * @return
	 * @throws QueryException
	 * @throws CommandException
	 */
	@RequestMapping(value="/transactions/generate/{reportCode}/{dataSetCode}/{pageIndex}/{pageSize}/", method=RequestMethod.POST)
	public Object doGenerateNCReport(@PathVariable String reportCode, @PathVariable("dataSetCode")String dataSetCode,
			@PathVariable("pageIndex")int pageIndex, @PathVariable("pageSize")int pageSize, 
				@RequestBody Map<String, Object> data, HttpServletRequest request) throws QueryException, CommandException{
		logger.info(this.getClass()+" - doGenerateReport()");
		
		Map<String, Object> parameters = new LinkedHashMap<String, Object>();
	
		parameters.put("username", UserSession.getUsername());
		parameters.put("membershipCode", UserSession.getActiveAuthority().getCode());
		parameters.put("dataSetCode", dataSetCode);
		parameters.put("searchCriteria", convertToXML(data, pageIndex, pageSize));
		parameters.put("pageIndex", pageIndex);
		parameters.put("pageSize", pageSize);

		parameters.put("reportName", reportCode);
		
		ReportGeneratorCommand command = new ReportGeneratorCommand();
		
		command.setReportCode(reportCode);
		command.setParams(parameters);
		command.setUsername(UserSession.getUsername());
		command.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
		command.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());
		
		CommandMessage message = new CommandMessage();
		
		message = reportCommandBus.doPublish(command);
		
		System.out.println("message: " + message.getMessageMap());
		
		return message;
	}
	
	/**
	 * 
	 * @param reportCode
	 * @param recordProfileID
	 * @param dataSetCode
	 * @param pageIndex
	 * @param pageSize
	 * @param data
	 * @param request
	 * @return
	 * @throws QueryException
	 * @throws CommandException
	 */
	@RequestMapping(value="/journalEntries/generate/{reportCode}/{recordProfileID}/{dataset}/{pageIndex}/{pageSize}/", method=RequestMethod.POST)
	public Object doGenerateJEReport(@PathVariable String reportCode, @PathVariable Long recordProfileID, @PathVariable("dataset")Long dataset,
			@PathVariable("pageIndex")int pageIndex, @PathVariable("pageSize")int pageSize, 
				@RequestBody Map<String, Object> data, HttpServletRequest request) throws QueryException, CommandException{
		logger.info(this.getClass()+" - doGenerateReport()");
		
		Map<String, Object> parameters = new LinkedHashMap<String, Object>();
	
		parameters.put("username", UserSession.getUsername());
		parameters.put("membershipID", UserSession.getActiveAuthority().getMembershipID());
		parameters.put("recordProfileID", recordProfileID);
		parameters.put("dataset", dataset);
		parameters.put("searchCriteria", convertToXML(data, pageIndex, pageSize));
		parameters.put("pageIndex", pageIndex);
		parameters.put("pageSize", pageSize);

		parameters.put("reportName", reportCode);
		
		ReportGeneratorCommand command = new ReportGeneratorCommand();
		
		command.setReportCode(reportCode);
		command.setParams(parameters);
		command.setUsername(UserSession.getUsername());
		command.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
		command.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());
		
		CommandMessage message = new CommandMessage();
		
		message = reportCommandBus.doPublish(command);
		
		System.out.println("message: " + message.getMessageMap());
		
		return message;
	}
	
	/**
	 * @param searchCriteriaData
	 * @param pageIndex
	 * @param pageSize
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private String convertToXML(Map<String, Object> searchCriteriaData, int pageIndex, int pageSize){
		List<Map<String, Object>> filterFields = new ArrayList<>();
		if(searchCriteriaData.get("filterList") != null){
			filterFields = (ArrayList<Map<String, Object>>)searchCriteriaData.get("filterList");
		}
		
		List<Map<String, Object>> sortFields = new ArrayList<>();
		if(searchCriteriaData.get("sortList") != null){
			sortFields = (ArrayList<Map<String, Object>>)searchCriteriaData.get("sortList");
		}
		
		SearchCriteria searchCriteria = new SearchCriteria(filterFields, sortFields, pageIndex, pageSize);		
		
		return searchCriteria.convertSearchCriteriaToXML();
	}
}
