package com.bdo.itdis.bdocas;

import java.io.IOException;
import java.util.Date;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.embedded.ServletContextInitializer;
import org.springframework.boot.context.web.SpringBootServletInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ImportResource;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;

import com.bdo.itd.util.logger.LoggerUtility;
import com.bdo.itd.util.logger.LoggerUtilityFactory;
import com.bdo.itd.util.properties.PropertiesLoader;

@SpringBootApplication
@ImportResource({
	"classpath:config/applicationContext.xml", 
	"classpath:config/context/sharedContext.xml",
	"classpath:config/context/advanceSearchContext.xml",
	"classpath:config/context/auditLoggingContext.xml",
	"classpath:config/context/batchSheetContext.xml", 
	"classpath:config/context/dataCleanUpContext.xml",
	"classpath:config/context/inboundInterfaceContext.xml", 
	"classpath:config/context/inventoryContext.xml",
	"classpath:config/context/journalEntryContext.xml",
	"classpath:config/context/outboundInterfaceContext.xml", 
	"classpath:config/context/remarksContext.xml",
	"classpath:config/context/reportContext.xml", 
	"classpath:config/context/securityContext.xml",
	"classpath:config/context/transactionContext.xml",
	"classpath:config/context/controlTotalsContext.xml",
	"classpath:config/context/queryContext.xml"
})
public class BCASApplicationWar extends SpringBootServletInitializer{
	private static Date timeStarted = new Date(System.currentTimeMillis());
	
	private static LoggerUtility logger = 
			LoggerUtilityFactory.createLoggerUtility(BCASApplicationWar.class);
	
	public static void main(String[] args){
		@SuppressWarnings("unused")
		ConfigurableApplicationContext applicationContext = new SpringApplicationBuilder(BCASApplicationWar.class)		
				.sources(BCASApplicationWar.class)
				.properties(getProperties(getResourceInitializer()))
				.run(args);	
	}
	
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
		return builder
				.sources(BCASApplicationWar.class)
				.properties(getProperties(getResourceInitializer()));
	}
	
	@Bean
	public ServletContextInitializer servletContextInitializer() {
	    return new ServletContextInitializer() {

	        @Override
	        public void onStartup(ServletContext servletContext) throws ServletException {
	        	logger.info("onStartup()");
	            servletContext.getSessionCookieConfig().setSecure(true);
	            servletContext.getSessionCookieConfig().setHttpOnly(true);
	        }
	    };
	}
	
	private static Resource getResourceInitializer() {
		DefaultResourceLoader loader = new DefaultResourceLoader();
		Resource resource = loader.getResource("classpath:config/application.properties");
		try {
			logger.info(String.format(
					"Reading resource from [%s]", resource.getFile().getAbsolutePath()));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return resource;
	}
	
	private static Properties getProperties(Resource resource) {
		Properties properties = new Properties();
		try {
			properties = PropertiesLoader.loadProperties(resource.getInputStream());
			logger.info(String.format(
					"Setting property [spring.config.location] to [%s]", properties.get("spring.config.location")));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return properties;
	}
	
	public static Date getTimeStarted() {
		return new Date(timeStarted.getTime());
	};
}
