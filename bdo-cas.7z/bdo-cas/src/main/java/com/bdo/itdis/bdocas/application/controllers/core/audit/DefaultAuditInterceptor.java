package com.bdo.itdis.bdocas.application.controllers.core.audit;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.bdo.itd.util.audit.AuditDataHandler;
import com.bdo.itd.util.audit.HTTPServletUtils;
import com.bdo.itd.util.audit.data.AuditData;
import com.bdo.itd.util.audit.data.AuditParam;
import com.bdo.itd.util.audit.model.ApplicationConfig;
import com.bdo.itd.util.audit.model.Task;
import com.bdo.itd.util.persistence.DataAccessInterface;

public abstract class DefaultAuditInterceptor implements HandlerInterceptor, InitializingBean {

	/**
	 * 
	 */
	private static final Logger logger = Logger.getLogger(DefaultAuditInterceptor.class);

	/**
	 * 
	 */
	private static final HTTPServletUtils ipUtil = new HTTPServletUtils();

	/**
	 * 
	 */
	protected ApplicationConfig applicationConfig;

	/**
	 * 
	 */
	private static final String EXEC_LOG_AUDIT_DATA = "EXEC logAuditData ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?";

	/**
	 * 
	 */
	@Autowired
	protected DataAccessInterface dataAccess;

	@Override
	public void afterPropertiesSet() throws Exception {
		Assert.notNull(applicationConfig, "Property [applicationConfig] required.");
	}

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object object) throws Exception {
		String completeUri = getCompleteUri(request);
		logger.info("Intercepting requested uri [" + completeUri + "]");

		Task task = applicationConfig.getTask(completeUri, request.getMethod());
		if (null != task) {
			AuditDataHandler.put(AuditParam.TASK, task);
		}

		return true;
	}

	@Override
	public void afterCompletion(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, Exception arg3)
			throws Exception {
		/**
		 * release thread local
		 */
		AuditDataHandler.destroy();
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object object,
			ModelAndView modelAndView) throws Exception {
		Task task = (Task) AuditDataHandler.get(AuditParam.TASK);
		if (null != task) {
			String completeUri = getCompleteUri(request);

			logger.info("Processing requested uri [" + completeUri + "]");

			AuditData data = initializeAuditData(request);
			data.setMaintenanceType(task.getName());
			data.setStatus(getRequestStatus());
			this.saveAuditData(data);
		} else {
			logger.info("Requested uri [" + request.getRequestURI() + "] not supported for audit.");
		}

	}

	private AuditData initializeAuditData(HttpServletRequest request) {
		AuditData data = new AuditData();

		logger.info("Initializing audit data with datasource set to [" + applicationConfig.isWithDataSource() + "]");
		logger.info("Setting datasource to [" + (String) AuditDataHandler.get(AuditParam.DATA_SOURCE) + "]");

		if (applicationConfig.isWithDataSource()) {
			data.setApplicationName(
					applicationConfig.getName() + "-" + (String) AuditDataHandler.get(AuditParam.DATA_SOURCE));
		} else {
			data.setApplicationName(applicationConfig.getName());
		}

		data.setInstance(applicationConfig.getInstance());
		data.setWorkstation(ipUtil.getRemoteAddr(request));
		// data.setWorkstation(request.getRemoteAddr());
		data.setDateProcessed(new Date());
		data.setProcessedBy((String) AuditDataHandler.get(AuditParam.PROCESSED_BY));
		data.setModifiedData((String) AuditDataHandler.get(AuditParam.MODIFIED_DATA));
		setUserInformation(data, request);

		logger.info("Audit data set to [" + data.toJSON() + "]");

		return data;
	}

	/**
	 * 
	 * @param request
	 * @return
	 */
	protected String getCompleteUri(HttpServletRequest request) {
		String url = request.getRequestURI();
		String queryString = request.getQueryString();
		if (null != queryString && !queryString.isEmpty()) {
			url = url + "?" + queryString;
		}
		return url;
	}

	/**
	 * 
	 */
	protected String getRequestStatus() {
		Exception ex = (Exception) AuditDataHandler.get(AuditParam.AUDIT_ERROR);
		if (null != ex) {
			logger.error("Received exception message [" + ex.getMessage() + "]", ex);
			return "FAILED";
		} else {
			return "SUCCESS";
		}
	}

	/**
	 * @return the applicationConfig
	 */
	public ApplicationConfig getApplicationConfig() {
		return applicationConfig;
	}

	/**
	 * @param applicationConfig
	 *            the applicationConfig to set
	 */
	public void setApplicationConfig(ApplicationConfig applicationConfig) {
		this.applicationConfig = applicationConfig;
	}

	/**
	 * 
	 * @param field
	 * @return
	 */
	protected boolean notNullAndNotEmpty(String field) {
		return null != field && !field.isEmpty();
	}

	/**
	 * 
	 * @param data
	 * @param request
	 */
	protected abstract void setUserInformation(AuditData data, HttpServletRequest request);

	/**
	 * 
	 * @param auditData
	 */
	protected void saveAuditData(AuditData auditData) {
		/**
		 * 
		 */
		String applicationName = auditData.getApplicationName();
		
		logger.info("Saving data [" + auditData.toJSON() + "] of application [" + applicationName + "] for audit.");
		
		System.out.println("Audit data [" + auditData.toJSON() + "]");
		
		try {			
			
			dataAccess.executeSQLUpdate(EXEC_LOG_AUDIT_DATA, this.createParameterList(auditData));
			
		} catch (Exception e) {
			logger.error(e);
			e.printStackTrace();
		}
	}

	/**
	 * 
	 * @param data
	 * @return
	 */
	private Object[] createParameterList(AuditData data) {
		List<Object> parameters = new ArrayList<>();

		parameters.add(data.getApplicationName());
		parameters.add(data.getInstance());
		parameters.add(data.getUserId());
		parameters.add(data.getUserName());
		parameters.add(data.getPosition());
		parameters.add(data.getRole());
		parameters.add(data.getMaintenanceType());
		parameters.add(data.getProcessedBy());
		parameters.add(data.getDateProcessed());
		parameters.add(data.getStatus());
		parameters.add(data.getWorkstation());
		parameters.add(data.getModifiedData());

		return parameters.toArray();
	}
	
	
}
