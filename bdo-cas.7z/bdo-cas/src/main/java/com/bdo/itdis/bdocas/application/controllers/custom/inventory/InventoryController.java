package com.bdo.itdis.bdocas.application.controllers.custom.inventory;

import java.util.Date;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.cqrs.query.ResultModel;
import com.bdo.itd.util.security.application.UserSession;
import com.bdo.itdis.bdocas.inventory.application.query.IInventoryQueryService;
import com.ibm.icu.text.SimpleDateFormat;

@RestController
public class InventoryController {
	
	private final IInventoryQueryService queryService;
	
	@Inject
	public InventoryController(@Named("inventoryQueryService") IInventoryQueryService queryService) {
		super();
		this.queryService = queryService;
	}
	
	@RequestMapping(value="/inventory/result", method=RequestMethod.POST)
	public Object doQuery(@RequestBody Map<String, Object> data, HttpServletRequest request) throws Exception{
		System.out.println("doQuery");
		System.out.println(data);
		
		
		String processingDateFrom =  this.isNull(data.get("processingDateFrom"))? "":data.get("processingDateFrom").toString();
		String processingDateTo = this.isNull(data.get("processingDateTo"))? "":data.get("processingDateTo").toString();
		String selectedUser = this.isNull(data.get("selectedUser"))? "" : data.get("selectedUser").toString();
		int pageIndex = this.isNull(data.get("pageIndex"))? 0:Integer.parseInt(data.get("pageIndex").toString());
		int pageSize = this.isNull(data.get("pageSize"))? 0:Integer.parseInt(data.get("pageSize").toString());
		long dataSetID = this.isNull(data.get("dataSetID"))? 0L:Long.parseLong(data.get("dataSetID").toString());
		String inventoryCode = this.isNull(data.get("inventoryCode"))? "":data.get("inventoryCode").toString();
		String username = UserSession.getUsername();
		long membershipID = UserSession.getActiveAuthority().getMembershipID();
		
		
		ResultModel resultModel = queryService.doSearch(this.convertToDate(processingDateFrom), this.convertToDate(processingDateTo), selectedUser, 
				username, membershipID, dataSetID, inventoryCode, pageIndex, pageSize);
		
		
		return resultModel;
	}
	
	private Date convertToDate(String date) throws Exception{		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date out = null;
		
		if(date != null && !date.isEmpty()){
			out = sdf.parse(date);
		}

		return out; 
	}
	
	private boolean isNull(Object object){
		if(object == null){
			return true;
		}else{
			return false;
		}
	}
}
