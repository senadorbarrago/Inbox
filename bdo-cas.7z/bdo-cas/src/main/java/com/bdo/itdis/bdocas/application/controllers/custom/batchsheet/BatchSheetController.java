package com.bdo.itdis.bdocas.application.controllers.custom.batchsheet;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.cqrs.query.QueryException;
import com.bdo.itd.util.cqrs.query.ResultModel;
import com.bdo.itd.util.crqs.command.CommandException;
import com.bdo.itd.util.crqs.command.CommandMessage;
import com.bdo.itd.util.crqs.command.ICommandBus;
import com.bdo.itd.util.security.application.UserSession;
import com.bdo.itdis.bdocas.application.controllers.AbstractController;
import com.bdo.itdis.bdocas.batchsheet.application.command.AddBatchSheetCommand;
import com.bdo.itdis.bdocas.batchsheet.application.command.ApproveBatchSheetCommand;
import com.bdo.itdis.bdocas.batchsheet.application.command.SubmitBatchSheetCommand;
import com.bdo.itdis.bdocas.batchsheet.application.command.UndoApproveBatchSheetCommand;
import com.bdo.itdis.bdocas.batchsheet.application.query.IBatchSheetQueryService;
import com.bdo.itdis.bdocas.report.infrastructure.ReportGeneratorService;


@RestController
public class BatchSheetController extends AbstractController{
	
	private final IBatchSheetQueryService batchSheetQueryService;
	private final ICommandBus commandBus;
	private ReportGeneratorService reportGeneratorService;
	
	@Inject
	public BatchSheetController(@Named("batchSheetQueryService")IBatchSheetQueryService batchSheetQueryService,
			@Named("batchSheetCommandBus")ICommandBus commandBus, @Named("reportGeneratorService")ReportGeneratorService reportGeneratorService) {
		super();
		this.batchSheetQueryService = batchSheetQueryService;
		this.commandBus= commandBus;
		this.reportGeneratorService = reportGeneratorService;
	}
	
	@RequestMapping(value="/batchsheet/save/", method=RequestMethod.POST)
	public Object doSaveForm(@RequestBody AddBatchSheetCommand command, HttpServletRequest request) throws CommandException, Exception{
		System.out.println("doSaveNewBatchSheet()");
		
		CommandMessage message = new CommandMessage();
		
		System.out.println("data: "+command);
		command.setUsername(UserSession.getUsername());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());
		
		message = commandBus.doPublish(command);
		
		return message;
	}
	
	@RequestMapping(value="/batchsheet/submit", method=RequestMethod.POST)
	public Object doSubmitForm(@RequestBody Map<String, Object> data, HttpServletRequest request)  throws CommandException, Exception{
		System.out.println("doApproveForm()");
		CommandMessage message = new CommandMessage();

		SubmitBatchSheetCommand command = new SubmitBatchSheetCommand();
		command.setBatchSheetID(Long.parseLong(data.get("batchSheetID").toString()));
		command.setDataSetCode(data.get("dataSetCode").toString());
		command.setEncodingUnitCode(data.get("encodingUnitCode").toString());
		command.setUsername(UserSession.getUsername());
		command.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
		command.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());
			
		message = commandBus.doPublish(command);

		return message;
	}
	
	@RequestMapping(value="/batchsheet/approve", method=RequestMethod.POST)
	public Object doApproveForm(@RequestBody Map<String, Object> data, HttpServletRequest request)  throws CommandException, Exception{
		System.out.println("doApproveForm()");
		CommandMessage message = new CommandMessage();

		ApproveBatchSheetCommand command = new ApproveBatchSheetCommand();
		command.setBatchSheetID(Long.parseLong(data.get("batchSheetID").toString()));
		command.setDataSetCode(data.get("dataSetCode").toString());
		command.setEncodingUnitCode(data.get("encodingUnitCode").toString());
		command.setUsername(UserSession.getUsername());
		command.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
		command.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());
			
		message = commandBus.doPublish(command);

		return message;
	}
	
	@RequestMapping(value="/batchsheet/undoapprove", method=RequestMethod.POST)
	public Object doUndoApproveForm(@RequestBody Map<String, Object> data, HttpServletRequest request) throws CommandException, Exception{
		System.out.println("doUndoApproveForm()");
		CommandMessage message = new CommandMessage();
		
		UndoApproveBatchSheetCommand command = new UndoApproveBatchSheetCommand();
		command.setBatchSheetID(Long.parseLong(data.get("batchSheetID").toString()));
		command.setDataSetCode(data.get("dataSetCode").toString());
		command.setEncodingUnitCode(data.get("encodingUnitCode").toString());
		command.setUsername(UserSession.getUsername());
		command.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
		command.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());
		
		message = commandBus.doPublish(command);
		
		return message;
	}
	
	@RequestMapping(value="/batchsheet/preparation/{dataSetCode}/{username}/{encodingUnitCode}", method=RequestMethod.GET)
	public Object doQueryBatchSheetPreparation(@PathVariable("dataSetCode")String dataSetCode, @PathVariable("username")String username, 
			@PathVariable("encodingUnitCode")String encodingUnitCode, HttpServletRequest request){
		System.out.println("doQueryBatchSheetPreparation()");
		ResultModel resultModel = null;
		try{
			resultModel = batchSheetQueryService.doQueryPrepareBatchSheet(dataSetCode, 
					UserSession.getActiveAuthority().getGroup().getCode(), encodingUnitCode, username);
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return resultModel;
	}
	
	@RequestMapping(value="/batchsheet/preparationsummary/{dataSetID}/{username}/{encodingUnit}", method=RequestMethod.GET)
	public Object doQueryBatchSheetPreparationSummary(@PathVariable("dataSetID")long dataSetID, @PathVariable("username")String username, 
			@PathVariable("encodingUnit")String encodingUnit, HttpServletRequest request){
		System.out.println("doQueryBatchSheetPreparationSummary()");
		ResultModel resultModel = null;
		try{
			resultModel = batchSheetQueryService.doQueryPrepareBatchSheetSummary(dataSetID, username, encodingUnit);
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return resultModel;
	}
	
	@RequestMapping(value="/batchsheet/list", method=RequestMethod.POST)
	public Object doQueryBatchSheetList(@RequestBody Map<String, Object> data, 
			HttpServletRequest request){
		System.out.println("doQueryBatchSheetList()");
		
		ResultModel resultModel = null;
		try{
			data.put("username", UserSession.getUsername());
			data.put("roleCode", UserSession.getActiveAuthority().getRole().getCode());
			data.put("groupCode", UserSession.getActiveAuthority().getGroup().getCode());			
			
			resultModel = batchSheetQueryService.doQueryBatchSheetList(data);
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return resultModel;
	}
	
	@RequestMapping(value="/batchsheet/takeups/{batchSheetID}", method=RequestMethod.GET)
	public Object doQueryTakeUpsByBatchSheetID(@PathVariable("batchSheetID")long batchSheetID,
			HttpServletRequest request){
		System.out.println("doQueryTakeUpsByBatchSheetID()");
		ResultModel resultModel = null;
		try{
			resultModel = batchSheetQueryService.doQueryTakeUpsByBatchSheetID(batchSheetID);
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return resultModel;
	}
	
	@RequestMapping(value="/batchsheet/preparation/{reportName}", 
			method=RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE)
	public Object doQueryPrintBatchSheet(@PathVariable String reportName, 
			@RequestBody Map<String, Object> data ,HttpServletRequest request)throws Exception{
		
		Map<String, Object> parameters = new LinkedHashMap<String, Object>();
		Map<String, Object> reportParameters = new LinkedHashMap<String, Object>();
		
		parameters = data;
		reportParameters.putAll(data);
		
		parameters.put("reportName", reportName);
		parameters.put("reportParameters", reportParameters);
		
		System.out.println("ReportName: " + parameters);
		
		return reportGeneratorService.generate(parameters).map();
	}
	
	@RequestMapping(value="/batchsheet/headerInfo/{batchSheetID}", method=RequestMethod.GET)
	public Object doQueryBatchSheetHeaderInfo(@PathVariable("batchSheetID") Long batchSheetID,
			HttpServletRequest request){
		System.out.println("doQueryBatchSheetHeaderInfo()");
		System.out.println("batchSheetID: " + batchSheetID);
		
		ResultModel resultModel = null;
		try{
			resultModel = batchSheetQueryService.doQueryBatchSheetHeaderInfo(batchSheetID);
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return resultModel;
	}
	
	@RequestMapping(value="/batchsheet/summary/{dataSetCode}/{batchSheetID}/{bookCode}/"
			+ "{currencyCode}/{encodingUnitCode}", method=RequestMethod.GET)
	public Object doQueryBatchSheetSummaryInfo(@PathVariable("dataSetCode") String dataSetCode,
			@PathVariable("batchSheetID") Long batchSheetID, @PathVariable("bookCode") String bookCode,
				@PathVariable("currencyCode") String currencyCode, @PathVariable("encodingUnitCode") String encodingUnitCode,
					HttpServletRequest request) throws QueryException, Exception{
		System.out.println("doQueryBatchSheetSummaryInfo()");

		ResultModel resultModel = batchSheetQueryService.doQueryBatchSheeSummary(dataSetCode, batchSheetID, bookCode, currencyCode, UserSession.getUsername(), 
				UserSession.getActiveAuthority().getGroup().getCode(), encodingUnitCode);
		
		return resultModel;
	}
}
