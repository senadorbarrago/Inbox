package com.bdo.itdis.bdocas.application.controllers.custom.transaction;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.crqs.command.CommandException;
import com.bdo.itd.util.crqs.command.CommandMessage;
import com.bdo.itd.util.crqs.command.ICommandBus;
import com.bdo.itd.util.security.application.UserSession;
import com.bdo.itdis.bdocas.transactions.application.command.UndoFinalizeTransactionCommand;
import com.bdo.itdis.bdocas.transactions.application.query.values.IUndoFinalizeQueryService;


@RestController
public class UndoFinalizeController {
	
	private final ICommandBus commandBus;
	private final IUndoFinalizeQueryService queryService;;
	
	@Inject
	public UndoFinalizeController(@Named("transactionManagementCommandBus")ICommandBus commandBus,
			@Named("undoFinalizeQueryService") IUndoFinalizeQueryService queryService) {
		super();
		this.commandBus = commandBus;
		this.queryService = queryService;
	}
	
	@RequestMapping(value="/transactions/undofinalize/save", consumes=MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.POST)
	public Object doUndoFinalize(@RequestBody Map<String, Object> data, HttpServletRequest request)throws Exception{
		System.out.println("doUndoFinalize()");
		
		CommandMessage message = new CommandMessage();
		
		UndoFinalizeTransactionCommand command = new UndoFinalizeTransactionCommand();
		
		command.setDatasetID(Long.parseLong(data.get("dataSetID").toString()));
		command.setProcessID(queryService.doGetProcessID(command.getDatasetID()));
		System.out.println("ProcessID: "+command.getProcessID());
		
		SimpleDateFormat sdfGlDate = new SimpleDateFormat("yyyy-MM-dd");
		Date glDate = sdfGlDate.parse(data.get("currentProcessingDate").toString());
		command.setGlDate(glDate);
		
		command.setUsername(UserSession.getUsername());
		command.setMembershipID(UserSession.getActiveAuthority().getMembershipID());
		command.setUsername(UserSession.getUsername());
		command.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
		command.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());
		
		System.out.println("MembershipID: "+command.getMembershipID());
		
		message = commandBus.doPublish(command);
	
		return message;
	}
	
	@ExceptionHandler(CommandException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	public Object handleCommandException(HttpServletResponse response, Exception ex){
		Map<String, String> messageMap = new HashMap<>();
		messageMap.put("errorMsg", ex.getMessage());
		
		return  messageMap;
	}
	
	@ExceptionHandler(Exception.class)
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public Object handlegenericException(HttpServletResponse response, Exception ex){
		Map<String, String> messageMap = new HashMap<>();
		messageMap.put("errorMsg", ex.getMessage());
		
		return  messageMap;
	}
}
