package com.bdo.itdis.bdocas.application.controllers.custom.reference;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itdis.bdocas.application.controllers.custom.reference.utils.IReferenceService;

@RestController
public class AccountProfileByBookCodeAndCurrencyIDQueryController {
	
	private final String NC_GL_CODE = "NC_GL_CODE";
	private final IReferenceService referenceService;
	
	@Inject
	public AccountProfileByBookCodeAndCurrencyIDQueryController(@Named("referenceService")IReferenceService referenceService) {
		super();
		this.referenceService = referenceService;
	}
	
	@RequestMapping(value="/references/accountProfileByBookCodeAndCurrency/{bookCode}/{currency}", method=RequestMethod.GET)
	public Object doQuery(@PathVariable("bookCode")String bookCode, 
			@PathVariable("currency")String currency, HttpServletRequest request){
		
		System.out.println("bookCode: "+bookCode);
		System.out.println("currency: "+currency);
		
		List<Object> paramList = new ArrayList<>();
		paramList.add(bookCode);
		paramList.add(currency);
		
		return referenceService.getReferenceWithAdditionalDetails("dbo.spGetAccountProfileByBookCodeAndCurrency ?,?", paramList);
	}
	
	@RequestMapping(value="/references/accountProfileByGL/{bookCode}/{currency}", method=RequestMethod.GET)
	public Object doQueryAccountProfileByGL(@PathVariable("bookCode")String bookCode, 
			@PathVariable("currency")String currency, HttpServletRequest request){
		
		System.out.println("bookCode: "+bookCode);
		System.out.println("currency: "+currency);
		
		List<Object> paramList = new ArrayList<>();
		paramList.add(NC_GL_CODE);
		paramList.add(bookCode);
		paramList.add(currency);
		
		return referenceService.getReferenceWithCode("dbo.spGetAccountProfileByGLCodeBookCodeAndCurrency ?,?,?", paramList);
	}
}
