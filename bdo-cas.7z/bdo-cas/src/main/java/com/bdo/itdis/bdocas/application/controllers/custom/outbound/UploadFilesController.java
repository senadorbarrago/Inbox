/**
 * 
 */
package com.bdo.itdis.bdocas.application.controllers.custom.outbound;

import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.crqs.command.CommandException;
import com.bdo.itd.util.crqs.command.CommandMessage;
import com.bdo.itd.util.crqs.command.ICommandBus;
import com.bdo.itd.util.security.application.UserSession;
import com.bdo.itdis.bdocas.application.controllers.AbstractController;
import com.bdo.itdis.bdocas.outbound.application.command.UploadInterfaceFileCommand;

@RestController
public class UploadFilesController extends AbstractController{
	
	private ICommandBus commandBus;
	
	@Inject
	public UploadFilesController(@Named("outboundCommandBus")ICommandBus commandBus) {
		super();
		this.commandBus = commandBus;
	}
	
	@RequestMapping(value="/uploads/upload/{dataSetCode}", method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE)
	public Object doUpload(@PathVariable("dataSetCode")String dataSetCode, @RequestBody Map<String, Object> parameters, 
			HttpServletRequest request) throws CommandException, Exception{		
		System.out.println("doUpload()");
		System.out.println(parameters);
		System.out.println((Map)parameters.get("selectedFile"));
		
		System.out.println(((Map)parameters.get("selectedFile")).get("selectedFile"));
		
		
		
		System.out.println(((Map)parameters.get("selectedFile")).get("path").toString());
		
		String selectedFile = ((Map)parameters.get("selectedFile")).get("selectedFile").toString();		
		String path = ((Map)parameters.get("selectedFile")).get("path").toString();
		String systemCode = parameters.get("systemCode").toString();
		System.out.println("dataSetCode: "+dataSetCode);
		System.out.println("selectedFile: "+selectedFile);
		System.out.println("path: "+path);
		
		UploadInterfaceFileCommand command = new UploadInterfaceFileCommand(); 
		command.setDataSetCode(dataSetCode);
		command.setPath(path);
		command.setSelectedFile(selectedFile);
		command.setSystemCode(systemCode);
		command.setUsername(UserSession.getUsername());
		
		CommandMessage message = new CommandMessage();
		message = commandBus.doPublish(command);
		
		return message;
	}	
	
}
