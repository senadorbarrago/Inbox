/**
 * 
 */
package com.bdo.itdis.bdocas.application.controllers.custom.reference;

import java.util.ArrayList;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itdis.bdocas.application.controllers.custom.reference.utils.IReferenceService;

/**
 * @author c150819004
 *
 */
@RestController
public class EncodingUnitQueryController {
	
	private final IReferenceService referenceService;
	
	@Inject
	public EncodingUnitQueryController(@Named("referenceService")IReferenceService referenceService) {
		super();
		this.referenceService = referenceService;
	}

	@RequestMapping(value = "/references/encodingUnits",method = RequestMethod.GET)
	public Object doQuery(HttpServletRequest request){
		
		System.out.println("EncodingUnitQueryController: doQuery()");
		
		return referenceService.getReferenceWithCode("spGetEncodingSections", new ArrayList<Object>());
	}
}
