package com.bdo.itdis.bdocas.application.controllers.custom.transaction;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.cqrs.query.ResultModel;
import com.bdo.itd.util.crqs.command.CommandException;
import com.bdo.itd.util.crqs.command.CommandMessage;
import com.bdo.itd.util.crqs.command.ICommandBus;
import com.bdo.itd.util.security.application.UserSession;
import com.bdo.itdis.bdocas.transactions.application.command.GLDateSetupCommand;
import com.bdo.itdis.bdocas.transactions.application.query.values.IGLDateSetupQueryService;

@RestController
public class GLDateController {
	
	private final ICommandBus commandBus;
	private final IGLDateSetupQueryService queryService;
	
	@Inject
	public GLDateController(@Named("transactionManagementCommandBus")ICommandBus commandBus,
			@Named("gLDateSetUpQueryService") IGLDateSetupQueryService queryService) {
		super();
		this.commandBus = commandBus;
		this.queryService = queryService;
	}
	
	@RequestMapping(value="/transactions/glDate/currentGlDate/{dataSetID}", method=RequestMethod.GET)
	public Object doGetCurrentGLDate(@PathVariable("dataSetID")Long dataSetID, HttpServletRequest request){
		System.out.println("dataSetID: "+dataSetID);
		String currentGlDate = "";
		try{
			currentGlDate = queryService.doGetCurrentGLDate(dataSetID);
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return "{\"previousGlDate\" : \""+currentGlDate+"\"}";
	}
	
	@RequestMapping(value="/transactions/glDate/processID/{dataSetID}", method=RequestMethod.GET)
	public Object doGetProcessID(@PathVariable("dataSetID")Long dataSetID, HttpServletRequest request){
		System.out.println("dataSetID: "+dataSetID);
		Long processID = 0L;
		try{
			processID = queryService.doGetProcessID(dataSetID);
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return "{\"processID\" : \""+processID+"\"}";
	}
	
	@RequestMapping(value="/transactions/glDate/save", consumes=MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.POST)
	public Object doSaveGLDate(@RequestBody Map<String, Object> data, HttpServletRequest request)throws Exception {
		System.out.println("doSaveGLDate()");
		
		CommandMessage message = new CommandMessage();
		
		GLDateSetupCommand command = new GLDateSetupCommand();
		command.setProcessID(Long.parseLong(data.get("processID").toString()));
		
		SimpleDateFormat sdfGlDate = new SimpleDateFormat("yyyy-MM-dd");
		Date glDate = sdfGlDate.parse(data.get("glDate").toString());
		command.setGlDate(glDate);
		
		SimpleDateFormat sdfPrevGlDate = new SimpleDateFormat("yyyy-MM-dd");
		Date previousGlDate = sdfPrevGlDate.parse(data.get("previousGlDate").toString());
		command.setPrevGlDate(previousGlDate);
		
		command.setDatasetID(Long.parseLong(data.get("dataSetID").toString()));
		command.setForwardRate(Boolean.parseBoolean(data.get("forwardRates").toString()));
		command.setUsername(UserSession.getUsername());
		command.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
		command.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());
		
		message = commandBus.doPublish(command);
	
		return message;
	}
	
	@RequestMapping(value="/transactions/glDate/currentCurrencyRatesList", method=RequestMethod.GET)
	public Object doGetCurrentCurrencyList(HttpServletRequest request) throws Exception{
		String dataSetCode = "LN";
		ResultModel resultModel  = queryService.doGetCurrentCurrencyRates(dataSetCode);
		
		return resultModel;
	}
	
	@RequestMapping(value="/transactions/glDate/currencyRatesByProcessingDate", 
					consumes=MediaType.APPLICATION_JSON_VALUE, 
					method=RequestMethod.POST)
	public Object doGetcurrencyByProcessingDateList(@RequestBody Map<String, Object> data, 
			HttpServletRequest request) throws Exception{
		String dataSetCode = String.valueOf(data.get("dataSetCode"));
		String processingDate = String.valueOf(data.get("processingDate"));
		ResultModel resultModel  = queryService.doGetCurrencyRatesByProcessingDate(dataSetCode, processingDate);
		
		return resultModel;
	}
	
	@ExceptionHandler(CommandException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	public Object handleCommandException(HttpServletResponse response, Exception ex){
		Map<String, String> messageMap = new HashMap<>();
		messageMap.put("errorMsg", ex.getMessage());
		
		return  messageMap;
	}
	
	@ExceptionHandler(Exception.class)
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public Object handlegenericException(HttpServletResponse response, Exception ex){
		Map<String, String> messageMap = new HashMap<>();
		messageMap.put("errorMsg", ex.getMessage());
		
		return  messageMap;
	}
	
}
