package com.bdo.itdis.bdocas.application.controllers.core;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.map.ResultMapBuilder;
import com.bdo.itdis.bdocas.application.controllers.AbstractController;

/**
 * 
 * @author a014000098
 *
 */
@RestController("healthCheckController")
public class HealthCheckController extends AbstractController {
	
	/**
	 * 
	 */
	private final Logger logger = LoggerFactory.getLogger(HealthCheckController.class);
	
	/**
	 * 
	 */
	private String applicationName = "BDO-Comptrollership Accounting System";
	
	/**
	 * 
	 */
	private String applicationCode = "BCAS";
	
	/**
	 * 
	 */
	private String applicationVersion = "1.0.0";
	
	/**
	 * 
	 */
	private final String STATUS_OK = "OK";
	
	/**
	 * 
	 * @return
	 */
	@RequestMapping(
			value = "/healthCheck",
			method = RequestMethod.GET,
			produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseStatus(value = HttpStatus.OK)
	public Object healthCheck() {
		logger.info("healthCheck()");
		
		return ResultMapBuilder.instance()
				.add("appName", applicationName)
				.add("appVersion", applicationVersion)
				.add("appStatus", STATUS_OK)
				.build();
	}
	
}
