package com.bdo.itdis.bdocas.application.controllers.custom.inbound;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.cqrs.query.QueryException;
import com.bdo.itd.util.cqrs.query.ResultModel;
import com.bdo.itd.util.crqs.command.CommandException;
import com.bdo.itd.util.crqs.command.ICommandBus;
import com.bdo.itd.util.security.application.UserSession;
import com.bdo.itdis.bdocas.application.controllers.AbstractController;
import com.bdo.itdis.bdocas.inbound.application.command.handlers.UndoLoadSourceFilesCommand;
import com.bdo.itdis.bdocas.inbound.application.query.IInboundQueryService;	

/**
 * @author c140618008
 *
 */
@RestController
@RequestMapping("/inboundinterface/processedfiles")
public class InboundProcessedFilesController extends AbstractController{
	
	/**
	 * 
	 */
	@Inject
	@Named("inboundInterfaceCommandBus")
	private ICommandBus commandBus;
	
	/**
	 * 
	 */
	@Inject
	@Named("inboundQueryService")
	private IInboundQueryService inboundQueryService;

	/**
	 * @param requestBody
	 * @param request
	 * @return
	 * @throws QueryException
	 */
	@RequestMapping(method=RequestMethod.POST)
	public Object doQuery(@RequestBody Map<String, Object> requestBody, 
			HttpServletRequest request) throws QueryException{
		System.out.println(requestBody);
		
		ResultModel resultModel = inboundQueryService.findProcessedFiles(requestBody);
		
		return resultModel;
	}
	
	/**
	 * @param requestBody
	 * @param request
	 * @return
	 * @throws CommandException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value="/undoloadsourcefile", method=RequestMethod.POST)
	public Object doUndoLoad(@RequestBody Map<String, Object> requestBody, HttpServletRequest request)
			throws CommandException{
		System.out.println(requestBody);
		String dataSetCode = requestBody.get("dataSetCode").toString();
		List<String> sourceFileList = (ArrayList)requestBody.get("sourceFileList");
		
		UndoLoadSourceFilesCommand command = new UndoLoadSourceFilesCommand();
		command.setDataSetCode(dataSetCode);
		command.setFileList(sourceFileList);
		command.setUsername(UserSession.getUsername());
		command.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
		command.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());
		
		return commandBus.doPublish(command);
	}
	
}
