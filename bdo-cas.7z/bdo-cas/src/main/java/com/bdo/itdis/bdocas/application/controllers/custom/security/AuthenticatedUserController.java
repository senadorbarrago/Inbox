package com.bdo.itdis.bdocas.application.controllers.custom.security;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.audit.data.AuditParam;
import com.bdo.itd.util.persistence.DataAccessInterface;
import com.bdo.itd.util.security.application.UserSession;

@RestController
public class AuthenticatedUserController {
	
	private final DataAccessInterface dataAccessService;
	
	@Inject
	public AuthenticatedUserController(@Named("dataAccessService")DataAccessInterface dataAccessService) {
		super();
		this.dataAccessService = dataAccessService;
	}

	@RequestMapping(value="/authenticatedUser", method=RequestMethod.GET)
	public Object getAutheticatedUser(HttpServletRequest request){
		System.out.println("getAutheticatedUser()");
		
		HttpSession session = request.getSession();
		session.setAttribute(AuditParam.USER_ID, UserSession.getUsername());
		session.setAttribute(AuditParam.USER_NAME, UserSession.getFullname());
		session.setAttribute(AuditParam.USER_ROLE, UserSession.getActiveAuthority().getRole().getCode());
		session.setAttribute(AuditParam.PROCESSED_BY, UserSession.getUsername());
		 
		return UserSession.getUserProfile();
	}
	
//	@RequestMapping(value="/changeActiveMembership", method=RequestMethod.POST)
//	public Object doChangeActiveMembership(@RequestBody String membershipCode, 
//			HttpServletRequest request){
//		System.out.println("doChangeActiveMembership(); "+ membershipCode);
//		
//		for(GrantedAuthority authority : UserSession.getAuthorities()){
//			if(((Authority)authority).getMembershipCode().equals(membershipCode)){
//				UserSession.setActiveAuthority((Authority)authority);
//				dataAccessService.executeSQLUpdate("dbo.spChangeDefaultMembership ?,?", new Object[]{
//					UserSession.getUsername(), membershipCode	
//				});
//				break;
//			}
//		}
//		 
//		return UserSession.getUserProfile();
//	}
	
	@RequestMapping(value="/sessionTimeOut", method=RequestMethod.GET)
	public void getSessionTimeOut(HttpServletRequest request, HttpServletResponse response){
		System.out.println("getSessionTimeOut()");
		response.setStatus(HttpStatus.FORBIDDEN.value());
	}
}
