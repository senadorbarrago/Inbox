package com.bdo.itdis.bdocas.application.controllers.custom.transaction;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.cqrs.query.QueryException;
import com.bdo.itd.util.cqrs.query.ResultModel;
import com.bdo.itd.util.crqs.command.CommandException;
import com.bdo.itd.util.crqs.command.CommandMessage;
import com.bdo.itd.util.crqs.command.ICommandBus;
import com.bdo.itd.util.security.application.UserSession;
import com.bdo.itdis.bdocas.application.controllers.AbstractController;
import com.bdo.itdis.bdocas.report.application.command.ReportGeneratorCommand;
import com.bdo.itdis.bdocas.transactions.application.command.UndoCleanUpCommand;
import com.bdo.itdis.bdocas.transactions.application.query.list.ITransactionInboxQueryService;
import com.bdo.itdis.bdocas.transactions.application.query.list.searchcriteria.SearchCriteria;


/**
 * @author c140618008
 *
 */
@RestController
@RequestMapping("/transactions")
public class TransactionInboxController extends AbstractController{
	
	/**
	 * 
	 */
	private static final Logger logger = Logger.getLogger(TransactionInboxController.class);
	
	
	/**
	 * 
	 */
	private final ITransactionInboxQueryService queryService;
	
	/**
	 * 
	 */
	private final ICommandBus commandBus;
	
	/**
	 * 
	 */
	private final ICommandBus reportCommandBus;
	
	/**
	 * @param queryService
	 * @param commandBus
	 * @param reportCommandBus
	 */
	@Inject
	public TransactionInboxController(@Named("transactionInboxQueryService")ITransactionInboxQueryService queryService,
			@Named("transactionManagementCommandBus")ICommandBus commandBus,
				@Named("reportCommandBus")ICommandBus reportCommandBus) {
		super();
		this.queryService = queryService;
		this.commandBus = commandBus;
		this.reportCommandBus = reportCommandBus;
	}
	
	/**
	 * @param dataSetCode
	 * @param pageIndex
	 * @param pageSize
	 * @param searchCriteria
	 * @param request
	 * @return
	 * @throws QueryException
	 */
	@RequestMapping(value="/inbox/{dataSetCode}/{pageIndex}/{pageSize}/", method=RequestMethod.POST, consumes="application/json")
	public Object doQueryList(@PathVariable("dataSetCode")String dataSetCode, @PathVariable("pageIndex")int pageIndex, 
			@PathVariable("pageSize")int pageSize, @RequestBody Map<String, Object> searchCriteria, HttpServletRequest request)
				throws QueryException{
		logger.info(this.getClass()+" - doQueryList()");
		
		ResultModel resultModel = null;
		
		Map<String, Object> params = new HashMap<>();
		params.put("userName", UserSession.getUsername());
		params.put("membershipCode", UserSession.getActiveAuthority().getCode());
		params.put("dataSetCode", dataSetCode);
		params.put("searchCriteria", convertToXML(searchCriteria, pageIndex, pageSize));
		params.put("pageIndex", pageIndex);
		params.put("pageSize", pageSize);
		
		resultModel = queryService.doQuery(params);
		
		return resultModel;
	}
	
	/**
	 * @param transactionIDs
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/inbox/undoCleanUp",
			method=RequestMethod.POST,
			consumes=MediaType.APPLICATION_JSON_VALUE)
	public Object doUndoCleanUp(@RequestBody List<String> transactionIDs, HttpServletRequest request) throws Exception{
		logger.info(this.getClass()+" - doUndoCleanUp()");
		
		UndoCleanUpCommand command = new UndoCleanUpCommand();
		
		command.setUsername(UserSession.getUsername());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());
		command.setMembershipCode(UserSession.getActiveAuthority().getCode());
		command.setTransactionIDs(transactionIDs);
		
		CommandMessage message = new CommandMessage();
		message = commandBus.doPublish(command);
		
		return message;
	}
	
	/**
	 * @param reportCode
	 * @param dataSetCode
	 * @param pageIndex
	 * @param pageSize
	 * @param data
	 * @param request
	 * @return
	 * @throws QueryException
	 * @throws CommandException
	 */
	@RequestMapping(value="/inbox/generate/{reportCode}/{dataSetCode}/{pageIndex}/{pageSize}/", method=RequestMethod.POST)
	public Object doGenerateReport(@PathVariable String reportCode, @PathVariable("dataSetCode")String dataSetCode,
			@PathVariable("pageIndex")int pageIndex, @PathVariable("pageSize")int pageSize, 
				@RequestBody Map<String, Object> data, HttpServletRequest request) throws QueryException, CommandException{
		logger.info(this.getClass()+" - doGenerateReport()");
		
		Map<String, Object> parameters = new LinkedHashMap<String, Object>();
	
		parameters.put("username", UserSession.getUsername());
		parameters.put("membershipCode", UserSession.getActiveAuthority().getCode());
		parameters.put("dataSetCode", dataSetCode);
		parameters.put("searchCriteria", convertToXML(data, pageIndex, pageSize));
		parameters.put("pageIndex", pageIndex);
		parameters.put("pageSize", pageSize);

		parameters.put("reportName", reportCode);
		
		ReportGeneratorCommand command = new ReportGeneratorCommand();
		
		command.setReportCode(reportCode);
		command.setParams(parameters);
		command.setUsername(UserSession.getUsername());
		command.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
		command.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());
		
		CommandMessage message = new CommandMessage();
		
		message = reportCommandBus.doPublish(command);
		
		System.out.println("message: " + message.getMessageMap());
		
		return message;
	}
	
	/**
	 * @param searchCriteriaData
	 * @param pageIndex
	 * @param pageSize
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private String convertToXML(Map<String, Object> searchCriteriaData, int pageIndex, int pageSize){
		List<Map<String, Object>> filterFields = new ArrayList<>();
		if(searchCriteriaData.get("filterList") != null){
			filterFields = (ArrayList<Map<String, Object>>)searchCriteriaData.get("filterList");
		}
		
		List<Map<String, Object>> sortFields = new ArrayList<>();
		if(searchCriteriaData.get("sortList") != null){
			sortFields = (ArrayList<Map<String, Object>>)searchCriteriaData.get("sortList");
		}
		
		SearchCriteria searchCriteria = new SearchCriteria(filterFields, sortFields, pageIndex, pageSize);		
		
		return searchCriteria.convertSearchCriteriaToXML();
	}
}
