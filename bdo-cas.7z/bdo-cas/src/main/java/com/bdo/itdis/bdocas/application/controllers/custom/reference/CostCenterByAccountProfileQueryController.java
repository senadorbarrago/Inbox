package com.bdo.itdis.bdocas.application.controllers.custom.reference;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itdis.bdocas.application.controllers.custom.reference.utils.IReferenceService;

@RestController
public class CostCenterByAccountProfileQueryController {
	
	private final IReferenceService referenceService;
	
	@Inject
	public CostCenterByAccountProfileQueryController(@Named("referenceService")IReferenceService referenceService) {
		super();
		this.referenceService = referenceService;
	}
	
	@RequestMapping(value="/references/costCenterByAccountProfile/{accountProfileID}/{index}", method=RequestMethod.GET)
	public Object doQuery(@PathVariable("accountProfileID")Long accountProfileID, @PathVariable("index")int index,
			HttpServletRequest request){
		
		System.out.println("accountProfileID: "+accountProfileID);
		
		List<Object> paramList = new ArrayList<>();
		paramList.add(accountProfileID);
		
		Map<String, Object> returnMap = new HashMap<>();
		returnMap.put("index", index);
		returnMap.put("referenceList", referenceService.getReferenceWithCode("dbo.spGetCostCenterByAccountProfileID ?", paramList));
		
		return returnMap;
	}
}
