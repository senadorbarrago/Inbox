package com.bdo.itdis.bdocas.application.controllers.custom.reference;

import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itdis.bdocas.journalentry.application.query.references.IPhpAndUsdRateQueryService;

@RestController
public class PhpAndUsdRatesQueryController {
	
	private final IPhpAndUsdRateQueryService phpAndUsdRateQueryService;
	
	@Inject
	public PhpAndUsdRatesQueryController(@Named("phpAndUsdRateQueryService")
	IPhpAndUsdRateQueryService phpAndUsdRateQueryService) {
		super();
		this.phpAndUsdRateQueryService = phpAndUsdRateQueryService;
	}
	
	@RequestMapping(value="/references/phpAndUsdRatesByCurrency/{currency}", method=RequestMethod.GET)
	public Object doQuery(@PathVariable("currency")String currency, HttpServletRequest request){
		System.out.println("currency: "+currency);		
		
		Map<String, Object> phpAndUsdRatesMap = new HashMap<>();
		try{
			phpAndUsdRatesMap = phpAndUsdRateQueryService.getPhpAndUsdRateByCurrency(currency);
		
		}catch(Exception ex){
			ex.printStackTrace();
		}
		
		return phpAndUsdRatesMap;
	}
}
