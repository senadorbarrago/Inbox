package com.bdo.itdis.bdocas.application.controllers.custom.reference;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itdis.bdocas.journalentry.application.query.references.ILatestEffectiveDateQueryService;

@RestController
public class LatestEffectiveDateQueryController {
	
	private final ILatestEffectiveDateQueryService latestEffectiveDateQueryService;
	
	@Inject
	public LatestEffectiveDateQueryController(@Named("latestEffectiveDateQueryService")
	ILatestEffectiveDateQueryService latestEffectiveDateQueryService) {
		super();
		this.latestEffectiveDateQueryService = latestEffectiveDateQueryService;
	}
	
	@RequestMapping(value="/references/latestEffectiveDateByDataSetID/{dataSetID}", method=RequestMethod.GET)
	public Object doQuery(@PathVariable("dataSetID")Long dataSetID, HttpServletRequest request){
		System.out.println("dataSetID: "+dataSetID);		
		String latestEffectiveDate = "";
		try{
			latestEffectiveDate = latestEffectiveDateQueryService.getEffectiveDateByDataSetID(dataSetID);
		}catch(Exception ex){
			ex.printStackTrace();
		}
		
		return "{\"latestEffectiveDate\":\""+latestEffectiveDate+"\"}";
	}
}
