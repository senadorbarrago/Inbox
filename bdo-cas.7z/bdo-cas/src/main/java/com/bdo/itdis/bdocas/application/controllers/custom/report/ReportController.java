/**
 * 
 */
package com.bdo.itdis.bdocas.application.controllers.custom.report;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.crqs.command.CommandException;
import com.bdo.itd.util.crqs.command.CommandMessage;
import com.bdo.itd.util.crqs.command.ICommandBus;
import com.bdo.itd.util.security.application.UserSession;
import com.bdo.itdis.bdocas.report.application.command.DispositionSheetReportGeneratorCommand;
import com.bdo.itdis.bdocas.report.application.command.ReportGeneratorCommand;
import com.bdo.itdis.bdocas.report.application.query.IReportDownloaderQueryService;


/**
 * @author c150819004
 *
 */
@RestController
public class ReportController {
	
	private ICommandBus commandBus;
	private IReportDownloaderQueryService queryService;
	
	@Inject
	public ReportController(
			@Named("reportCommandBus")ICommandBus commandBus,
			@Named("reportDownloaderQueryService")IReportDownloaderQueryService queryService
			) {
		super();
		this.commandBus = commandBus;
		this.queryService = queryService;
	}
	
	@RequestMapping(
			value="/reports/create/{reportName}",
			method=RequestMethod.POST,
			consumes=MediaType.APPLICATION_JSON_VALUE
			)
	@ResponseBody
	public Object getReportParameter(
			@PathVariable String reportName,
			@RequestBody Map<String, Object> requestBody,
			HttpServletRequest request
			){
		
		Map<String, Object> parameters = new LinkedHashMap<String, Object>();
		Map<String, Object> reportParameters = new LinkedHashMap<String, Object>();
		parameters = requestBody;
		reportParameters.putAll(requestBody);
		
		parameters.put("reportName", reportName);
		parameters.put("dataSetCode", reportParameters.get("dataSetCode").toString());
		parameters.put("reportParameters", reportParameters);
		
		System.out.println("Parameters: " + parameters);
		System.out.println("Report Parameters: " + reportParameters);
		
		CommandMessage message = new CommandMessage();
		
		if(reportName.contains("DispositionSheet")){
			message = this.doGenerateDispositionSheet(parameters);
		}else {
			message = this.doGenerateReport(parameters);
		}
		
		return message;
	}
	
	@RequestMapping(
			value="/reports/download/{reportName}",
			method=RequestMethod.GET
			)
	public FileSystemResource downloadReport(
			@PathVariable String reportName,
			@RequestParam String file,
			HttpServletRequest request,
			HttpServletResponse response) {
		
		Map<String, Object> parameters = new LinkedHashMap<String, Object>();
		
		parameters.put("reportName", reportName);
		parameters.put("filename", file);
		
		Map<String, Object> resultMap = new LinkedHashMap<String, Object>();
		try {
			resultMap = queryService.doQuery(parameters);
		} catch (Exception e) {
			e.printStackTrace();
		}
			
		FileSystemResource rsc = (FileSystemResource) resultMap.get("fileSystemResource");
		response.setHeader("Content-Disposition", "attachment; filename=" + resultMap.get("filename"));
		//response.setHeader("Content-Type", (String) resultMap.get("mimeType"));
		response.setHeader("Content-Type", "application/octet-stream");
		response.setStatus(HttpStatus.OK.value());
		
		return rsc;
		
	}
	
	
	@RequestMapping(
			value="/reports/getEncoding",
			method=RequestMethod.GET,
			produces="application/json"
			)
	@ResponseStatus(value=HttpStatus.OK)
	public Object getReferences(
			){
		
		System.out.println("getReferences");
		
		return null;
	}
	
	private CommandMessage doGenerateReport(Map<String, Object> parameters){
		
		System.out.println("ReportController: doGenerateReport()");
		
		ReportGeneratorCommand command = new ReportGeneratorCommand();
		
		command.setReportCode(parameters.get("reportName").toString());
		command.setParams(parameters);
		command.setUsername(UserSession.getUsername());
		command.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
		command.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());
		
		CommandMessage message = new CommandMessage();
		
		try {
			message = commandBus.doPublish(command);
		} catch (CommandException e) {
			e.printStackTrace();
		}
		System.out.println("message: " + message.getMessageMap());
		
		return message;
	}
	
	private CommandMessage doGenerateDispositionSheet(Map<String, Object> parameters){
		
		System.out.println("ReportController: doGenerateDispositionSheet()");
		
		DispositionSheetReportGeneratorCommand command = new DispositionSheetReportGeneratorCommand();
		
		command.setReportCode(parameters.get("reportName").toString());
		command.setDatasetCode(parameters.get("dataSetCode").toString());
		command.setParams(parameters);
		command.setUsername(UserSession.getUsername());
		command.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
		command.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());
		
		CommandMessage message = new CommandMessage();
		
		try {
			message = commandBus.doPublish(command);
		} catch (CommandException e) {
			e.printStackTrace();
		}
		System.out.println("message: " + message.getMessageMap());
		
		return message;
	}
}
