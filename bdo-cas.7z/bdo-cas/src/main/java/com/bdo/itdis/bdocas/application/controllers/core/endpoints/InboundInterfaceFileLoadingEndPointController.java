package com.bdo.itdis.bdocas.application.controllers.core.endpoints;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.crqs.command.CommandException;
import com.bdo.itd.util.crqs.command.CommandMessage;
import com.bdo.itd.util.crqs.command.ICommandBus;
import com.bdo.itd.util.security.application.UserSession;
import com.bdo.itdis.bdocas.application.controllers.AbstractController;
import com.bdo.itdis.bdocas.inbound.application.command.handlers.FileDownloadCommand;
import com.bdo.itdis.bdocas.inbound.application.command.handlers.LoadSourceFileCommand;

/**
 * @author c140618008
 *
 */
@RestController
@RequestMapping("/endpoint/inboundinterface")
public class InboundInterfaceFileLoadingEndPointController extends AbstractController{
	
	/**
	 * 
	 */
	private static final Logger logger = Logger.getLogger(InboundInterfaceFileLoadingEndPointController.class);
	
	/**
	 * 
	 */
	@Inject
	@Named("inboundInterfaceCommandBus")
	private ICommandBus commandBus;
	
	/**
	 * @param interfaceFileCode
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/{profileCode}/{interfaceFileCode}", method=RequestMethod.GET, produces="application/json")
	public Object receiveRequest(@PathVariable(value="profileCode") String profileCode, 
			@PathVariable(value="interfaceFileCode") String interfaceFileCode,
			HttpServletRequest request, HttpServletResponse response) throws CommandException{
		logger.info(this.getClass()+" - "+"receiveRequest()");
		logger.info(this.getClass()+" - "+"{profileCode}: "+profileCode);
		logger.info(this.getClass()+" - "+"{interfaceFileCode}: "+interfaceFileCode);
		
		FileDownloadCommand fileDownloadCommand = new FileDownloadCommand();
		fileDownloadCommand.setProfileCode(profileCode);
		fileDownloadCommand.setInboundInterfaceFileCode(interfaceFileCode);
		fileDownloadCommand.setDataSetCode("LN");
		
		CommandMessage commandMessage = commandBus.doPublish(fileDownloadCommand);
		String downloadedFileName = commandMessage.getMessageMap().get("downloadedFileName");
		logger.info(this.getClass()+" - downloadedFileName: "+downloadedFileName);
		
		if( downloadedFileName != null && !downloadedFileName.isEmpty()){
			String applicationName = "bcas";
			List<String> sourceFileList = new ArrayList<>();
			sourceFileList.add(downloadedFileName);
			
			LoadSourceFileCommand loadSourceFileCommand = new LoadSourceFileCommand();
			loadSourceFileCommand.setApplicationName(applicationName);
			loadSourceFileCommand.setDatasetCode("LN");
			loadSourceFileCommand.setSourceFileList(sourceFileList);
			
			loadSourceFileCommand.setUsername("BCAS-AUTOSCHEDULER");
			
			commandBus.doPublish(loadSourceFileCommand);
		}
		
		return "{\"message\": \"success\"}";
	}
	
}
