/**
 * 
 */
package com.bdo.itdis.bdocas.application.controllers.custom.reference;

import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.cqrs.query.ResultModel;
import com.bdo.itdis.bdocas.transactions.application.query.list.IColumnListQueryService;


/**
 * @author c150819004
 *
 */
@RestController
public class ColumnListQueryController {
	
	private final IColumnListQueryService columnListQueryService;
	
	@Inject
	public ColumnListQueryController(@Named("columnListQueryService")IColumnListQueryService columnListQueryService) {
		super();
		this.columnListQueryService = columnListQueryService;
	}

	@RequestMapping(value="/transactions/columns/{dataSetID}/{recordProfileID}", method=RequestMethod.GET)
	public Object doGetColumnList(@PathVariable("dataSetID")long dataSetID, 
									@PathVariable("recordProfileID")long recordProfileID,
									HttpServletRequest request){
		
		ResultModel resultModel = null;
		
		try {
			Map<String, Object> params = new HashMap<>();
			params.put("dataSetID", dataSetID);
			params.put("recordProfileID", recordProfileID);
			System.out.println("TransactionInboxController: doGetColumnList() Column Parameters: " + params);
			
			resultModel = columnListQueryService.doQuery(params);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return resultModel;
	}
}
