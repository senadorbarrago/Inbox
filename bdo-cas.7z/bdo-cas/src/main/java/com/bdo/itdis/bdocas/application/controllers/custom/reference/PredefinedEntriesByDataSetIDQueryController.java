package com.bdo.itdis.bdocas.application.controllers.custom.reference;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itdis.bdocas.application.controllers.custom.reference.utils.IReferenceService;

@RestController
public class PredefinedEntriesByDataSetIDQueryController {
	
	private final IReferenceService referenceService;
	
	@Inject
	public PredefinedEntriesByDataSetIDQueryController(@Named("referenceService")IReferenceService referenceService) {
		super();
		this.referenceService = referenceService;
	}


	@RequestMapping(value="/references/predefinedEntries/{dataSetID}/{bookCode}/{currency}", method=RequestMethod.GET)
	public Object doQuery(@PathVariable("dataSetID")Long dataSetID, @PathVariable("bookCode")String bookCode, 
			@PathVariable("currency")String currency, HttpServletRequest request){
		
		System.out.println("dataSetID: "+dataSetID);
		System.out.println("bookCode: "+bookCode);
		System.out.println("currency: "+currency);
		
		List<Object> paramList = new ArrayList<>();
		paramList.add(dataSetID);
		paramList.add(bookCode);
		paramList.add(currency);
		
		return referenceService.getReference("dbo.spGetPredefinedEntries ?,?,?", paramList);
	}
	
	@RequestMapping(value="/references/clientCodes/{dataSetCode}", method=RequestMethod.GET)
	public Object doQuery(@PathVariable("dataSetCode")String dataSetCode, HttpServletRequest request){
		
		System.out.println("dataSetCode: "+dataSetCode);
		
		List<Object> paramList = new ArrayList<>();
		paramList.add(dataSetCode);
		
		return referenceService.getReferenceWithCode("dbo.spGetClientCodes ?", paramList);
	}
	
	@RequestMapping(value="/references/pdeDataFields/{dataSetID}/{recordProfileID}", method=RequestMethod.GET)
	public Object doQuery(@PathVariable("dataSetID")Long dataSetID, @PathVariable("recordProfileID")Long recordProfileID, 
			HttpServletRequest request){
		
		System.out.println("dataSetID: "+dataSetID);
		
		List<Object> paramList = new ArrayList<>();
		paramList.add(dataSetID);
		paramList.add(recordProfileID);
		
		return referenceService.getReferenceWithCode("dbo.spGetDataFieldColumnByRecordProfile ?,?", paramList);
	}
	
	@RequestMapping(value="/references/pdeRecordProfiles/{dataSetID}", method=RequestMethod.GET)
	public Object doQuery(@PathVariable("dataSetID")Long dataSetID, HttpServletRequest request){
		
		System.out.println("dataSetID: "+dataSetID);
		
		List<Object> paramList = new ArrayList<>();
		paramList.add(dataSetID);
		
		return referenceService.getReferenceWithCode("dbo.spDisplayPDERecordProfile ?", paramList);
	}
}
