package com.bdo.itdis.bdocas.application.controllers.core.cqrs;

import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.cqrs.query.IQueryModelProvider;
import com.bdo.itd.util.cqrs.query.QueryException;
import com.bdo.itd.util.cqrs.query.QueryParam;
import com.bdo.itd.util.cqrs.query.ResultModel;
import com.bdo.itdis.bdocas.application.controllers.AbstractController;

/**
 * 
 * @author a014000098
 *
 */
@RestController("queryRequestController")
@RequestMapping("/qry")
public class QueryRequestController extends AbstractController {
	
	/**
	 * 
	 */
	private final IQueryModelProvider queryModelProvider;
	
	/**
	 * 
	 * @param queryModelProvider
	 */
	@Inject
	public QueryRequestController(@Named("queryModelProvider")IQueryModelProvider queryModelProvider) {
		super();
		this.queryModelProvider = queryModelProvider;
	}
	
	/**
	 * 
	 * @param queryCode
	 * @param requestBody
	 * @param request
	 * @param response
	 * @return
	 * @throws QueryException
	 */
	@RequestMapping(value="/{queryCode}", method=RequestMethod.POST)
	public Object handleQueryPostRequest(@PathVariable String queryCode,
			@RequestBody Map<String, Object> requestBody, HttpServletRequest request, HttpServletResponse response) throws QueryException {

		return executeQuery(queryCode, requestBody);
	}	

	/**
	 * 
	 * @param parameters
	 * @return
	 */
	private ResultModel executeQuery(String queryCode, Map<String, Object> parameters) throws QueryException{
		return queryModelProvider.getQuerymodel(queryCode).doQuery(new QueryParam(parameters));
	}
}
