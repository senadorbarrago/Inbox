package com.bdo.itdis.bdocas.application.controllers.custom.controltotals;

import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.cqrs.query.QueryException;
import com.bdo.itd.util.cqrs.query.ResultModel;
import com.bdo.itd.util.crqs.command.CommandException;
import com.bdo.itd.util.crqs.command.CommandMessage;
import com.bdo.itd.util.crqs.command.ICommandBus;
import com.bdo.itd.util.security.application.UserSession;
import com.bdo.itdis.bdocas.application.controllers.AbstractController;
import com.bdo.itdis.bdocas.controltotals.application.command.AddControlTotalsCommand;
import com.bdo.itdis.bdocas.controltotals.application.command.DeleteControlTotalsCommand;
import com.bdo.itdis.bdocas.controltotals.application.command.UpdateControlTotalsCommand;
import com.bdo.itdis.bdocas.controltotals.application.query.IControlTotalsQueryService;


/**
 * @author c140618008
 *
 */
@RestController
public class ControlTotalsController extends AbstractController{
	
	/**
	 * 
	 */
	private final ICommandBus commandBus;
	
	/**
	 * 
	 */
	private final IControlTotalsQueryService queryService;
	
	/**
	 * @param queryService
	 * @param commandBus
	 */
	@Inject
	public ControlTotalsController(@Named("controlTotalsQueryService")IControlTotalsQueryService queryService,
			@Named("controlTotalsCommandBus")ICommandBus commandBus) {
		super();
		this.queryService = queryService;
		this.commandBus= commandBus;
	}
	
	/**
	 * @param command
	 * @param request
	 * @return
	 * @throws CommandException
	 * @throws Exception
	 */
	@RequestMapping(value="/controltotals/add/", method=RequestMethod.POST)
	public Object doAdd(@RequestBody AddControlTotalsCommand command, HttpServletRequest request)
		throws CommandException, Exception{
		System.out.println("doAdd()");
		
		CommandMessage message = new CommandMessage();
		command.setUsername(UserSession.getUsername());
		command.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
		command.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());
		command.setSectionCode(UserSession.getActiveAuthority().getGroup().getCode());
		
		message = commandBus.doPublish(command);
		
		return message;
	}
	
	/**
	 * @param command
	 * @param request
	 * @return
	 * @throws CommandException
	 * @throws Exception
	 */
	@RequestMapping(value="/controltotals/update/", method=RequestMethod.POST)
	public Object doUpdate(@RequestBody UpdateControlTotalsCommand command, HttpServletRequest request)
		throws CommandException, Exception{
		System.out.println("doUpdate()");
		
		CommandMessage message = new CommandMessage();
		command.setUsername(UserSession.getUsername());
		command.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
		command.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());
		
		message = commandBus.doPublish(command);
		
		return message;
	}
	
	/**
	 * @param command
	 * @param request
	 * @return
	 * @throws CommandException
	 * @throws Exception
	 */
	@RequestMapping(value="/controltotals/delete/", method=RequestMethod.POST)
	public Object doDelete(@RequestBody DeleteControlTotalsCommand command, HttpServletRequest request)
		throws CommandException, Exception{
		System.out.println("doDelete()");
		
		CommandMessage message = new CommandMessage();
		command.setUsername(UserSession.getUsername());
		command.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
		command.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());
		
		message = commandBus.doPublish(command);
		
		return message;
	}
	
	/**
	 * @param data
	 * @param request
	 * @return
	 * @throws QueryException
	 */
	@RequestMapping(value="/controlTotals/actionable", method=RequestMethod.POST)
	public Object doQueryActionableControlTotals(@RequestBody Map<String, Object> data, 
			HttpServletRequest request) throws QueryException{
		System.out.println("doQueryActionableControlTotals()");
		
		try{
		String dataSetCode = data.get("dataSetCode").toString();
		String encodingUnitCode = data.get("encodingUnitCode").toString();
		String selectedUser = data.get("selectedUser").toString();
		int pageIndex = Integer.parseInt(data.get("pageIndex").toString());
		int pageSize = Integer.parseInt(data.get("pageSize").toString());
		
		ResultModel resultModel = queryService.doQueryActionableControlTotals(dataSetCode, 
				UserSession.getUsername(), UserSession.getActiveAuthority().getRole().getCode(), 
					UserSession.getActiveAuthority().getGroup().getCode(), encodingUnitCode, 
					selectedUser, pageIndex, pageSize);
			
			return resultModel;
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return null;
	}
	
	/**
	 * @param dataSetCode
	 * @param controlTotalsID
	 * @param request
	 * @return
	 * @throws QueryException
	 * @throws Exception
	 */
	@RequestMapping(value="/controltotals/header/{dataSetCode}/{controlTotalsID}", method=RequestMethod.GET)
	public Object doQueryControlTotalsHeaderQueryModel(@PathVariable("dataSetCode")String dataSetCode,
			@PathVariable("controlTotalsID")long controlTotalsID, 
					HttpServletRequest request) throws QueryException, Exception{
		System.out.println("doQueryControlTotalsHeaderQueryModel()");
		
		ResultModel resultModel = queryService.doQueryControlTotalsHeader(dataSetCode, controlTotalsID);
		
		return resultModel;
	}
	
	/**
	 * @param dataSetCode
	 * @param controlTotalsID
	 * @param request
	 * @return
	 * @throws QueryException
	 * @throws Exception
	 */
	@RequestMapping(value="/controltotals/manuallyencoded/{dataSetCode}/{controlTotalsID}", method=RequestMethod.GET)
	public Object doQueryManuallyEncodedControlTotals(@PathVariable("dataSetCode")String dataSetCode,
			@PathVariable("controlTotalsID")long controlTotalsID, 
					HttpServletRequest request) throws QueryException, Exception{
		System.out.println("doQueryControlTotalsHeaderQueryModel()");
		
		ResultModel resultModel = queryService.doQueryManuallyEncodedControlTotals(dataSetCode, controlTotalsID);
		
		return resultModel;
	}
	
	/**
	 * @param dataSetCode
	 * @param bookCodeID
	 * @param currencyID
	 * @param encodingUnitCode
	 * @param controlTotalsID
	 * @param batchSheetType
	 * @param request
	 * @return
	 * @throws QueryException
	 * @throws Exception
	 */
	@RequestMapping(value="/controltotals/autocomputed/{dataSetCode}/{bookCodeID}/{currencyID}/"
			+ "{encodingUnitCode}/{controlTotalsID}/{batchSheetType}", method=RequestMethod.GET)
	public Object doQueryAutoComputedControlTotals(@PathVariable("dataSetCode")String dataSetCode,
			@PathVariable("bookCodeID")long bookCodeID, @PathVariable("currencyID")long currencyID, 
				@PathVariable("encodingUnitCode")String encodingUnitCode, @PathVariable("controlTotalsID")long controlTotalsID, 
				@PathVariable("batchSheetType")String batchSheetType,
					HttpServletRequest request) throws QueryException, Exception{
		System.out.println("doQueryAutoComputedControlTotals()");
		
		ResultModel resultModel = queryService.doQueryAutoComputedControlTotals(dataSetCode, controlTotalsID, bookCodeID, currencyID, 
				UserSession.getActiveAuthority().getGroup().getCode(), encodingUnitCode, UserSession.getUsername(), batchSheetType);
		
		return resultModel;
	}	
	
}
