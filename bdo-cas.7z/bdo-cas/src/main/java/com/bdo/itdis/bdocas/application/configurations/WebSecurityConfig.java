package com.bdo.itdis.bdocas.application.configurations;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.security.core.session.SessionRegistryImpl;
import org.springframework.security.web.authentication.Http403ForbiddenEntryPoint;
import org.springframework.security.web.csrf.CsrfFilter;
import org.springframework.security.web.csrf.CsrfTokenRepository;
import org.springframework.security.web.csrf.HttpSessionCsrfTokenRepository;
import org.springframework.security.web.session.HttpSessionEventPublisher;

import com.bdo.itd.util.logger.LoggerUtility;
import com.bdo.itd.util.logger.LoggerUtilityFactory;
import com.bdo.itd.util.security.application.SpringSecurityAuthenticationProvider;
import com.bdo.itd.util.security.infrastructure.services.authentication.handlers.CustomAuthenticationFailureHandler;
import com.bdo.itd.util.security.infrastructure.services.authentication.handlers.CustomAuthenticationSuccessHandler;
import com.bdo.itd.util.security.infrastructure.utils.csrf.CsrfHeaderFilter;

@EnableWebSecurity
@Configuration
public class WebSecurityConfig extends WebSecurityConfigurerAdapter{
	
	@Autowired
	private SpringSecurityAuthenticationProvider authenticationProvider;
	
	@Autowired
	private CustomAuthenticationSuccessHandler successHandler;
	
	@Autowired
	private CustomAuthenticationFailureHandler failureHandler;
	
	private static final LoggerUtility logger = 
			LoggerUtilityFactory.createLoggerUtility(WebSecurityConfig.class);	
	
//	@Autowired
//	@Named("dataAccessService")
//	private DataAccessInterface dataAccessService;
//	
//	@Value("$eua.authenticatiourl")
//	private String authenticationUrl;
//	
//	@Value("${eua.domain}")
//	private String domain;
//	
//	@Value("${eua.application-code}")
//	private String applicationCode;
//	
//	@Value("${eua.hostname}")
//	private String hostname;
//	
//	@Value("${eua.userid}")
//	private String userid;
//	
//	@Value("${eua.credentials}")
//	private String credentials;
//	
//	@Value("${eua.key}")
//	private String key;
//	
//	@Value("${eua.keyspecs}")
//	private String keyspecs;
//	
//	@Value("${eua.algorithm}")
//	private String algorithm;
//	
//	@Value("${eua.result-type}")
//	private ResultType resultType;
	
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http
			.authorizeRequests()
				.antMatchers("/webjars/**", "/app/**", "/assets/**", "/login*", "/", "/#/**", "/controlcenter/*", "/rmf/**", "/sessionTimeOut*", "/endpoint/**").permitAll()
				.anyRequest().authenticated()
				.and()
			.csrf().csrfTokenRepository(this.csrfTokenRepository())
				.and()
			.addFilterAfter(new CsrfHeaderFilter(), CsrfFilter.class)
			.sessionManagement()
				.maximumSessions(1)
				.maxSessionsPreventsLogin(true)
				.and()
				.enableSessionUrlRewriting(false)
				.sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED)
				.sessionFixation().migrateSession()
				.invalidSessionUrl("/")
				.sessionAuthenticationErrorUrl("/sessionTimeOut")
				.and()
			.formLogin()
				.loginPage("/")
				.loginProcessingUrl("/login")
				.usernameParameter("username")
				.passwordParameter("password")
				.successHandler(successHandler)
				.failureHandler(failureHandler)
				.and()
			.logout();
		
		http.exceptionHandling().authenticationEntryPoint(new Http403ForbiddenEntryPoint());
	}

	@Autowired
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.authenticationProvider(authenticationProvider);
		logger.info(authenticationProvider.getClass().toString());
	}	
	
	private CsrfTokenRepository csrfTokenRepository(){
		HttpSessionCsrfTokenRepository repository = new HttpSessionCsrfTokenRepository();
		repository.setHeaderName("X-XSRF-TOKEN");
		
		return repository;
	}
	
	@Bean
	public HttpSessionEventPublisher httpSessionEventPublisher(){
		return new HttpSessionEventPublisher();
	}
	
	@Bean
	public SessionRegistry sessionRegistry(){
		return new SessionRegistryImpl();
	}
}
