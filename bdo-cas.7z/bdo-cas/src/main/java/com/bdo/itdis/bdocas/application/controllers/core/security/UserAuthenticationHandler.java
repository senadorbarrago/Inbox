package com.bdo.itdis.bdocas.application.controllers.core.security;

import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.logger.LoggerUtility;
import com.bdo.itd.util.logger.LoggerUtilityFactory;
import com.bdo.itdis.bdocas.application.controllers.AbstractController;


/**
 * 
 * @author a014000098
 *
 */
@RestController("userAuthenticationHandler")
public class UserAuthenticationHandler extends AbstractController {

	/**
	 * 
	 */
	private static final LoggerUtility LOGGER = 
			LoggerUtilityFactory.createLoggerUtility(UserAuthenticationHandler.class);
	
	/**
	 * 
	 * @throws Exception
	 */
	@RequestMapping(
			value="/loginSuccess",
			method=RequestMethod.GET)
	public void loginSuccess(HttpServletResponse response) throws Exception {		
		LOGGER.info("Login success. Routing request to /home");
				
		response.setHeader("defaultSuccessUrl", "/home");
		response.setStatus(HttpStatus.OK.value());
	}
	
	/**
	 * 
	 * @throws Exception
	 */
	@RequestMapping(
			value="/logoutSuccess",
			method=RequestMethod.GET)
	public void logoutSuccess(HttpServletResponse response) throws Exception {
		LOGGER.info("Logout success. Routing request to /");		
				
		response.setHeader("defaultSuccessUrl", "/");
		response.setStatus(HttpStatus.OK.value());
	}
	
	/**
	 * 
	 * @throws Exception
	 */
	@RequestMapping(
			value="/loginFailure",
			method=RequestMethod.GET)
	public void loginFailure(HttpServletResponse response) throws Exception {		
		LOGGER.info("Login failed. Routing request to /");
		
		response.setHeader("defaultFailureUrl", "/");
		response.setStatus(HttpStatus.OK.value());				
	}
	
}
