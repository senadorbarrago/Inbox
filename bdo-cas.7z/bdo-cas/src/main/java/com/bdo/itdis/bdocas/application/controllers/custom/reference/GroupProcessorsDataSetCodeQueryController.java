/**
 * 
 */
package com.bdo.itdis.bdocas.application.controllers.custom.reference;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.security.application.UserSession;
import com.bdo.itdis.bdocas.application.controllers.custom.reference.utils.IReferenceService;

/**
 * @author c150819004
 *
 */
@RestController
public class GroupProcessorsDataSetCodeQueryController {

	private final IReferenceService referenceService;

	@Inject
	public GroupProcessorsDataSetCodeQueryController(
			IReferenceService referenceService) {
		super();
		this.referenceService = referenceService;
	}
	
	@RequestMapping(value="/references/groupProcessors/{dataSetCode}", method=RequestMethod.GET)
	public Object doQuery(@PathVariable("dataSetCode")String dataSetCode, HttpServletRequest request){
		
		System.out.println("dataSetCode: "+dataSetCode);
		System.out.println("membershipID: "+UserSession.getActiveAuthority().getMembershipID());
		
		List<Object> paramList = new ArrayList<>();
		paramList.add(dataSetCode);
		paramList.add(UserSession.getActiveAuthority().getMembershipID());
		
		return referenceService.getReferenceWithCode("dbo.spGetProcessorsPerGroupByMembershipID ?,?", paramList);
	}
}
