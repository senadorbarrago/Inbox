/**
 * 
 */
package com.bdo.itdis.bdocas.application.controllers.custom.transaction;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.crqs.command.CommandMessage;
import com.bdo.itd.util.crqs.command.ICommandBus;
import com.bdo.itd.util.security.application.UserSession;
import com.bdo.itdis.bdocas.application.controllers.AbstractController;
import com.bdo.itdis.bdocas.transactions.application.command.RateSetupCommand;

/**
 * @author c150819004
 *
 */
@RestController
public class RateMaintenanceController extends AbstractController{
	
	private final ICommandBus commandBus;
	
	@Inject
	public RateMaintenanceController(@Named("transactionManagementCommandBus") ICommandBus commandBus) {
		super();
		this.commandBus = commandBus;
	}
	
	@RequestMapping(value="/transactions/rate/setup", consumes=MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.POST)
	public Object doSetupRate(@RequestBody Map<String, Object> data, HttpServletRequest request) throws Exception{
		
		System.out.println("doSetupRate()");
		System.out.println("Data:" + data);
		
		String rateActionTag = data.get("rateActionTag").toString();
		long datasetID = Long.valueOf(data.get("dataSetID").toString());
		long currencyID = Long.valueOf(data.get("currencyID").toString());
		SimpleDateFormat sdfGlDate = new SimpleDateFormat("yyyy-MM-dd");
		Date glDate = sdfGlDate.parse(data.get("glDate").toString());
		double pesoRate = Double.valueOf(data.get("pesoRate").toString());
		double usdRate = Double.valueOf(data.get("usdRate").toString());
		long rateID = Long.valueOf(data.get("rateID").toString());
		
		CommandMessage message = new CommandMessage();
		RateSetupCommand command = new RateSetupCommand(rateActionTag, rateID, datasetID, currencyID, glDate, pesoRate, usdRate);
		command.setUsername(UserSession.getUsername());
		command.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
		command.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());
		
		message = commandBus.doPublish(command);
		
		return message;
	}
}
