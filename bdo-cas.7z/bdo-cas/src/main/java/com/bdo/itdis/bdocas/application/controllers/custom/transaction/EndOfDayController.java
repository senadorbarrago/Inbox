package com.bdo.itdis.bdocas.application.controllers.custom.transaction;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.crqs.command.CommandMessage;
import com.bdo.itd.util.crqs.command.ICommandBus;
import com.bdo.itd.util.security.application.UserSession;
import com.bdo.itdis.bdocas.transactions.application.command.EndOfDayCommand;
import com.bdo.itdis.bdocas.transactions.application.query.values.IEndOfDayQueryService;


@RestController
public class EndOfDayController {
	
	private final ICommandBus commandBus;
	private final IEndOfDayQueryService queryService;
	
	@Inject
	public EndOfDayController(@Named("transactionManagementCommandBus")ICommandBus commandBus,
			@Named("endOfDayQueryService") IEndOfDayQueryService queryService) {
		super();
		this.commandBus = commandBus;
		this.queryService = queryService;
	}
	
	@RequestMapping(value="/transactions/endOfDay/save", consumes=MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.POST)
	public Object doSetEndOfDay(@RequestBody Map<String, Object> form, HttpServletRequest request)throws Exception{
		System.out.println("doSetEndOfDay()");
		
		CommandMessage message = new CommandMessage();
		
		EndOfDayCommand command = new EndOfDayCommand();
		command.setDatasetID(Long.parseLong(form.get("dataSetID").toString()));
		command.setProcessID(queryService.doGetProcessID(command.getDatasetID()));
		System.out.println("ProcessID: "+command.getProcessID());
		
		SimpleDateFormat sdfGlDate = new SimpleDateFormat("yyyy-MM-dd");
		Date glDate = sdfGlDate.parse(form.get("previousProcessingDate").toString());
		command.setGlDate(glDate);
		
		command.setUsername(UserSession.getUsername());
		command.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
		command.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());
		command.setMembershipID(UserSession.getActiveAuthority().getMembershipID());
		
		System.out.println("MembershipID: "+command.getMembershipID());
		
//		form.put("userName", UserSession.getUsername());
//		form.put("dataset", form.get("dataSetID"));
//		form.put("datasetCode", form.get("dataSetCode"));
//		form.put("processingDate", form.get("currentGlDate"));
//		form.put("encodingUnit", form.get("encodingUnit"));
//		form.put("reportCriteria", form.get("reportCriteria"));
		
		System.out.println("Report Data: " + form);
		
		command.setParams(form);
		message = commandBus.doPublish(command);
	
		return message;
	}
	
	@RequestMapping(value="/transactions/endOfDay/processID/{dataSetID}", method=RequestMethod.GET)
	public Object doGetProcessID(@PathVariable("dataSetID")Long dataSetID, HttpServletRequest request){
		System.out.println("dataSetID: "+dataSetID);
		Long processID = 0L;
		try{
			processID = queryService.doGetProcessID(dataSetID);
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return "{\"processID\" : \""+processID+"\"}";
	}
	
	@RequestMapping(value="/transactions/endOfDay/encodingUnit/{id}", method=RequestMethod.GET)
	public Object doGetEncodingUnit(@PathVariable("id")Long id, HttpServletRequest request){
		System.out.println("CostCenterID : "+id);
		String encodingUnit = null;
		
		try{
			encodingUnit = queryService.doGetEncodingUnitByID(id);
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return "{\"encodingUnit\" : \""+encodingUnit+"\"}";
	}
	@ExceptionHandler(Exception.class)
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public Object handlegenericException(HttpServletResponse response, Exception ex){
		Map<String, String> messageMap = new HashMap<>();
		messageMap.put("errorMsg", ex.getMessage());
		
		return  messageMap;
	}
	
}
