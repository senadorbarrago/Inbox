package com.bdo.itdis.bdocas.application.controllers.custom.reference;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itdis.bdocas.application.controllers.custom.reference.utils.IReferenceService;

@RestController
public class DebitTypeQueryController {
	
	private final IReferenceService referenceService;
	
	@Inject
	public DebitTypeQueryController(@Named("referenceService")IReferenceService referenceService) {
		super();
		this.referenceService = referenceService;
	}
	
	@RequestMapping(value="/references/debitType/{dataSetCode}", method=RequestMethod.GET)
	public Object doQuery(@PathVariable("dataSetCode")String dataSetCode, HttpServletRequest request){
		
		
		List<Object> paramList = new ArrayList<>();
		paramList.add(dataSetCode);
		
		return referenceService.getReferenceWithCode("dbo.spGetDebitTypeByDataSet ?", paramList);
	}
}
