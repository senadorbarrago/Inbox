package com.bdo.itdis.bdocas.application.controllers.core.cqrs;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itdis.bdocas.application.controllers.AbstractController;

/**
 * 
 * @author a014000098
 *
 */
@RestController("commandRequestController")
@RequestMapping("/cmd")
public class CommandRequestController extends AbstractController {

//	/**
//	 * 
//	 */
//	@Autowired
//	private ICommandBus commandBus;
//	
//	/**
//	 * 
//	 * @return
//	 */
//	@RequestMapping(method={
//			RequestMethod.GET, 
//			RequestMethod.DELETE, 
//			RequestMethod.PUT, 
//			RequestMethod.POST})
//	public Object handleCommandRequest(@RequestBody Map<String, Object> parameters) {
//		
//		String name = (String) parameters.get("commandName");	
//		
//		ICommand command = CommandFactory.create(name, parameters);
//		
//		CommandMessage message = commandBus.doPublish(command);
//						
//		return ResultMapBuilder
//				.instance()
//				.addAll(Collections.unmodifiableMap(message.getMessageMap()))
//				.build()				
//				.map();
//	}

}
