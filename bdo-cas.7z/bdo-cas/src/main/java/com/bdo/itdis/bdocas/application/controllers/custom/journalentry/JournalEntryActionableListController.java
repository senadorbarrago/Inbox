package com.bdo.itdis.bdocas.application.controllers.custom.journalentry;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.cqrs.query.QueryException;
import com.bdo.itd.util.crqs.command.CommandException;
import com.bdo.itd.util.crqs.command.ICommandBus;
import com.bdo.itd.util.security.application.UserSession;
import com.bdo.itdis.bdocas.application.controllers.AbstractController;
import com.bdo.itdis.bdocas.journalentry.application.command.ApproveJournalEntryCommand;
import com.bdo.itdis.bdocas.journalentry.application.command.DeleteJournalEntryCommand;
import com.bdo.itdis.bdocas.journalentry.application.command.DenyJournalEntryCommand;
import com.bdo.itdis.bdocas.journalentry.application.command.SubmitJournalEntryCommand;
import com.bdo.itdis.bdocas.journalentry.application.query.dto.searchcriteria.SearchCriteria;
import com.bdo.itdis.bdocas.journalentry.application.query.lists.IJournalEntryActionableQueryService;


@RestController
public class JournalEntryActionableListController extends AbstractController{
	
	private final IJournalEntryActionableQueryService journalEntryActionableQueryService;
	private ICommandBus commandBus;
	
	@Inject
	public JournalEntryActionableListController(@Named("journalEntryActionableQueryService")IJournalEntryActionableQueryService journalEntryActionableQueryService,
			@Named("journalEntryManagementCommandBus") ICommandBus commandBus) {
		super();
		this.journalEntryActionableQueryService = journalEntryActionableQueryService;
		this.commandBus = commandBus;
	}
	
	@RequestMapping(value="/journalentry/actionable/{dataSetID}/{pageIndex}/{pageSize}/", method=RequestMethod.POST)
	public Object doQueryActionableList(@PathVariable("dataSetID")long dataSetID, @PathVariable("pageIndex")int pageIndex, 
			@PathVariable("pageSize")int pageSize, @RequestBody Map<String, Object> searchcriteria, HttpServletRequest request)
				throws QueryException{
		System.out.println("doQueryActionableList()");
		
		return journalEntryActionableQueryService.doQuery(convertToXML(searchcriteria, pageIndex, pageSize), dataSetID, UserSession.getUsername(), 
				UserSession.getActiveAuthority().getMembershipID(), pageIndex, pageSize);
	}
	
	@RequestMapping(value="/journalentry/submit", consumes=MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.POST)
	public Object submitForm(@RequestBody List<String> batchIDs, HttpServletRequest request) throws CommandException{		
		SubmitJournalEntryCommand command = new SubmitJournalEntryCommand();
		
		command.setJournalEntryIDList(batchIDs);
		command.setUsername(UserSession.getUsername());
		command.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
		command.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());
		command.setMembershipID(UserSession.getActiveAuthority().getMembershipID());
		
		return commandBus.doPublish(command);
	}
	
	@RequestMapping(value="/journalentry/approve", consumes=MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.POST)
	public Object approveForm(@RequestBody List<String> batchIDs, HttpServletRequest request) throws CommandException{		
		ApproveJournalEntryCommand command = new ApproveJournalEntryCommand();
		
		command.setJournalEntryIDList(batchIDs);
		command.setUsername(UserSession.getUsername());
		command.setMembershipID(UserSession.getActiveAuthority().getMembershipID());
		
		return commandBus.doPublish(command);
	}
	
	@RequestMapping(value="/journalentry/deny", consumes=MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.POST)
	public Object denyForm(@RequestBody List<String> batchIDs, HttpServletRequest request)throws CommandException{		
		DenyJournalEntryCommand command = new DenyJournalEntryCommand();
		
		command.setJournalEntryIDList(batchIDs);
		command.setUsername(UserSession.getUsername());
		command.setMembershipID(UserSession.getActiveAuthority().getMembershipID());
		
		return commandBus.doPublish(command);
	}
	
	@RequestMapping(value="/journalentry/delete", consumes=MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.POST)
	public Object deleteForm(@RequestBody List<String> batchIDs, HttpServletRequest request)throws CommandException{		
		DeleteJournalEntryCommand command = new DeleteJournalEntryCommand();
		
		command.setJournalEntryIDList(batchIDs);
		command.setUsername(UserSession.getUsername());
		command.setMembershipID(UserSession.getActiveAuthority().getMembershipID());
		
		return commandBus.doPublish(command);
	}
	
	@SuppressWarnings("unchecked")
	private String convertToXML(Map<String, Object> searchCriteriaData, int pageIndex, int pageSize){
		List<Map<String, Object>> filterFields = new ArrayList<>();
		if(searchCriteriaData.get("filterList") != null){
			filterFields = (ArrayList<Map<String, Object>>)searchCriteriaData.get("filterList");
		}
		
		List<Map<String, Object>> sortFields = new ArrayList<>();
		if(searchCriteriaData.get("sortList") != null){
			sortFields = (ArrayList<Map<String, Object>>)searchCriteriaData.get("sortList");
		}
		
		SearchCriteria searchCriteria = new SearchCriteria(filterFields, sortFields, pageIndex, pageSize);		
		
		return searchCriteria.convertSearchCriteriaToXML();
	}
	
}
