package com.bdo.itdis.bdocas.application.controllers.custom.reference.utils;

/**
 *
 * @author SENADOR BARRAGO
 */
public class DTOReferenceHolder {

    private long id;
    private String desc;
    private String code;
    private String additionalDetail;
    
    public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	
	public String getAdditionalDetail() {
		return additionalDetail;
	}

	public void setAdditionalDetail(String additionalDetail) {
		this.additionalDetail = additionalDetail;
	}

	@Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("\"id\": ").append(this.getId()).append(", ")
          .append("\"desc\": \"").append(this.getDesc()).append("\"");
        
        return sb.toString();
    }
    
}
