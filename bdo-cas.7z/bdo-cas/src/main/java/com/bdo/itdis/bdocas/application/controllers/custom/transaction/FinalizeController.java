package com.bdo.itdis.bdocas.application.controllers.custom.transaction;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.crqs.command.CommandException;
import com.bdo.itd.util.crqs.command.ICommandBus;
import com.bdo.itd.util.security.application.UserSession;
import com.bdo.itdis.bdocas.application.controllers.AbstractController;
import com.bdo.itdis.bdocas.transactions.application.command.FinalizeTransactionCommand;
import com.bdo.itdis.bdocas.transactions.application.query.values.IFinalizeQueryService;

@RestController
public class FinalizeController extends AbstractController{
	
	private final ICommandBus commandBus;
	private final IFinalizeQueryService queryService;;
	
	@Inject
	public FinalizeController(@Named("transactionManagementCommandBus")ICommandBus commandBus,
			@Named("finalizeQueryService") IFinalizeQueryService queryService) {
		super();
		this.commandBus = commandBus;
		this.queryService = queryService;
	}
	
	@RequestMapping(value="/transactions/finalize/save", consumes=MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.POST)
	public Object doFinalize(@RequestBody Map<String, Object> data, HttpServletRequest request)throws CommandException, Exception{
		FinalizeTransactionCommand command = new FinalizeTransactionCommand();
		
		command.setDatasetID(Long.parseLong(data.get("dataSetID").toString()));
		command.setDataSetCode(data.get("dataSetCode").toString());
		command.setEncodingUnitCode(data.get("encodingUnitCode").toString());
		
		SimpleDateFormat sdfGlDate = new SimpleDateFormat("yyyy-MM-dd");
		Date glDate = sdfGlDate.parse(data.get("currentProcessingDate").toString());
		command.setGlDate(glDate);
		
		command.setUsername(UserSession.getUsername());
		command.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
		command.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());
		command.setMembershipID(UserSession.getActiveAuthority().getMembershipID());
	
		return commandBus.doPublish(command);
	}
	
	@RequestMapping(value="/transactions/finalize/currentProcessingDate/{dataSetID}/{costCenterID}", method=RequestMethod.GET)
	public Object doGetCurrentProcessingDate(@PathVariable("dataSetID")Long dataSetID, @PathVariable("costCenterID")Long costCenterID, 
			HttpServletRequest request){
		System.out.println("dataSetID: "+dataSetID);
		System.out.println("costCenterID: "+costCenterID);
		String currentProcessingDate = "";
		try{
			currentProcessingDate = queryService.doGetGLDatePerCostCenter(dataSetID, costCenterID);
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return "{\"currentProcessingDate\" : \""+currentProcessingDate+"\"}";
	}
}
