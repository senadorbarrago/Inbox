package com.bdo.itdis.bdocas.application.controllers.custom.reference;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itdis.bdocas.journalentry.application.query.dto.form.DTORecord;
import com.bdo.itdis.bdocas.journalentry.application.query.forms.IJournalEntryFormQueryService;

@RestController
public class PredefinedEntriesQueryController {
	
	private final IJournalEntryFormQueryService journalEntryFormQueryService;
	
	@Inject
	public PredefinedEntriesQueryController(@Named("journalEntryFormQueryService")
	IJournalEntryFormQueryService journalEntryFormQueryService) {
		super();
		this.journalEntryFormQueryService = journalEntryFormQueryService;
	}
	
	@RequestMapping(value="/references/predefinedEntries/{dataSetID}/{predefID}", method=RequestMethod.GET)
	public Object doQuery(@PathVariable("dataSetID")Long dataSetID, @PathVariable("predefID")Long predefID,
			HttpServletRequest request){
		System.out.println("predefID: "+predefID);		
		System.out.println("dataSetID: "+dataSetID);
		
		List<DTORecord> predefRecords = new ArrayList<>();
		try{
			predefRecords  = journalEntryFormQueryService.generatePredefinedEntries(dataSetID, predefID);
			
			Set<String> keySet = predefRecords.get(0).getRecordFieldMap().keySet();
			System.out.println("Predefined Entries:");
			for(DTORecord record : predefRecords){
				for(String key : keySet){
					System.out.println("key: "+key+" - value: "+record.getRecordFieldMap().get(key).getValue());
				}
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
		
		return predefRecords;
	}
}
