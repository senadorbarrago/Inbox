package com.bdo.itdis.bdocas.application.controllers.custom.otheradjustments;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.cqrs.query.QueryException;
import com.bdo.itd.util.cqrs.query.ResultModel;
import com.bdo.itd.util.crqs.command.CommandException;
import com.bdo.itd.util.crqs.command.CommandMessage;
import com.bdo.itd.util.crqs.command.ICommandBus;
import com.bdo.itd.util.security.application.UserSession;
import com.bdo.itdis.bdocas.application.controllers.AbstractController;
import com.bdo.itdis.bdocas.controltotals.application.command.DeleteOtherAdjustmentCommand;
import com.bdo.itdis.bdocas.controltotals.application.query.IOtherAdjustmentsQueryService;

/**
 * 
 * @author c140618008
 *
 */
@RestController
@RequestMapping("/otheradjustments")
public class OtherAdjustmentsController extends AbstractController{
	
	/**
	 * 
	 */
	private final ICommandBus commandBus;
	/**
	 * 
	 */
	private final IOtherAdjustmentsQueryService queryService;
	
	/**
	 * 
	 * @param commandBus
	 * @param queryService
	 */
	@Inject
	public OtherAdjustmentsController(@Named("controlTotalsCommandBus")ICommandBus commandBus, 
			@Named("otherAdjustmentsQueryService")IOtherAdjustmentsQueryService queryService) {
		super();
		this.commandBus = commandBus;
		this.queryService = queryService;
	}
	
	/**
	 * 
	 * @param command
	 * @param request
	 * @return
	 * @throws CommandException
	 * @throws Exception
	 */
	@RequestMapping(value="/remove/", method=RequestMethod.POST)
	public Object doUpdate(@RequestBody DeleteOtherAdjustmentCommand command, HttpServletRequest request)
		throws CommandException, Exception{

		CommandMessage message = new CommandMessage();
		command.setUsername(UserSession.getUsername());
		command.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
		command.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());
		
		message = commandBus.doPublish(command);
		
		return message;
	}
	
	/**
	 * 
	 * @param controlTotalsID
	 * @param request
	 * @return
	 * @throws QueryException
	 */
	@RequestMapping(value="/details/{controlTotalsID}", method=RequestMethod.GET)
	public Object doQueryOtherAdjustmentsByControlTotalsID(@PathVariable("controlTotalsID")long controlTotalsID,
			HttpServletRequest request) throws QueryException{
		ResultModel resultModel = null;
		
		resultModel = queryService.doQueryOtherAdjustmentsByControlTotalsID(controlTotalsID);
		
		return resultModel;
	}
	
	/**
	 * 
	 * @param dataSetCode
	 * @param controlTotalsID
	 * @param request
	 * @return
	 * @throws QueryException
	 */
	@RequestMapping(value="/summary/{dataSetCode}/{controlTotalsID}", method=RequestMethod.GET)
	public Object doQueryOtherAdjustmentSummaryByControlTotalsID(@PathVariable("dataSetCode")String dataSetCode,
			@PathVariable("controlTotalsID")long controlTotalsID, HttpServletRequest request) throws QueryException{
		ResultModel resultModel = null;
		
		resultModel = queryService.doQueryOtherAdjustmentSummarysByControlTotalsID(dataSetCode, controlTotalsID);
		
		return resultModel;
	}
}
