package com.bdo.itdis.bdocas.application.controllers.custom.transaction;

import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.cqrs.query.ResultModel;
import com.bdo.itd.util.crqs.command.CommandException;
import com.bdo.itd.util.crqs.command.CommandMessage;
import com.bdo.itd.util.crqs.command.ICommandBus;
import com.bdo.itdis.bdocas.transactions.application.command.PredefinedEntriesBindingSetupCommand;
import com.bdo.itdis.bdocas.transactions.application.command.PredefinedEntriesClientCodeSetupCommand;
import com.bdo.itdis.bdocas.transactions.application.command.PredefinedEntriesDefinitionSetupCommand;
import com.bdo.itdis.bdocas.transactions.application.command.PredefinedEntriesSetupCommand;
import com.bdo.itdis.bdocas.transactions.application.query.list.IPredefinedEntriesClientCodeQueryService;
import com.bdo.itdis.bdocas.transactions.application.query.list.IPredefinedEntriesDefinitionQueryService;
import com.bdo.itdis.bdocas.transactions.application.query.list.IPredefinedEntriesQueryService;

@RestController
public class PredefinedEntriesController {
	
	private final ICommandBus commandBus;
	private final IPredefinedEntriesDefinitionQueryService predefinedEntriesDefinitionQueryService;
	private final IPredefinedEntriesQueryService predefinedEntriesQueryService;
	private final IPredefinedEntriesClientCodeQueryService predefinedEntriesClientCodeQueryService;
	
	@Inject
	public PredefinedEntriesController(
			@Named("transactionManagementCommandBus")ICommandBus commandBus,
			@Named("predefinedEntriesDefinitionQueryService") IPredefinedEntriesDefinitionQueryService predefinedEntriesDefinitionQueryService,
			@Named("predefinedEntriesQueryService") IPredefinedEntriesQueryService predefinedEntriesQueryService,
			@Named("predefinedEntriesClientCodeQueryService") IPredefinedEntriesClientCodeQueryService predefinedEntriesClientCodeQueryService) {
		super();
		this.commandBus = commandBus;
		this.predefinedEntriesDefinitionQueryService = predefinedEntriesDefinitionQueryService;
		this.predefinedEntriesQueryService = predefinedEntriesQueryService;
		this.predefinedEntriesClientCodeQueryService =predefinedEntriesClientCodeQueryService;
	}
	
	@RequestMapping(value="/transactions/predefinedEntries/{currencyCode}/{pdeTypeCode}", method=RequestMethod.GET)
	public Object doGetPredefinedEntries(@PathVariable("currencyCode")String currencyCode, @PathVariable("pdeTypeCode")String pdeTypeCode,
			HttpServletRequest request) throws Exception{
		ResultModel resultModel  = predefinedEntriesQueryService.doGetPredefinedEntries(currencyCode, pdeTypeCode);
		return resultModel;
	}
	
	@RequestMapping(value="/transactions/predefinedEntries/predefinedEntriesDefinition/{dataSetCode}/{predefinedEntryID}", method=RequestMethod.GET)
	public Object doGetPredefinedEntriesDefinitionList(@PathVariable("dataSetCode")String dataSetCode,
			@PathVariable("predefinedEntryID")Long predefinedEntryID, 
			HttpServletRequest request) throws Exception{
		
		ResultModel resultModel  = predefinedEntriesDefinitionQueryService.doGetPredefinedEntriesDefinition(dataSetCode, predefinedEntryID);
		return resultModel;
	}
	
	@RequestMapping(value="/transactions/predefinedEntries/predefinedEntriesClientCode/{dataSetCode}/{predefinedEntryID}", method=RequestMethod.GET)
	public Object doGetPredefinedEntriesClientCodeList(@PathVariable("dataSetCode")String dataSetCode,
			@PathVariable("predefinedEntryID")Long predefinedEntryID, 
			HttpServletRequest request) throws Exception{
		
		ResultModel resultModel  = predefinedEntriesClientCodeQueryService.doGetPredefinedEntriesClientCode(dataSetCode, predefinedEntryID);
		return resultModel;
	}
	
	@RequestMapping(value="/transactions/predefinedEntries/predefinedEntriesDefinitionValue/{dataFieldCode}", method=RequestMethod.GET)
	public Object doGetPredefinedEntriesDefinitionMappedValue(@PathVariable("dataFieldCode")String dataFieldCode, HttpServletRequest request) throws Exception{
		ResultModel resultModel  = predefinedEntriesDefinitionQueryService.doGetPredefinedEntriesDefinitionValue(dataFieldCode);
		return resultModel;
	}
	
	@RequestMapping(value="/transactions/predefinedEntriesDefinition/setup", consumes=MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.POST)
	public Object doSetupPredefinedEntryDefinition(@RequestBody Map<String, Object> data, HttpServletRequest request) throws Exception{
		
		System.out.println("doSetupPredefinedEntriesDefinitionValue()");
		System.out.println("Data:" + data);
		
		String pdeActionTag = data.get("pdeActionTag").toString();
		long pdedID = Long.valueOf(data.get("pdedID").toString());
		long predefinedEntriesID = Long.valueOf(data.get("predefinedEntriesID").toString());
		int recordNo = Integer.valueOf(data.get("recordNo").toString());
		String journalFieldCode = data.get("journalFieldCode").toString();
		String value = data.get("value").toString();
		
		CommandMessage message = new CommandMessage();
		PredefinedEntriesDefinitionSetupCommand command = new PredefinedEntriesDefinitionSetupCommand(pdeActionTag, pdedID, predefinedEntriesID, recordNo, journalFieldCode, value);
		
		message = commandBus.doPublish(command);
		
		return message;
	}
	
	@RequestMapping(value="/transactions/predefinedEntries/setup", consumes=MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.POST)
	public Object doSetupPredefinedEntry(@RequestBody Map<String, Object> data, HttpServletRequest request) throws Exception{
		
		System.out.println("doSetupPredefinedEntriesValue()");
		System.out.println("Data:" + data);
		
		String pdeActionTag = data.get("pdeActionTag").toString();
		long predefinedEntriesID = Long.valueOf(data.get("predefinedEntryID").toString());
		String bookCode = data.get("bookCode").toString();
		String currencyCode = data.get("currencyCode").toString();
		String dataSetCode = data.get("dataSetCode").toString();
		String description = data.get("pdeDesc").toString();
		String pdeDetail = data.get("pdeDetail").toString();
		String pdeType = data.get("pdeType").toString();
		
		CommandMessage message = new CommandMessage();
		PredefinedEntriesSetupCommand command = new PredefinedEntriesSetupCommand(pdeActionTag, predefinedEntriesID, bookCode, 
				currencyCode, dataSetCode, description, pdeDetail, pdeType);
		
		message = commandBus.doPublish(command);
		
		return message;
	}
	
	@RequestMapping(value="/transactions/predefinedEntriesClientCode/setup", consumes=MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.POST)
	public Object doSetupPredefinedEntryClientCode(@RequestBody Map<String, Object> data, HttpServletRequest request) throws Exception{
		
		System.out.println("doSetupPredefinedEntriesClientCode()");
		System.out.println("Data:" + data);
		
		long mapID = Long.valueOf(data.get("id").toString());
		String actionTag = data.get("actionTag").toString();
		long predefinedEntriesID = Long.valueOf(data.get("predefinedEntriesID").toString());
		long clientCodeID = Long.valueOf(data.get("clientCodeID").toString());
		
		CommandMessage message = new CommandMessage();
		PredefinedEntriesClientCodeSetupCommand command = new PredefinedEntriesClientCodeSetupCommand(mapID, actionTag, predefinedEntriesID, clientCodeID);
		
		message = commandBus.doPublish(command);
		
		return message;
	}
	
	@RequestMapping(value="/transactions/predefinedEntriesBinding/setup", consumes=MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.POST)
	public Object doSetupPredefinedEntryBinding(@RequestBody Map<String, Object> data, HttpServletRequest request) throws Exception{
		
		System.out.println("doSetupPredefinedEntriesBinding()");
		System.out.println("Data:" + data);
		
		long mapID = Long.valueOf(data.get("id").toString());
		String actionTag = data.get("actionTag").toString();
		long predefinedEntriesID = Long.valueOf(data.get("predefinedEntriesID").toString());
		long recordProfileID = Long.valueOf(data.get("recordProfileID").toString());
		long dataFieldColumnID = Long.valueOf(data.get("dataFieldColumnID").toString());
		
		CommandMessage message = new CommandMessage();
		PredefinedEntriesBindingSetupCommand command = new PredefinedEntriesBindingSetupCommand(mapID, actionTag, 
				predefinedEntriesID, recordProfileID, dataFieldColumnID);
		
		message = commandBus.doPublish(command);
		
		return message;
	}
	
	@ExceptionHandler(CommandException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	public Object handleCommandException(HttpServletResponse response, Exception ex){
		Map<String, String> messageMap = new HashMap<>();
		messageMap.put("errorMsg", ex.getMessage());
		
		return  messageMap;
	}
	
	@ExceptionHandler(Exception.class)
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public Object handlegenericException(HttpServletResponse response, Exception ex){
		Map<String, String> messageMap = new HashMap<>();
		messageMap.put("errorMsg", ex.getMessage());
		
		return  messageMap;
	}
	
}
