package com.bdo.itdis.bdocas.application.controllers.custom.reference.utils;


import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;

import com.bdo.itd.util.persistence.DataAccessInterface;

/**
 *
 * @author SENADOR BARRAGO
 */
@Named("referenceService")
public class ReferenceService implements IReferenceService{

    private final DataAccessInterface das;
    
    @Inject
    public ReferenceService(@Named("dataAccessService")DataAccessInterface das) {
        this.das = das;
    }
    
    @Override
    public List<DTOReferenceHolder> getReference(String query) {
        List<LinkedHashMap<String, Object>> list;
        List<DTOReferenceHolder> ret = new ArrayList<>();
        list = das.executeSQLQuery(query);

        if (list != null && !list.isEmpty()) {
            for (Map<String, Object> map : list) {
                DTOReferenceHolder ref = new DTOReferenceHolder();
                ref.setId((Long)map.get("id"));
                ref.setDesc(map.get("descr").toString().trim());
                ret.add(ref);
            }
        }
        return ret;

    }
    
    @Override
    public List<DTOReferenceHolder> getReference(String query, List<Object> param) {
        List<LinkedHashMap<String, Object>> list;
        List<DTOReferenceHolder> ret = new ArrayList<>();
        list = das.executeSQLQuery(query, param.toArray());

        if (list != null && !list.isEmpty()) {
            for (Map<String, Object> map : list) {
                DTOReferenceHolder ref = new DTOReferenceHolder();
                ref.setId((Long)map.get("id"));
                ref.setDesc(map.get("descr").toString().trim());
                ret.add(ref);
            }
        }
        return ret;
    }
    
    @Override
    public List<DTOReferenceHolder> getReferenceWithCode(String query, List<Object> param) {
        List<LinkedHashMap<String, Object>> list;
        List<DTOReferenceHolder> ret = new ArrayList<>();
         list = das.executeSQLQuery(query, param.toArray());

        if (list != null && !list.isEmpty()) {
            for (Map<String, Object> map : list) {
                DTOReferenceHolder ref = new DTOReferenceHolder();
                ref.setId((Long)map.get("id"));
                ref.setDesc(map.get("descr").toString().trim());
                ref.setCode(map.get("code").toString().trim());
                ret.add(ref);
            }
        }
        return ret;
    }
    
    @Override
    public List<DTOReferenceHolder> getReferenceMultipleCol(String query, List<Object> param) {
        List<LinkedHashMap<String, Object>> list;
        List<DTOReferenceHolder> ret = new ArrayList<>();
         list = das.executeSQLQuery(query, param.toArray());

        if (list != null && !list.isEmpty()) {
            for(Map<String, Object> map : list) {
                DTOReferenceHolder ref = new DTOReferenceHolder();
                ref.setId((Long)map.get("id"));
                ref.setDesc(map.get("descr").toString().trim());
                ref.setCode(map.get("code").toString().trim());
                ret.add(ref);
            }
        }
        return ret;
    }
    
    @Override
    public List<DTOReferenceHolder> getReferenceWithAdditionalDetails(String query, List<Object> param) {
        List<LinkedHashMap<String, Object>> list;
        List<DTOReferenceHolder> ret = new ArrayList<>();
         list = das.executeSQLQuery(query, param.toArray());

        if (list != null && !list.isEmpty()) {
            for (Map<String, Object> map : list) {
                DTOReferenceHolder ref = new DTOReferenceHolder();
                ref.setId((Long)map.get("id"));
                ref.setDesc(map.get("descr").toString().trim());
                ref.setCode(map.get("code").toString().trim());
                ref.setAdditionalDetail(map.get("additionalDetails").toString().trim());
                ret.add(ref);
            }
        }
        return ret;
    }
}
