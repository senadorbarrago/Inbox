/**
 * 
 */
package com.bdo.itdis.bdocas.application.controllers.custom.remarks;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.cqrs.query.ResultModel;
import com.bdo.itd.util.crqs.command.CommandException;
import com.bdo.itd.util.crqs.command.CommandMessage;
import com.bdo.itd.util.crqs.command.ICommandBus;
import com.bdo.itd.util.map.ParameterMap;
import com.bdo.itd.util.security.application.UserSession;
import com.bdo.itdis.bdocas.remark.application.command.AddRemarksCommand;
import com.bdo.itdis.bdocas.remark.application.query.IViewRemarkQueryService;


/**
 * @author c150819004
 *
 */
@RestController
public class RemarkController {
	
	private final IViewRemarkQueryService viewRemarkQueryService;
	private ICommandBus commandBus; 
	
	@Inject
	public RemarkController(@Named("viewRemarkQueryService")IViewRemarkQueryService viewRemarkQueryService,
			@Named("remarkCommandBus")ICommandBus commandBus) {
		super();
		this.viewRemarkQueryService = viewRemarkQueryService;
		this.commandBus = commandBus;
	}

	@RequestMapping(
			value="/remarks/add",
			method=RequestMethod.POST,
			consumes=MediaType.APPLICATION_JSON_VALUE
			)
	public Object addRemarks(
			@RequestBody Map<String, Object> requestBody,
			HttpServletRequest request
			){
		
		System.out.println("Add Remarks Params: " + requestBody);
		
		AddRemarksCommand addRemarkCommand = new AddRemarksCommand();
		addRemarkCommand.setDataset(Long.valueOf(requestBody.get("dataset").toString()));
		addRemarkCommand.setSourceID(Long.valueOf(requestBody.get("sourceID").toString()));
		addRemarkCommand.setSourceType(requestBody.get("sourceType").toString());
		addRemarkCommand.setRemarks(requestBody.get("remarks").toString());
		addRemarkCommand.setMembershipID(UserSession.getActiveAuthority().getMembershipID());
		addRemarkCommand.setUsername(UserSession.getUsername());
		addRemarkCommand.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
		addRemarkCommand.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
		addRemarkCommand.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());
		
		CommandMessage message = new CommandMessage();
		
		try{
			message = commandBus.doPublish(addRemarkCommand);
		}catch(CommandException comex){
			comex.printStackTrace();
		}
		
		return message;
	}
	
	@RequestMapping(
			value="/remarks/view/{dataset}/{sourceID}/{sourceType}",
			method=RequestMethod.GET
			)
	public Object viewRemarks(
			@PathVariable long dataset,
			@PathVariable long sourceID,
			@PathVariable String sourceType,
			HttpServletRequest request,
			HttpServletResponse response
			){
		
		System.out.println("View Remarks Params: " + dataset + "," + sourceID + "," + sourceType);
		
		ParameterMap params = ParameterMap.createInstance();
		
		params.add("dataSetID", dataset);
		params.add("sourceID", sourceID);
		params.add("sourceType", sourceType);
		
		ResultModel resultModel = null;
		
		try {
			resultModel = viewRemarkQueryService.doQuery(params.map());
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return resultModel;
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(
			value="/remarks/batchAdd",
			method=RequestMethod.POST,
			consumes=MediaType.APPLICATION_JSON_VALUE
			)
	public Object batchAddRemarks(
			@RequestBody Map<String, Object> requestBody,
			HttpServletRequest request
			){
		
		System.out.println("Batch Add Remarks Params: " + requestBody);
		
		ArrayList<Long> sourceIDs = (ArrayList<Long>)requestBody.get("sourceID");
		
		System.out.println("Source IDs: " + sourceIDs);
		
		AddRemarksCommand addRemarkCommand = new AddRemarksCommand();
		addRemarkCommand.setDataset(Long.valueOf(requestBody.get("dataset").toString()));
		addRemarkCommand.setSourceIDs((List<Object>) requestBody.get("sourceID"));
		addRemarkCommand.setSourceType(requestBody.get("sourceType").toString());
		addRemarkCommand.setRemarks(requestBody.get("remarks").toString());
		addRemarkCommand.setMembershipID(UserSession.getActiveAuthority().getMembershipID());
		addRemarkCommand.setUsername(UserSession.getUsername()	);
		
		CommandMessage message = new CommandMessage();
		
		try{
			message = commandBus.doPublish(addRemarkCommand);
		}catch(CommandException comex){
			comex.printStackTrace();
		}
		
		return message;
	}
}
