package com.bdo.itdis.bdocas.application.controllers;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.bdo.itd.util.cqrs.query.QueryException;
import com.bdo.itd.util.crqs.command.CommandException;



public abstract class AbstractController {
	
	@ExceptionHandler(CommandException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	public Object handleCommandException(HttpServletResponse response, CommandException ex){
		Map<String, String> messageMap = new HashMap<>();
		messageMap.put("errorMsg", ex.getMessage());
		
		System.out.println("handleCommandException(): "+ex.getMessage());
		System.out.println("handleCommandException2(): "+messageMap.get("errorMsg"));
		
		return  messageMap;
	}
	
	@ExceptionHandler(QueryException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	public Object handleQueryException(HttpServletResponse response, QueryException ex){
		Map<String, String> messageMap = new HashMap<>();
		messageMap.put("errorMsg", ex.getMessage());
		
		System.out.println("handleQueryException()");
		System.out.println(ex.getCause().getClass());
		
		
		return  messageMap;
	}
	
	@ExceptionHandler(Exception.class)
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public Object handlegGenericException(HttpServletResponse response, Exception ex){
		Map<String, String> messageMap = new HashMap<>();
		messageMap.put("errorMsg", ex.getMessage());
		
		System.out.println("handlegGenericException()");
		System.out.println(ex.getCause().getClass());
		
		return  messageMap;
	}
	
}
