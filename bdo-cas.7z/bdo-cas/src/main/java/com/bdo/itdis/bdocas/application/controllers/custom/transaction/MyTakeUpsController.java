package com.bdo.itdis.bdocas.application.controllers.custom.transaction;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.cqrs.query.QueryException;
import com.bdo.itd.util.cqrs.query.ResultModel;
import com.bdo.itd.util.crqs.command.CommandException;
import com.bdo.itd.util.crqs.command.CommandMessage;
import com.bdo.itd.util.crqs.command.ICommandBus;
import com.bdo.itd.util.security.application.UserSession;
import com.bdo.itdis.bdocas.application.controllers.AbstractController;
import com.bdo.itdis.bdocas.transactions.application.command.ForwardNCTransactionCommand;
import com.bdo.itdis.bdocas.transactions.application.command.ReturnTransactionCommand;
import com.bdo.itdis.bdocas.transactions.application.query.list.IMyTakeUpsQueryService;
import com.bdo.itdis.bdocas.transactions.application.query.list.searchcriteria.SearchCriteria;


@RestController
public class MyTakeUpsController extends AbstractController {
	
	private final ICommandBus commandBus;
	private final IMyTakeUpsQueryService queryService;
	
	@Inject
	public MyTakeUpsController(@Named("transactionManagementCommandBus")ICommandBus commandBus,
			@Named("myTakeUpsQueryService")IMyTakeUpsQueryService queryService) {
		super();
		this.queryService = queryService;
		this.commandBus = commandBus;
	}
	
	@RequestMapping(value="/transactions/mytxn/{dataSetCode}/{pageIndex}/{pageSize}/", method=RequestMethod.POST, consumes="application/json")
	public Object doQueryList(@PathVariable("dataSetCode")String dataSetCode, @PathVariable("pageIndex")int pageIndex, 
			@PathVariable("pageSize")int pageSize, @RequestBody Map<String, Object> searchCriteria, HttpServletRequest request) throws QueryException{
		
		Map<String, Object> params = new HashMap<>();
		params.put("userName", UserSession.getUsername());
		params.put("membershipCode", UserSession.getActiveAuthority().getCode());
		params.put("dataSetCode", dataSetCode);
		params.put("searchCriteria", convertToXML(searchCriteria, pageIndex, pageSize));
		params.put("pageIndex", pageIndex);
		params.put("pageSize", pageSize);
		
		ResultModel resultModel = queryService.doQuery(params);
		
		return resultModel;
	}
	
	
	@RequestMapping(value="/transactions/mytxn/returntoinbox", method=RequestMethod.POST)
	public Object doReturnToInbox(@RequestBody List<String> takeUpIDs, HttpServletRequest request)throws CommandException{
		ReturnTransactionCommand command = new ReturnTransactionCommand();
		
		command.setTakeUpIDList(takeUpIDs);
		command.setTaggedByID(UserSession.getUsername());
		command.setUsername(UserSession.getUsername());
		command.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
		command.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
		command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());
		
		return commandBus.doPublish(command);
		
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value="/transactions/mytxn/reassigntakeup", consumes=MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.POST)
	public Object doReassignTakeup(@RequestBody Map<String, Object> data, HttpServletRequest request)throws CommandException{
		CommandMessage message = new CommandMessage();		
		List<Integer> transactionRecordIDs = (ArrayList) data.get("transactionID");
		long transactionRecordID = 0L;
		String reassignTo = data.get("reassignTo") != null ? data.get("reassignTo").toString() : ""; 
		
		for(Integer tranRecordID : transactionRecordIDs){
			transactionRecordID =  tranRecordID;
			ForwardNCTransactionCommand command = new ForwardNCTransactionCommand(transactionRecordID, reassignTo);
			command.setUsername(UserSession.getUsername());
			command.setMembershipCode(UserSession.getActiveAuthority().getCode().toString());
			command.setRoleCode(UserSession.getActiveAuthority().getRole().getCode());
			command.setGroupCode(UserSession.getActiveAuthority().getGroup().getCode());			
		
			message = commandBus.doPublish(command);
		}
		
		return message;
	}
	
	@SuppressWarnings("unchecked")
	private String convertToXML(Map<String, Object> searchCriteriaData, int pageIndex, int pageSize){
		List<Map<String, Object>> filterFields = new ArrayList<>();
		if(searchCriteriaData.get("filterList") != null){
			filterFields = (ArrayList<Map<String, Object>>)searchCriteriaData.get("filterList");
		}
		
		List<Map<String, Object>> sortFields = new ArrayList<>();
		if(searchCriteriaData.get("sortList") != null){
			sortFields = (ArrayList<Map<String, Object>>)searchCriteriaData.get("sortList");
		}
		
		SearchCriteria searchCriteria = new SearchCriteria(filterFields, sortFields, pageIndex, pageSize);		
		
		return searchCriteria.convertSearchCriteriaToXML();
	}
	
}
