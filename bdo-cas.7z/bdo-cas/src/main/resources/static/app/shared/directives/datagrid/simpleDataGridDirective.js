'use strict'

define(function(){
	console.log('simpleDataGridDirective.js loaded');
	var core = angular.module('core'); 
	core.directive('simpleDataGrid', function(){
		console.log('simpleDataGrid initialization...');
		return{
			restrict: 'E',
			transclude: true,
			templateUrl: 'app/shared/directives/datagrid/simpleDataGrid.html',
			scope: {
				resultList: '='			
			},
			controller: function($scope){
				$scope.dataList = angular.fromJson($scope.resultList)
				
				console.log($scope.dataList);
			}
		}
	});
	return core;
});