'use strict';

define(function(){
	
	console.log('assignedLogicalBranchController.js loaded');
	var core = angular.module('core');
	
	core.registerController('assignedLogicalBranchController', ['$rootScope', '$scope', '$uibModalInstance', 'DataAccessService', 
			function($rootScope, $scope, $uibModalInstance, dataAccessService){
		
		$scope.title = 'Assigned Logical Branch';
		
		var vm = this;
		
		// Get Assigned Logical Branch
		vm.getAssignedLogicalBranch = function() {
			console.log('vm.getAssignedLogicalBranch()');
			var data  = {	 
							'dataSetCode' : $rootScope.dataSetCode,
							'username' 	  : $rootScope.session['AUTHENTICATED_USER'].username,
					     	'groupCode'   : $rootScope.session['AUTHENTICATED_USER'].activeMembership.group.code,
						}; 
			console.log(data);
			dataAccessService.doQuery('AssignedLogicalBranchQueryModel', data, function(response){
				console.log(response);
				$scope.assignedLogicalBranchList = response.data.resultSet;
			},function(errorResponse){
				errorCallBack(errorResponse);
			});
		};
		
		vm.init = function(){
			vm.getAssignedLogicalBranch();
		}
		// Initialize
		vm.init();
		
		// Close this modal
		$scope.close = function(){
			$uibModalInstance.dismiss();
		};
	}]);
});