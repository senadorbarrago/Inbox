'use strict';

define(function(){
	console.log('utility.js loaded');
	var utility = angular.module('utility', []);
	
	// ControllerProvider Configuration
	utility.config(['$controllerProvider', function($controllerProvider){
		console.log('utility.config');
		utility.register = {
				controller : $controllerProvider.register
		}
	}]);
	
	
});