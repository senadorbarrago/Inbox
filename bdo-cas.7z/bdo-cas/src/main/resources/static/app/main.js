'use strict';

require.config({
	baseUrl: '/bcas',
	waitSeconds: 0,
	paths: {
			'angular'                :  'webjars/angularjs/1.5.0/angular.min',
			'angular-route'          :  'webjars/angularjs/1.5.0/angular-route.min',
			'angular-cookies'        :  'webjars/angularjs/1.5.0/angular-cookies.min',
			'angular-ui-bootstrap'   :  'webjars/angular-ui-bootstrap/2.2.0/ui-bootstrap-tpls.min',
			'angular-sanitize'       :  'webjars/angular-sanitize/1.3.11/angular-sanitize.min',
			'angular-idle'       	 :  'webjars/ng-idle/1.1.0/angular-idle.min',
			'jquery'		   		 :  'webjars/jquery/3.2.1/dist/jquery.min',
			'jquery-ui'		         :  'webjars/jquery-ui/1.12.1/jquery-ui.min',
			'core'			         :  'app/core',
			'journalEntryFormModule' :  'app/components/forms/journalentryform/journalEntryFormModule',
			'utility'                :  'app/shared/utility',
			'serviceIndex'        	 :  'app/components/serviceIndex',
			'directiveIndex'         :  'app/components/directiveIndex',
			'reportFormModule' 		 :  'app/components/reports/reportFormModule',
			'ng-table' 		 		 :  'webjars/ng-table/0.3.4/ng-table-modified',
			'block-ui'				 :  'assets/lib/blockUI/jquery.blockUI.min',
			'numericInput'		     :  'assets/lib/validators/numericInput',
			'ui-select'			     :  'assets/lib/ui-select/select.min',
			'ng-model-format'	     :  'assets/lib/ng-model-format/ngmodel.format'
	},
	shim: {
			'angular'   	         : {'exports': 'angular', deps: ['jquery-ui']},
			'angular-route'          : {deps: ['angular']},
			'angular-cookies'        : {deps: ['angular']},
			'angular-ui-bootstrap'	 : {deps: ['angular']},
			'ui-select'				 : {deps: ['angular']},
			'ng-model-format'        : {deps: ['angular']},
			'angular-sanitize'		 : {deps: ['angular']},
			'angular-idle'			 : {deps: ['angular']},
			'jquery'		         : {'exports': '$'},
			'jquery-ui'		         : {deps: ['jquery']},
			'block-ui'				 : {deps: ['jquery']}, 
			'numericInput'			 : {deps: ['jquery']}, 
			'core'			         : {deps: ['journalEntryFormModule','reportFormModule']},
			'journalEntryFormModule' : {deps: ['utility']},
			'reportFormModule' 		 : {deps: ['utility']},
			'utility'                : {deps: ['angular-route', 'angular-cookies', 'angular-ui-bootstrap', 'angular', 'angular-sanitize', 'angular-idle', 'ng-table', 'block-ui', 'numericInput', 'ui-select', 'ng-model-format']},
			'ng-table'          	 : {deps: ['angular']}
	},
	deps: ['core']
});
