'use strict';

define(function(){
	angular.module("core").provider('TransactionFormCommandService', function(){
		this.$get =['DataAccessService', function(dataAccessService){
			var service = {
				doAcceptTransaction: function(data, successCallBack, errorCallBack) {
					var url  = 'transactions/form/save';
					dataAccessService.doPostData(url, data, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				doTagTransaction: function(data, successCallBack, errorCallBack) {
					var url  = 'transactions/tag';
					dataAccessService.doPostData(url, data, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				doAcceptRecord: function(data, successCallBack, errorCallBack) {
					var url  = 'transactions/record/save';
					dataAccessService.doPostData(url, data, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				}
				
			}
			return service;
		}]
	});	
});