'use strict';

define(function(){
	var core = angular.module('core');
	
	core.registerController('glDateController',[ '$rootScope', '$scope', '$uibModal', 'DataAccessService',
		function($rootScope, $scope, $uibModal, dataAccessService){
		$rootScope.screenName = 'GL DATE';
		
		var vm = this;

		vm.init = function(){
			$scope.data = {};
			$scope.data.forwardRates = true;
			$scope.datePicker = { };
			$scope.dateOptions = {
					startingDay : 1,
					showWeeks : false,	
					format : "yyyy-MM-dd"
				};
			$scope.dateFormat = "yyyy-MM-dd";
			
			$scope.data.dataSetID = $rootScope.dataSetID;
			
			vm.getCurrentGLDate();
			vm.getProcessID();
			vm.getCurrentCurrencyRates();
		}
		
		$scope.open = function(columnName, $event) {
			$event.preventDefault();
			$event.stopPropagation();
			
			if ($scope.datePicker[columnName]) {
				if ($scope.datePicker[columnName].opened) {
					$scope.datePicker[columnName].opened = false;
				}
			} else {
				$scope.datePicker = {};
				$scope.datePicker[columnName] = {};
				$scope.datePicker[columnName].opened = true;
			}
		}
		
		$scope.process = function(){
			console.log($scope.data.forwardRates);
			console.log($scope.data.glDate);
			var saveGLDateUrl = "transactions/glDate/save";			
			
			if(!$scope.data.glDate){
				alertify.alert("Please select a GL Date in order to proceed");
				return;
			}else{
				alertify.confirm("Do you really want to set GL Date?", function(e){
					
					if(e){
						dataAccessService.doPostData(saveGLDateUrl, $scope.data, function(response){
							console.log(response);
							alertify.alert(response.data.messageMap.successMsg);
							vm.init();
						},function(errorResponse){
							console.log(errorResponse);
							alertify.fail(errorResponse.data.errorMsg);
						});
					}else{
						return;
					}
				});
			}
			
		}
		
		vm.getCurrentGLDate = function(){
			var getCurrentGLDateUrl = "transactions/glDate/currentGlDate/"+$scope.data.dataSetID;			
			dataAccessService.doGetData(getCurrentGLDateUrl, null, function(response){
				console.log(response);
				$scope.data.previousGlDate = response.data.previousGlDate;
			},function(errorResponse){
				console.log(errorResponse);
			});
		}
		
		vm.getProcessID = function(){
			var getProcessIDUrl = "transactions/glDate/processID/"+$scope.data.dataSetID;			
			dataAccessService.doGetData(getProcessIDUrl, null, function(response){
				console.log(response);
				$scope.data.processID = response.data.processID;
			},function(errorResponse){
				console.log(errorResponse);
			});
		}
		
		vm.getCurrentCurrencyRates = function(){
			var url = "transactions/glDate/currentCurrencyRatesList";		
			dataAccessService.doGetData(url, null, function(response){
				console.log(response);
				$scope.currencyRates = response.data;
			},function(errorResponse){
				console.log(errorResponse);
			});
		}
		
		vm.init();
		
	}]);
	
});