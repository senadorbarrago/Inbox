'use strict';

define(function(){
	console.log('takeUpsInventoryController.js loaded');
	var core = angular.module('core');
	
	core.registerController('takeUpsInventoryController',['$rootScope', '$scope', '$uibModal', 'DataAccessService', 'ngTableParams', '$filter', '$http', 'InventoryQueryService',  
		function($rootScope, $scope, $uibModal, dataAccessService, ngTableParams, $filter, $http, inventoryQueryService){
		$rootScope.screenName = 'Inventory --> Take Ups';
		
		var vm = this;
		
		/**
		 * init()
		 * 
		 */
		vm.init = function () {
			$scope.data = {};
			$scope.form = {};
			$scope.reference = {};
			$scope.data.inventoryCode = 'INV-004';
			$scope.data.dataSetID = $rootScope.dataSetID;
			$scope.data.dataSetCode = $rootScope.dataSetCode;
			$scope.data.costCenterID = $rootScope.costCenterID;
			$scope.data.pageSize = 50;
			$scope.data.pageIndex = 1;
			
			$scope.inventoryTypeList = [
											{
												 "heading"	: "Transactions",
												 "url"	    : "inventory/transactions",
												 "selected" : false
											 },
											 {
												 "heading"  : "Take Ups",
												 "url"	    : "inventory/takeups",
												 "selected" : true
											 },
											 {
												 "heading"  : "Journal Entries",
												 "url"	    : "inventory/journalentries",
												 "selected" : false
											 },
											 {
												 "heading"  : "Batch Sheet",
												 "url"	    : "inventory/batchsheets",
												 "selected" : false
											 }
										];
			
			//Search
			$scope.form.searchcriteria = {};
			$scope.form.searchcriteria.data = {};
			$scope.form.searchcriteria.data.filterList = [];
			$scope.form.searchcriteria.data.sortList = [];
			$scope.form.datagrid = {};
			vm.getFieldList();
			vm.loadPage();
		}
		
		/**
		 * Get filter field list
		 * 
		 */
		vm.getFieldList= function(){
			inventoryQueryService.getColumnList($scope.data.dataSetID, 32, function(response){
				$scope.form.searchcriteria.dataFieldList = [];
				angular.forEach(response.data.resultSet, function(value, key) {
						$scope.form.searchcriteria.dataFieldList.push(value);
				});
			}, function(error){
				console.log(error);
			});
		};
		
		/**
		 * Load data grid
		 * 
		 */
		vm.loadPage = function() {
			$scope.tableParams = new ngTableParams(
					{	page: 1,
						count: 25
					},
					{	getData: function ($defer, params) {
						return inventoryQueryService.getTakeUpsInventory($scope.data.dataSetCode,
								params.page(), params.count(), $scope.form.searchcriteria.data, function (response) {
								$scope.form.resultmodel = response.data;
								params.total($scope.form.resultmodel.resultOverAllCount);
								$defer.resolve($scope.form.resultmodel.resultSet);
							}, function(response) {});
						}
					}
			);
		};
		
		/**
		 * Select filter field
		 * 
		 */
		$scope.selectFilterField = function(){
			console.log($scope.form.searchcriteria.filterField);
		};
		
		/**
		 * Add filter field
		 * 
		 */
		$scope.doAddFilter = function(){
			if(!$scope.form.searchcriteria.filterField){
				alertify.alert("Please select a filter field in order to proceed.");
				return false;
			}
			
			var record = {"id":$scope.form.searchcriteria.filterField.dataFieldID, "fieldName":$scope.form.searchcriteria.filterField.fieldName, "fieldLabel":$scope.form.searchcriteria.filterField.label , "hasRange":$scope.form.searchcriteria.filterField.hasRange, "valueFrom":"", "valueTo":""};
			var isExists = false;
			
			angular.forEach($scope.form.searchcriteria.data.filterList, function(value, key){
				if(!isExists){
					if(value.id === $scope.form.searchcriteria.filterField.dataFieldID){
						isExists = true;
					}
				}
			});
			
			if(!isExists){
				$scope.form.searchcriteria.data.filterList.push(record);
			}
		};
		
		/**
		 * Remove filter field
		 * 
		 */
		$scope.removeFilter = function(index){
			var item = $scope.form.searchcriteria.data.filterList[index];
			$scope.form.searchcriteria.data.filterList.splice(index, 1);
		};
		
		/**
		 * Clear filter fields
		 * 
		 */
		$scope.doClearFilterFields = function(){
			$scope.form.searchcriteria.filterField = {};
			$scope.form.searchcriteria.data.filterList = [];
		};
		
		/**
		 * Select sort field
		 * 
		 */
		$scope.selectSortField = function(){
			console.log($scope.form.searchcriteria.sortField);
		};
		
		/**
		 * Add sort field
		 * 
		 */
		$scope.doAddSort = function(){
			if(!$scope.form.searchcriteria.sortField){
				alertify.alert("Please select a sort field in order to proceed.");
				return false;
			}
			
			var record = {"id":$scope.form.searchcriteria.sortField.dataFieldID, "fieldName":$scope.form.searchcriteria.sortField.fieldName, "fieldLabel":$scope.form.searchcriteria.sortField.label, "order":"1", "valueFrom":"ASC"};
			var isExists = false;
			
			angular.forEach($scope.form.searchcriteria.data.sortList, function(value, key){
				if(!isExists){
					if(value.id === $scope.form.searchcriteria.sortField.dataFieldID){
						isExists = true;
					}
				}
			});
			
			if(!isExists){
				$scope.form.searchcriteria.data.sortList.push(record);
			}
		};
		
		/**
		 * Remove sort field
		 * 
		 */
		$scope.removeSort = function(index){
			var item = $scope.form.searchcriteria.data.sortList[index];
			$scope.form.searchcriteria.data.sortList.splice(index, 1);
		};
		
		/**
		 * Clear sort fields
		 * 
		 */
		$scope.doClearSortFields = function(){
			$scope.form.searchcriteria.sortField = {};
			$scope.form.searchcriteria.data.sortList = [];			
		};
		
		/**
		 * Clear filter and sort fields
		 * 
		 */
		$scope.doClearAll = function(){
			$scope.doClearFilterFields();
			$scope.doClearSortFields();
		};
		
		/**
		 * Show all records
		 * 
		 */
		$scope.doShowAll = function(){
			$scope.doClearAll();
			
			// Reset pageSize and pageIndex
			$scope.tableParams.page(1);
			$scope.tableParams.count(25);

			//Reload Paginated Request
			$scope.tableParams.reload();
		}
		
		/**
		 * Search record
		 * 
		 */
		$scope.doSearch = function(){			
			//Revert to page 1
			$scope.tableParams.page(1);
			//Reload Paginated Request
			$scope.tableParams.reload();
		};
		
		
		/**
		 * Call init();
		 * 
		 */ 
		vm.init();
		
		/**
		 * Show transaction form
		 * 
		 */
		$scope.doShowAcceptTransactionForm = function(transactionID){
			var modalInstance = $uibModal.open({
				animation: true,
				backdrop: 'static',
				templateUrl: 'app/components/forms/transactionform/transactionForm.html',
				controller: 'transactionFormController',
				size: 'lg',
				resolve:{
					load: ['$q', function($q){
						var defered = $q.defer();
						require(['app/components/forms/transactionform/transactionFormController'], function(){
							defered.resolve();
						});
						return defered.promise;
					}],
					data : function(){
						var data = {}; 
						data.transactionID = transactionID;
						data.allowAcceptTransaction = false;
						data.fromInventory = true;
						return data;
					}
				}
			});
			modalInstance.result.then(function(message){
				alertify.alert(message);
			}, 
			function() {				
				// dismissed
				console.log("dismissed");
			});
			return modalInstance.result;
		}
		
	}]);
	
});