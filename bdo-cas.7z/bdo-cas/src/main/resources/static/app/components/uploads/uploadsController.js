'use strict';

define(function(){
	console.log('uploadsController.js loaded');
	var core = angular.module('core');
	
	core.registerController('uploadsController',['$rootScope','$scope', 'DataAccessService', 
	    function($rootScope, $scope, dataAccessService){
		var vm = this;
		
		// URL
		var URL_UPLOADS = 'uploads/';
		
		// Table Header 
		$scope.tableHeader = ['Select', 'File Name', 'File Path', 'Size', 'Date Created'];
		
		// Initialize Data
		vm.init = function(){
			$rootScope.screenName = 'Uploads'
			$scope.dataSetCode = $rootScope.dataSetCode;
			$scope.systemCodeList = [];
			$scope.systemCodeList.push({'code':'uploadBCAStoICBS', 'description':'ICBS-CLG'});
			$scope.systemCodeList.push({'code':'uploadBCAStoICBSFCDU', 'description':'ICBS-FCDU'});
			$scope.systemCodeList.push({'code':'uploadBCAStoICBSIBG', 'description':'ICBS-IBG'});
			
			$scope.data = {};
			
			vm.doGetUploadsContents();
		};
		
		// Private functions
		vm.doGetUploadsContents = function(){
			var url = 'uploads/'+$scope.dataSetCode;
			dataAccessService.doGetData(url, null, function(response){
				console.log(response);
				$scope.data = response.data;
				// Add additional selection element
				angular.forEach($scope.data.result, function(value, key){
					value["Selected"] = false;
				});
			},function(errorResponse){
				console.log(errorResponse);
			});
		}
		
		// UI Validations
		vm.checkIfHasSelection = function(list){
			for(var index = 0; index < list.length; index++){
				if(list[index]["Selected"]){
					return true;
				}
			}
			return false;
		}
		vm.init();
		
		$scope.doUploadSelectedFile = function(){
			var datacopy = angular.copy($scope.data.resultSet);
			var hasSelection = vm.checkIfHasSelection(datacopy);
			console.log($scope.data.systemCode);
			if(!$scope.data.systemCode){
				alertify.alert("Please select the corresponding system code in order to proceed");
				return false;
			}
			if(!hasSelection){
				alertify.alert("Please select a file to be uploaded in order to proceed");
			}else{
				alertify.confirm("This action uploads the selected files to ICBS." +
								"Are you sure you want to proceed?", function(e){
				if(e){
						angular.forEach(datacopy, function(value, key){
							if(value["Selected"]){
								var path = value["Path"]+'\\';
								var selectedFileName = value["File Name"];
								console.log(selectedFileName);
								var selectedFile = {
													"selectedFile" : selectedFileName,
													"path" : path,
													};
								var url = 'uploads/upload/'+$scope.dataSetCode;
								var data = {};
								data.systemCode = $scope.data.systemCode;
								data.selectedFile = selectedFile;
								
								//$scope.data.selectedFile = selectedFile;
								console.log(data);
								dataAccessService.doPostData(url, data, function(response){
									vm.doGetUploadsContents();
									alertify.alert(response.data.messageMap.successMsg, function(e){});
								}, function(errorResponse){
									vm.doGetUploadsContents();
									alertify.alert(errorResponse.data.errorMsg, function(e){});
								});
							}
						});
					}else{
						return;
					}
				});
			}
		};
		
	}]);
});