'use strict';

define(function(){
	
	console.log('batchSheetFormController.js loaded');
	var core = angular.module('core');
	
	core.registerController('batchSheetFormController', function($rootScope, $scope, $uibModal){
		$scope.title = 'Batch Sheet Form';
		console.log("Batch Sheet Form");
		$scope.doShowControlTotalsForm = function(){
			var modalInstance = $uibModal.open({
				animation: true,
				templateUrl: 'app/components/forms/batchsheetform/controlTotalsForm.html',
				controller: 'controlTotalsFormController',
				size: 'lg',
				resolve:{
					load: ['$q', function($q){
						var defered = $q.defer();
						require(['app/components/forms/batchsheetform/controlTotalsFormController2'], function(){
							defered.resolve();
						});
						return defered.promise;
					}]
				}
			});
			
			modalInstance.result.then(function(x, y){
				console.log('BatchSheet');
				console.log(x);
				console.log(y);
			})
			
			return modalInstance.result;
			
		};
		
		$scope.doShowOtherAdjustmentsForm = function(){
			var modalInstance = $uibModal.open({
				animation: true,
				templateUrl: 'app/components/forms/batchsheetform/otherAdjustmentsForm.html',
				controller: 'otherAdjustmentsFormController',
				size: 'lg',
				resolve:{
					load: ['$q', function($q){
						var defered = $q.defer();
						require(['app/components/forms/batchsheetform/otherAdjustmentsFormController'], function(){
							defered.resolve();
						});
						return defered.promise;
					}]
				}
			});
			return modalInstance.result;
			
		};
		
		
		
		
		
	});
	
	
	
	
});