'use strict';

define(function(){
	console.log('transactionTakeUpListByDetailsController.js loaded');
	var core = angular.module('core');
	
	core.registerController('transactionTakeUpListByDetailsController', [ '$rootScope', '$scope', '$uibModalInstance', 'data', '$http',
		function($rootScope, $scope, $uibModalInstance, data, $http){
		$scope.title = 'Transaction Take Up List';
		
		var vm = this;
		vm.init = function() {
			var url  = 'batchsheet/takeUpList';
			$http.post(url, data.bs).
			then(function(response){
				console.log("transactionTakeUpListByDetailsController().init");
				console.log(response);
				$scope.form = response.data;
			});
			return $scope.form;
		}
		// Initialize
		vm.init();
		
		$scope.close = function(){
			$uibModalInstance.close();
		};
		
	}]);
	
});