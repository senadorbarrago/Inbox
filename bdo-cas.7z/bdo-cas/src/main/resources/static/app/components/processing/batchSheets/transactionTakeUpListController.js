'use strict';

define(function(){
	console.log('transactionTakeUpListController.js loaded');
	var core = angular.module('core');
	
	core.registerController('transactionTakeUpListController', [ '$rootScope', '$scope', '$uibModalInstance', 'transactionTakeUps', 
		function($rootScope, $scope, $uibModalInstance, transactionTakeUps){
		$scope.title = 'Transaction Take Up List';
		
		var vm = this;
		vm.init = function() {
			$scope.form = transactionTakeUps;
			console.log($scope.form);
		}
		// Initialize
		vm.init();
		
		$scope.close = function(){
			$uibModalInstance.close();
		};
		
	}]);
	
});