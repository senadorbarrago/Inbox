'use strict';

define(function(){
	console.log('forReferralController.js loaded');
	var core = angular.module('core');
	
	core.registerController('forReferralController',['$rootScope', '$scope', '$uibModal', 'ReferralQueryService', 'ngTableParams', '$filter', 'DataAccessService', 
  		function($rootScope, $scope, $uibModal, referralQueryService, ngTableParams, $filter, dataAccessService){
  		$scope.title = 'This is the For Referral Screen';
  		$rootScope.screenName = 'For Referral';
		
  		// Create controller object VM
		var vm = this;
		
		vm.init = function() {
			vm.dataSetID = $rootScope.dataSetID;
			vm.dataSetCode = $rootScope.dataSetCode;
			
			$scope.form = {};
			$scope.form.searchcriteria = {};
			$scope.form.searchcriteria.data = {};
			$scope.form.searchcriteria.data.filterList = [];
			$scope.form.searchcriteria.data.sortList = [];
			$scope.form.datagrid = {};
			$scope.references = {};
			
			vm.pageIndex = 1;
			vm.pageSize = 50;
			
			vm.getFieldList();
			vm.loadPage();
		}
		
		vm.getFieldList= function(){
			referralQueryService.getColumnList(vm.dataSetID, 33, function(response){
				$scope.form.searchcriteria.dataFieldList = [];
				angular.forEach(response.data.resultSet, function(value, key) {
						$scope.form.searchcriteria.dataFieldList.push(value);
				});
				console.log($scope.form.searchcriteria.dataFieldList);
			}, function(error){
				console.log(error);
			});
		};
		
		vm.loadPage = function() {
			$scope.tableParams = new ngTableParams(
					{	page: 1,
						count: 25
					},
					{	getData: function ($defer, params) {
						return referralQueryService.getReferralList(vm.dataSetCode,
								params.page(), params.count(), $scope.form.searchcriteria.data, function (response) {
								$scope.form.datagrid = response.data;			
								params.total($scope.form.datagrid.resultOverAllCount);
								$defer.resolve($scope.form.datagrid.resultSet);
							}, function(response) {});
						}
					}
			);
		};
		
		/**
		 * 
		 */
		vm.init();		
		
		/**
		 * 
		 */
		$scope.selectFilterField = function(){
			console.log($scope.form.searchcriteria.filterField);
		};
		
		/**
		 * 
		 */
		$scope.doAddFilter = function(){
			if(!$scope.form.searchcriteria.filterField){
				alertify.alert("Please select a filter field in order to proceed.");
				return false;
			}
			
			var record = {"id":$scope.form.searchcriteria.filterField.dataFieldID, "fieldName":$scope.form.searchcriteria.filterField.fieldName, "fieldLabel":$scope.form.searchcriteria.filterField.label , "hasRange":$scope.form.searchcriteria.filterField.hasRange, "valueFrom":"", "valueTo":""};
			var isExists = false;
			
			angular.forEach($scope.form.searchcriteria.data.filterList, function(value, key){
				if(!isExists){
					if(value.id === $scope.form.searchcriteria.filterField.dataFieldID){
						isExists = true;
					}
				}
			});
			
			if(!isExists){
				$scope.form.searchcriteria.data.filterList.push(record);
			}
		};
		
		/**
		 * 
		 */
		$scope.removeFilter = function(index){
			var item = $scope.form.searchcriteria.data.filterList[index];
			$scope.form.searchcriteria.data.filterList.splice(index, 1);
		};
		
		/**
		 * 
		 */
		$scope.doClearFilterFields = function(){
			$scope.form.searchcriteria.filterField = {};
			$scope.form.searchcriteria.data.filterList = [];
		};
		
		/**
		 * 
		 */
		$scope.selectSortField = function(){
			console.log($scope.form.searchcriteria.sortField);
		};
		
		/*
		 * 
		 */
		$scope.doAddSort = function(){
			if(!$scope.form.searchcriteria.sortField){
				alertify.alert("Please select a sort field in order to proceed.");
				return false;
			}
			
			var record = {"id":$scope.form.searchcriteria.sortField.dataFieldID, "fieldName":$scope.form.searchcriteria.sortField.fieldName, "fieldLabel":$scope.form.searchcriteria.sortField.label, "order":"1", "valueFrom":"ASC"};
			var isExists = false;
			
			angular.forEach($scope.form.searchcriteria.data.sortList, function(value, key){
				if(!isExists){
					if(value.id === $scope.form.searchcriteria.sortField.dataFieldID){
						isExists = true;
					}
				}
			});
			
			if(!isExists){
				$scope.form.searchcriteria.data.sortList.push(record);
			}
		};
		
		/**
		 * 
		 */
		$scope.removeSort = function(index){
			var item = $scope.form.searchcriteria.data.sortList[index];
			$scope.form.searchcriteria.data.sortList.splice(index, 1);
		};
		
		/**
		 * 
		 */
		$scope.doClearSortFields = function(){
			$scope.form.searchcriteria.sortField = {};
			$scope.form.searchcriteria.data.sortList = [];			
		};
		
		/**
		 * 
		 */
		$scope.doClearAll = function(){
			$scope.doClearFilterFields();
			$scope.doClearSortFields();
		};
		
		/**
		 * 
		 */
		$scope.doShowAll = function(){
			$scope.doClearAll();
			
			// Reset pageSize and pageIndex
			$scope.tableParams.page(1);
			$scope.tableParams.count(25);

			//Reload Paginated Request
			$scope.tableParams.reload();
		}
		
		/**
		 * 
		 */
		$scope.doSearch = function(){			
			console.log($scope.form.searchcriteria.data.filterList);
			console.log($scope.form.searchcriteria.data.sortList);
			//Revert to page 1
			$scope.tableParams.page(1);
			
			//Reload Paginated Request
			$scope.tableParams.reload();
		};
		
		/**
		 * 
		 */
		$scope.selectAll = function(){
			var toggleStatus = $scope.form.isAllSelected;
			console.log(toggleStatus);
			angular.forEach($scope.form.datagrid.resultSet, function(record){
				record.selected = toggleStatus;
			});
		}
		
		/**
		 * 
		 */
		$scope.doChangeSelection = function(record){
			record.selected = !record.selected;
			if(!record.selected){
				$scope.form.isAllSelected = false;
			}
		}
		
		/**
		 * 
		 */
		$scope.referTransaction = function(){
			// To do if selectedTransactionIDList.length === 0
			var selectedRecordList = [];
			
			for(var index = 0; index < $scope.form.datagrid.resultSet.length; index++){
				if($scope.form.datagrid.resultSet[index].selected === true){
					selectedRecordList.push($scope.form.datagrid.resultSet[index]);
				}
			}
			
			if (selectedRecordList.length === 0){				
				alertify.alert("Pleases select atleast 1 transaction to be referred.");				
			} else {				
				var modalInstance = $uibModal.open({
					animation: true,
					templateUrl: 'app/components/forms/refertransactionform/refertransactionForm.html',
					controller: 'refertransactionFormController',
					size: 'lg',
					resolve:{
						load: ['$q', function($q){
							var defered = $q.defer();
							require(['app/components/forms/refertransactionform/refertransactionFormController'], function(){
								defered.resolve();
							});
							return defered.promise;
						}],
						data : function(){
							var data = {}; 
							data.selectedRecordList = selectedRecordList;
							return data;
						}
					}
				});
				modalInstance.result.then(
					function(messageList) {
						//Reload Paginated Request
						vm.doShowMessageForm(messageList);
						$scope.tableParams.reload();
					}, 
					function() {				
						// dismissed
					}
				);
				return modalInstance.result;					
			}						
		};
		
		/**
		 * 
		 */
		$scope.doShowGrabTransactionForm = function(){
			// To do if selectedTransactionIDList.length === 0
			var selectedRecordList = [];
			
			for(var index = 0; index < $scope.form.datagrid.resultSet.length; index++){
				if($scope.form.datagrid.resultSet[index].selected === true){
					selectedRecordList.push($scope.form.datagrid.resultSet[index]);
				}
			}
			
			if (selectedRecordList.length === 0){				
				alertify.alert("Please select atleast 1 transaction to be grabbed.");				
			} else {	
				var modalInstance = $uibModal.open({
					animation: true,
					backdrop: 'static',
					templateUrl: 'app/components/forms/grabtransactionform/grabTransactionForm.html',
					controller: 'grabTransactionFormController',
					size: 'lg',
					keyboard: false,
					resolve:{
						load: ['$q', function($q){
							var defered = $q.defer();
							require(['app/components/forms/grabtransactionform/grabTransactionFormController'], function(){
								defered.resolve();
							});
							return defered.promise;
						}],
						data : function(){
							var data = {}; 
							data.selectedItems = selectedRecordList;
							
							return data;
						}
					}
				});
				modalInstance.result.then(function(messageList){
					vm.doShowMessageForm(messageList);
					$scope.tableParams.reload();
				}, 
				function() {				
					// dismissed
				});
				return modalInstance.result;
			}
		};
		
		$scope.doShowAcceptTransactionForm = function(transactionID){
			var modalInstance = $uibModal.open({
				animation: true,
				backdrop: 'static',
				templateUrl: 'app/components/forms/transactionform/transactionForm.html',
				controller: 'transactionFormController',
				size: 'lg',
				resolve:{
					load: ['$q', function($q){
						var defered = $q.defer();
						require(['app/components/forms/transactionform/transactionFormController'], function(){
							defered.resolve();
						});
						return defered.promise;
					}],
					data : function(){
						var data = {}; 
						data.transactionID = transactionID;
						data.allowAcceptTransaction = false;
						return data;
					}
				}
			});
			modalInstance.result.then(function(message){
				alertify.alert(message);
				$scope.tableParams.reload();
			}, 
			function() {				
				// dismissed
			});
			return modalInstance.result;
		};
		
		// Get selected items
		vm.getSelectedItems = function(items){
			var selectedItems = [];
			for(var i = 0; i < items.length; i++){
				var selected = items[i].selected;
				if(selected === true){
					selectedItems.push(items[i]);
				}
			}
			return selectedItems;
		};
		
		// Result Message
		vm.doShowMessageForm = function(messageList){
			var modalInstance = $uibModal.open({
				animation: true,
				backdrop: 'static',
				templateUrl: 'app/shared/message/tabularMessage.html',
				controller: 'tabularMessageController',
				size: 'md',
				keyboard: false,
				resolve:{
					load: ['$q', function($q){
						var defered = $q.defer();
						require(['app/shared/message/tabularMessageController'], function(){
							defered.resolve();
						});
						return defered.promise;
					}],
					data : function(){
						var data = {}; 
					
						data.messageList =  angular.fromJson(messageList).messageList;
						console.log(data.messageList);
						
						return data;
					}
				}
			});
			return modalInstance.result;
		}
		
		$scope.doAddRemarks = function(){
			var selectedItems = vm.getSelectedItems($scope.form.datagrid.resultSet);
			
			if(selectedItems.length == 0){
				alertify.alert("Please select item/s first in order to proceed with this action");
				return false;
			}
			
			var batchIDs = [];
			
			for(var i = 0; i < selectedItems.length; i++){
				batchIDs.push(selectedItems[i]['TransactionID']);
			}
			
			var modalInstance = $uibModal.open({
				animation: true,
				backdrop: 'static',
				templateUrl: 'app/components/forms/remarks/remarksForm.html',
				controller: 'remarksFormController',
				size: 'lg',
				keyboard: false,
				resolve:{
					load: ['$q', function($q){
						var defered = $q.defer();
						require(['app/components/forms/remarks/remarksFormController'], function(){
							defered.resolve();
						});
						return defered.promise;
					}],
					data : function(){
						var data = {}; 
						data.batchIDs = batchIDs;
						data.sourceType = 'TRN';
						return data;
					}
				}
			});
			modalInstance.result.then(function(message){
				alertify.alert(message);
			}, 
			function() {				
				// dismissed
			});
			return modalInstance.result;
		};
		
		$scope.removeSpace = function(field){
			return 'hdrFld'+field.replace(/ /g,'');
		};
		
		// Generate report
		$scope.doGenerateReport = function(){
			referralQueryService.generateReport(vm.dataSetCode,
						1, 1000000, $scope.form.searchcriteria.data, function (response) {
			 	$scope.resultMessage = response.data;
				$scope.message = $scope.resultMessage.messageMap;
				
				if($scope.message.successMsg!=undefined && $scope.message.successMsg!=null){
					alertify.alert($scope.message.successMsg);
					$scope.requestStatus = $scope.reportDescription + ' generation successful!';
					
				}else if($scope.message.errorMsg!=undefined && $scope.message.errorMsg!=null){
					alertify.alert($scope.message.errorMsg);
					$scope.requestStatus = $scope.reportDescription + ' generation failed!';
				}
				
			},function(errorResponse){
				console.log(errorResponse);
				alertify.alert('Error Occurred.');
				$scope.requestStatus = $scope.reportDescription + ' generation failed!';
			});
		};
	}]);	
});