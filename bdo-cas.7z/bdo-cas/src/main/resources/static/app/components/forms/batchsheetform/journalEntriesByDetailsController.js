'use strict';

define(function(){
	console.log('journalEntriesByDetails.js loaded');
	var core = angular.module('core');
	
	core.registerController('journalEntriesByDetailsController', [ '$rootScope', '$scope', '$uibModalInstance', 'DataAccessService', 'data', '$http', 
		function($rootScope, $scope, $uibModalInstance, dataAccessService, data, $http){
		$scope.title = 'Journal Entries By Batch Sheet';
		
		var vm = this;
		vm.init = function() {
			var url  = 'batchsheet/journalentries';
			$http.post(url, data.bs).
			then(function(response){
				console.log("journalEntriesByDetailsController().init");
				console.log(response);
				$scope.form = response.data;
			});
			return $scope.form;
		}
		// Initialize
		vm.init();
		
		$scope.close = function(){
			$uibModalInstance.close();
		};
		
	}]);
	
});