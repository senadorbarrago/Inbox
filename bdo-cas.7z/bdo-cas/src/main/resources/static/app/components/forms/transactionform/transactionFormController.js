'use strict';

define(function(){
	
	console.log('transactionFormController.js loaded');
	var core = angular.module('core');
	
	core.registerController('transactionFormController',[
			'$rootScope', 
			'$scope', 
			'$uibModalInstance', 
			'$uibModal', 
			'TransactionFormCommandService', 
			'TransactionFormQueryService', 
			'data',
			function($rootScope, $scope, $uibModalInstance, $uibModal, transactionFormCommandService, transactionFormQueryService, data){
				$scope.title = 'Transaction Form';
				$scope.prevRecords = {};
		
				var vm = this;
				
				// Init
				vm.init = function(){
					console.log('init()');
					console.log(data);
					// Initialized form variables
					$scope.form = {};
					
					$scope.transactionID = data.transactionID;
					$scope.filtering = 'A';
					$scope.defaultTag = '';
					$scope.references = {};
					$scope.data = {};
					$scope.data.summary = {};
					$scope.data.takeups = {};
					$scope.fromInventory = false;
					$scope.trRemarks = '';
					$scope.remarksData = {};
					
					if(data.allowAcceptTransaction){
						$scope.allowAcceptTransaction = data.allowAcceptTransaction;
						console.log('$scope.allowAcceptTransaction: '+$scope.allowAcceptTransaction);
					}
					if(data.fromInventory){
						$scope.fromInventory = data.fromInventory;
					}
			
			// References
			vm.getTaggingReference();
			vm.getReferenceTypes();
			vm.getProcessingDate();
			vm.initializeRemarks();
			
			// Form
			vm.getTransactionFormDetails();
		}
		
		
		// Get Transaction From Details
		vm.getTransactionFormDetails = function(){
			transactionFormQueryService.getTransactionFormDetails($rootScope.dataSetID, $scope.transactionID, $scope.filtering, 
					function(response){
				console.log('getTransactionFormDetails()');
				console.log(response);
				$scope.form = response.data;
				vm.getTakeUps();
			}, function(errorResponse){
				console.log(errorResponse);
			});	
		}
		
		// Get Takeups
		vm.getTakeUps = function(){
			transactionFormQueryService.getTakeUpDetails($rootScope.dataSetID, $scope.transactionID, function(response){
				console.log('getTakeUps()');
				console.log(response);
				if(response.data.resultOverAllCount > 0){
					$scope.form.takeups = response.data;
					
					if($scope.prevRecords.length > 0){
						console.log("PLS ADD!");
						
						angular.forEach($scope.prevRecords, function(value, key){
							
							$scope.form.takeups.resultSet.push(value);
						});
					}else{
						console.log("DONT ADD!")
					}
					
				}else{
					vm.initializeTakeUpData();
				}
			}, function(errorResponse){
				console.log(errorResponse);
			});	
		}
		
		// Get Tagging Reference
		vm.getTaggingReference = function(){
			console.log('getTaggingReference()');
			transactionFormQueryService.getTaggingReferences($rootScope.dataSetID, $scope.transactionID, $rootScope.encodingUnitCode, function(response){
				console.log(response);
				$scope.references.taggingList = response.data;
			}, function(errorResponse){
				console.log(errorResponse);
			});	
		}				
				
		// Get ReferenceTypes
		vm.getReferenceTypes = function(){
			var data = {
							'dataSetCode' : $rootScope.dataSetCode
						};
			
			transactionFormQueryService.doGetReferenceType(data, function(response){
				console.log("transactionFormQueryService.doGetReferenceType()");
				console.log(response);
				$scope.references.referenceTypeList = response.data.resultSet;
			}, function(error){
				console.log(error);
			});
		}
		
		// Get Processing Date
		vm.getProcessingDate = function(){
			console.log('getProcessingDate()');
			transactionFormQueryService.getProcessingDate($rootScope.dataSetID, $rootScope.costCenterID, function(response){
				console.log(response);
				$scope.processingDate = response.data.processingDate;
			}, function(error){
				console.log(error);
			});
		}
		
		// Initialize first take-up data
		vm.initializeTakeUpData = function(){
			console.log("initializeTakeUpData()");
			
			// defaultTag
			//console.log($scope.form.resultSet[0]['Tagging']);
			if(!$scope.form.resultSet[0]['Tagging']){
				for(var index = 0; index < $scope.references.taggingList.length; index++){
					console.log($scope.references.taggingList[index]);
					$scope.defaultTag = $scope.references.taggingList[index]['code'];
					$scope.form.resultSet[0]['Tagging'] = $scope.defaultTag; 
					break;
				}
			}
			vm.initializeTakeUpRecord();
		}
		
		// Initialize first take-up record
		vm.initializeTakeUpRecord = function(){
			console.log("initializeTakeUpRecord()");
			
			$scope.form.takeups = {};
			$scope.form.takeups.columns = [
											'TakeUpID',
											'ICBSTotal', 
											'ManualTotal', 
											'RefType', 
											'RefNo', 
											'AccountName', 
											'PaymentDate', 
											'ICBSDate', 
											'TakeUpBy', 
											'DateOfTakeUp'
											];
			$scope.form.takeups.record = {};
			
			// Initialize record keys
			for(var index = 0; index < $scope.form.takeups.columns.length; index++){
				$scope.form.takeups.record[$scope.form.takeups.columns[index]] = '';
			}
			
			// Intialize record values
			$scope.form.takeups.record['ICBSTotal'] = $scope.form.resultSet[0]['Transaction Amount'];
			$scope.form.takeups.record['ManualTotal'] = '0.00';
			$scope.form.takeups.record['RefType'] = 1;
			$scope.form.takeups.record['AccountName'] = $scope.form.resultSet[0]['Account Name'];
			$scope.form.takeups.record['PaymentDate'] = $scope.form.resultSet[0]['Payment Reference Date'];
			$scope.form.takeups.record['ICBSDate'] = $scope.processingDate;
			
			// Add record
			$scope.form.takeups.resultSet = [];
			$scope.form.takeups.resultSet.push($scope.form.takeups.record);
		}
		
		// Initialize Remarks
		vm.initializeRemarks = function(){
			console.log("initializeRemarks() ");
			$scope.trRemarks = '';
	
			transactionFormQueryService.viewRemarks($rootScope.dataSetID, $scope.transactionID, 'TRN', function(response){
				console.log(response);
				$scope.txtRemarks = response.data.resultSet;
				$scope.loopRemarks();
			}, function(error){
				console.log(error);
			});
		};
		
		// Get Tagging Details
		vm.getTaggingDetails = function(){
			transactionFormQueryService.getTransactionFormDetails($rootScope.dataSetID, $scope.transactionID, $scope.filtering, 
					function(response){
				console.log(response.data.resultSet);
				$scope.form.resultSet[0]['Tagging'] = response.data.resultSet[0]['Tagging'];
				$scope.form.resultSet[0]['Tagged By'] = response.data.resultSet[0]['Tagged By'];
				vm.getTakeUps();
			}, function(errorResponse){
				console.log(errorResponse);
			});	
		};
		
		// Initialize
		vm.init();
		
		
		
		
		$scope.doAddTakeUp = function(){
			
			console.log($scope.form.takeups);
			
			var isValid = true;
			var isValidAmountLength = true;
			
			for(var index = 0; index < $scope.form.takeups.resultSet.length; index++){
				
				if($scope.validateNumericInput(parseFloat($scope.form.takeups.resultSet[index]['ICBSTotal'])) === 'invalid' || $scope.validateNumericInput(parseFloat($scope.form.takeups.resultSet[index]['ManualTotal'])) === 'invalid'){
					isValidAmountLength = false;
					console.log("isValidAmountLength = false");
				}
				
				if(isValidAmountLength === false){
					alertify.alert("Amount's maximum whole number must be 14 digits only.");
					isValid = false;
					console.log("isValid = false;");
				}
			}
			
			if(isValid){
				if($scope.form.takeups.resultSet.length === 0){
					vm.initializeTakeUpRecord();
				}else{
					var record = angular.copy($scope.form.takeups.resultSet[$scope.form.takeups.resultSet.length - 1]);
					record['TakeUpID'] = '';
					record['TakeUpBy'] = '';
					record['DateOfTakeUp'] = '';
					$scope.form.takeups.resultSet.push(record);
					
					console.log($scope.form.takeups.resultSet);
				}
			}else{
				return;
			}
		}
		
		$scope.removeTakeUp = function(index){
			
			$scope.form.takeups.resultSet.splice(index, 1);
			console.log($scope.form.takeups.resultSet);
		}
		
		vm.validate = function(){
			var isValid = true;
			var isValidAmount = true;
			var isValidNumber = true;
			var isValidRefType = true;
			var isValidRefNo = true;
			var isValidAccountName = true;
			var isValidAmountLength = true;
			
			for(var index = 0; index < $scope.form.takeups.resultSet.length; index++){
				console.log($scope.form.takeups.resultSet[index]);
				console.log($scope.form.takeups.resultSet[index]['ICBSTotal']);
				console.log($scope.form.takeups.resultSet[index]['ManualTotal']);
				console.log(isNaN($scope.form.takeups.resultSet[index]['ICBSTotal']));
				
				if(parseFloat($scope.form.takeups.resultSet[index]['ICBSTotal']) === 0 && parseFloat($scope.form.takeups.resultSet[index]['ManualTotal']) === 0){
					console.log('ICBS Total and Manual Total cannot be 0 at the same time.');
					isValidAmount = false;
				}
// if(isNaN($scope.form.takeups.resultSet[index]['ICBSTotal']) === true ||
// $scope.form.takeups.resultSet[index]['ICBSTotal'] === '' ||
// isNaN($scope.form.takeups.resultSet[index]['ManualTotal']) === true ||
// $scope.form.takeups.resultSet[index]['ManualTotal'] == ''){
// console.log('ICBS Total and Manual Total must be a valid number.');
// isValidNumber = false;
// }
				
// if($scope.form.takeups.resultSet[index]['RefType'] === null ||
// $scope.form.takeups.resultSet[index]['RefType'] === undefined ||
// $scope.form.takeups.resultSet[index]['RefType'] === ''){
// isValidRefType = false;
// }
// if($scope.form.takeups.resultSet[index]['RefNo'] === null ||
// $scope.form.takeups.resultSet[index]['RefNo'] === undefined ||
// $scope.form.takeups.resultSet[index]['RefNo'] === ''){
// isValidRefNo = false;
// }
				if($scope.form.takeups.resultSet[index]['AccountName'] === null || $scope.form.takeups.resultSet[index]['AccountName'] === undefined || $scope.form.takeups.resultSet[index]['AccountName'] === ''){
					isValidAccountName = false;
				}
				if($scope.validateNumericInput(parseFloat($scope.form.takeups.resultSet[index]['ICBSTotal'])) === 'invalid' || $scope.validateNumericInput(parseFloat($scope.form.takeups.resultSet[index]['ManualTotal'])) === 'invalid'){
					isValidAmountLength = false;
				}
				
			}
			
			if($scope.form.resultSet[0]['Tagging'] === 'FT'){
				alertify.alert("Select the appropriate tagging type for this transaction first in order to proceed with this action");
				isValid = false;
			}else if(isValidAmount === false){
				alertify.alert("ICBS Total and Manual Total cannot be 0 at the same time.");
				isValid = false;
			}else if(isValidNumber === false){
				alertify.alert("ICBS Total and Manual Total must be a valid number.");
				isValid = false;
			}else if(isValidRefType === false){
				alertify.alert("Reference Type cannot be blank.");
				isValid = false;
			}else if(isValidRefNo === false){
				alertify.alert("Reference Number cannot be blank.");
				isValid = false;
			}else if(isValidAccountName === false){
				alertify.alert("Account Name cannot be blank.");
				isValid = false;
			}else if(isValidAmountLength === false){
				alertify.alert("Amount's maximum whole number must be 14 digits only.");
				isValid = false;
			}else{
				var takeUpTotal = $scope.data.summary.icbsTotal + $scope.data.summary.manualTotal;
				if(takeUpTotal > $scope.form.resultSet[0]['Transaction Amount']){
					alertify.alert("The Take Up Total Amount exceeded. Enter take up amount values that are not greater than the Transaction Amount.");
					isValid = false;
				}
			}
			
			return isValid;
		}
		
		vm.validateTagging = function(){
			var isValid = true;
			
			if($scope.form.resultSet[0]['Tagging'] === 'FT'){
				alertify.alert("Select the appropriate tagging type for this transaction first in order to proceed with this action");
				isValid = false;
			}
			
			return isValid;
		}
		
		$scope.doSaveTakeUp = function(record, index){
			
			console.log("doSaveTakeUp()");
			if(vm.validate()){
				alertify.confirm("This action saves the currently selected take-up. " +
					"Are you sure you want to proceed?", function(e){
					if(e){
						$scope.data.takeUpTag = $scope.form.resultSet[0]['Tagging'];
						$scope.data.transactionID = $scope.transactionID;
						// FilterData
						$scope.data.takeuprecord = {};						
						$scope.data.takeuprecord['PaymentDate'] = record['PaymentDate'];
						$scope.data.takeuprecord['ICBSDate'] = record['ICBSDate'];
						$scope.data.takeuprecord['ICBSTotal'] = record['ICBSTotal'].replace(/,/g,'');
						$scope.data.takeuprecord['ManualTotal'] = record['ManualTotal'].replace(/,/g,'');
						$scope.data.takeuprecord['RefType'] = record['RefType'];
						$scope.data.takeuprecord['RefNo'] = record['RefNo'];
						$scope.data.takeuprecord['AccountName'] = record['AccountName'];
						
						console.log($scope.data);
						transactionFormCommandService.doAcceptRecord($scope.data, function(response){
							console.log(response);							
							
							// Get the corresponding newly accepted Manual Take
							// Up ID
							if(!$scope.data.takeuprecord['ManualTotal'] ||
									$scope.data.takeuprecord['ManualTotal'] > 0){
								var postData = {
										'transactionID' : data.transactionID	
										};
								transactionFormQueryService.doQueryManualTakeUp(postData, function(response){
									$scope.form.latestManualTakeUpRecord = response.data.resultSet[0];
									console.log("$scope.form.latestManualTakeUpRecord:");
									console.log($scope.form.latestManualTakeUpRecord);
								
									vm.doShowJournalEntryForm(index);
								}, function(errorResponse){
								   console.log(errorResponse);
								   alertify.alert(errorResponse.data.errorMsg);
								})
							
							}else{
								$scope.retainAddedItems(index);
								vm.getTaggingDetails();
							}
						}, function(error){
							console.log(error);
							console.log('FAILED');
							alertify.alert(error.data.errorMsg);
						});
					}else{
						return;
					}
				});
			}else{
				return;
			}
		}
		
		$scope.doTag = function(){
			console.log("doTag()");
			if(vm.validateTagging()){
				alertify.confirm("This action saves any changes or updates made in this transaction. " +
					"Are you sure you want to proceed?", function(e){
					if(e){
						$scope.data.takeUpTag = $scope.form.resultSet[0]['Tagging'];
						$scope.data.transactionID = $scope.transactionID;

						transactionFormCommandService.doTagTransaction($scope.data, function(response){
							console.log(response);
							console.log('SUCCESS');
							$uibModalInstance.close(response.data.messageMap.successMsg);
						}, function(error){
							console.log(error);
							console.log('FAILED');
							alertify.alert(error.data.errorMsg);
						});
					}else{
						return;
					}
				});
			}else{
				return;
			}
		}
		
		$scope.calculateICBSTotal = function(){
			$scope.data.summary.icbsTotal = 0.00;
// console.log('ICBSTotal');
// console.log($scope.form.takeups);
			
			if($scope.form.takeups && $scope.form.takeups.resultSet){
				var total = 0.00;
				for(var index = 0; index < $scope.form.takeups.resultSet.length; index++){
					if($scope.form.takeups.resultSet[index]['ICBSTotal']){
						total = parseFloat(total) + 
							parseFloat($scope.form.takeups.resultSet[index]['ICBSTotal'].replace(/,/g,''));
						// console.log($scope.form.takeups.resultSet[index]['ICBSTotal'].replace(/,/g,''));
					}
				}
				$scope.data.summary.icbsTotal = total;
// if($scope.form.takeups.resultSet != null && $scope.form.takeups.resultSet !=
// undefined){
// for(var index = 0; index < $scope.form.takeups.resultSet.length; index++){
// if($scope.form.takeups.resultSet[index]['ICBSTotal'] != null &&
// !isNaN($scope.form.takeups.resultSet[index]['ICBSTotal']) &&
// parseFloat($scope.form.takeups.resultSet[index]['ICBSTotal']) > 0){
// $scope.data.summary.icbsTotal = parseFloat($scope.data.summary.icbsTotal) +
// parseFloat($scope.form.takeups.resultSet[index]['ICBSTotal']);
// }
// }
// }
				
			}
			
			return  $scope.roundNumber($scope.data.summary.icbsTotal, 2);
		}
		
		$scope.calculateManualTotal = function(){
			$scope.data.summary.manualTotal = 0.00;
			
			if($scope.form.takeups && $scope.form.takeups.resultSet){
				for(var index = 0; index < $scope.form.takeups.resultSet.length; index++){
					if($scope.form.takeups.resultSet[index]['ManualTotal']){
						$scope.data.summary.manualTotal = parseFloat($scope.data.summary.manualTotal) + 
							parseFloat($scope.form.takeups.resultSet[index]['ManualTotal'].replace(/,/g,''));
					}
				}
			}
			return  $scope.roundNumber($scope.data.summary.manualTotal, 2);
		}
		
		$scope.calculateBalance = function(){
			$scope.data.summary.balance = 0.00;
			
			if($scope.form.resultSet){
				$scope.data.summary.balance = parseFloat($scope.form.resultSet[0]['Transaction Amount'].replace(/,/g,'')) 
				- (parseFloat($scope.data.summary.icbsTotal) + parseFloat($scope.data.summary.manualTotal));	
			}
		
			return  $scope.data.summary.balance;
		}
		
		$scope.close = function() {
			alertify.confirm("This action cancels any changes or updates in this transaction " +
					"Are you sure you want to proceed?", function(e){
					if(e){
						$uibModalInstance.dismiss();
					}else{
						return;
					}
				});
		};
		
		$scope.doAddRemarks = function() {
			
			$scope.batchIDs = [];
			$scope.batchIDs.push($scope.transactionID);
			
			console.log('TransactionID: ' + $scope.transactionID);
			$scope.addRemarksParam = {};
			
			$scope.addRemarksParam["dataset"] = $rootScope.dataSetID;
			$scope.addRemarksParam["sourceID"] = $scope.batchIDs;
			$scope.addRemarksParam["sourceType"] = 'TRN';
			$scope.addRemarksParam["remarks"] =  $scope.remarksData.remarks;
			$scope.addRemarksParam["membershipID"] = $rootScope.session['AUTHENTICATED_USER'].activeMembership.membershipID;
			$scope.addRemarksParam["userName"] = $rootScope.session["AUTHENTICATED_USER"].username;

			console.log(' $scope.remarksData.remarks=' + $scope.remarksData.remarks);
			if($scope.remarksData.remarks){
				transactionFormQueryService.batchAddRemarks($scope.addRemarksParam)
				.then(function(response){
					alertify.alert('Successfully added remarks.', function(e){
						console.log("transactionFormQueryService: batchAddRemarks()");
						console.log(response);
						$scope.remarksData.remarks = '';
						vm.initializeRemarks();
					});
				}).catch(function(error){
					console.log(error);
				});
			}
		};	
		
		$scope.doManualTakeUp = function(record) {
			record['ICBSTotal'] = "0.00";
		};
		
		$scope.doICBSTakeUp = function(record) {
			record['ManualTotal'] = "0.00";
		};
		
		$scope.validateSave = function() {
			
			var isValidParams = true;
			
			for(var index = 0; index < $scope.form.takeups.resultSet.length; index++){
				console.log($scope.form.takeups.resultSet[index]);
				console.log($scope.form.takeups.resultSet[index]['ICBSTotal']);
				console.log($scope.form.takeups.resultSet[index]['ManualTotal']);
				if(parseFloat($scope.form.takeups.resultSet[index]['ICBSTotal']) === 0 && parseFloat($scope.form.takeups.resultSet[index]['ManualTotal']) === 0){
					console.log('ICBS Total and Manual Total cannot be 0 at the same time.');
					isValidParams = false;
				}else{
					console.log('OK po.');
					isValidParams = true;
				}
			}
			
			return isValidParams;
		};
		
		$scope.roundNumber = function(num, scale) {
			if(!("" + num).includes("e")) {
				return +(Math.round(num + "e+" + scale)  + "e-" + scale);
			} else {
				var arr = ("" + num).split("e");
				var sig = ""
				if(+arr[1] + scale > 0) {
					sig = "+";
				}
				return +(Math.round(+arr[0] + "e" + sig + (+arr[1] + scale)) + "e-" + scale);
			}
		}
		
		String.prototype.includes = function (str) {
			
			var returnValue = false;

			if (this.indexOf(str) !== -1) {
				returnValue = true;
			}

			return returnValue;
		}
		
		$scope.preventPaste = function(e){
			   e.preventDefault();
			   return false;
		};
		
		vm.doShowJournalEntryForm = function(index){
			// Get last Manual Take-Up record
			var modalInstance = $uibModal.open({
				animation: true,
				backdrop: 'static',
				templateUrl: 'app/components/forms/journalentryform/viewJournalEntryForm.html',
				controller: 'journalEntryFormController',
				size: 'lg',
				resolve:{
					data:function(){
						var record = $scope.form.latestManualTakeUpRecord;
						var data = {};
						
						data.header = {};
						data.header.batchID = record['Journal Entry ID'];
						data.header.transactionSourceID = record['TakeUp ID'];
						data.header.glDate = record['Effective Date'];
						data.header.bookCode = record['Book'];
						data.header.currencyCode = record['Currency'];
							
						console.log('CURRENCY CODE:');	
						console.log(data.header.currencyCode);
						
// data.header.takeUpAmount = parseFloat(record['Manual
// Total'].replace(/\,/g,'')).toFixed(2);
						data.header.takeUpAmount = parseFloat(record['Manual Total']).toFixed(2);
						data.header.referenceNo = record['Ref No'];
						
						data.record = {};
						data.record.drCrTag = record['ReverseDrCr'];
						data.record.accountProfileID = record['AcctProfileID'].toString();
						data.record.accountName = record['Account Name'];
						data.record.hdescription = record['Details']; 
// data.record.origAmount = parseFloat(record['Manual
// Total'].replace(/\,/g,'')).toFixed(2);
						data.record.origAmount =  parseFloat(record['Manual Total']).toFixed(2);
						data.record.recordSource =  record['Record Source'];
						
						return data;
					},
					load: ['$q', function($q){
						var defered = $q.defer();
						require(['app/components/forms/journalentryform/journalEntryFormController'], function(){
							defered.resolve();
						});
						return defered.promise;
					}]
				}
			});
			modalInstance.result.then(
				function(message) {
					$scope.retainAddedItems(index);
					vm.getTaggingDetails();
					// $scope.tableParams.reload();
				}, 
				function() {				
					// dismissed
					$scope.retainAddedItems(index);
					vm.getTaggingDetails();
					console.log("dismissed");
				}
			);
			return modalInstance.result;
		};
		
		$scope.toggleTakeUp = function(){
			console.log('$scope.toggleTakeUp: '+$scope.form);
			console.log($scope.form);
			if($scope.form){
				if($scope.form.resultSet && $scope.form.resultSet[0]['Tagging']){
					if($scope.references.taggingList){
						for(var index = 0; $scope.references.taggingList.length > index; index++){
							if($scope.references.taggingList[index].code === $scope.form.resultSet[0]['Tagging']){
								$scope.form.hasTakeUp = $scope.references.taggingList[index].additionalDetail;
								console.log('$scope.form.hasTakeUp 1: '+$scope.references.taggingList[index]);
								console.log('$scope.form.hasTakeUp 1: '+$scope.form.hasTakeUp);
								
								return; 
							}
						}
					}
				}else{
					if($scope.references.taggingList){
						$scope.form.hasTakeUp = $scope.references.taggingList[0].additionalDetail;
						console.log('$scope.form.hasTakeUp 2: '+console.log($scope.form.hasTakeUp));
						
						return;
					}
				}
			}else{
				$scope.form.hasTakeUp = 'false';
				console.log('$scope.form.hasTakeUp 3: '+console.log($scope.form.hasTakeUp));
				
				return;
			}			
		};
		
		$scope.loopRemarks = function(){
			
			angular.forEach($scope.txtRemarks, function(value, key){
				
				console.log(value);
				console.log(key);
				$scope.trRemarks = $scope.trRemarks + '\n' + value.trRemarks;
			});
			
			$scope.trRemarks = $scope.trRemarks.substring(1);
			
		};
		
		$scope.retainAddedItems = function(index){
			
			console.log(index);
			$scope.prevRecords = angular.copy($scope.form.takeups.resultSet);
			$scope.prevRecords.splice(index, 1);
			
			var counter = $scope.prevRecords.length - 1;
			for(counter = $scope.prevRecords.length - 1; counter>=0; counter--){
				
				if($scope.prevRecords[counter].TakeUpID !== ""){
					$scope.prevRecords.splice(counter, 1);
				}
			}
		};
		
//		$scope.$watch('references.taggingList', function(newVal, oldVal) {
//	        console.log('watching: form.resultSet[0].Tagging');
//	        console.log('newVal: '+newVal+'; oldVal'+oldVal);
//	        console.log('$scope.form: '+$scope.form);
//			console.log('$scope.references.taggingList: '+$scope.references.taggingList);
//			console.log($scope.form);
//			console.log($scope.references.taggingList);
//	        if(newVal !== oldVal && $scope.form){
//				 console.log('watched!');
//	        	$scope.toggleTakeUp();
//	        }
//	    });
		
		$scope.$watch('form', function(newVal, oldVal) {
	        console.log('watching: form');
	        console.log('newVal: '+newVal+'; oldVal'+oldVal);
	        console.log('$scope.form: '+$scope.form);
			console.log($scope.form);
			$scope.toggleTakeUp();
	    });
		
		/**
		 * 
		 */
		$scope.restrictLargeNumericInput = function(amount, $event, idx){
			console.log("idx: " + idx);
			var isValid = vm.restrictNumericInput(amount, $event, idx);
			console.log('$scope.restrictLargeNumericInput: '+isValid);
			console.log('$event.keyCode: '+$event.keyCode);
			if(isValid === 'invalid'){
				if($event.keyCode === 0) { 
					$event.preventDefault();
					return false;
				}
			}
		}
		
		/**
		 * 
		 */
		vm.restrictNumericInput = function(amount, $event, idx){
			var decimalCount =  vm.countDecimals(amount);
			var integerCount =  vm.countIntegers(amount);
			var totalDigitCount = decimalCount + integerCount;
			var numericType = $scope.select(amount, idx);
			
			console.log('AMOUNT: ' + amount);
			console.log('DECIMAL COUNT: ' + decimalCount);
			console.log('INTEGER COUNT: ' + integerCount);
			console.log('TOTAL COUNT: ' + totalDigitCount);
			
			if(numericType === 'Integer'){
				if(integerCount > 13 || decimalCount > 2){
					return 'invalid';
				}else{
					return 'valid';
				}
			}else if(numericType === 'Decimal'){
				if(decimalCount > 1){
					return 'invalid';
				}else{
					return 'valid';
				}
			}else if(numericType === 'Numeric_Dot'){
				if ((window.event ? $event.keyCode : $event.which !== 46)) {
					console.log('DOT_ONLY & DELETE');
					return 'invalid';
				}else{
					return 'valid';
				}
			}else if(numericType === 'Decimal_Dot'){
				if ((window.event ? $event.keyCode : $event.which !== 8)) {
					console.log('DOT_ONLY & DELETE');
					return 'invalid';
				}else{
					return 'valid';
				}
			}
		};
		
		/**
		 * 
		 */
		$scope.validateNumericInput = function(amount){
			var decimalCount =  vm.countDecimals(amount);
			var integerCount =  vm.countIntegers(amount);
			var totalDigitCount = decimalCount + integerCount;
			
			console.log('AMOUNT: ' + amount);
			console.log('DECIMAL COUNT: ' + decimalCount);
			console.log('INTEGER COUNT: ' + integerCount);
			console.log('TOTAL COUNT: ' + totalDigitCount);
			
			if(totalDigitCount > 16 || integerCount > 14){
				return 'invalid';
			}else{
				return 'valid';
			}
		};
		
		/**
		 * 
		 */
		vm.countDecimals = function (value) {
		    if(Math.floor(value) === value) return 0;
		    if(value.toString().indexOf(".") !== -1){
		    	return value.toString().split(".")[1].length || 0;
		    }else{
		    	return 0;
		    }
		    
		};
		
		/**
		 * 
		 */
		vm.countIntegers = function (value) {
			var valueStr = value.toString();
			
			if(valueStr.indexOf(".") !== -1){
				var valueIndex = valueStr.indexOf('.');
				var valueLatest = valueStr.substring(0, valueIndex);
				return valueLatest.length;
			}else{
				return valueStr.length;
			}
		};
		
		$scope.select = function(value, idx){
			
			var valueStr = value.toString();
			var dotIndex = valueStr.indexOf(".");
			var cursorPosition = $("#"+idx).prop("selectionStart");
			var numericType = ''; 
			
			console.log("DOT POSITION: " + dotIndex);
			console.log("CURSOR POSITION: " + cursorPosition);
			
			var valueofIndex = valueStr.charAt(parseInt(cursorPosition));
			
			console.log(valueofIndex);
			
			if(dotIndex >= 0){
				if(cursorPosition <= dotIndex){
					console.log("Integer");
					numericType = 'Integer';
				}else{
					console.log("Decimal");
					numericType = 'Decimal';
				}
			}else if(dotIndex === -1 && cursorPosition === 14){
				console.log("Numeric_Dot");
				numericType = 'Numeric_Dot';
			}else{
				console.log("Integer");
				numericType = 'Integer';
			}
			
			return numericType;
		};
		
		$scope.removeTagDot = function (event) {
		    if (window.event ? event.keyCode : event.which === 46) {
		        console.log('DOT');
		    }
		};
		
		$scope.removeTagOnBackspace = function (event) {
		    if (event.keyCode === 8) {
		        console.log('DELETE');
		    }
		};
		
	}]);
});