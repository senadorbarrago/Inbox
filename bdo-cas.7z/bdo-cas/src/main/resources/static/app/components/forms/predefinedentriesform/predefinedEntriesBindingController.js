'use strict';

define(function(){
	var core = angular.module('core');
	
	core.registerController('predefinedEntriesBindingController',['$rootScope', '$scope', '$uibModalInstance', '$uibModal', 'data', 'DataAccessService', '$filter',
	                                                     function($rootScope, $scope, $uibModalInstance, $uibModal, data, dataAccessService, $filter){
	    $scope.title = 'Predefined Entries Binding Form';
		
		var vm = this;

		vm.init = function(){
			console.log(data);
			console.log('HEY');
			
			$scope.form = {};
			$scope.data = {};
			
			$scope.data.id = data.bindID;
			$scope.data.predefinedEntriesID = data.predefinedEntryID;
			$scope.data.dataSetID = $rootScope.dataSetID;
			$scope.data.dataSetCode = $rootScope.dataSetCode;
			$scope.data.recordProfileID = data.recordProfileID;
			$scope.data.dataFieldColumnID = data.dataFieldColumnID;
			
			if(data.bindID === 0){
				$scope.data.actionTag = "ADD";
			}else{
				$scope.data.actionTag = "UPDATE";
			}
			
			vm.getRecordProfiles();
			vm.getPDEFields();
		}
		
		//Get Record Profiles
		vm.getRecordProfiles = function(){
			
			var url = 'references/pdeRecordProfiles/'+$rootScope.dataSetID;
			dataAccessService.doGetData(url, null, function(response){
				console.log(response.data);
				$scope.pdeRecordProfiles = response.data;
			},function(errorResponse){
				errorCallBack(errorResponse);
			});
		};
		
		//Get Data Field Columns
		vm.getPDEFields = function(){
			
			console.log($scope.data.recordProfileID);
			
			var url = 'references/pdeDataFields/'+$rootScope.dataSetID+'/'+$scope.data.recordProfileID;
			dataAccessService.doGetData(url, null, function(response){
				console.log(response.data);
				$scope.pdeDataFields = response.data;
			},function(errorResponse){
				errorCallBack(errorResponse);
			});
		};
		
		vm.init();
		
		//Get Data Field Columns
		$scope.getPDEFields = function(){
			
			console.log($scope.data.recordProfileID);
			
			var url = 'references/pdeDataFields/'+$rootScope.dataSetID+'/'+$scope.data.recordProfileID;
			dataAccessService.doGetData(url, null, function(response){
				console.log(response.data);
				$scope.pdeDataFields = response.data;
			},function(errorResponse){
				errorCallBack(errorResponse);
			});
		};
		
		$scope.addPDED = function(){
			
			console.log("Add Predefined Entries Binding.");
			$scope.data.pdeActionTag = "ADD";
			$scope.setAttribute($scope.data.pdeActionTag)
			
			console.log($scope.data);
		};
		
		$scope.editPDED = function(){
			
			console.log("Edit Predefined Entries Binding.");
			$scope.data.pdeActionTag = "UPDATE";
			
			if(!$scope.selectedRecord){
				alertify.alert("Please select an item first in order to proceed with this action.");
				return false;
			}else {
				console.log("OK");
				$scope.setAttribute($scope.data.pdeActionTag)

				console.log($scope.data);
			}
			
		};
		
		//Save
		$scope.save = function(){
			
			console.log("pdeActionTag: " + $scope.data.pdeActionTag);
			console.log($scope.data);
			
			var savePredefinedEntriesDefinitionUrl = 'transactions/predefinedEntriesBinding/setup';
			alertify.confirm("Do you really want to save this predefined entry binding?", function(e){
					
				if(e){
					dataAccessService.doPostData(savePredefinedEntriesDefinitionUrl, $scope.data, function(response){
						console.log(response);
						alertify.alert(response.data.messageMap.successMsg);
						$uibModalInstance.dismiss();
					},function(errorResponse){
						console.log(errorResponse);
						alertify.fail(errorResponse.data.errorMsg);
					});
				}else{
					return;
				}
				
			});
		};
		
		$scope.cancel = function() {
			alertify.confirm("This action cancels any changes or updates in this predefined entry. " +
					"Are you sure you want to proceed?", function(e){
					if(e){
						$uibModalInstance.dismiss();
					}else{
						return;
					}
				});
		};
		
	}]);
	
});