'use strict';

define(function(){
	angular.module("core").provider('TransactionFormQueryService', function(){
		this.$get =['$http', 'DataAccessService', function($http, dataAccessService){
			var service = {
				getTransactionFormDetails: function(dataSetID, transactionID, filtering, successCallBack, errorCallBack) {
					var url  = 'transactions/form/details/'+dataSetID+'/'+transactionID+'/'+filtering;
					dataAccessService.doGetData(url, null, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getTakeUpDetails: function(dataSetID, transactionID, successCallBack, errorCallBack) {
					var url  = 'transactions/form/takeups/'+dataSetID+'/'+transactionID;
					dataAccessService.doGetData(url, null, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getTaggingReferences: function(dataSetID, transactionID, encodingUnitCode, successCallBack, errorCallBack){
					var url = 'references/tagging/'+dataSetID+'/'+transactionID+'/'+encodingUnitCode;
					dataAccessService.doGetData(url, null, function(response){
						console.log(response.data);
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getProcessingDate: function(dataSetID, encodingUnitID, successCallBack, errorCallBack){
					var url = 'references/processingDate/'+dataSetID+'/'+encodingUnitID;
					dataAccessService.doGetData(url, null, function(response){
						console.log(response.data);
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				addRemarks: function(addRemarksData) {
					var url  = 'remarks/add';
					return $http.post(url, addRemarksData);
				},
				viewRemarks: function(dataset, sourceID, sourceType, successCallBack, errorCallBack) {
					var url  = 'remarks/view/' + dataset + '/' + sourceID + '/' + sourceType;

					dataAccessService.doGetData(url, null, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				batchAddRemarks: function(addRemarksData) {
					var url  = 'remarks/batchAdd';
					return $http.post(url, addRemarksData);
				},
				doQueryManualTakeUp: function(data, successCallBack, errorCallBack) {
					var url  = 'transactions/form/manualtakeup';
					dataAccessService.doPostData(url, data, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				doGetReferenceType: function(data, successCallBack, errorCallBack) {
					var url  = 'qry/ReferenceTypeQueryModel';
					dataAccessService.doPostData(url, data, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				}
			}
			return service;
		}]
	});	
});