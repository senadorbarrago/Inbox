'use strict';

define(function(){
	console.log('reportFormModule.js loaded');
	var reportFormModule = angular.module('reportFormModule', ['utility']);
	
	// ControllerProvider Configuration
	reportFormModule.config(['$controllerProvider', function($controllerProvider){
		reportFormModule.registerController = $controllerProvider.register;
	}]);
	
	
});