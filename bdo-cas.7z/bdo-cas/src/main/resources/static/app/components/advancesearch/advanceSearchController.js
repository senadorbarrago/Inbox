'use strict';

define(function(){
	console.log('advanceSearchController.js loaded');
	var core = angular.module('core');
	
	core.registerController('advanceSearchController',['$rootScope', '$scope', '$uibModal', '$routeParams', 'DataAccessService',
		function($rootScope, $scope, $uibModal, $routeParams, dataAccessService){
		$rootScope.screenName = 'Advance Search';
		
		
		
		/*console.log(advancesearch);
		
		var advancesearch = advancesearch.get($routeParams.code) || { title: 'Advance Search' };
		console.log(advancesearch);
	    // Updates the breadcrumb trail with the given context
	    crumble.update({advancesearch: advancesearch});

	    // Instead you could also build up context in place before calling update
	    crumble.context = {advancesearch: advancesearch};
	    crumble.update();*/
		
		var vm = this;
		
		vm.init = function () {
			
			vm.dataSetID = $rootScope.dataSetID;
			$scope.data = {};
			$scope.data.displayFieldValues = [];
			$scope.data.filterFieldValues = {};
			$scope.data.sortFieldValues = {};
			
			vm.searchType = $routeParams.code;
			
			$scope.advancesearchTypeList = [
											{
											 "heading"	: "Transactions",
											 "code"	    : "ADV-002",
											 "selected" : vm.searchType === "ADV-002" ? true : false 
											 },
											 {
											 "heading"  : "Journal Entries",
											 "code"	    : "ADV-001",
											 "selected" : vm.searchType === "ADV-001" ? true : false
											 }
										];
			$scope.sortTypes = [
								 {
								   'id'  : 0,
								   'code': 'ASC'
								 },
								 {
								   'id'  : 1,
								   'code': 'DESC'
								 }
							   ];
			
			$scope.operatorTypes = [
									 {
									   'id'  : 1,
									   'code': '=',
									   'desc': '='
									 },
									 {
									   'id'  : 2,
									   'code': 'LIKE%',
									   'desc': 'LIKE%'
									 },
									 {
									   'id'  : 3,
									   'code': '%LIKE',
									   'desc': '%LIKE'
									 },
									 {
									   'id'  : 4,
									   'code': '%LIKE%',
									   'desc': '%LIKE%'
									 },
									 {
									   'id'  : 5,
									   'code': 'LT',
									   'desc': '<'
									 },
									 {
									   'id'  : 6,
									   'code': 'GT',
									   'desc': '>'
									 },
									 {
									   'id'  : 7,
									   'code': 'LTE',
									   'desc': '<='
									 },
									 {
									   'id'  : 8,
									   'code': 'GTE',
									   'desc': '>='
									 }
							   ];
			
			vm.getDisplayFields();
			vm.getFilterFields();
			vm.getSortFields();
		}
		
		// DisplayFields
		vm.getDisplayFields = function(){
			var url = "advancesearch/fields/"+vm.dataSetID+"/"+vm.searchType+"/DISPLAY_FIELD";
			dataAccessService.doGetData(url, null, function(response){
				console.log(response);
				$scope.displayFieldList = response.data;
				
				// Initialize default displayFieldValues
				for(var index = 0; index < $scope.displayFieldList.length; index++){
					$scope.displayFieldList[index].selected = true;
				}
			}, function(errorResponse){
				console.log(errorResponse.status+': '+errorResponse.headers("ERROR_MESSAGE"));
				alertify.fail(errorResponse.status+': '+errorResponse.headers("ERROR_MESSAGE"));
			});
		}
		// FilterFields
		vm.getFilterFields = function(){
			var url = "advancesearch/fields/"+vm.dataSetID+"/"+vm.searchType+"/FILTER_FIELD";
			dataAccessService.doGetData(url, null, function(response){
				console.log(response);
				$scope.filterFieldList = response.data;
				
				// Initialize default filterFieldValues
				for(var index = 0; index < $scope.filterFieldList.length; index++){
					$scope.filterFieldList[index].selected = false;
					if($scope.filterFieldList[index].hasRange === true){
						$scope.filterFieldList[index].operator = 'BETWEEN';
					}else{
						$scope.filterFieldList[index].valueTo = '';
					}
				}
			}, function(errorResponse){
				console.log(errorResponse.status+': '+errorResponse.headers("ERROR_MESSAGE"));
				alertify.fail(errorResponse.status+': '+errorResponse.headers("ERROR_MESSAGE"));
			});
		}
		// SortFields
		vm.getSortFields = function(){
			var url = "advancesearch/fields/"+vm.dataSetID+"/"+vm.searchType+"/SORT_FIELD";
			dataAccessService.doGetData(url, null, function(response){
				console.log(response);
				$scope.sortFieldList = response.data;
				for(var index = 0; index < $scope.sortFieldList.length; index++){
					$scope.sortFieldList[index].selected = false;
				}
			}, function(errorResponse){
				console.log(errorResponse.status+': '+errorResponse.headers("ERROR_MESSAGE"));
				alertify.fail(errorResponse.status+': '+errorResponse.headers("ERROR_MESSAGE"));
			});
		}
		
		$scope.doSearch = function(){
			$scope.data.displayFieldValues = [];
			for(var index = 0; index < $scope.displayFieldList.length; index++){
				if($scope.displayFieldList[index].selected === true){
					$scope.data.displayFieldValues.push($scope.displayFieldList[index].id);
				}
			}
			console.log($scope.data.displayFieldValues);
			
			$scope.data.filterFieldValues = [];
			for(var index = 0; index < $scope.filterFieldList.length; index++){
				console.log($scope.filterFieldList[index].selected);
				if($scope.filterFieldList[index].selected === true){
					var filter = {};
					filter.id = $scope.filterFieldList[index].id;
					filter.operator = $scope.filterFieldList[index].operator;
					filter.valueFrom = $scope.filterFieldList[index].valueFrom;
					filter.valueTo = $scope.filterFieldList[index].valueTo;
					
					if($scope.filterFieldList[index].hasRange === true){
						if(filter.valueFrom && filter.valueTo){
							filter.operator = 'BETWEEN'
						}else if(filter.valueFrom && !filter.valueTo){
							filter.operator = 'GTE'
						}else if(!filter.valueFrom && filter.valueTo){
							filter.operator = 'LTE'
						}
					}
					
					$scope.data.filterFieldValues.push(filter);
				}
			}
			console.log($scope.data.filterFieldValues);
			
			$scope.data.sortFieldValues = [];
			for(var index = 0; index < $scope.sortFieldList.length; index++){
				console.log($scope.sortFieldList[index].selected);
				if($scope.sortFieldList[index].selected === true){
					var sort = {};
					sort.id = $scope.sortFieldList[index].id;
					sort.order = $scope.sortFieldList[index].order;
					sort.valueFrom = $scope.sortFieldList[index].valueFrom;
					
					$scope.data.sortFieldValues.push(sort);
				}
			}
			console.log($scope.data.sortFieldValues);
			
			$scope.data.advanceSearchCode = vm.searchType;
			
			vm.doShowResultForm($scope.data);
		};
		
		vm.doShowResultForm = function(data){
			var modalInstance = $uibModal.open({
				animation: true,
				backdrop: 'static',
				templateUrl: 'app/components/advancesearch/advanceSearchResult.html',
				controller: 'advanceSearchResultController',
				size: 'lg',
				resolve:{
					load: ['$q', function($q){
						var defered = $q.defer();
						require(['app/components/advancesearch/advanceSearchResultController'], function(){
							defered.resolve();
						});
						return defered.promise;
					}],
					data:function(){
						return data;
					}
				}
			});
			modalInstance.result.then(function(message){
				alertify.alert(message);
			}, 
			function() {				
				// dismissed
				console.log("dismissed");
			}
			);
			return modalInstance.result;
		}
		
		// Initialize
		vm.init();
		
		// Toggle Display Fields
		$scope.doToggleDisplayFields = function(){
			if($scope.displayFieldList && $scope.displayFieldList.length > 1){
				angular.forEach($scope.displayFieldList, function(value, key){
					value.selected = !value.selected;
				});
			}
		}
		
		// Clear All Filter Fields
		$scope.doClearAllFilterFields = function(){
			if($scope.filterFieldList && $scope.filterFieldList.length > 1){
				angular.forEach($scope.filterFieldList, function(value, key){
					value.selected = false;
					value.operator = '';
					value.valueFrom = '';
					value.valueTo = '';
				});
			}
		}
		
		// Clear All Order Fields
		$scope.doClearAllOrderFields = function(){
			if($scope.sortFieldList && $scope.sortFieldList.length > 1){
				angular.forEach($scope.sortFieldList, function(value, key){
					value.selected = false;
					value.order = '';
					value.valueFrom = '';
				});
			}
		}
		
	}]);
	
});