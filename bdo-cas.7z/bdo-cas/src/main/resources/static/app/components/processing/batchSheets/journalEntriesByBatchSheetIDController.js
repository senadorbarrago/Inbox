'use strict';

define(function(){
	console.log('journalEntriesByBatchSheetIDController.js loaded');
	var core = angular.module('core');
	
	core.registerController('journalEntriesByBatchSheetIDController', [ '$rootScope', '$scope', '$uibModalInstance', 'DataAccessService', 'data', 
		function($rootScope, $scope, $uibModalInstance, dataAccessService, data){
		$scope.title = 'Journal Entries By Batch Sheet';
		
		var vm = this;
		vm.init = function() {
			console.log(data);
			if(data.batchSheetID != null && data.batchSheetID > 0){
				var url  = 'journalentries/batchsheet/'+data.batchSheetID;
				dataAccessService.doGetData(url, null, function(response){
					console.log(response);
					$scope.form = response.data;
				},function(errorResponse){
					console.log(errorResponse);
				});
			}
			console.log($scope.form);
		}
		// Initialize
		vm.init();
		
		$scope.close = function(){
			$uibModalInstance.close();
		};
		
	}]);
	
});