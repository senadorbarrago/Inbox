'use strict';

define(function(){
	
	console.log('outboundController.js loaded');
	var core = angular.module('core');
	
	core.registerController('outboundController', function($rootScope, $scope){
		$scope.title = 'This is the Outbound Screen';
		$rootScope.screenName = 'OUTBOUND_INTERFACE';
	});
	
});