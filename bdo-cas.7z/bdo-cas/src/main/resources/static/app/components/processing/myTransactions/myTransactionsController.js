'use strict';

define(function(){
	
	console.log('myTransactionController.js loaded');
	var core = angular.module('core');
	
	core.registerController('myTransactionsController',['$rootScope', '$scope', '$uibModal', 'MyTransactionsQueryService', 'MyTransactionsCommandService', 'ngTableParams', '$filter', 'DataAccessService',
		function($rootScope, $scope, $uibModal, myTransactionsQueryService, myTransactionsCommandService, ngTableParams, $filter, dataAccessService){
		$scope.title = 'This is the My Take-Ups Screen';
		$rootScope.screenName = 'PROCESSING --> MY TAKE-UPS';
		
		// Create controller object VM
		var vm = this;
		
		vm.init = function() {
			vm.dataSetID = $rootScope.dataSetID;
			vm.dataSetCode = $rootScope.dataSetCode;
			
			$scope.form = {};
			$scope.form.searchcriteria = {};
			$scope.form.searchcriteria.data = {};
			$scope.form.searchcriteria.data.filterList = [];
			$scope.form.searchcriteria.data.sortList = [];
			$scope.form.datagrid = {};
			$scope.references = {};
			
			vm.pageIndex = 1;
			vm.pageSize = 50;
			
			vm.getFieldList();
			vm.loadPage();
			vm.getGroupUser();
			
			$scope.data = {};
		}
		
		vm.getFieldList= function(){
			myTransactionsQueryService.getColumnList(vm.dataSetID, 32, function(response){
				$scope.form.searchcriteria.dataFieldList = [];
				angular.forEach(response.data.resultSet, function(value, key) {
						$scope.form.searchcriteria.dataFieldList.push(value);
				});
				console.log($scope.form.searchcriteria.dataFieldList);
			}, function(error){
				console.log(error);
			});
		};
		
		vm.loadPage = function() {
			$scope.tableParams = new ngTableParams(
					{	page: 1,
						count: 25
					},
					{	getData: function ($defer, params) {
						return myTransactionsQueryService.getMyTransactionsList(vm.dataSetCode,
								params.page(), params.count(), $scope.form.searchcriteria.data, function (response) {
								$scope.form.datagrid = response.data;			
								params.total($scope.form.datagrid.resultOverAllCount);
								$defer.resolve($scope.form.datagrid.resultSet);
							}, function(response) {});
						}
					}
			);
		};
		
		vm.getGroupUser = function(){
			myTransactionsQueryService.getGroupUsers($scope.dataSetID, function(response){
				$scope.references.groupUsersList = response.data;			
			}, function(errorResponse){
				console.log(errorResponse);
			});
		}
		// Initialize
		vm.init();		
		
		// SearchPanel
		$scope.selectFilterField = function(){
			console.log($scope.form.searchcriteria.filterField);
		};
		
		$scope.doAddFilter = function(){
			if(!$scope.form.searchcriteria.filterField){
				alertify.alert("Please select a filter field in order to proceed.");
				return false;
			}
			
			var record = {"id":$scope.form.searchcriteria.filterField.dataFieldID, "fieldName":$scope.form.searchcriteria.filterField.fieldName, "fieldLabel":$scope.form.searchcriteria.filterField.label , "hasRange":$scope.form.searchcriteria.filterField.hasRange, "valueFrom":"", "valueTo":""};
			var isExists = false;
			
			angular.forEach($scope.form.searchcriteria.data.filterList, function(value, key){
				if(!isExists){
					if(value.id === $scope.form.searchcriteria.filterField.dataFieldID){
						isExists = true;
					}
				}
			});
			
			if(!isExists){
				$scope.form.searchcriteria.data.filterList.push(record);
			}
		};
		
		$scope.removeFilter = function(index){
			var item = $scope.form.searchcriteria.data.filterList[index];
			$scope.form.searchcriteria.data.filterList.splice(index, 1);
		};
		
		$scope.doClearFilterFields = function(){
			$scope.form.searchcriteria.filterField = {};
			$scope.form.searchcriteria.data.filterList = [];
		};
		
		$scope.selectSortField = function(){
			console.log($scope.form.searchcriteria.sortField);
		};
		
		$scope.doAddSort = function(){
			if(!$scope.form.searchcriteria.sortField){
				alertify.alert("Please select a sort field in order to proceed.");
				return false;
			}
			
			var record = {"id":$scope.form.searchcriteria.sortField.dataFieldID, "fieldName":$scope.form.searchcriteria.sortField.fieldName, "fieldLabel":$scope.form.searchcriteria.sortField.label, "order":"1", "valueFrom":"ASC"};
			var isExists = false;
			
			angular.forEach($scope.form.searchcriteria.data.sortList, function(value, key){
				if(!isExists){
					if(value.id === $scope.form.searchcriteria.sortField.dataFieldID){
						isExists = true;
					}
				}
			});
			
			if(!isExists){
				$scope.form.searchcriteria.data.sortList.push(record);
			}
		};
		
		$scope.removeSort = function(index){
			var item = $scope.form.searchcriteria.data.sortList[index];
			$scope.form.searchcriteria.data.sortList.splice(index, 1);
		};
		
		$scope.doClearSortFields = function(){
			$scope.form.searchcriteria.sortField = {};
			$scope.form.searchcriteria.data.sortList = [];			
		};
		
		$scope.doClearAll = function(){
			$scope.doClearFilterFields();
			$scope.doClearSortFields();
		};
		
		$scope.doShowAll = function(){
			$scope.doClearAll();
			
			// Reset pageSize and pageIndex
			$scope.tableParams.page(1);
			$scope.tableParams.count(25);

			//Reload Paginated Request
			$scope.tableParams.reload();
		}
		
		$scope.doSearch = function(){			
			console.log("doSearch()");
			console.log($scope.form.searchcriteria.data.filterList);
			console.log($scope.form.searchcriteria.data.sortList);
			
			//Revert to page 1
			$scope.tableParams.page(1);
			//Reload Paginated Request
			$scope.tableParams.reload();
		};
		
		$scope.selectAll = function(){
			var toggleStatus = $scope.form.isAllSelected;
			console.log(toggleStatus);
			angular.forEach($scope.form.datagrid.resultSet, function(record){
				record.selected = toggleStatus;
			});
		}
		
		$scope.doChangeSelection = function(record){
			record.selected = !record.selected;
			if(!record.selected){
				$scope.form.isAllSelected = false;
			}
		}
		
		$scope.doReturnToInbox = function(){
			var selectedItems = vm.getSelectedItems($scope.form.datagrid.resultSet);
			if(selectedItems.length == 0){
				alertify.alert("Please select items first in order to proceed with this action");
			}else{
				alertify.confirm("This action returns the selected accounts to inbox and removes the corresponding take up details. " +
					"Are you sure you want to proceed?", function(e){
					if(e){
						var takeUpIDs = [];
						
						for(var i = 0; i < selectedItems.length; i++){
							takeUpIDs.push(selectedItems[i]['TakeUp ID']);
						}
						
						myTransactionsCommandService.returnToInbox(takeUpIDs, function(response){
							alertify.alert(response.data.messageMap.successMsg);							
							$scope.tableParams.reload();
						}, function(error){
							console.log(error);
							alertify.fail(error.errorMsg);
						});
					}else{
						return false;
					}
				});		
			}
			
		};
		
		// Tag selected transactions for referral
		$scope.doReassignTakeup = function(){
			var selectedTakeupIDList = [];
			
			var selectedItems = vm.getSelectedItems($scope.form.datagrid.resultSet);
			
			if(selectedItems.length == 0){
				alertify.alert("Please select items first in order to proceed with this action.");
				return false;
			}
			
			if($scope.data.reassignTo === undefined || $scope.data.reassignTo === null){
				alertify.alert("Please select a user to be assigned.");
				return false;
			}
			
			for(var i = 0; i < selectedItems.length; i++){
				selectedTakeupIDList.push(selectedItems[i]['TakeUp ID']);
			}
			$scope.data.transactionID = selectedTakeupIDList;
			
			alertify.confirm("This action returns the selected batch sheets approved. " +
				"Are you sure you want to proceed?", function(e){
				if(e){
						myTransactionsCommandService.reassignTakeup($scope.data, function(response){
							$scope.tableParams.reload();
							alertify.alert("The selected records has been successfully reassigned.");
						}, function(error){
							alertify.fail("Reassigning of take up/s failed.");
						});
				}else{
					return;
				}
			});
			
		};
		
		$scope.doShowAcceptTransactionForm = function(transactionID){
			console.log(transactionID);
			var modalInstance = $uibModal.open({
				animation: true,
				backdrop: 'static',
				templateUrl: 'app/components/forms/transactionform/transactionForm.html',
				controller: 'transactionFormController',
				size: 'lg',
				resolve:{
					load: ['$q', function($q){
						var defered = $q.defer();
						require(['app/components/forms/transactionform/transactionFormController'], function(){
							defered.resolve();
						});
						return defered.promise;
					}],
					data : function(){
						var data = {}; 
						data.transactionID = transactionID;
						data.allowAcceptTransaction = false;
						return data;
					}
				}
			});
			modalInstance.result.then(function(message){
				alertify.alert(message);
				$scope.tableParams.reload();
			}, 
			function() {				
				// dismissed
				console.log("dismissed");
			});
			return modalInstance.result;
		}
		
		$scope.doShowJournalEntryForm = function(index){
			var modalInstance = $uibModal.open({
				animation: true,
				backdrop: 'static',
				templateUrl: 'app/components/forms/journalentryform/viewJournalEntryForm.html',
				controller: 'journalEntryFormController',
				size: 'lg',
				resolve:{
					data:function(){
						var record = $scope.form.datagrid.resultSet[index];
						var data = {};
						
						data.header = {};
						data.header.batchID = record['Journal Entry ID'];
						data.header.transactionSourceID = record['TakeUp ID'];
						data.header.glDate = record['Effective Date'];
						data.header.bookCode = record['Book'];
						data.header.currencyCode = record['Currency'];
						data.header.takeUpAmount = parseFloat(record['Manual Total'].replace(/\,/g,'')).toFixed(2);
						data.header.referenceNo = record['Ref No'];
						
						data.record = {};
						data.record.drCrTag = record['ReverseDrCr'];
						data.record.accountProfileID = record['AcctProfileID'].toString();
						data.record.accountName = record['Account Name'];
						data.record.hdescription = record['Details']; 
						data.record.origAmount =  parseFloat(record['Manual Total'].replace(/\,/g,'')).toFixed(2);
						console.log('OrigAmount: '+record['Manual Total']);
						console.log('OrigAmount: '+parseFloat(record['Manual Total'].replace(/\,/g,'')).toFixed(2));
						console.log('RecordSource: '+record['Record Source']);
						data.record.recordSource =  record['Record Source'];
						
						return data;
					},
					load: ['$q', function($q){
						var defered = $q.defer();
						require(['app/components/forms/journalentryform/journalEntryFormController'], function(){
							defered.resolve();
						});
						return defered.promise;
					}]
				}
			});
			modalInstance.result.then(
				function(message) {
					$scope.tableParams.reload();
				}, 
				function() {				
					// dismissed
					console.log("dismissed");
				}
			);
			return modalInstance.result;
		};
		
		// Get selected items
		vm.getSelectedItems = function(items){
			var selectedItems = [];
			for(var i = 0; i < items.length; i++){
				var selected = items[i].selected;
				if(selected === true){
					selectedItems.push(items[i]);
				}
			}
			return selectedItems;
		}		
		
		$scope.doAddRemarks = function(){
			var selectedItems = vm.getSelectedItems($scope.form.datagrid.resultSet);
			
			if(selectedItems.length == 0){
				alertify.alert("Please select item/s first in order to proceed with this action");
				return false;
			}
			
			$scope.batchIDs = [];
			
			for(var i = 0; i < selectedItems.length; i++){
				var batchID = selectedItems[i]['TakeUp ID'];
				$scope.batchIDs.push(batchID);
			}
			
			var modalInstance = $uibModal.open({
				animation: true,
				backdrop: 'static',
				templateUrl: 'app/components/forms/remarks/remarksForm.html',
				controller: 'remarksFormController',
				size: 'lg',
				keyboard: false,
				resolve:{
					load: ['$q', function($q){
						var defered = $q.defer();
						require(['app/components/forms/remarks/remarksFormController'], function(){
							defered.resolve();
						});
						return defered.promise;
					}],
					data : function(){
						var data = {}; 
						data.batchIDs = $scope.batchIDs;
						data.sourceType = 'TU';
						return data;
					}
				}
			});
			modalInstance.result.then(function(message){
				alertify.alert(message);
			},function() {				
				// dismissed
				console.log("dismissed");
			});
			return modalInstance.result;
		};
		
	}]);
	
});