'use strict';

define(function(){
	angular.module("core").provider('JournalEntriesActionableQueryService', function(){
		this.$get =['DataAccessService', function(dataAccessService){
			var service = {
				getJournalEntries: function(dataSetID, pageIndex, pageSize, searchcriteria, successCallBack, errorCallBack) {
					var url  = 'journalentry/actionable/'+dataSetID+'/'+pageIndex+'/'+pageSize+'/';
					dataAccessService.doPostData(url, searchcriteria, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getColumnList: function(dataSetID, recordProfileID, successCallBack, errorCallBack) {
					var url  = 'transactions/columns/'+dataSetID+'/'+recordProfileID;
					dataAccessService.doGetData(url, null, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				}
				
			}
			return service;
		}]
	});	
});