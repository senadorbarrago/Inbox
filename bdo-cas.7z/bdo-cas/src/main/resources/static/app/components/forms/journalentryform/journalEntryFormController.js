'use strict';

define(function(){
	console.log('journalEntryFormController.js loaded');
	var journalEntryFormModule = angular.module('journalEntryFormModule');
	
	journalEntryFormModule.registerController('journalEntryFormController',[
		'$rootScope', 
		'$scope', 
		'$uibModalInstance', 
		'JournalEntryFormCommandService', 
	    'JournalEntryFormQueryService', 
	    'data', 
	    '$filter', 
	    function($rootScope, $scope, $uibModalInstance, journalEntryFormCommandService, journalEntryFormQueryService, data, $filter){
			$scope.title = 'Journal Entry Form';
			
			$scope.form = null;
			$scope.reference = {};
			$scope.summary = {};
			$scope.user = $rootScope.session["AUTHENTICATED_USER"];
			$scope.membership = $rootScope.session['AUTHENTICATED_USER'].activeMembership.membershipID;
			
			
			$scope.batchIDs = [];
			$scope.sourceType = 'JE';
			$scope.resultMessage = [];
			$scope.message = [];
			$scope.trRemarks = '';
			
			console.log('data:');
			console.log(data);
			
			var vm = this;
			vm.dataSetID = $rootScope.dataSetID;
			vm.dataSetCode = $rootScope.dataSetCode;
			vm.batchID   = data.batchID;
			
			$scope.fromInventory = false;
			if(data.fromInventory){
				$scope.fromInventory = data.fromInventory;
			}
			
			console.log("$scope.fromInventory=" + $scope.fromInventory);
			
			vm.assembleExistingForm = function(journalEntryID){
				// Existing Form
				journalEntryFormQueryService.getExistingForm(journalEntryID, function(response){
					$scope.form = response.data;
					
					console.log('assembleExistingForm: ');
					console.log(response.data);
					vm.getBookCodeListWithPermission();
					vm.getCurrencyListWithPermission();
					vm.getAccountProfileList();
				}, function(error){
					console.log(error);
				});
			};
			
			vm.assembleNewForm = function(){
				// New Form
				journalEntryFormQueryService.getNewForm(vm.dataSetID, function(response){
					$scope.form = response.data;
					// With SourceData
					if(data.header){
						for(var key in data.header){
							console.log("key: "+key+" value: "+data.header[key]);
							$scope.form.header.headerFieldMap[key].value = data.header[key];
						}
					}
					if(data.record){
						for(var key in data.record){
							console.log("key: "+key+" value: "+data.record[key]);
							$scope.form.recordList[0].recordFieldMap[key].value = data.record[key];
						}
					}
					
					console.log('assembleNewForm: ');
					console.log($scope.form.recordList);
					
					// Effective Date = Process Date
					$scope.form.header.headerFieldMap.glDate.value = $rootScope.session["PROCESSINFO"].processDate;
					vm.getBookCodeListWithPermission();
					
				}, function(error){
					console.log(error);
				});
			};
			
			vm.init = function (){
				if(!data.header.batchID){
					// New Form
					console.log("New");
					vm.assembleNewForm();
				}else{
					// Existing Form
					console.log("Existing");
					vm.assembleExistingForm(data.header.batchID);
				}
				//Default References
				//vm.getBookCodeList(vm.dataSetCode);
				//console.log('vm.getBookCodeListWithPermission(vm.batchID);');
				//vm.getBookCodeListWithPermission(vm.batchID);
				vm.getDebitCreditRefList(vm.dataSetCode);
				vm.getDebitTypeRefList(vm.dataSetCode);
				vm.initializeRemarks();
				
			}
			
			/****** References *****/
			// Book Code with Permission
			vm.getBookCodeListWithPermission = function(journalEntryID){
				let activeMembership = $rootScope.session['AUTHENTICATED_USER'].activeMembership.membershipID;
				
				// Check if has journalEntryID
				if(!journalEntryID){
					journalEntryID = 0;
				};
				
				let data = {
								'membershipID'   : activeMembership,
								'journalEntryID' : journalEntryID
							};
				
				journalEntryFormQueryService.doQuery('jeBookCodeWithPermission', data, function(response){
					console.log('jeBookCodeWithPermission');
					console.log(response);
					$scope.reference.bookCodeList = response.data.resultSet;
					if($scope.reference.bookCodeList.length === 1){
						if($scope.form){
							$scope.form.header.headerFieldMap.bookCode.value = $scope.reference.bookCodeList[0].code;
							vm.getCurrencyListWithPermission();
						}
					}
				}, function(error){
					console.log(error);
				});
			}
			
			// DebitCredit
			vm.getDebitCreditRefList = function(dataSetCode){ 
				journalEntryFormQueryService.getDebitCreditByDataSet(dataSetCode, function(response){
					$scope.reference.debitCreditList = response.data;
				}, function(error){
					console.log(error);
				});
			}
			// DebitType
			vm.getDebitTypeRefList = function(dataSetCode){
				journalEntryFormQueryService.getDebitTypeByDataSet(dataSetCode, function(response){
					$scope.reference.debitTypeList = response.data;
					console.log(response);
				}, function(error){
					console.log(error);
				});
			}
			
			// Currency
			vm.getCurrencyListWithPermission = function(){
				if(!$scope.form || !$scope.form.header){
					return false;
				}
				
				let activeMembership = $rootScope.session['AUTHENTICATED_USER'].activeMembership.membershipID;
				var selectedBookCode = $scope.form.header.headerFieldMap.bookCode.value;
				
				let journalEntryID = $scope.form.batchID;
				
				if(!journalEntryID){
					journalEntryID = 0;
				}
				
				let data = {
								'membershipID'   : activeMembership,
								'bookCode'		 : selectedBookCode,
								'journalEntryID' : journalEntryID
							};
				
				journalEntryFormQueryService.doQuery('jeCurrencyWithPermission', data, function(response){
					$scope.reference.currencyList = response.data.resultSet;
					if($scope.reference.currencyList.length === 1){
						$scope.form.header.headerFieldMap.currencyCode.value = $scope.reference.currencyList[0].code;
						vm.getPredefinedEntriesListWithPermission();
					}
					// Reset predefined entries
					$scope.reference.predefinedEntriesList = [];
				}, function(error){
					console.log(error);
				});
			}
			
			/*
			 * Get currencyRates
			 * Allowable if the currencyCode is supplied
			 */ 
			vm.getCurrencyRates = function(){
				$scope.form.header.headerFieldMap.phpRate.value = '';
				$scope.form.header.headerFieldMap.usdRate.value = '';
				var selectedCurrencyCode = $scope.form.header.headerFieldMap.currencyCode.value;
				
				if(!$scope.form || !$scope.form.header || !selectedCurrencyCode){
					return false;
				}
				
				journalEntryFormQueryService.getPhpAndUsdRatesByCurrency(selectedCurrencyCode, function(response){
					$scope.form.header.headerFieldMap.phpRate.value = response.data.phpRate;
					$scope.form.header.headerFieldMap.usdRate.value = response.data.usdRate;
				},function(error){
					console.log(error);
				});
			}
			
			/**
			 * Initialize Original Amount
			 * 
			 */
			$scope.initializeOrigAmount = function(index){
				if(!$scope.form.recordList[index].recordFieldMap.origAmount.value || isNaN($scope.form.recordList[index].recordFieldMap.origAmount.value)){
					$scope.form.recordList[index].recordFieldMap.origAmount.value = 0.00;
				}
				return $scope.form.recordList[index].recordFieldMap.phpAmount.value;
			}
			
			/**
			 * Compute converted PHP
			 * 
			 */
			$scope.computeConvertedToPhpAmount = function(index){
				if(!$scope.form.recordList[index].recordFieldMap.origAmount.value || isNaN($scope.form.recordList[index].recordFieldMap.origAmount.value) || isNaN($scope.form.header.headerFieldMap.phpRate.value)){
					$scope.form.recordList[index].recordFieldMap.phpAmount.value = 0.00;
				}else{
					$scope.form.recordList[index].recordFieldMap.phpAmount.value = 
						(parseFloat($scope.form.recordList[index].recordFieldMap.origAmount.value) * parseFloat($scope.form.header.headerFieldMap.phpRate.value)).toFixed(2);
				}
				return $scope.form.recordList[index].recordFieldMap.phpAmount.value;
			}
			
			/*
			 * Compute converted USD
			 */
			$scope.computeConvertedToUsdAmount = function(index){
				if(!$scope.form.recordList[index].recordFieldMap.origAmount.value || isNaN($scope.form.recordList[index].recordFieldMap.origAmount.value) || ($scope.form.header.headerFieldMap.bookCode.value === "1") || isNaN($scope.form.header.headerFieldMap.usdRate.value)){
					$scope.form.recordList[index].recordFieldMap.usdAmount.value = 0.00;
				}else{
					$scope.form.recordList[index].recordFieldMap.usdAmount.value = 
						(parseFloat($scope.form.recordList[index].recordFieldMap.origAmount.value) * parseFloat($scope.form.header.headerFieldMap.usdRate.value)).toFixed(2);
				}
				return $scope.form.recordList[index].recordFieldMap.usdAmount.value;
			}
			
			/* 
			 * Get accountProfile reference list
			 */
			vm.getAccountProfileList = function(){
				if(!$scope.form || !$scope.form.header){
					return false;
				}
				var selectedBookCode = $scope.form.header.headerFieldMap.bookCode.value;
				var selectedCurrencyCode = $scope.form.header.headerFieldMap.currencyCode.value;
				
				if(!selectedBookCode || !selectedCurrencyCode){
					$scope.reference.accountProfileList = [];
					return false;
				}
				
				var data = {
								bookCode : selectedBookCode,
								currency : selectedCurrencyCode
							}
				
				console.log("vm.getAccountProfileList: ");
				console.log(data);
				journalEntryFormQueryService.doQuery('AccountProfileQueryModel', data, function(response){
					console.log(response.data);
					
					$scope.reference.accountProfileList = response.data.resultSet;
					for(var i = 0; i < $scope.form.recordList.length; i++){
						console.log($scope.form.recordList[i].recordFieldMap.accountProfileID.value);
						var accountProfileID = $scope.form.recordList[i].recordFieldMap.accountProfileID.value; 
						vm.getCostCenterList(i, accountProfileID);
					}		
					$scope.doChangeAccountProfile(0);
					$scope.doChangeCostCenter(0);
				}, function(error){
					console.log(error);
				});
			}
			
			/**
			 * Get costCenter list
			 * Execute only of accountProfileID is supplied
			 */
			vm.getCostCenterList = function(index, accountProfileID){
				if(!accountProfileID || accountProfileID <= 0){
					return false;
				}
				
				journalEntryFormQueryService.getCostCenterByAccountProfile(index, accountProfileID, function(response){
					var rowIndex1 = response.data.index;
					$scope.form.recordList[rowIndex1].costCenterList = response.data.referenceList;
				}, function(error){
					console.log(error);
				});
			}
			
			// Predefined Entries
			vm.getPredefinedEntriesListWithPermission = function(){
				let activeMembership = $rootScope.session['AUTHENTICATED_USER'].activeMembership.membershipID;
				let selectedBookCode = $scope.form.header.headerFieldMap.bookCode.value;
				let selectedCurrency = $scope.form.header.headerFieldMap.currencyCode.value;
				
				let dataSetID = vm.dataSetID;
				
				let data = {
								'dataSetID' : dataSetID,
								'bookCode'		 : selectedBookCode,
								'currency'		 : selectedCurrency,
								'membershipID'   : activeMembership
							};
				
				console.log(data);
				
				journalEntryFormQueryService.doQuery('jePredefinedEntriesWithPermission', data, function(response){
					$scope.reference.predefinedEntriesList = response.data.resultSet;
				}, function(error){
					console.log(error);
				});
			}			
			
			/**
			 * Update bookCode dependencies 
			 */
			vm.doUpdateBookCodeDependencies = function(){
				vm.getCurrencyListWithPermission();
				vm.getAccountProfileList();
			}
			
			/**
			 * Update currencyCode dependencies 
			 */
			vm.doUpdateCurrencyDependencies = function(){
				vm.getCurrencyRates();
				vm.getAccountProfileList();
				vm.getPredefinedEntriesListWithPermission();
			}			
			
			/**
			 * Watch for bookCode
			 */
			$scope.$watch('form.header.headerFieldMap.bookCode.value', function(newVal, oldVal){
				var batchID = '';
				if($scope.form){
				 batchID = $scope.form.header.headerFieldMap.batchID.value;
				}
				
				if(oldVal !== newVal && !batchID){
					vm.doUpdateBookCodeDependencies();
					vm.resetJournalEntryAccountProfileDetails();
				}
			});
			
			/**
			 * Watch for currencyCode
			 */
			$scope.$watch('form.header.headerFieldMap.currencyCode.value', function(newVal, oldVal){
				var batchID = '';
				if($scope.form){
				 batchID = $scope.form.header.headerFieldMap.batchID.value;
				}
				if(oldVal !== newVal && !batchID){
					vm.doUpdateCurrencyDependencies();
					vm.resetJournalEntryAccountProfileDetails();
				}
			});
			
			/**
			 * Reset the journal entry accountProfile contents
			 */
			vm.resetJournalEntryAccountProfileDetails = function(){
				var sfvID = '';
				if($scope.form && $scope.form.header){
					sfvID = $scope.form.header.headerFieldMap.transactionSourceID.value;
				}
				
				angular.forEach($scope.form.recordList, function(row, index){
					if(sfvID){
						if(index > 1){
							row.recordFieldMap.accountProfileID.value = '';
						}
					}else{
						row.recordFieldMap.accountProfileID.value = '';
					}
					row.recordFieldMap.costCenter.value = '';
					row.recordFieldMap.branchCode.value = '';
				});
			}
			
			/**
			 * Recompute converted amounts
			 */
			vm.recomputeConvertedAmounts = function(){
				console.log('RecomputeConvertedAmounts');
				console.log($scope.form.recordList);
				angular.forEach($scope.form.recordList, function(record, $index) {
					$scope.initializeOrigAmount($index);
					$scope.computeConvertedToPhpAmount($index);
					$scope.computeConvertedToUsdAmount($index);
				});
				
			}
			
			/**
			 * Watch phpRate and usdRate
			 */
			$scope.$watchGroup(['form.header.headerFieldMap.phpRate.value', 'form.header.headerFieldMap.usdRate.value'],
					function(newVal, oldVal){
				console.log("watch: phpRate and usdRate");
				if(oldVal !== newVal){
					vm.recomputeConvertedAmounts();
				}
			});
			
			$scope.doChangePredefEntries = function(){
				if($scope.selectedPredefinedEntries !== null && $scope.selectedPredefinedEntries.id > 0){
					for(var i = 0; i < $scope.form.recordList.length; i++){
						$scope.form.recordList[i].costCenterList = null;
					}
					
					console.log($scope.form.recordList);
					console.log("doChangePredefEntries();");
					
					journalEntryFormQueryService.getPredefinedEntriesByPredefID(vm.dataSetID, $scope.selectedPredefinedEntries.id, function(response){
						$scope.form.recordList = response.data;
						for(var i = 0; i < $scope.form.recordList.length; i++){
							var accountProfileID = $scope.form.recordList[i].recordFieldMap.accountProfileID.value; 
							$scope.doChangeAccountProfile(i);
						}					
						vm.recomputeConvertedAmounts();
					}, function(error){
						console.log(error);
					});
				}
			}
			
			/**
			 * Change accountProfile
			 * Allowable if accountProfileID is supplied
			 */
			$scope.doChangeAccountProfile = function(index){
				var accountProfileID = $scope.form.recordList[index].recordFieldMap.accountProfileID.value;
				
				if(!accountProfileID || accountProfileID <= '0'){
					return false;
				}
				
				journalEntryFormQueryService.getCostCenterByAccountProfile(index, accountProfileID, function(response){
					var recordIndex = response.data.index;
					$scope.form.recordList[recordIndex].costCenterList = response.data.referenceList;
					
					if(response.data.referenceList && response.data.referenceList.length === 1){
						$scope.form.recordList[recordIndex].recordFieldMap.costCenter.value = response.data.referenceList[0].code;
					}
					
					$scope.doChangeCostCenter(recordIndex);
				}, function(error){
					console.log(error);
				});
			}
			
			/**
			 * Change costCenter.
			 * Allowable if target costCenter is supplied
			 */
			$scope.doChangeCostCenter = function(index){
				var costCenter = $scope.form.recordList[index].recordFieldMap.costCenter.value;
				
				if(!costCenter){
					$scope.form.recordList[index].recordFieldMap.branchCode.value = '';
					return false;
				}
				
				journalEntryFormQueryService.getBranchCodeByCostCenterAndDataSetID(index, costCenter,vm.dataSetID, function(response){
					var rowIndex = response.data.index;
					$scope.form.recordList[rowIndex].recordFieldMap.branchCode.value = response.data.branchCode;
				}, function(error){
					console.log(error);
				});
			}
			
			$scope.addJournalEntry = function(){
				if(!vm.validateHeader()){
					return;
				}
				
				if(!vm.validateJEDetails()){
					return;
				}
				
				var lastRecordIndex = $scope.form.recordList.length - 1;
				console.log($scope.form.recordList[lastRecordIndex].recordFieldMap);
				var length = $scope.form.recordList.length;
				var currentRecord = {};
				if(length === 1){
					console.log($scope.form.recordList[lastRecordIndex]);
					currentRecord = angular.copy($scope.form.recordList[lastRecordIndex]);
					var drCrTag = currentRecord.recordFieldMap.drCrTag.value;
					if(drCrTag === '0'){
						currentRecord.recordFieldMap.drCrTag.value = '6';
					}else{
						currentRecord.recordFieldMap.drCrTag.value = '0';
					}
					console.log(currentRecord.recordFieldMap.drCrTag.value);
				}else if(length > 1){
					currentRecord = angular.copy($scope.form.recordList[lastRecordIndex]);
				}
				console.log(currentRecord);
				currentRecord.recordFieldMap.recordSource.value = 'M';
				$scope.form.recordList.push(currentRecord);
			}
			
			$scope.removeJournalEntry = function(index){	
				$scope.form.recordList.splice(index, 1);
			}
			
			$scope.saveJournalEntry = function(){
				console.log($scope.form);
				console.log($scope.summary.totalDebitAmountPhp);
				console.log($scope.summary.totalCreditAmountPhp);
				console.log($scope.summary.totalDebitAmountPhp - $scope.summary.totalCreditAmountPhp);
				console.log("$scope.summary.netTotalPhp:");
				console.log($scope.summary.netTotalPhp);
				
				if(!vm.validateHeader()){
					return;
				}
				
				if($scope.form.recordList.length === 0){
					alertify.alert("Invalid journal entry record. Correct the journal entries first in order to proceed with this action");
					return;
				}else{
					if($scope.summary.netTotalOrig < 0.00 || $scope.summary.netTotalOrig > 0.00){
						alertify.alert("Invalid net total amount. Correct the journal entries first in order to proceed with this action");
						return;
					}else if($scope.summary.netTotalUSD < 0.00 || $scope.summary.netTotalUSD > 0.00){
						alertify.alert("Invalid net total USD amount. Correct the journal entries first in order to proceed with this action");
						return;
					}else if($scope.summary.netTotalPhp < 0.00 || $scope.summary.netTotalPhp > 0.00){
						
						alertify.alert("Invalid net total PHP amount. Correct the journal entries first in order to proceed with this action");
						return;
					}else{
						console.log($scope.form.recordList.length);
						if(!vm.validateJEDetails()){
							return;
						}
						
						alertify.confirm("This action saves the journal entry details encoded with this transaction. " +
								"Are you sure you want to proceed?", function(e){
								if(e){
									console.log($scope.form);
									
									$scope.form.dataSetID = $rootScope.dataSetID;
									$scope.form.dataSetCode = $rootScope.dataSetCode;
									$scope.form.encodingUnitCode = $rootScope.encodingUnitCode;
									
									
									journalEntryFormCommandService.submitForm(vm.dataSetID, $scope.form, function(response){
										console.log(response);
										$scope.resultMessage = response.data;
										$scope.message = $scope.resultMessage.messageMap;
										
										if($scope.message.successMsg){
											alertify.alert($scope.message.successMsg);
											$uibModalInstance.close(response.data.messageMap.successMsg);
										}else if($scope.message.errorMsg){
											alertify.alert($scope.message.errorMsg);
										}
									}, function(error){
										console.log(error);
										alertify.alert(error.data.errorMsg);
									});
								}else{
									return;
								}
							});
					}
				}	
				
			}
			
			$scope.updateJournalEntry = function(){
				if(!vm.validateHeader()){
					return;
				}
				if($scope.form.recordList.length === 0){
					alertify.alert("Invalid journal entry record. Correct the journal entries first in order to proceed with this action");
					return;
				}else{
					if($scope.summary.netTotalOrig !== 0.00){
						alertify.alert("Invalid net total amount. Correct the journal entries first in order to proceed with this action");
						return;
					}else{
						if(!vm.validateJEDetails()){
							return;
						}
						
						$scope.form.dataSetID = $rootScope.dataSetID;
						$scope.form.dataSetCode = $rootScope.dataSetCode;
						$scope.form.encodingUnitCode = $rootScope.encodingUnitCode;
						
						alertify.confirm("This action saves the journal entry details encoded with this transaction. " +
								"Are you sure you want to proceed?", function(e){
								if(e){
									console.log('HEY');
									console.log($scope.form);
									var form = $scope.form;
									journalEntryFormCommandService.updateForm(form, function(response){
										console.log(response);
										$scope.resultMessage = response.data;
										$scope.message = $scope.resultMessage.messageMap;
										
										if($scope.message.successMsg){
											alertify.alert($scope.message.successMsg);
											$uibModalInstance.close(response.data.messageMap.successMsg);
										}else
										if($scope.message.errorMsg){
											alertify.alert($scope.message.errorMsg);
										}
									}, function(error){
										alertify.alert(error.data.errorMsg);
									});
								}else{
									return;
								}
							});
					}
				}				
			}
			
			vm.validateHeader = function(){
				if(!$scope.form.header.headerFieldMap.bookCode.value){
					alertify.alert("Select the Book Code first in order to proceed");
					return false;
				}
				if(!$scope.form.header.headerFieldMap.currencyCode.value){
					alertify.alert("Select the corresponding Currency first in order to proceed");
					return false;
				}
				if(!$scope.form.header.headerFieldMap.referenceNo.value){
					alertify.alert("Provide the corresponding Reference No in order to proceed");
					return false;
				}
				return true;
			}
			
			vm.validateJEDetails = function(){
				console.log("vm.validateJEDetails()");
				var errorMessage = 'Please supply correct data for the following fields: <br/>';
				var errorDetails = '';
				
				console.log($scope.form.recordList.length);
				
				for(var index = 0; index < $scope.form.recordList.length; index++){
					
					if(!$scope.form.recordList[index].recordFieldMap['drCrTag'].value){
						errorDetails = errorDetails+'Record No: '+(index+1)+' - Field: '+$scope.form.recordList[index].recordFieldMap['drCrTag'].label+'<br/>';
					}
					
					if(!$scope.form.recordList[index].recordFieldMap['accountProfileID'].value){
						errorDetails = errorDetails+'Record No: '+(index+1)+' - Field: '+$scope.form.recordList[index].recordFieldMap['accountProfileID'].label+'<br/>';
					}
					
					if(!$scope.form.recordList[index].recordFieldMap['accountName'].value){
						errorDetails = errorDetails+'Record No: '+(index+1)+' -  Field: '+$scope.form.recordList[index].recordFieldMap['accountName'].label+'<br/>';
					}
					
					if(!$scope.form.recordList[index].recordFieldMap['origAmount'].value){
						errorDetails = errorDetails+'Record No: '+(index+1)+' -  Field: '+$scope.form.recordList[index].recordFieldMap['origAmount'].label+'<br/>';
					
					}else{
						if(!isNaN($scope.form.recordList[index].recordFieldMap['origAmount'].value)){
							var ret = $scope.validateNumericInput($scope.form.recordList[index].recordFieldMap['origAmount'].value);
							if(ret === 'invalid'){
								errorDetails = errorDetails+'Record No: '+(index+1)+' - Field: '+$scope.form.recordList[index].recordFieldMap['origAmount'].label+' Must be less than or equal to 16 digits only<br/>';
							}
						}
					}
					
					if(!isNaN($scope.form.recordList[index].recordFieldMap['phpAmount'].value)){
						var ret = $scope.validateNumericInput($scope.form.recordList[index].recordFieldMap['phpAmount'].value);
						if(ret === 'invalid'){
							errorDetails = errorDetails+'Record No: '+(index+1)+' - Field: '+$scope.form.recordList[index].recordFieldMap['phpAmount'].label+ ' Must be less than or equal to 16 digits only<br/>';
						}
					}
					
					if(!isNaN($scope.form.recordList[index].recordFieldMap['usdAmount'].value)){
						var ret = $scope.validateNumericInput($scope.form.recordList[index].recordFieldMap['usdAmount'].value);
						if(ret === 'invalid'){
							errorDetails = errorDetails+'Record No: '+(index+1)+' - Field: '+$scope.form.recordList[index].recordFieldMap['usdAmount'].label+' Must be less than or equal to 16 digits only<br/><br/>';
						}
					}
				}
				if(errorDetails){
					console.log(errorMessage+errorDetails);
					alertify.alert(errorMessage+errorDetails);
					return false;
				}
				return true;
			}
			
			$scope.calculatePHPSummaryAmount = function(debitCredit){
				var total = 0.00;
				$scope.summary.totalDebitAmountPhp = 0.00;
				$scope.summary.totalCreditAmountPhp = 0.00;
				$scope.summary.netTotalPhp = 0.00;
				
				var form = $scope.form;
				
				if(form != null){
					for(var i = 0; i < form.recordList.length; i++){
						var record = form.recordList[i];
						if(record.recordFieldMap.drCrTag != undefined){
							if(record.recordFieldMap.drCrTag.value === '6'){
								if(record.recordFieldMap.phpAmount.value != null && !isNaN(record.recordFieldMap.phpAmount.value)){
									$scope.summary.totalDebitAmountPhp = parseFloat($scope.summary.totalDebitAmountPhp) + parseFloat(record.recordFieldMap.phpAmount.value);
								}
							}else{
								if(record.recordFieldMap.phpAmount.value != null && !isNaN(record.recordFieldMap.phpAmount.value)){
									$scope.summary.totalCreditAmountPhp = parseFloat($scope.summary.totalCreditAmountPhp) + parseFloat(record.recordFieldMap.phpAmount.value);
								}	
							}
						}
					}
					
					$scope.summary.netTotalPhp = $scope.roundNumber($scope.summary.totalDebitAmountPhp, 2) - $scope.roundNumber($scope.summary.totalCreditAmountPhp, 2);
					
					if(debitCredit === 'DEBIT'){	
						total = $scope.roundNumber($scope.summary.totalDebitAmountPhp, 2);
					}else{
						total = $scope.roundNumber($scope.summary.totalCreditAmountPhp, 2);
					}
				}
				return total;
			}
			
			$scope.calculateUSDSummaryAmount = function(debitCredit){
				var total = 0.00;
				$scope.summary.totalDebitAmountUSD = 0.00;
				$scope.summary.totalCreditAmountUSD = 0.00;
				$scope.summary.netTotalUSD = 0.00;
				
				var form = $scope.form;
				
				if(form != null){
					for(var i = 0; i < form.recordList.length; i++){
						var record = form.recordList[i];
						
						if(record.recordFieldMap.drCrTag != undefined){
							if(record.recordFieldMap.drCrTag.value === '6'){
								if(record.recordFieldMap.usdAmount.value != null && !isNaN(record.recordFieldMap.usdAmount.value)){
									$scope.summary.totalDebitAmountUSD = parseFloat($scope.summary.totalDebitAmountUSD) + parseFloat(record.recordFieldMap.usdAmount.value);
								}
								
							}else{
								if(record.recordFieldMap.usdAmount.value != null && !isNaN(record.recordFieldMap.usdAmount.value)){
									$scope.summary.totalCreditAmountUSD = parseFloat($scope.summary.totalCreditAmountUSD) + parseFloat(record.recordFieldMap.usdAmount.value);
								}	
							}
						}
					}
					
					$scope.summary.netTotalUSD = $scope.roundNumber($scope.summary.totalDebitAmountUSD, 2) - $scope.roundNumber($scope.summary.totalCreditAmountUSD, 2);
					
					if(debitCredit === 'DEBIT'){
						total = $scope.roundNumber($scope.summary.totalDebitAmountUSD, 2);
					}else{
						total = $scope.roundNumber($scope.summary.totalCreditAmountUSD, 2);
					}
				}
				return total;
			}
			
			$scope.calculateOrigSummaryAmount = function(debitCredit){
				var total = 0.00;
				$scope.summary.totalDebitAmountOrig = 0.00;
				$scope.summary.totalCreditAmountOrig = 0.00;
				$scope.summary.netTotalOrig = 0.00;
				
				var form = $scope.form;
				
				if(form != null){
					for(var i = 0; i < form.recordList.length; i++){
						var record = form.recordList[i];	
						
						if(record.recordFieldMap.drCrTag != undefined){
							if(record.recordFieldMap.drCrTag.value === '6'){
								if(record.recordFieldMap.origAmount.value != null && !isNaN(record.recordFieldMap.origAmount.value)){
									$scope.summary.totalDebitAmountOrig = parseFloat($scope.summary.totalDebitAmountOrig) + parseFloat(record.recordFieldMap.origAmount.value);
								}
							}else{
								if(record.recordFieldMap.origAmount.value != null && !isNaN(record.recordFieldMap.origAmount.value)){
									$scope.summary.totalCreditAmountOrig = parseFloat($scope.summary.totalCreditAmountOrig) + parseFloat(record.recordFieldMap.origAmount.value);
								}	
							}
						}
					}
					
					$scope.summary.netTotalOrig = $scope.roundNumber($scope.summary.totalDebitAmountOrig,2) - $scope.roundNumber($scope.summary.totalCreditAmountOrig,2);
					
					if(debitCredit === 'DEBIT'){
						total = $scope.roundNumber($scope.summary.totalDebitAmountOrig, 2);
						$scope.form.header.headerFieldMap.debitAmount.value = total;
					}else{
						total = $scope.roundNumber($scope.summary.totalCreditAmountOrig, 2);
						$scope.form.header.headerFieldMap.creditAmount.value = total;
					}
				}
				return total;
			}
			
			$scope.changeAmountInOriginalCurrency = function(index){
				$scope.form.recordList[index].recordFieldMap.phpAmount.value  = 0.00;
				$scope.form.recordList[index].recordFieldMap.usdAmount.value = 0.00;
				if(!isNaN($scope.form.recordList[index].recordFieldMap.origAmount.value) && !isNaN($scope.form.header.headerFieldMap.phpRate.value)){
					$scope.form.recordList[index].recordFieldMap.phpAmount.value = parseFloat($scope.form.recordList[index].recordFieldMap.origAmount.value) * parseFloat($scope.form.header.headerFieldMap.phpRate.value);
				}
				if(!isNaN($scope.form.recordList[index].recordFieldMap.origAmount.value) && !isNaN($scope.form.header.headerFieldMap.usdRate.value)){
					$scope.form.recordList[index].recordFieldMap.usdAmount.value = parseFloat($scope.form.recordList[index].recordFieldMap.origAmount.value) * parseFloat($scope.form.header.headerFieldMap.usdRate.value);
				}
			}
			
			$scope.blockNonNumber = function (val, index){
				console.log(val);
				$scope.form.recordList[index].recordFieldMap.origAmount.value = parseFloat(val.toString().replace(/[^0-9\.]/g, ''));
			}
			
			$scope.close = function() {
				alertify.confirm("This action cancels any changes or updates in this journal entry. " +
						"Are you sure you want to proceed?", function(e){
						if(e){
							$uibModalInstance.dismiss();
						}else{
							return;
						}
					});
			};
			
			$scope.doAddRemarks = function() {
				
				$scope.batchIDs = [];
				$scope.batchIDs.push(data.header.batchID);
				console.log('BatchID: ' + data.batchID);
				
				$scope.addRemarksParam = {};
				
				$scope.addRemarksParam["dataset"] = $rootScope.dataSetID;
				$scope.addRemarksParam["sourceID"] = $scope.batchIDs;
				$scope.addRemarksParam["sourceType"] = $scope.sourceType;
				$scope.addRemarksParam["remarks"] = $scope.form.txtAddRemarks;
				$scope.addRemarksParam["membershipID"] = $scope.membership;
				$scope.addRemarksParam["userName"] = $scope.user.username;
				console.log($scope.form.txtAddRemarks);
				
				if($scope.form.txtAddRemarks != '' && $scope.form.txtAddRemarks != null){
					journalEntryFormQueryService.batchAddRemarks($scope.addRemarksParam)
					.then(function(response){
						alertify.alert('Successfully added remarks.', function(e){
							console.log("journalEntryFormQueryService: batchAddRemarks()");
							console.log(response);
							$scope.form.txtAddRemarks = '';
							vm.initializeRemarks();
						});
					}).catch(function(error){
						console.log(error);
					});
				}
			};
			
			/**
			 * Initilialize remarks history for this form
			 * Allowable if batch ID is present
			 */
			vm.initializeRemarks = function(){
				
				$scope.trRemarks = '';
				
				if(!data.header || !data.header.batchID){
					return false;
				}
				
				journalEntryFormQueryService.viewRemarks($rootScope.dataSetID, data.header.batchID, $scope.sourceType, function(response){
					$scope.txtRemarks = response.data.resultSet;
					$scope.loopRemarks();
				}, function(error){
					console.log(error);
				});
			};
			
			$scope.roundNumber = function(num, scale) {
				if(!("" + num).includes("e")) {
					return +(Math.round(num + "e+" + scale)  + "e-" + scale);
				} else {
					var arr = ("" + num).split("e");
					var sig = ""
					if(+arr[1] + scale > 0) {
						sig = "+";
					}
					return +(Math.round(+arr[0] + "e" + sig + (+arr[1] + scale)) + "e-" + scale);
				}
			}
			
			$scope.round = function(number, precision) {
			    var pair = (number + 'e').split('e')
			    var value = Math.round(pair[0] + 'e' + (+pair[1] + precision))
			    pair = (value + 'e').split('e')
			    return +(pair[0] + 'e' + (+pair[1] - precision))
			}
			
			String.prototype.includes = function (str) {
				
				var returnValue = false;
	
				if (this.indexOf(str) !== -1) {
					returnValue = true;
				}
	
				return returnValue;
			}
			
			$scope.preventPaste = function(e){
				   e.preventDefault();
				   return false;
			};
			
			$scope.isCompoundEntry = function(record){			
				if($scope.reference.accountProfileList){
					for(var index = 0; $scope.reference.accountProfileList.length > index; index++){
						if($scope.reference.accountProfileList[index].id == record.recordFieldMap.accountProfileID.value){
							if($scope.reference.accountProfileList[index].additionalDetails === 'true'){
								
								return true;
							}
						}
					}
					record.recordFieldMap.isCompoundEntry.value = 'false';
				}
				return false;
			}
			
			$scope.showDebitType = function(record){		
				if($scope.reference.accountProfileList){
					for(var index = 0; $scope.reference.accountProfileList.length > index; index++){
						if($scope.reference.accountProfileList[index].id == record.recordFieldMap.accountProfileID.value){
							if($scope.reference.accountProfileList[index].showDebitType === 'true'){
								return true;
							}
						}
					}
				}
				return false;
			}
			
			$scope.returnZeroIfNaN = function(number){
				if(!number || isNaN(number)){
					return 0.00;
				}
			}
			
			/**
			 * 
			 */
			$scope.loopRemarks = function(){
				angular.forEach($scope.txtRemarks, function(value, key){
					console.log(value);
					console.log(key);
					$scope.trRemarks = $scope.trRemarks + '\n' + value.trRemarks;
				});
				
				$scope.trRemarks = $scope.trRemarks.substring(1);
				
			};
			
			/**
			 * 
			 */
			$scope.restrictLargeNumericInput = function(amount, $event){
				var isValid = vm.restrictNumericInput(amount);
				console.log('$scope.restrictLargeNumericInput: '+isValid);
				console.log('$event.keyCode: '+$event.keyCode);
				if(isValid === 'invalid'){
					if($event.keyCode === 0) { 
						$event.preventDefault();
						return false;
					}
				}
			}
			
			/**
			 * 
			 */
			vm.restrictNumericInput = function(amount){
				var decimalCount =  vm.countDecimals(amount);
				var integerCount =  vm.countIntegers(amount);
				var totalDigitCount = decimalCount + integerCount;
				
				console.log('AMOUNT: ' + amount);
				console.log('DECIMAL COUNT: ' + decimalCount);
				console.log('INTEGER COUNT: ' + integerCount);
				console.log('TOTAL COUNT: ' + totalDigitCount);
				
				if(totalDigitCount > 15 || integerCount > 13){
					return 'invalid';
				}else{
					return 'valid';
				}
			};
			
			/**
			 * 
			 */
			$scope.validateNumericInput = function(amount){
				var decimalCount =  vm.countDecimals(amount);
				var integerCount =  vm.countIntegers(amount);
				var totalDigitCount = decimalCount + integerCount;
				
				console.log('AMOUNT: ' + amount);
				console.log('DECIMAL COUNT: ' + decimalCount);
				console.log('INTEGER COUNT: ' + integerCount);
				console.log('TOTAL COUNT: ' + totalDigitCount);
				
				if(totalDigitCount > 16 || integerCount > 14){
					return 'invalid';
				}else{
					return 'valid';
				}
			};
			
			/**
			 * 
			 */
			vm.countDecimals = function (value) {
			    if(Math.floor(value) === value) return 0;
			    if(value.toString().indexOf(".") !== -1){
			    	return value.toString().split(".")[1].length || 0;
			    }else{
			    	return 0;
			    }
			    
			};
			
			/**
			 * 
			 */
			vm.countIntegers = function (value) {
				var valueStr = value.toString();
				
				if(valueStr.indexOf(".") !== -1){
					var valueIndex = valueStr.indexOf('.');
					var valueLatest = valueStr.substring(0, valueIndex);
					return valueLatest.length;
				}else{
					return valueStr.length;
				}
			};
			
			// Initialize form
			vm.init();
	}]);	
});