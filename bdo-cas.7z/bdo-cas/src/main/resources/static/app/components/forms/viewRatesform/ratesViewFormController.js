'use strict';

define(function(){
	var core = angular.module('core');
	
	core.registerController('ratesViewFormController',['$rootScope', '$scope', '$uibModalInstance', '$uibModal', 'data', 'DataAccessService', '$filter',
	                                                     function($rootScope, $scope, $uibModalInstance, $uibModal, data, dataAccessService, $filter){
	    $scope.title = 'Rates View Form';
		
		var vm = this;
		
		vm.init = function(){
			$scope.form = {};
			$scope.data = {};
			$scope.datePicker = { };
			$scope.dateOptions = {
					startingDay : 1,
					showWeeks : false,	
					format : "yyyy-MM-dd"
				};
			$scope.dateFormat = "yyyy-MM-dd";
			
			$scope.data.dataSetID = $rootScope.dataSetID;
			$scope.data.dataSetCode = $rootScope.dataSetCode;
			$scope.data.processingDate = '';
			
			vm.getCurrencyRatesByProcessingDate();
		}
		
		
		$scope.open = function(columnName, $event) {
			$event.preventDefault();
			$event.stopPropagation();
			
			if ($scope.datePicker[columnName]) {
				if ($scope.datePicker[columnName].opened) {
					$scope.datePicker[columnName].opened = false;
				}
			} else {
				$scope.datePicker = {};
				$scope.datePicker[columnName] = {};
				$scope.datePicker[columnName].opened = true;
			}
		}
		
		
		vm.getCurrencyRatesByProcessingDate = function(){
			
			var url = "transactions/glDate/currencyRatesByProcessingDate";		
			dataAccessService.doPostData(url, $scope.data, function(response){
				console.log(response);
				$scope.currencyRates = response.data;
			},function(errorResponse){
				console.log(errorResponse);
				alertify.alert(errorResponse.data.errorMsg);
			});
		}
		
		vm.init();
		
		$scope.search = function(){
			
			console.log($scope.data.selectedDate);
			
			if($scope.data.selectedDate === undefined || $scope.data.selectedDate === null){
				$scope.data.processingDate = '';
				alertify.alert("Please select a valid GL Date.");
			} else{
				$scope.data.processingDate = $filter('date')(new Date($scope.data.selectedDate), 'yyyy/MM/dd');
				vm.getCurrencyRatesByProcessingDate();
			}
			
		};
		
		$scope.showAll = function(){
			
			$scope.data.processingDate = '';
			$scope.data.selectedDate = '';
			
			vm.getCurrencyRatesByProcessingDate();
		};
		
		$scope.close = function() {
			
			alertify.confirm("Are you sure you want to proceed?", function(e){
					if(e){
						$uibModalInstance.dismiss();
					}else{
						return;
					}
				});
		};
		
	}]);
	
});