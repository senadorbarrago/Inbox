'use strict';

define(function(){
	angular.module("core").provider('ReferTransactionFormQueryService', function(){
		this.$get =['DataAccessService', function(dataAccessService){
			var service = {
				getGroupReferences: function(dataSetID, successCallBack, errorCallBack){
					var url = 'references/groupByDataSetID/'+dataSetID;
					dataAccessService.doGetData(url, null, function(response){
						console.log(response.data);
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				}, 
				getNCTypeReferences: function(dataSetID, successCallBack, errorCallBack){
					var url = 'references/ncTypeByDataSetID/'+dataSetID;
					dataAccessService.doGetData(url, null, function(response){
						console.log(response.data);
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				viewReferralDetails: function(dataSetCode, transID, successCallBack, errorCallBack){
					var url = 'transactions/referralDetails/'+dataSetCode+'/'+transID;
					dataAccessService.doGetData(url, null, function(response){
						console.log(response.data);
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				}
			
			}
			return service;
		}]
	});	
});