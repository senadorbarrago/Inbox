'use strict';

define(function(){
	angular.module("journalEntryFormModule").provider('JournalEntryFormQueryService', function(){
		this.$get =['$http', 'DataAccessService', function($http, dataAccessService){
			var service = {
				getNewForm: function(dataSetID, successCallBack, errorCallBack) {
					var url  = 'journalentry/form/new/'+dataSetID;
					dataAccessService.doGetData(url, null, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getExistingForm: function(batchID, successCallBack, errorCallBack) {
					var url  = 'journalentry/form/'+batchID;
					dataAccessService.doGetData(url, null, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getBookCodeByDataSet: function(dataSetCode, successCallBack, errorCallBack) {
					var url  = 'references/bookCodeByDataSet/'+dataSetCode;
					dataAccessService.doGetData(url, null, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getPredefinedEntriesByDataSetID: function(dataSetID, bookCode, currency, successCallBack, errorCallBack) {
					var url  = 'references/predefinedEntries/'+dataSetID+'/'+bookCode+'/'+currency;
					dataAccessService.doGetData(url, null, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getDebitCreditByDataSet: function(dataSetCode, successCallBack, errorCallBack) {
					var url  = 'references/debitCreditByDataSet/'+dataSetCode;
					dataAccessService.doGetData(url, null, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getDebitTypeByDataSet: function(dataSet, successCallBack, errorCallBack) {
					var url  = 'references/debitType/'+dataSet;
					dataAccessService.doGetData(url, null, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getCurrencyReferenceListByBookCode: function(bookCode, successCallBack, errorCallBack) {
					var url  = 'references/currencyByBookCode/'+bookCode;
					dataAccessService.doGetData(url, null, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getAccountProfileByCurrency: function(bookCode, currency, successCallBack, errorCallBack) {
					var url  = 'references/accountProfileByBookCodeAndCurrency/'+bookCode+'/'+currency;
					dataAccessService.doGetData(url, null, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getLatestEffectiveDateByDataSetID: function(dataSetID, successCallBack, errorCallBack) {
					var url  = 'references/latestEffectiveDateByDataSetID/'+dataSetID;
					dataAccessService.doGetData(url, null, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getLatestEffectiveDateByDataSetCodeAndEncodingUnitCode: function(dataSetCode, encodingUnitCode, successCallBack, errorCallBack) {
					var url  = 'references/processingInfo/'+dataSetCode+'/'+encodingUnitCode;
					dataAccessService.doGetData(url, null, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getPhpAndUsdRatesByCurrency: function(currency, successCallBack, errorCallBack) {
					var url  = 'references/phpAndUsdRatesByCurrency/'+currency;
					console.log('FIRE');
					dataAccessService.doGetData(url, null, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getPredefinedEntriesByPredefID: function(dataSetID, predefID, successCallBack, errorCallBack) {
					var url  = 'references/predefinedEntries/'+dataSetID+'/'+predefID;
					dataAccessService.doGetData(url, null, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getBranchCodeByCostCenterAndDataSetID: function(index, costCenter, dataSetID, successCallBack, errorCallBack) {
					var url  = 'references/branchCodeByCostCenterAndDataSetID/'+costCenter+'/'+dataSetID+'/'+index;
					dataAccessService.doGetData(url, null, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getCostCenterByAccountProfile: function(index, accountProfileID, successCallBack, errorCallBack) {
					var url  = 'references/costCenterByAccountProfile/'+accountProfileID+'/'+index;
					dataAccessService.doGetData(url, null, function(response){
						console.log(response.data);
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getEncodingUnits: function(successCallBack, errorCallBack){
					var url = 'references/encodingUnits'
					dataAccessService.doGetData(url, null, function(response){
						console.log(response.data);
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getTagTypeByDataSetID: function(dataSetID, successCallBack, errorCallBack) {
					var url  = 'references/tagTypeByDataSetID/'+dataSetID;
					dataAccessService.doGetData(url, null, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getGLGroupByDataSetID: function(dataSetID, successCallBack, errorCallBack) {
					var url  = 'references/glGroupByDataSetID/'+dataSetID;
					dataAccessService.doGetData(url, null, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getAccountProfileByGL: function(bookCode, currency, successCallBack, errorCallBack) {
					var url  = 'references/accountProfileByGL/'+bookCode+'/'+currency;
					dataAccessService.doGetData(url, null, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				addRemarks: function(addRemarksData) {
					var url  = 'remarks/add';
					return $http.post(url, addRemarksData);
				},
				viewRemarks: function(dataset, sourceID, sourceType, successCallBack, errorCallBack) {
					var url  = 'remarks/view/' + dataset + '/' + sourceID + '/' + sourceType;

					dataAccessService.doGetData(url, null, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				batchAddRemarks: function(addRemarksData) {
					var url  = 'remarks/batchAdd';
					return $http.post(url, addRemarksData);
				},
				getGroupByDataSetID: function(dataSetID, successCallBack, errorCallBack) {
					var url  = 'references/groupByDataSetID/'+dataSetID;
					dataAccessService.doGetData(url, null, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				doQuery: function(queryCode, data, successCallBack, errorCallBack) {
					dataAccessService.doQuery(queryCode, data, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				}
				
			}
			return service;
		}]
	});	
});