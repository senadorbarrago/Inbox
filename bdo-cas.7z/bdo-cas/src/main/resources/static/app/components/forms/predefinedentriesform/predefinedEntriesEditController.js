'use strict';

define(function(){
	var core = angular.module('core');
	
	core.registerController('predefinedEntriesEditController',['$rootScope', '$scope', '$uibModalInstance', '$uibModal', 'data', 'DataAccessService', '$filter',
	                                                     function($rootScope, $scope, $uibModalInstance, $uibModal, data, dataAccessService, $filter){
	    $scope.title = 'Predefined Entries Edit Form';
		
		var vm = this;

		vm.init = function(){
			console.log(data);
			
			$scope.form = {};
			$scope.data = {};
			
			$scope.data.pdeActionTag = "UPDATE";
			$scope.data.predefinedEntryID = 0;
			$scope.data.dataSetID = $rootScope.dataSetID;
			$scope.data.dataSetCode = $rootScope.dataSetCode;
			
			vm.getBookCodeByDataSetCode();
			$scope.data.bookCode = data.bookCode;
			
			$scope.data.currencyCode = data.currencyCode;
			$scope.data.pdeDesc = data.pdeDesc;
			$scope.data.predefinedEntryID = data.predefinedEntryID;
			$scope.data.pdeDetail = data.pdeDetail;
			$scope.data.pdeType = data.pdeTypeCode;
			
			vm.getCurrencies();
			vm.getPDEType();
			
			$scope.data.dataFieldColumnID = data.dataFieldColumnID;
		}
		
		//Get bookCode
		vm.getBookCodeByDataSetCode = function(){
			var url = 'references/bookCodeByDataSet/'+$rootScope.dataSetCode;
			dataAccessService.doGetData(url, null, function(response){
				console.log(response.data);
				$scope.bookCodes = response.data;
			},function(errorResponse){
				errorCallBack(errorResponse);
			});
		};
		
		vm.getCurrencies = function(){
			
			var url = 'references/currencyByBookCode/'+$scope.data.bookCode;
			dataAccessService.doGetData(url, null, function(response){
				console.log(response.data);
				$scope.currencies = response.data;
			},function(errorResponse){
				errorCallBack(errorResponse);
			});
		}
		
		//Get PDE Types
		vm.getPDEType = function(){
			
			var url = 'references/pdeTypeByDataSetCode/'+$rootScope.dataSetCode;
			dataAccessService.doGetData(url, null, function(response){
				console.log(response.data);
				$scope.pdeTypes = response.data;
			},function(errorResponse){
				errorCallBack(errorResponse);
			});
		};
		
		vm.init();
		
		$scope.getCurrencies = function(){
			
			var url = 'references/currencyByBookCode/'+$scope.data.bookCode;
			dataAccessService.doGetData(url, null, function(response){
				console.log(response.data);
				$scope.currencies = response.data;
			},function(errorResponse){
				errorCallBack(errorResponse);
			});
		};
		
		//Save
		$scope.save = function(){
			
			console.log("Save Predefined Entry.");
			console.log("pdeActionTag: " + $scope.data.pdeActionTag);
			console.log($scope.data);
			
			var savePredefinedEntriesDefinitionUrl = 'transactions/predefinedEntries/setup';
			alertify.confirm("Do you really want to save this predefined entry?", function(e){
					
				if(e){
					dataAccessService.doPostData(savePredefinedEntriesDefinitionUrl, $scope.data, function(response){
						console.log(response);
						alertify.alert(response.data.messageMap.successMsg);
						$uibModalInstance.dismiss();
					},function(errorResponse){
						console.log(errorResponse);
						alertify.fail(errorResponse.data.errorMsg);
					});
				}else{
					return;
				}
				
			});
		};
		
		$scope.cancel = function() {
			alertify.confirm("This action cancels any changes or updates in this predefined entry. " +
					"Are you sure you want to proceed?", function(e){
					if(e){
						$uibModalInstance.dismiss();
					}else{
						return;
					}
				});
		};
		
	}]);
	
});