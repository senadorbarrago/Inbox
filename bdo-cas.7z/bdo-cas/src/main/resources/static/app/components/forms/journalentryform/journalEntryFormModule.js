'use strict';

define(function(){
	console.log('journalEntryFormModule.js loaded');
	var journalEntryFormModule = angular.module('journalEntryFormModule', ['utility']);
	
	// ControllerProvider Configuration
	journalEntryFormModule.config(['$controllerProvider', function($controllerProvider){
		console.log('journalEntryFormModule.config');
		journalEntryFormModule.registerController = $controllerProvider.register;
	}]);
	
	
});