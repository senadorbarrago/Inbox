'use strict';

define(function(){
	angular.module("core").provider('BatchSheetsCommandService', function(){
		this.$get =['DataAccessService', function(dataAccessService){
			var service = {
				submit: function(data, successCallBack, errorCallBack) {
					var url  = 'batchsheet/submit';
					dataAccessService.doPostData(url, data, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				approve: function(data, successCallBack, errorCallBack) {
					var url  = 'batchsheet/approve';
					dataAccessService.doPostData(url, data, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				undoapprove: function(data, successCallBack, errorCallBack) {
					var url  = 'batchsheet/undoapprove';
					dataAccessService.doPostData(url, data, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				}
			}
			return service;
		}]
	});	
});