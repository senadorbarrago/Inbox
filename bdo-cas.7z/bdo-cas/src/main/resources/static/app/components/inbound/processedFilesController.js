'use strict';

define(function(){
	console.log('processedFilesController.js loaded');
	var core = angular.module('core');
	
	core.registerController('processedFilesController',['$rootScope','$scope', 'DataAccessService', 'ngTableParams', '$filter', 
	    function($rootScope, $scope, dataAccessService, ngTableParams, $filter){
		$scope.title = 'This is the Processed Files screen';
		$rootScope.screenName = 'Inbound --> Processed Files'
		
		var vm = this;
		
		// Initialize Data
		vm.init = function(){
			$scope.form = {};
			$scope.form.dataset = $rootScope.dataSetID;			
			
			vm.initUrl();
			vm.initDatePicker();
			vm.initDataGrid();
		};
		
		// URL
		vm.initUrl = function(){
			$scope.form.urlFindProcessedFiles = 'inboundinterface/processedfiles',
			$scope.form.urlExecuteUndoLoad = 'inboundinterface/processedfiles/undoloadsourcefile';
		}
		
		// Date Picker Setup
		vm.initDatePicker = function(){
			$scope.datePicker = {};
			$scope.dateFormat = "yyyy-MM-dd";
			$scope.dateOptions = {
				startingDay : 1,
				showWeeks : false,	
				format : "yyyy-MM-dd"
			};
		}
		
		// Datagrid Set-Up
		vm.initDataGrid = function() {
			$scope.tableParams = new ngTableParams(
			    {
			        page: 1,
					count: 10
				},
				{
					getData: function ($defer, params) {
						var data = {};
						data.dataset = $scope.form.dataset;
						data.membershipCode = $rootScope.session['AUTHENTICATED_USER'].activeMembership.code;
						data.dateLoaded = $filter('date')($scope.form.dateLoaded, $scope.dateFormat);
						data.pageIndex  = params.page();
						data.pageSize   = params.count();
						console.log(data);
						return dataAccessService.doPostData($scope.form.urlFindProcessedFiles, data, function(response){
						    $scope.form.datagrid = response.data;
							angular.forEach($scope.form.datagrid.resultSet, function(value, key){
								value["Selected"] = false;
							});
							
							params.total($scope.form.datagrid.overAllCount);
							
							},function(errorResponse){
								alertify.alert(errorResponse.data.errorMsg);
								console.log(errorResponse);
						});
					}
				}
			);
		};
		
		// UI Validations
		vm.checkIfHasSelection = function(list){
			for(var index = 0; index < list.length; index++){
				if(list[index]["Selected"]){
					return true;
				}
			}
			return false;
		}
		
		// Initialize Controller
		vm.init();
		
		// Search processed files by date
		$scope.doSearchProcessedFiles = function(){
			//Reload Paginated Request
			$scope.tableParams.reload();
		};
		
		// Show all processed files today 
		$scope.doShowProcessedFilesToday = function(){
			$scope.form.dateLoaded = "";
			$scope.tableParams.reload();
		};
		
		// Execute undo load
		$scope.doUndoLoadSelectedFiles = function(){
			var resultSetCopy = angular.copy($scope.form.datagrid.resultSet),
				hasSelection = vm.checkIfHasSelection(resultSetCopy);
			
			if(!hasSelection){
				alertify.alert("Please select a file to be unloaded in order to proceed");
				return false;
			}
			else{
				alertify.confirm("This action unloads the selected files from and their corresponding " +
						"transactions from the system. Are you sure you want to proceed?", function(e){
					if(e){
						var data = {};
						data.dataSetCode = $rootScope.dataSetCode;
						data.sourceFileList = [];
//						data.systemDate = $filter('date')(new Date(), 'yyyyMMddhhmmssS');
						
						angular.forEach(resultSetCopy, function(value, key){
							if(value["Selected"]){
								var selectedFileName = value["File ID"] + "|" + value["File Name"];
								data.sourceFileList.push(selectedFileName);
							}
						});
						console.log(data);
						dataAccessService.doPostData($scope.form.urlExecuteUndoLoad, data, function(response){
							if(response.data.messageMap.successMsg!=undefined && response.data.messageMap.successMsg!=null){
								alertify.alert(response.data.messageMap.successMsg, function(e){
									$scope.tableParams.reload();
								});
							}
							else if(response.data.messageMap.errorMsg!=undefined && response.data.messageMap.errorMsg!=null){
								alertify.alert(response.data.messageMap.errorMsg);
							}
							
						}, function(errorResponse){
							alertify.alert(errorResponse.data.errorMsg, function(e){});
							$scope.tableParams.reload();
							console.log(errorResponse);
						});
					}
				}); 
			}
		};
		// Open DatePicker
		$scope.open = function(columnName, $event){
			$event.preventDefault();
			$event.stopPropagation();
			if ($scope.datePicker[columnName]) {
				if ($scope.datePicker[columnName].opened) {
					$scope.datePicker[columnName].opened = false;
				}
			} else {
				$scope.datePicker = {};
				$scope.datePicker[columnName] = {};
				$scope.datePicker[columnName].opened = true;
			}
		}
		
	}]);
});