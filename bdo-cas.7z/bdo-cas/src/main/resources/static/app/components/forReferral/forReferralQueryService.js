'use strict';

define(function(){
	angular.module("core").provider('ReferralQueryService', function(){
		this.$get =['$http', 'DataAccessService', function($http, dataAccessService){
			var service = {
				getReferralList: function(dataSetCode, pageIndex, pageSize, searchCriteria, successCallBack, errorCallBack) {
					var url  = 'transactions/forReferral/'+dataSetCode+'/'+pageIndex+'/'+pageSize+'/';
					dataAccessService.doPostData(url, searchCriteria, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getColumnList: function(dataSetID, recordProfileID, successCallBack, errorCallBack) {
					var url  = 'transactions/columns/'+dataSetID+'/'+recordProfileID;
					dataAccessService.doGetData(url, null, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				generateReport: function(dataSetCode, pageIndex, pageSize, searchCriteria, successCallBack, errorCallBack) {
					var reportCode = "ForReferral_csv";
					var url  = 'transactions/forReferral/generate/'+reportCode+"/"+dataSetCode+'/'+pageIndex+'/'+pageSize+'/';
					dataAccessService.doPostData(url, searchCriteria, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				}
				
			}
			return service;
		}]
	});	
});