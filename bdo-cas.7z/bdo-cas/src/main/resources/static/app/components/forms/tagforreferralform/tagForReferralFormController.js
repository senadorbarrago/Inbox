'use strict';

define(function(){
	console.log('forReferralForm.js loaded');
	var core = angular.module('core');
	
	core.registerController('forReferralFormController', [
		'$rootScope', 
		'$scope', 
		'$uibModalInstance', 
		'DataAccessService', 
		'data',
		function($rootScope, $scope, $uibModalInstance, dataAccessService, data){
			
			$scope.title = 'Tag for Referral Form';
			var vm = this;
		
			vm.init = function(){
				$scope.form = {};
				$scope.form.tagForReferralList = data.selectedItems; 
			}

			// Tag selected transactions for referral
			$scope.doTagForReferral = function(){
				alertify.confirm("This action tags the selected transactions for referral. " +
					"Are you sure you want to proceed?", function(e){
					if(e){
						var url = 'transactions/forReferral/tagforreferral';

						var data = {};
							data.recordList = [];
						angular.forEach($scope.form.tagForReferralList, function(value, key){
							var record = { 
						    				'tranID'         : value['TransactionID'],
						    				'referredAmount' : parseFloat(value['Running Balance'].replace(/,/g,'')).toFixed(2)
						    			};
						    this.push(record);
						}, data.recordList);
						
						console.log(data);
					
						dataAccessService.doPostData(url, data, function(response){
							console.log(response);
							$uibModalInstance.close(response.data.messageMap.resultMsg);
						},function(errorResponse){
							console.log(errorResponse);
							alertify.fail(errorResponse.data.errorMsg);
						});
						
					}else{
						return false;
					}
				});
			}
			
			// Close Tag for Referral Form
			$scope.close = function() {
				$uibModalInstance.dismiss();
			};
			
			vm.init();
			
			
			
			
			
			
	
	}]);
});