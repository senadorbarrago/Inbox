'use strict';

define(function(){
	console.log('journalEntriesController.js loaded');
	var core = angular.module('core');
	
	core.registerController('journalEntriesController',[ '$rootScope', '$scope', '$uibModal', 'JournalEntriesActionableQueryService',  
	                              'JournalEntriesActionableCommandService', 'ngTableParams', '$filter', function($rootScope, $scope, $uibModal, journalEntriesActionableQueryService,
	                            		  journalEntriesActionableCommandService, ngTableParams, $filter){
		$scope.title = 'This is the Journal Entries Screen';
		$rootScope.screenName = 'PROCESSING --> JOURNAL ENTRIES';
		
		// Create controller object VM
		var vm = this;
		
		vm.init = function() {
			vm.dataSetID = $rootScope.dataSetID;
			vm.dataSetCode = $rootScope.dataSetCode;
			
			$scope.form = {};
			$scope.form.searchcriteria = {};
			$scope.form.searchcriteria.data = {};
			$scope.form.searchcriteria.data.filterList = [];
			$scope.form.searchcriteria.data.sortList = [];
			$scope.form.datagrid = {};
			
			vm.pageIndex = 1;
			vm.pageSize = 50;
			
			vm.getFieldList();
			vm.loadPage();
		}
		
		vm.getFieldList= function(){
			journalEntriesActionableQueryService.getColumnList(vm.dataSetID, 9, function(response){
				$scope.form.searchcriteria.dataFieldList = [];
				angular.forEach(response.data.resultSet, function(value, key) {
						$scope.form.searchcriteria.dataFieldList.push(value);
				});
				console.log($scope.form.searchcriteria.dataFieldList);
			}, function(error){
				console.log(error);
			});
		};
		
		vm.loadPage = function() {
			$scope.tableParams = new ngTableParams(
					{	page: 1,
						count: 25
					},
					{	getData: function ($defer, params) {
							return journalEntriesActionableQueryService.getJournalEntries($rootScope.dataSetID,
									params.page(), params.count(), $scope.form.searchcriteria.data, function(response) {
									$scope.form.datagrid = response.data;									
									
									params.total($scope.form.datagrid.resultOverAllCount);
									$defer.resolve($scope.form.datagrid.resultSet);
								}, function (response) {});
						}
					}
			);
		};
		// Initialize
		vm.init();
		
		// SearchPanel
		$scope.selectFilterField = function(){
			console.log($scope.form.searchcriteria.filterField);
		};
		
		$scope.doAddFilter = function(){
			if(!$scope.form.searchcriteria.filterField){
				alertify.alert("Please select a filter field in order to proceed.");
				return false;
			}
			
			var record = {"id":$scope.form.searchcriteria.filterField.dataFieldID, "fieldName":$scope.form.searchcriteria.filterField.fieldName, "fieldLabel":$scope.form.searchcriteria.filterField.label , "hasRange":$scope.form.searchcriteria.filterField.hasRange, "valueFrom":"", "valueTo":""};
			var isExists = false;
			
			angular.forEach($scope.form.searchcriteria.data.filterList, function(value, key){
				if(!isExists){
					if(value.id === $scope.form.searchcriteria.filterField.dataFieldID){
						isExists = true;
					}
				}
			});
			
			if(!isExists){
				$scope.form.searchcriteria.data.filterList.push(record);
			}
		};
		
		$scope.removeFilter = function(index){
			var item = $scope.form.searchcriteria.data.filterList[index];
			$scope.form.searchcriteria.data.filterList.splice(index, 1);
		};
		
		$scope.doClearFilterFields = function(){
			$scope.form.searchcriteria.filterField = {};
			$scope.form.searchcriteria.data.filterList = [];
		};
		
		$scope.selectSortField = function(){
			console.log($scope.form.searchcriteria.sortField);
		};
		
		$scope.doAddSort = function(){
			if(!$scope.form.searchcriteria.sortField){
				alertify.alert("Please select a sort field in order to proceed.");
				return false;
			}
			
			var record = {"id":$scope.form.searchcriteria.sortField.dataFieldID, "fieldName":$scope.form.searchcriteria.sortField.fieldName, "fieldLabel":$scope.form.searchcriteria.sortField.label, "order":"1", "valueFrom":"ASC"};
			var isExists = false;
			
			angular.forEach($scope.form.searchcriteria.data.sortList, function(value, key){
				if(!isExists){
					if(value.id === $scope.form.searchcriteria.sortField.dataFieldID){
						isExists = true;
					}
				}
			});
			
			if(!isExists){
				$scope.form.searchcriteria.data.sortList.push(record);
			}
		};
		
		$scope.removeSort = function(index){
			var item = $scope.form.searchcriteria.data.sortList[index];
			$scope.form.searchcriteria.data.sortList.splice(index, 1);
		};
		
		$scope.doClearSortFields = function(){
			$scope.form.searchcriteria.sortField = {};
			$scope.form.searchcriteria.data.sortList = [];			
		};
		
		$scope.doClearAll = function(){
			$scope.doClearFilterFields();
			$scope.doClearSortFields();
		};
		
		$scope.doShowAll = function(){
			$scope.doClearAll();
			
			// Reset pageSize and pageIndex
			$scope.tableParams.page(1);
			$scope.tableParams.count(25);

			//Reload Paginated Request
			$scope.tableParams.reload();
		}
		
		$scope.doSearch = function(){			
			console.log("doSearch()");
			console.log($scope.form.searchcriteria.data.filterList);
			console.log($scope.form.searchcriteria.data.sortList);
			
			//Revert to page 1
			$scope.tableParams.page(1);
			//Reload Paginated Request
			$scope.tableParams.reload();
		};
		
		$scope.selectAll = function(){
			var toggleStatus = $scope.form.isAllSelected;
			console.log(toggleStatus);
			angular.forEach($scope.form.datagrid.resultSet, function(record){
				record.selected = toggleStatus;
			});
		}
		
		$scope.doChangeSelection = function(record){
			record.selected = !record.selected;
			if(!record.selected){
				$scope.form.isAllSelected = false;
			}
		}
		
		$scope.showFormByBatchID = function(batchID){
			$scope.doShowJournalEntryForm(batchID);
		}
		
		// Submit Form
		$scope.submitForm = function(){
			var selectedItems = vm.getSelectedItems($scope.form.datagrid.resultSet);
			if(selectedItems.length == 0){
				alertify.alert("Please select item/s first in order to proceed with this action");
			}else{
				var invalidRecords = '';
				for(var i = 0; i < selectedItems.length; i++){
					var status = selectedItems[i]['Status'];
					if(status.toUpperCase() !== 'Newly Encoded'.toUpperCase() && status.toUpperCase() !== 'For Update'.toUpperCase()){
						invalidRecords = invalidRecords+selectedItems[i]['Batch ID']+'\n';
					}
				}
				if(invalidRecords){
					alertify.alert("Only journal entries with status 'Newly Encoded' or 'For Update' are valid for approval." +
							"Remove the following invalid records from the selection in order to proceed:\n" +
							invalidRecords);
					return false;
				}		
				
				alertify.confirm("This action submits the selected journal entries for approval. " +
					"Are you sure you want to proceed?", function(e){
					if(e){
						var batchIDs = [];
						for(var i = 0; i < selectedItems.length; i++){
							batchIDs.push(selectedItems[i]['Batch ID']);
						}
						journalEntriesActionableCommandService.submitForm(batchIDs, function(response){
							alertify.alert(response.data.messageMap.successMsg);
							$scope.tableParams.reload();
						}, function(error){
							console.log(error);
							alertify.fail(error.data.errorMsg);
						});
					}else{
						return false;
					}
				});
			}
		}
		
		$scope.approveForm = function(){
			var selectedItems = vm.getSelectedItems($scope.form.datagrid.resultSet);
			
			if(selectedItems.length == 0){
				alertify.alert("Please select items first in order to proceed with this action");
			}else{
				var invalidRecords = '';
				for(var i = 0; i < selectedItems.length; i++){
					var status = selectedItems[i]['Status'];
					if(status.toUpperCase() !== 'For Approval'.toUpperCase()){
						invalidRecords = invalidRecords+selectedItems[i]['Batch ID']+'\n';
					}
				}
				if(invalidRecords){
					alertify.alert("Only journal entries with status 'for Approval' are valid for approval." +
							"Remove the following invalid records from the selection in order to proceed:\n" +
							invalidRecords);
					return false;
				}
				
				alertify.confirm("This action approves the selected journal entries. " +
					"Are you sure you want to proceed?", function(e){
					if(e){
						var batchIDs = [];
						for(var i = 0; i < selectedItems.length; i++){
							batchIDs.push(selectedItems[i]['Batch ID']);
						}
						journalEntriesActionableCommandService.approveForm(batchIDs, function(response){
							alertify.alert(response.data.messageMap.successMsg);
							$scope.tableParams.reload();
						}, function(error){
							console.log(error);
							alertify.fail(error.data.errorMsg);
						});
					}else{
						return false;
					}
				});
			}
			
		}
		
		$scope.denyForm = function(){
			var selectedItems = vm.getSelectedItems($scope.form.datagrid.resultSet);
			if(selectedItems.length == 0){
				alertify.alert("Please select items first in order to proceed with this action");
			}else{
				var invalidRecords = '';
				for(var i = 0; i < selectedItems.length; i++){
					var status = selectedItems[i]['Status'];
					console.log(status);
					if(status.toUpperCase() !== 'For Approval'.toUpperCase() && status.toUpperCase() !== 'Approved'.toUpperCase()){
						invalidRecords = invalidRecords+selectedItems[i]['Batch ID']+'\n';
					}
				}
				if(invalidRecords){
					alertify.alert("Only journal entries with status 'for Approval' and 'Approved' are valid for tagging as 'for Update'." +
							"Remove the following invalid records from the selection in order to proceed:\n" +
							invalidRecords);
					return false;
				}
				
				alertify.confirm("This action returns the selected journal entries for update. " +
					"Are you sure you want to proceed?", function(e){
					if(e){
						var batchIDs = [];
						for(var i = 0; i < selectedItems.length; i++){
							batchIDs.push(selectedItems[i]['Batch ID']);
						}
						journalEntriesActionableCommandService.denyForm(batchIDs, function(response){
							alertify.alert(response.data.messageMap.successMsg);
							$scope.tableParams.reload();
						}, function(error){
							console.log(error);
							alertify.fail(error.data.errorMsg);
						});
					}else{
						return false;
					}
				});
			}			
		}
		
		$scope.deleteForm = function(){
			var selectedItems = vm.getSelectedItems($scope.form.datagrid.resultSet);
			if(selectedItems.length == 0){
				alertify.alert("Please select items first in order to proceed with this action");
			}else{
				var invalidRecords = '';
				for(var i = 0; i < selectedItems.length; i++){
					var status = selectedItems[i]['Status'];
					console.log(status);
					if(status.toUpperCase() !== 'Newly Encoded'.toUpperCase() && status.toUpperCase() !== 'For Update'.toUpperCase()){
						invalidRecords = invalidRecords+selectedItems[i]['Batch ID']+'\n';
					}
				}
				if(invalidRecords){
					alertify.alert("Only journal entries with status 'Newly Encoded' and 'For Update' are valid for deletion." +
							"Remove the following invalid records from the selection in order to proceed:\n" +
							invalidRecords);
					return false;
				}
				
				alertify.confirm("This action deletes the selected journal entries. " +
					"Are you sure you want to proceed?", function(e){
					if(e){
						var batchIDs = [];
						for(var i = 0; i < selectedItems.length; i++){
							console.log(selectedItems[i]['Batch ID']);
							batchIDs.push(selectedItems[i]['Batch ID']);
						}
						journalEntriesActionableCommandService.deleteForm(batchIDs, function(response){
							alertify.alert(response.data.messageMap.successMsg);
							$scope.tableParams.reload();
						}, function(error){
							console.log(error);
							alertify.fail(error.data.errorMsg);
						});
					}else{
						return false;
					}
				});
			}			
		}
		
		$scope.doShowJournalEntryForm = function(batchID){
			console.log('doShowJournalEntryForm()');
			var modalInstance = $uibModal.open({
				animation: true,
				backdrop: 'static',
				templateUrl: 'app/components/forms/journalentryform/viewJournalEntryForm.html',
				controller: 'journalEntryFormController',
				size: 'lg',
				resolve:{
					data:function(){
						var data = {};
						data.header = {};
						data.header.batchID = batchID;
						data.sourceType = 'JE';
						return data;
					},
					load: ['$q', function($q){
						var defered = $q.defer();
						require(['app/components/forms/journalentryform/journalEntryFormController'], function(){
							defered.resolve();
						});
						return defered.promise;
					}]
				}
			});
			
			modalInstance.result.then(
				function(message) {
					//Reload Paginated Request
					$scope.tableParams.reload();
				}, 
				function() {				
					// dismissed
					console.log("dismissed");
				}
			);
			return modalInstance.result;
			
		};
		
		// Get selected items
		vm.getSelectedItems = function(items){
			var selectedItems = [];
			for(var i = 0; i < items.length; i++){
				var selected = items[i].selected;
				if(selected === true){
					selectedItems.push(items[i]);
				}
			}
			return selectedItems;
		}
		
		// Remarks
		$scope.doAddRemarks = function(){
			var selectedItems = vm.getSelectedItems($scope.form.datagrid.resultSet);
			if(selectedItems.length == 0){
				alertify.alert("Please select item/s first in order to proceed with this action");
				return false;
			}
			$scope.batchIDs = [];
			
			for(var i = 0; i < selectedItems.length; i++){
				$scope.batchIDs.push(selectedItems[i]['Batch ID']);
			}
			
			var modalInstance = $uibModal.open({
				animation: true,
				backdrop: 'static',
				templateUrl: 'app/components/forms/remarks/remarksForm.html',
				controller: 'remarksFormController',
				size: 'lg',
				keyboard: false,
				resolve:{
					load: ['$q', function($q){
						var defered = $q.defer();
						require(['app/components/forms/remarks/remarksFormController'], function(){
							defered.resolve();
						});
						return defered.promise;
					}],
					data : function(){
						var data = {}; 
						data.batchIDs = $scope.batchIDs;
						data.sourceType = 'JE';
						return data;
					}
				}
			});
			modalInstance.result.then(function(message){}, 
			function() {				
				// dismissed
				console.log("dismissed");
			});
			return modalInstance.result;
		};
		
	}]);
});