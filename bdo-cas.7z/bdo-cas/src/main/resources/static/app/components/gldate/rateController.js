'use strict';

define(function(){
	var core = angular.module('core');
	
	core.registerController('rateController',[ '$rootScope', '$scope', '$uibModal', 'DataAccessService', '$filter', 
		function($rootScope, $scope, $uibModal, dataAccessService, $filter){
		$rootScope.screenName = 'RATE';
		
		var vm = this;

		vm.init = function(){
			$scope.form = {};
			$scope.data = {};
			$scope.data.rateID = 0;
			$scope.data.forwardRates = true;
			$scope.data.dataSetID = 0.00;
			$scope.data.rateActionTag = "";
			$scope.datePicker = { };
			$scope.dateOptions = {
					startingDay : 1,
					showWeeks : false,	
					format : "yyyy-MM-dd"
				};
			$scope.dateFormat = "yyyy-MM-dd";
			
			$scope.data.dataSetID = $rootScope.dataSetID;
			
			vm.getCurrentGLDate();
			vm.getProcessID();
			vm.getCurrentCurrencyRates();
			vm.getCurrenciesByDataSetCode();
		}
		
		$scope.open = function(columnName, $event) {
			$event.preventDefault();
			$event.stopPropagation();
			
			if ($scope.datePicker[columnName]) {
				if ($scope.datePicker[columnName].opened) {
					$scope.datePicker[columnName].opened = false;
				}
			} else {
				$scope.datePicker = {};
				$scope.datePicker[columnName] = {};
				$scope.datePicker[columnName].opened = true;
			}
		}
		
		$scope.process = function(){
			console.log($scope.data.forwardRates);
			console.log($scope.data.glDate);
			var saveGLDateUrl = "transactions/glDate/save";			
			
			if(!$scope.data.glDate){
				alertify.alert("Please select a GL Date in order to proceed");
				return;
			}else{
				alertify.confirm("Do you really want to set GL Date?", function(e){
					
					if(e){
						dataAccessService.doPostData(saveGLDateUrl, $scope.data, function(response){
							console.log(response);
							alertify.alert(response.data.messageMap.successMsg);
							vm.init();
						},function(errorResponse){
							console.log(errorResponse);
							alertify.fail(errorResponse.data.errorMsg);
						});
					}else{
						return;
					}
				});
			}
			
		}
		
		vm.getCurrentGLDate = function(){
			var getCurrentGLDateUrl = "transactions/glDate/currentGlDate/"+$scope.data.dataSetID;			
			dataAccessService.doGetData(getCurrentGLDateUrl, null, function(response){
				console.log(response);
				$scope.data.previousGlDate = response.data.previousGlDate;
			},function(errorResponse){
				console.log(errorResponse);
			});
		}
		
		vm.getProcessID = function(){
			var getProcessIDUrl = "transactions/glDate/processID/"+$scope.data.dataSetID;			
			dataAccessService.doGetData(getProcessIDUrl, null, function(response){
				console.log(response);
				$scope.data.processID = response.data.processID;
			},function(errorResponse){
				console.log(errorResponse);
			});
		}
		
		vm.getCurrentCurrencyRates = function(){
			var url = "transactions/glDate/currentCurrencyRatesList";		
			dataAccessService.doGetData(url, null, function(response){
				console.log(response);
				$scope.currencyRates = response.data;
			},function(errorResponse){
				console.log(errorResponse);
			});
		}
		
		//Get currencies
		vm.getCurrenciesByDataSetCode = function(){
			var url = 'references/currencyByDataSetCode/'+$rootScope.dataSetCode;
			dataAccessService.doGetData(url, null, function(response){
				console.log(response.data);
				$scope.currencies = response.data;
			},function(errorResponse){
				errorCallBack(errorResponse);
			});
		};
		
		vm.init();
		
		$scope.addRate = function(){
			
			console.log("Add Rate.");
			$scope.data.rateActionTag = "ADD";
			$scope.setAttribute($scope.data.rateActionTag)
		};
		
		$scope.editRate = function(){
			
			console.log("Edit Rate.");
			$scope.data.rateActionTag = "UPDATE";
			
			if(!$scope.selectedRecord){
				alertify.alert("Please select an item first in order to proceed with this action.");
				return false;
			}else {
				console.log("OK");
				$scope.setAttribute($scope.data.rateActionTag)
				$scope.data.currencyID = $scope.selectedRecord.id;
				$scope.data.pesoRate = $scope.selectedRecord.phpRate;
				$scope.data.usdRate = $scope.selectedRecord.usdRate;
				$scope.data.glDate = new Date($scope.selectedRecord.refDate);
				$scope.data.rateID = $scope.selectedRecord.rateID;
			}
			
		};
		
		$scope.deleteRate = function(){
			
			console.log("Delete Rate.");
			$scope.data.rateActionTag = "DELETE";

			if(!$scope.selectedRecord){
				alertify.alert("Please select an item first in order to proceed with this action.");
				return false;
			}else {
				console.log("OK");
				$scope.setAttribute($scope.data.rateActionTag)
				$scope.data.currencyID = $scope.selectedRecord.id;
				$scope.data.pesoRate = $scope.selectedRecord.phpRate;
				$scope.data.usdRate = $scope.selectedRecord.usdRate;
				$scope.data.glDate = new Date($scope.selectedRecord.refDate);
				$scope.data.rateID = $scope.selectedRecord.rateID;
				$scope.setAttribute($scope.data.rateActionTag);
				
				var deleteGLDateUrl = 'transactions/rate/setup';
				alertify.confirm("Do you really want to delete rate for this currency?", function(e){
						
					if(e){
						dataAccessService.doPostData(deleteGLDateUrl, $scope.data, function(response){
							console.log(response);
							alertify.alert(response.data.messageMap.successMsg);
							vm.init();
						},function(errorResponse){
							console.log(errorResponse);
							alertify.fail(errorResponse.data.errorMsg);
						});
					}else{
						return;
					}
				});
				$scope.setAttribute("");
			}
		};
		
		$scope.saveRate = function(rateActionTag){
			
			$scope.data.glDate = $filter('date')(new Date($scope.data.glDate), 'yyyy-MM-dd')
			
			console.log("Save Rate.");
			console.log("rateActionTag: " + rateActionTag);
			console.log($scope.data);
			
			var saveGLDateUrl = 'transactions/rate/setup';
			alertify.confirm("Do you really want to save rate for this currency?", function(e){
					
				if(e){
					dataAccessService.doPostData(saveGLDateUrl, $scope.data, function(response){
						console.log(response);
						alertify.alert(response.data.messageMap.successMsg);
						vm.init();
					},function(errorResponse){
						console.log(errorResponse);
						alertify.fail(errorResponse.data.errorMsg);
					});
				}else{
					return;
				}
			});
			
			$scope.setAttribute("");
		};
		
		// Get selected items
		vm.getSelectedItems = function(items){
			var selectedItems = [];
			for(var i = 0; i < items.length; i++){
				var selected = items[i].selected;
				if(selected === true){
					selectedItems.push(items[i]);
				}
			}
			return selectedItems;
		}
		
		$scope.setAttribute = function(action){

			if(action === 'ADD'){
				$("#currency").attr("disabled", false);
				$("#pesoRate").attr("disabled", false);
				$("#usdRate").attr("disabled", false);
				$("#calendar").attr("disabled", false);
				$("#save").show();
				$scope.data.currencyID = 0;
				$scope.data.pesoRate = 0.00;
				$scope.data.usdRate = 0.00;
				$scope.data.glDate = new Date();
				$scope.data.rateID = 0;
			}else if(action === 'UPDATE'){
				$("#currency").attr("disabled", "disabled");
				$("#pesoRate").attr("disabled", false);
				$("#usdRate").attr("disabled", false);
				$("#calendar").attr("disabled", "disabled");
				$("#save").show();
			}else{
				$("#currency").attr("disabled", "disabled");
				$("#pesoRate").attr("disabled", "disabled");
				$("#usdRate").attr("disabled", "disabled");
				$("#calendar").attr("disabled", "disabled");
				$("#save").hide();
			}
		}
		
		$scope.validate = function(action, selectedItems){

			if(action === 'UPDATE' || action === 'DELETE'){
				if(selectedItems.length == 0){
					alertify.alert("Please select an item first in order to proceed with this action");
				}else if(selectedItems.length > 1){
					alertify.alert("Please one at a time in order to proceed with this action");
				}else {
					console.log("OK");
				}
				
			}else{
				$("#currency").attr("disabled", "disabled");
				$("#pesoRate").attr("disabled", "disabled");
				$("#usdRate").attr("disabled", "disabled");
				$("#calendar").attr("disabled", "disabled");
				$("#save").hide();
			}
		}
		
		$scope.setSelectedRecord = function(index){
			$scope.selectedRecord = $scope.currencyRates.resultSet[index];
			console.log($scope.selectedRecord);
			
			$scope.setAttribute($scope.data.rateActionTag)
			$scope.data.currencyID = $scope.selectedRecord.id;
			$scope.data.pesoRate = $scope.selectedRecord.phpRate;
			$scope.data.usdRate = $scope.selectedRecord.usdRate;
			$scope.data.glDate = new Date($scope.selectedRecord.refDate);
			$scope.data.rateID = $scope.selectedRecord.rateID;
		}
		
		$scope.doShowRatesViewForm = function(){
			
			var modalInstance = $uibModal.open({
				animation: true,
				backdrop: 'static',
				templateUrl: 'app/components/forms/viewRatesform/ratesViewForm.html',
				controller: 'ratesViewFormController',
				size: 'md',
				resolve:{
					load: ['$q', function($q){
						var defered = $q.defer();
						require(['app/components/forms/viewRatesform/ratesViewFormController'], function(){
							defered.resolve();
						});
						return defered.promise;
					}],
					data : function(){
						var data = {};
						return data;
					}
				}
			});
			modalInstance.result.then(function(message){
				alertify.alert(message);
				vm.init();
			}, 
			function() {				
				// dismissed
				console.log("dismissed");
				vm.init();
			});
			return modalInstance.result;
		}
		

		
	}]);
	
});