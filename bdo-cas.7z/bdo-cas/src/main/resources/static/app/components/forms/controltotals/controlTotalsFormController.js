'use strict';

define(function(){
	
	console.log('controlTotalsFormController.js loaded');
	var core = angular.module('core');
	
	core.registerController('controlTotalsFormController', ['$rootScope', '$scope', '$uibModal', '$uibModalInstance', 'DataAccessService',
			'data', function($rootScope, $scope, $uibModal, $uibModalInstance, dataAccessService, data){
		
		$scope.title = 'Control Totals Form';
		
		var vm = this;
		
		/**
		 * 
		 */
		vm.init = function(){
			// Form Data Set-Up
			$scope.data = {};
			$scope.data.controlTotals = {};
			$scope.data.controlTotals.resultSet = {};
			$scope.data.otherAdjustments = {};
			$scope.data.otherAdjustments.totalDebitAmount = 0.00;
			$scope.data.otherAdjustments.totalCreditAmount = 0.00;
			
			// Form Reference Set-Up
			$scope.reference = {};
			$scope.batchSheetTypeList = ['REG', 'ALL'];
			$scope.fields = [];
			
			// Others
			$scope.controlTotals = {};
			$scope.otherAdjustments = {};
			$scope.controltotalsautocomputed = {};			
			
			
			vm.getBookCodeByDataSetID();
			
			if(data.controlTotalsID && data.controlTotalsID > 0){
				$scope.data.controlTotalsID = data.controlTotalsID;
			}else{
				$scope.data.controlTotalsID = 0;
			}
			
			if($scope.data.controlTotalsID && $scope.data.controlTotalsID > 0){
				vm.getExistingForm();
			}else{
				vm.getNewForm();
			}
		}
		
		/**
		 * 
		 */
		vm.getNewForm = function(){
			vm.getProcessingDate();
			$scope.data.batchSheetType = 'REG';
			
			vm.getManuallyEncodedControlTotals();
			vm.getOtherAdjustmentSummary();
			$scope.getAutoComputedControlTotals();
		}
		
		/**
		 * 
		 */
		vm.getExistingForm = function(){
			vm.getControlTotalsHeader();
		}
				
		/**
		 * 
		 */
		vm.getProcessingDate = function(){
			var url = 'references/processingInfo/'+$rootScope.dataSetCode+'/'+$rootScope.encodingUnitCode;
			dataAccessService.doGetData(url, null, function(response){
				console.log(response.data);
				$scope.data.processingDate = response.data.resultSet[0].processDate;
			}, function(errorResponse){
				console.log(errorResponse);
			});
		}
		
		/**
		 * 
		 */
		vm.getBookCodeByDataSetID = function(){
			var url  = 'references/bookCodeByDataSet/'+$rootScope.dataSetCode;
			dataAccessService.doGetData(url, null, function(response){
				$scope.reference.bookCodeList = response.data;
			}, function(errorResponse){
				console.log(errorResponse);
			});
		}
		
		/**
		 * Control Totals Header for Existing Form
		 */
		vm.getControlTotalsHeader = function(){
			var url = 'controltotals/header/'+$rootScope.dataSetCode+'/'+$scope.data.controlTotalsID;
			dataAccessService.doGetData(url, null, function(response){
				console.log(response);
				$scope.data.processingDate = response.data.resultSet[0].processingDate;
				$scope.data.bookCodeID = response.data.resultSet[0].bookCodeID;
				
				$scope.data.currencyID = response.data.resultSet[0].currencyID;
				$scope.data.batchSheetID = response.data.resultSet[0].batchSheetID;
				$scope.statusCode = response.data.resultSet[0].statusCode;
				$scope.data.batchSheetType = response.data.resultSet[0].batchSheetType;
				
				vm.getManuallyEncodedControlTotals();
				vm.getOtherAdjustmentSummary();
				$scope.getAutoComputedControlTotals();
			},function(errorResponse){
				console.log(errorResponse);
			});	
		}
		
		/**
		 *  Manually Encoded Control Totals
		 */
		vm.getManuallyEncodedControlTotals = function(){
			var url = 'controltotals/manuallyencoded/'+$rootScope.dataSetCode+'/'+$scope.data.controlTotalsID;
			dataAccessService.doGetData(url, null, function(response){
				$scope.controlTotals.resultSet = response.data.resultSet;
				// Initialize control totals fields
				$scope.fields = [];
				for(var i = 0; i < $scope.controlTotals.resultSet.length; i++){
					var field = {'code' : $scope.controlTotals.resultSet[i].code};
					$scope.fields.push(field);
				}
			}, function(errorResponse){
				console.log(errorResponse);
			});
		}
		
		/**
		 * Auto Computed Control Totals
		 */
		$scope.getAutoComputedControlTotals = function(){
			console.log('$scope.getAutoComputedControlTotals()');
			
			var url = 'controltotals/autocomputed/'+$rootScope.dataSetCode+'/'+$scope.data.bookCodeID+'/'+$scope.data.currencyID+'/'+
			$rootScope.encodingUnitCode+'/'+$scope.data.controlTotalsID+'/'+$scope.data.batchSheetType;
			
			dataAccessService.doGetData(url, null, function(response){
				$scope.controltotalsautocomputed = {};
				$scope.controltotalsautocomputed.resultSet = response.data.resultSet;
				console.log(response);
			},function(errorResponse){
				console.log(errorResponse);
			});
		};
		
		/**
		 * Other Adjustments Summary
		 */
		vm.getOtherAdjustmentSummary = function(){
			var url = 'otheradjustments/summary/'+$rootScope.dataSetCode+'/'+$scope.data.controlTotalsID;
			dataAccessService.doGetData(url, null, function(response){
				console.log(response);
				$scope.otherAdjustments.resultSet = response.data.resultSet;
				$scope.data.otherAdjustments.totalDebitAmount = response.data.resultSet[0].debitAmount;
				$scope.data.otherAdjustments.totalCreditAmount = response.data.resultSet[0].creditAmount;
			},function(errorResponse){
				console.log(errorResponse);
			});
		}
		
		// Initialize
		vm.init();
		
		/**
		 * 
		 */
		$scope.$watch('data.bookCodeID', function(){
			console.log('$scope.$watch(\'data.bookCodeID\', function()');
			if($scope.data.bookCodeID){
				var url  = 'references/currencyByBookCodeID/'+$scope.data.bookCodeID;
				dataAccessService.doGetData(url, null, function(response){
					$scope.reference.currencyList = response.data;
					if($scope.reference.currencyList.length === 1){
						$scope.data.currencyID = $scope.reference.currencyList[0].id;
						$scope.getAutoComputedControlTotals();
					}
				}, function(errorResponse){
					console.log(errorResponse);
				});
			}
		});
		
		/**
		 * Save
		 */
		$scope.save = function(){
			console.log($scope.data);
			if(!$scope.data.bookCodeID || !$scope.data.currencyID){
				alertify.alert("Select a Book Code/Currency first in order to proceed");
				return false;
			}
			
			if(!$scope.data.batchSheetType){
				alertify.alert("Select a Batch Sheet Type in order to proceed");
				return false;
			}
			
			if($scope.data.creditTotal <= 0.00 && $scope.data.debitTotal <= 0.00){
				alertify.alert("You can only save this form if you have atleast one Control Total field value. " +
						"Perform the necessary transaction processing in order to proceed. ");
				return false;
			}
			
			var isValid = true;
			
			for(var i = 0; i < $scope.fields.length; i++){
				if($scope.data.controlTotals.resultSet[$scope.fields[i].code]){
					console.log($scope.data.controlTotals.resultSet[$scope.fields[i].code].debitAmount.replace(/,/g,''));
					console.log($scope.data.controlTotals.resultSet[$scope.fields[i].code].creditAmount.replace(/,/g,''));
					
					if($scope.validateNumericInput(parseFloat($scope.data.controlTotals.resultSet[$scope.fields[i].code].debitAmount.replace(/,/g,''))) === 'invalid' || 
							$scope.validateNumericInput(parseFloat($scope.data.controlTotals.resultSet[$scope.fields[i].code].creditAmount.replace(/,/g,''))) === 'invalid'){
						isValid = false;
						console.log("isValid = false");
					}
				}
			}
			
			if(!isValid){
				alertify.alert("Amount's maximum whole number must be 14 digits only.");
				return false;
			}
			
			alertify.confirm("This action saves the control totals and other adjustments. " +
					"Are you sure you want to proceed?", function(e){
				if(e){			
					var url = "controltotals/add/";	
					$scope.data.encodingUnitCode = $rootScope.encodingUnitCode;
					$scope.data.dataSetCode = $rootScope.dataSetCode;
					
					for(var i = 0; i < $scope.fields.length; i++){
						if($scope.data.controlTotals.resultSet[$scope.fields[i].code]){
							$scope.data.controlTotals.resultSet[$scope.fields[i].code].debitAmount = $scope.data.controlTotals.resultSet[$scope.fields[i].code].debitAmount.replace(/,/g,'');
							$scope.data.controlTotals.resultSet[$scope.fields[i].code].creditAmount = $scope.data.controlTotals.resultSet[$scope.fields[i].code].creditAmount.replace(/,/g,'');
						}
					}
					console.log($scope.data);
					
					dataAccessService.doPostData(url, $scope.data, function(response){
						console.log(response);
						alertify.alert(response.data.messageMap['successMsg']);
						$uibModalInstance.close($scope.data);
					},function(errorResponse){
						console.log(errorResponse);
						alertify.alert(errorResponse.data.errorMsg);
					});
			
				}
			});
			
		};
		
		/**
		 * Update
		 */
		$scope.update = function(){
			console.log($scope.data);
			if(!$scope.data.bookCodeID || !$scope.data.currencyID){
				alertify.alert("Select a Book Code/Currency first in order to proceed");
				return false;
			}
			
			if($scope.data.creditTotal <= 0.00 && $scope.data.debitTotal <= 0.00){
				alertify.alert("You can only save this form if you have atleast one Control Total field value. " +
						"Perform the necessary transaction processing in order to proceed. ");
				return false;
			}
			
			alertify.confirm("This action updates the control totals of the corresponding batch sheet." +
					"Are you sure you want to proceed?", function(e){
				if(e){			
					var url = "controltotals/update/";	
					$scope.data.encodingUnitCode = $rootScope.encodingUnitCode;
					$scope.data.dataSetCode = $rootScope.dataSetCode;
					
					for(var i = 0; i < $scope.fields.length; i++){
						if($scope.data.controlTotals.resultSet[$scope.fields[i].code]){
							$scope.data.controlTotals.resultSet[$scope.fields[i].code].debitAmount = $scope.data.controlTotals.resultSet[$scope.fields[i].code].debitAmount.replace(/,/g,'');
							$scope.data.controlTotals.resultSet[$scope.fields[i].code].creditAmount = $scope.data.controlTotals.resultSet[$scope.fields[i].code].creditAmount.replace(/,/g,'');
						}
					}

					console.log($scope.data);
					dataAccessService.doPostData(url, $scope.data, function(response){
						console.log(response);
						alertify.alert(response.data.messageMap['successMsg']);
						$uibModalInstance.close($scope.data);
					},function(errorResponse){
						console.log(errorResponse);
						alertify.alert(errorResponse.data.errorMsg);
					});
			
				}
			});
		};
		
		/**
		 * doDelete()
		 */
		$scope.doDelete = function(){
			console.log($scope.data);
			if(!$scope.data.bookCodeID || !$scope.data.currencyID){
				alertify.alert("Select a Book Code/Currency first in order to proceed");
				return false;
			}
			
			alertify.confirm("This action will delete this control totals and all its associated" +
					" take-ups, journal entries, icbs workstation balance, manually encoded control totals, " +
						"other adjustments, and batch sheet. This cannot be undone."  +
					"Are you sure you want to proceed?", function(e){
				if(e){			
					var url = "controltotals/delete/";	
					$scope.data.encodingUnitCode = $rootScope.encodingUnitCode;
					$scope.data.dataSetCode = $rootScope.dataSetCode;
					$scope.data.controlTotalsID = $scope.data.controlTotalsID
				
					console.log($scope.data);
					dataAccessService.doPostData(url, $scope.data, function(response){
						console.log(response);
						alertify.alert(response.data.messageMap['successMsg']);
						$uibModalInstance.close($scope.data);
					},function(errorResponse){
						console.log(errorResponse);
						alertify.alert(errorResponse.data.errorMsg);
					});
			
				}
			});
			
		};
		
		/**
		 * 
		 */
		$scope.computeDebitTotals = function(){
			$scope.data.controlTotals.totalDebitAmount = 0.00;
			$scope.controltotalsautocomputed.totalDebitAmount = 0.00;
			$scope.data.debitTotal = 0.00;
			if($scope.data.controlTotals.resultSet){
				for(var i = 0; i < $scope.fields.length; i++){
					if($scope.data.controlTotals.resultSet[$scope.fields[i].code]){
						$scope.data.controlTotals.totalDebitAmount = parseFloat($scope.data.controlTotals.totalDebitAmount) + 
						parseFloat($scope.data.controlTotals.resultSet[$scope.fields[i].code].debitAmount.replace(/,/g,''));
					}
				}
			}
			
			if($scope.controltotalsautocomputed){
				if($scope.controltotalsautocomputed.resultSet){					
					for(var i = 0; i < $scope.controltotalsautocomputed.resultSet.length; i++){
						
						if($scope.controltotalsautocomputed.resultSet[i]){
							$scope.controltotalsautocomputed.totalDebitAmount = parseFloat($scope.controltotalsautocomputed.totalDebitAmount) + 
							parseFloat($scope.controltotalsautocomputed.resultSet[i].debitAmount.replace(/,/g,''));
						}
					}
				}
			}
			
			$scope.data.debitTotal = $scope.roundNumber(parseFloat($scope.data.debitTotal)+parseFloat($scope.data.controlTotals.totalDebitAmount)+
						parseFloat($scope.data.otherAdjustments.totalDebitAmount.toString().replace(/,/g,''))+
						parseFloat($scope.controltotalsautocomputed.totalDebitAmount), 2);
			
			return $scope.roundNumber($scope.data.debitTotal, 2);
		};
		
		/*
		 * 
		 */
		$scope.computeCreditTotals = function(){
			$scope.data.controlTotals.totalCreditAmount = 0.00;
			$scope.controltotalsautocomputed.totalCreditAmount = 0.00;
			$scope.data.creditTotal = 0.00;
			if($scope.data.controlTotals.resultSet){
				for(var i = 0; i < $scope.fields.length; i++){
					if($scope.data.controlTotals.resultSet[$scope.fields[i].code]){
						$scope.data.controlTotals.totalCreditAmount = parseFloat($scope.data.controlTotals.totalCreditAmount) + 
						parseFloat($scope.data.controlTotals.resultSet[$scope.fields[i].code].creditAmount.replace(/,/g,''));
					}
				} 	
			}
			
			if($scope.controltotalsautocomputed){
				if($scope.controltotalsautocomputed.resultSet){					
					for(var i = 0; i < $scope.controltotalsautocomputed.resultSet.length; i++){
						if($scope.controltotalsautocomputed.resultSet[i]){
							$scope.controltotalsautocomputed.totalCreditAmount = parseFloat($scope.controltotalsautocomputed.totalCreditAmount) + 
							parseFloat($scope.controltotalsautocomputed.resultSet[i].creditAmount.replace(/,/g,''));
						}
					}
				}
			}
			
			$scope.data.creditTotal = parseFloat($scope.data.creditTotal)+parseFloat($scope.data.controlTotals.totalCreditAmount)+
						parseFloat($scope.data.otherAdjustments.totalCreditAmount.toString().replace(/,/g,''))+
						parseFloat($scope.controltotalsautocomputed.totalCreditAmount);
			
			return $scope.roundNumber($scope.data.creditTotal, 2);
		};
		
		$scope.computeTotal = function(){
			var debitTotalAmount = $scope.data.debitTotal;
			var creditTotalAmount = $scope.data.creditTotal;
			
			return $scope.roundNumber(debitTotalAmount - creditTotalAmount, 2);
		}
		
		/**
		 * 
		 */
		$scope.doShowOtherAdjustmentsForm = function(){			
			if(!$scope.data.bookCodeID || !$scope.data.currencyID){
				alertify.alert("Select a Book Code/Currency first in order to proceed");
				return false;
			}
			
			var modalInstance = $uibModal.open({
				animation: true,
				backdrop: 'static',
				templateUrl: 'app/components/forms/otheradjustmentsform/otherAdjustmentsForm.html',
				controller: 'otherAdjustmentsFormController',
				size: 'lg',
				resolve:{
					load: ['$q', function($q){
						var defered = $q.defer();
						require(['app/components/forms/otheradjustmentsform/otherAdjustmentsFormController'], function(){
							defered.resolve();
						});
						return defered.promise;
					}],
					data : function(){
						var data = {}; 
						data.controlTotalsID = $scope.data.controlTotalsID;
						data.batchSheetID = $scope.data.batchSheetID;
						return data;
					}
				}
			});
			modalInstance.result.then(function(otherAdjustmentsData){
				$scope.data.otherAdjustments = otherAdjustmentsData;
				$scope.data.otherAdjustments.totalDebitAmount = otherAdjustmentsData.totalDebitAmount;
				$scope.data.otherAdjustments.totalCreditAmount = otherAdjustmentsData.totalCreditAmount;
			}, 
			function() {});
			
			return modalInstance.result;
		};
		
		/**
		 * 
		 */
		$scope.close = function() {
			alertify.confirm("This action cancels any changes or updates in this control totals. " +
					"Are you sure you want to proceed?", function(e){
					if(e){
						$uibModalInstance.dismiss();
					}else{
						return;
					}
				});
		};
		
		/**
		 * 
		 */
		$scope.roundNumber = function(num, scale) {
			if(!("" + num).includes("e")) {
				return +(Math.round(num + "e+" + scale)  + "e-" + scale);
			} else {
				var arr = ("" + num).split("e");
				var sig = ""
				if(+arr[1] + scale > 0) {
					sig = "+";
				}
				return +(Math.round(+arr[0] + "e" + sig + (+arr[1] + scale)) + "e-" + scale);
			}
		}
		
		/**
		 * 
		 */
		String.prototype.includes = function (str) {
			
			var returnValue = false;

			if (this.indexOf(str) !== -1) {
				returnValue = true;
			}

			return returnValue;
		}
		
		/**
		 * 
		 */
		$scope.preventPaste = function(e){
			   e.preventDefault();
			   return false;
		};
		
		/**
		 * 
		 */
		$scope.restrictLargeNumericInput = function(amount, $event, idx){
			console.log('idx: ' + idx);
			var isValid = vm.restrictNumericInput(amount, $event, idx);
			console.log('$scope.restrictLargeNumericInput: '+isValid);
			console.log('$event.keyCode: '+$event.keyCode);
			if(isValid === 'invalid'){
				if($event.keyCode === 0) { 
					$event.preventDefault();
					return false;
				}
			}
		}
		
		/**
		 * 
		 */
		vm.restrictNumericInput = function(amount, $event, idx){
			var decimalCount =  vm.countDecimals(amount);
			var integerCount =  vm.countIntegers(amount);
			var totalDigitCount = decimalCount + integerCount;
			var numericType = $scope.select(amount, idx);
			
			console.log('AMOUNT: ' + amount);
			console.log('DECIMAL COUNT: ' + decimalCount);
			console.log('INTEGER COUNT: ' + integerCount);
			console.log('TOTAL COUNT: ' + totalDigitCount);
			
			if(numericType === 'Integer'){
				if(integerCount > 13 || decimalCount > 2){
					return 'invalid';
				}else{
					return 'valid';
				}
			}else if(numericType === 'Decimal'){
				if(decimalCount > 1){
					return 'invalid';
				}else{
					return 'valid';
				}
			}else if(numericType === 'Numeric_Dot'){
				if ((window.event ? $event.keyCode : $event.which !== 46)) {
					console.log('DOT_ONLY & DELETE');
					return 'invalid';
				}else{
					return 'valid';
				}
			}else if(numericType === 'Decimal_Dot'){
				if ((window.event ? $event.keyCode : $event.which !== 8)) {
					console.log('DOT_ONLY & DELETE');
					return 'invalid';
				}else{
					return 'valid';
				}
			}
		};
		
		/**
		 * 
		 */
		$scope.validateNumericInput = function(amount){
			var decimalCount =  vm.countDecimals(amount);
			var integerCount =  vm.countIntegers(amount);
			var totalDigitCount = decimalCount + integerCount;
			
			console.log('AMOUNT: ' + amount);
			console.log('DECIMAL COUNT: ' + decimalCount);
			console.log('INTEGER COUNT: ' + integerCount);
			console.log('TOTAL COUNT: ' + totalDigitCount);
			
			if(totalDigitCount > 16 || integerCount > 14){
				return 'invalid';
			}else{
				return 'valid';
			}
		};
		
		/**
		 * 
		 */
		vm.countDecimals = function (value) {
		    if(Math.floor(value) === value) return 0;
		    if(value.toString().indexOf(".") !== -1){
		    	return value.toString().split(".")[1].length || 0;
		    }else{
		    	return 0;
		    }
		    
		};
		
		/**
		 * 
		 */
		vm.countIntegers = function (value) {
			var valueStr = value.toString();
			
			if(valueStr.indexOf(".") !== -1){
				var valueIndex = valueStr.indexOf('.');
				var valueLatest = valueStr.substring(0, valueIndex);
				return valueLatest.length;
			}else{
				return valueStr.length;
			}
		};
		
		$scope.select = function(value, idx){
			
			var valueStr = value.toString();
			var dotIndex = valueStr.indexOf(".");
			var cursorPosition = $("#"+idx).prop("selectionStart");
			var numericType = ''; 
			
			console.log("DOT POSITION: " + dotIndex);
			console.log("CURSOR POSITION: " + cursorPosition);
			
			var valueofIndex = valueStr.charAt(parseInt(cursorPosition));
			
			console.log(valueofIndex);
			
			if(dotIndex >= 0){
				if(cursorPosition <= dotIndex){
					console.log("Integer");
					numericType = 'Integer';
				}else{
					console.log("Decimal");
					numericType = 'Decimal';
				}
			}else if(dotIndex === -1 && cursorPosition === 14){
				console.log("Numeric_Dot");
				numericType = 'Numeric_Dot';
			}else{
				console.log("Integer");
				numericType = 'Integer';
			}
			
			return numericType;
		};

	}]);
	
});