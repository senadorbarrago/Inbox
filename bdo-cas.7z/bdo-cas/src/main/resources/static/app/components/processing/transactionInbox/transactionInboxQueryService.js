'use strict';

define(function(){
	angular.module("core").provider('TransactionInboxQueryService', function(){
		this.$get =['$http', 'DataAccessService', function($http, dataAccessService){
			var service = {
				getTransactionInboxList: function(dataSetCode, pageIndex, pageSize, searchCriteria, successCallBack, errorCallBack) {
					var url  = 'transactions/inbox/'+dataSetCode+'/'+pageIndex+'/'+pageSize+'/';
					dataAccessService.doPostData(url, searchCriteria, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getColumnList: function(dataSetID, recordProfileID, successCallBack, errorCallBack) {
					var url  = 'transactions/columns/'+dataSetID+'/'+recordProfileID;
					dataAccessService.doGetData(url, null, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				doUndoCleanUp: function(transactionIds) {
					var url  = 'transactions/inbox/undoCleanUp';
					return $http.post(url, transactionIds);
				},
				generateReport: function(dataSetCode, pageIndex, pageSize, searchCriteria, successCallBack, errorCallBack) {
					var reportCode = "TransactionInbox_csv";
					var url  = 'transactions/inbox/generate/'+reportCode+"/"+dataSetCode+'/'+pageIndex+'/'+pageSize+'/';
					dataAccessService.doPostData(url, searchCriteria, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				}
			}
			return service;
		}]
	});	
});