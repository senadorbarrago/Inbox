'use strict';

define(function(){
	
	console.log('advanceSearchResultController.js loaded');
	var core = angular.module('core');
	
	core.registerController('advanceSearchResultController',['$rootScope', '$scope', '$uibModalInstance', 'ngTableParams', 'DataAccessService', 'data',
			function($rootScope, $scope, $uibModalInstance,ngTableParams,  dataAccessService, data){
		$scope.title = 'Advance Search Result';
		$scope.init = 0;
		$scope.columns = [];
		var vm = this;
		
		function loadPage() {
			console.log('Pagination');
				$scope.tableParams = new ngTableParams(
						{
							page: 1,
							count: 25
						},
						{getData: function ($defer, params) {
								var url = 'advancesearch/result';
								$scope.data.pageIndex = params.page();
								$scope.data.pageSize = params.count();
								
								console.log(params);
								console.log(params.page());
								console.log(params.count());
								
								return dataAccessService.doPostData(url, $scope.data, function(response){
									console.log(response);
									$scope.form = response.data;
									params.total($scope.form.resultOverAllCount);
									
									$defer.resolve($scope.form.resultSet);
								},function(errorResponse){
									console.log(errorResponse);
								});
							}
				});
		}
		vm.init = function(){
			console.log(data);
			loadPage();
			$scope.data = data; 
			$scope.data.dataSetID = $rootScope.dataSetID;
			//$scope.tableParams.reload();
		}
		
		vm.doSearch = function($defer){
			
			console.log($scope.data);
			
			var url  = 'advancesearch/result';
			dataAccessService.doPostData(url, $scope.data, function(response){
				console.log(response);
				$scope.form = response.data;
				console.log($scope.form.columns);
				$scope.columns = [];
				$scope.columns = $scope.form.columns;
			},function(errorResponse){
				console.log(errorResponse);
			});
		}
		
		// Initialize
		vm.init();
		
		$scope.doGenerateReport = function(){
			console.log("doGenerateReport()");
			// URL
			var reportDescription = $scope.reportDescription;
			var reportUrl = 'advancesearch/generate/AdvanceSearch_csv';
			var downloadUrl = 'advancesearch/download/AdvanceSearch_csv';
			
			$scope.requestStatus = $scope.reportDescription + ' generation ongoing...';
	
			dataAccessService.doPostData(reportUrl, $scope.data, function(response){
				console.log(response);
				$scope.resultMessage = response.data;
				$scope.message = $scope.resultMessage.messageMap;
				
				if($scope.message.successMsg!=undefined && $scope.message.successMsg!=null){
					alertify.alert($scope.message.successMsg);
					$scope.requestStatus = $scope.reportDescription + ' generation successful!';						
//					alertify.confirm('Report successfully generated. Do you want to download report?', function(e) {
//						if (e) {
//							window.location.href=downloadUrl+'?file=' + $scope.message.filename;
//						}else{
//							return;
//						}
//					});
				}else if($scope.message.errorMsg!=undefined && $scope.message.errorMsg!=null){
					alertify.alert($scope.message.errorMsg);
					$scope.requestStatus = $scope.reportDescription + ' generation failed!';
				}
				
			},function(errorResponse){
				console.log(errorResponse);
				alertify.alert('Error Occurred.');
				$scope.requestStatus = $scope.reportDescription + ' generation failed!';
			});
			
		};
		
		$scope.close = function() {
			$uibModalInstance.dismiss();
		};
		
	}]);
});