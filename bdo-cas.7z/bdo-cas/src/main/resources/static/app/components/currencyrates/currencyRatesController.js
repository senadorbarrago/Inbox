'use strict';

define(function(){
	
	console.log('currencyRatesController.js loaded');
	var core = angular.module('core');
	
	core.registerController('currencyRatesController', function($rootScope, $scope){
		$scope.title = 'This is the Currency Rates Screen';
		$rootScope.screenName = 'CURRENCY_RATES_MAINTENANCE';
	});
	
});