'use strict';

define(function(){
	angular.module("core").provider('StatusQueryService', function(){
		this.$get =['$http', '$rootScope', 'DataAccessService', function($http, $rootScope, dataAccessService){
			var service = {
				getGroupUsers: function(dataSetID, successCallBack, errorCallBack){
					var url = 'references/groupUsers/'+dataSetID;
					dataAccessService.doGetData(url, null, function(response){
						console.log(response.data);
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getProcessors: function(successCallBack, errorCallBack) {
					var data  = {
							     	'username' : $rootScope.session['AUTHENTICATED_USER'].username,
							     	'roleCode' : $rootScope.session['AUTHENTICATED_USER'].activeMembership.role.code,
							     	'groupCode' : $rootScope.session['AUTHENTICATED_USER'].activeMembership.group.code,
								}; 
					dataAccessService.doQuery('ProcessorListQueryModel', data, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getUserProcessInfo: function(dataSetCode, successCallBack, errorCallBack){
					var url = 'references/userProcessInfo/'+dataSetCode;
					dataAccessService.doGetData(url, null, function(response){
						console.log(response.data);
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				}, 
				getUserCode: function(dataSetCode, successCallBack, errorCallBack){
					var url = 'references/userCode/'+dataSetCode;
					dataAccessService.doGetData(url, null, function(response){
						console.log(response.data);
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				}
			}
			return service;
		}]
	});	
});