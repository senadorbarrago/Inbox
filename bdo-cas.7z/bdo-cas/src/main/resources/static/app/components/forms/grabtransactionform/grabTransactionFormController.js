'use strict';

define(function(){
	console.log('forReferralForm.js loaded');
	var core = angular.module('core');
	
	core.registerController('grabTransactionFormController', [
		'$rootScope', 
		'$scope', 
		'$uibModalInstance', 
		'DataAccessService', 
		'data',
		function($rootScope, $scope, $uibModalInstance, dataAccessService, data){
			$scope.title = 'Grab Transaction Form';
			var vm = this;
		
			vm.init = function(){
				$scope.form = {};
				$scope.form.recordList = data.selectedItems; 
			}

			// Tag selected transactions for referral
			$scope.doGrabTransactions = function(){
				alertify.confirm("This action grabs the selected transactions and will be transferred in your designated transaction inbox for processing. " +
					"Are you sure you want to proceed?", function(e){
					if(e){
						var url = 'transactions/forReferral/grabtransaction';

						var data = {};
							data.recordList = [];
							data.referralID = 0;
							data.sectionID = 0;
							data.recordList = $scope.form.recordList;
							
						console.log(data);
					
						dataAccessService.doPostData(url, data, function(response){
							console.log(response);
							$uibModalInstance.close(response.data.messageMap.resultMsg);
						},function(errorResponse){
							console.log(errorResponse);
							alertify.fail(errorResponse.data.errorMsg);
						});
						
					}else{
						return false;
					}
				});
			}
			
			// Close Tag for Referral Form
			$scope.close = function() {
				$uibModalInstance.dismiss();
			};
			
			// Initialize form
			vm.init();
			
	}]);
});