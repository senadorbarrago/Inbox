'use strict'

define(function(){
	return [
	        'app/shared/services/dataAccessService',
	        'app/components/forms/transactionform/transactionFormCommandService',
	        'app/components/forms/transactionform/transactionFormQueryService',
	        'app/components/forms/journalentryform/journalEntryFormCommandService',
	        'app/components/forms/journalentryform/journalEntryFormQueryService',
	        'app/components/processing/journalEntries/journalEntriesActionableQueryService',
	        'app/components/processing/journalEntries/journalEntriesActionableCommandService',
	        'app/components/processing/batchSheets/batchSheetsQueryService',
	        'app/components/processing/batchSheets/batchSheetsCommandService',
	        'app/components/processing/transactionInbox/transactionInboxQueryService',
	        'app/components/processing/myTransactions/myTransactionsQueryService',
	        'app/components/processing/myTransactions/myTransactionsCommandService',
	        'app/components/forReferral/forReferralQueryService',
	        'app/components/reports/reportFormQueryService',
	        'app/components/forms/refertransactionform/refertransactionFormQueryService',
	        'app/components/inventory/inventoryQueryService',
	        'app/components/forms/remarks/remarksFormQueryService',
	        'app/components/outbound/generateOutbound/generateOutboundQueryService',
	        'app/components/processing/status/statusCommandService',
	        'app/components/processing/status/statusQueryService',
	        ]
});