'use strict';

define(function(){
	angular.module("journalEntryFormModule").provider('JournalEntryFormCommandService', function(){
		this.$get =['DataAccessService', function(dataAccessService){
			var service = {
				submitForm: function(dataSetID, form, successCallBack, errorCallBack) {
					var url  = 'journalentry/form/save';
					dataAccessService.doPostData(url, form, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				updateForm: function(form, successCallBack, errorCallBack) {
					var url  = 'journalentry/form/update';
					console.log('updateForm()');
					console.log(form);
					dataAccessService.doPutData(url, form, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				}
			}
			return service;
		}]
	});	
});