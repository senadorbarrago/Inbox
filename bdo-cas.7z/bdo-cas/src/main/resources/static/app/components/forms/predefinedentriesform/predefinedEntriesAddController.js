'use strict';

define(function(){
	var core = angular.module('core');
	
	core.registerController('predefinedEntriesAddController',['$rootScope', '$scope', '$uibModalInstance', '$uibModal', 'data', 'DataAccessService', '$filter',
	                                                     function($rootScope, $scope, $uibModalInstance, $uibModal, data, dataAccessService, $filter){
	    $scope.title = 'Predefined Entries Add Form';
		
		var vm = this;

		vm.init = function(){
			console.log(data);
			console.log('HEY');
			
			$scope.form = {};
			$scope.data = {};
			
			$scope.data.pdeActionTag = "ADD";
			$scope.data.predefinedEntryID = 0;
			$scope.data.dataSetID = $rootScope.dataSetID;
			$scope.data.dataSetCode = $rootScope.dataSetCode;
			$scope.data.recordProfileID = 0;
			$scope.data.dataFieldColumnID = 0;
			
			vm.getBookCodeByDataSetCode();
			vm.getPDEType();
		}
		
		//Get bookCode
		vm.getBookCodeByDataSetCode = function(){
			var url = 'references/bookCodeByDataSet/'+$rootScope.dataSetCode;
			dataAccessService.doGetData(url, null, function(response){
				console.log(response.data);
				$scope.bookCodes = response.data;
			},function(errorResponse){
				errorCallBack(errorResponse);
			});
		};
		
		//Get currencies
		vm.getCurrenciesByDataSetCode = function(){
			var url = 'references/currencyByDataSetCode/'+$rootScope.dataSetCode;
			dataAccessService.doGetData(url, null, function(response){
				console.log(response.data);
				$scope.currencies = response.data;
			},function(errorResponse){
				errorCallBack(errorResponse);
			});
		};
		
		//Get PDE Types
		vm.getPDEType = function(){
			
			var url = 'references/pdeTypeByDataSetCode/'+$rootScope.dataSetCode;
			dataAccessService.doGetData(url, null, function(response){
				console.log(response.data);
				$scope.pdeTypes = response.data;
			},function(errorResponse){
				errorCallBack(errorResponse);
			});
		};
		
		vm.init();
		
		$scope.getCurrencies = function(){
			
			var url = 'references/currencyByBookCodeID/'+$scope.book.id;
			dataAccessService.doGetData(url, null, function(response){
				console.log(response.data);
				$scope.currencies = response.data;
			},function(errorResponse){
				errorCallBack(errorResponse);
			});
		};
		
		$scope.addPDED = function(){
			
			console.log("Add Predefined Entries Definition.");
			$scope.data.pdeActionTag = "ADD";
			$scope.setAttribute($scope.data.pdeActionTag)
			
			console.log($scope.data);
		};
		
		$scope.editPDED = function(){
			
			console.log("Edit Predefined Entries Definition.");
			$scope.data.pdeActionTag = "UPDATE";
			
			if(!$scope.selectedRecord){
				alertify.alert("Please select an item first in order to proceed with this action.");
				return false;
			}else {
				console.log("OK");
				$scope.setAttribute($scope.data.pdeActionTag)

				console.log($scope.data);
			}
			
		};
		
		//Save
		$scope.save = function(){
			
			$scope.data.bookCode = $scope.book.code;
			$scope.data.currencyCode = $scope.currency.code;
			$scope.data.pdeType = $scope.pdeType.code;
			
			console.log("Save Predefined Entry.");
			console.log("pdeActionTag: " + $scope.data.pdeActionTag);
			console.log($scope.data);
			
			var savePredefinedEntriesDefinitionUrl = 'transactions/predefinedEntries/setup';
			alertify.confirm("Do you really want to save this predefined entry?", function(e){
					
				if(e){
					dataAccessService.doPostData(savePredefinedEntriesDefinitionUrl, $scope.data, function(response){
						console.log(response);
						alertify.alert(response.data.messageMap.successMsg);
						$uibModalInstance.dismiss();
					},function(errorResponse){
						console.log(errorResponse);
						alertify.fail(errorResponse.data.errorMsg);
					});
				}else{
					return;
				}
				
			});
		};
		
		$scope.cancel = function() {
			alertify.confirm("This action cancels any changes or updates in this predefined entry. " +
					"Are you sure you want to proceed?", function(e){
					if(e){
						$uibModalInstance.dismiss();
					}else{
						return;
					}
				});
		};
		
	}]);
	
});