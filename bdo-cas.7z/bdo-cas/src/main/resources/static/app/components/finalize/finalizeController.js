'use strict';

define(function(){
	
	console.log('finalizeController.js loaded');
	var core = angular.module('core');
	
	core.registerController('finalizeController',['$rootScope', '$scope', '$cookies', 'DataAccessService', 
			function($rootScope, $scope, $cookies, dataAccessService){
		$scope.title = 'This is the Finalize Screen';
		$rootScope.screenName = 'FINALIZE/UNDO FINALIZE';
		
		var vm = this;
		
		vm.init = function(){
			$scope.data = {};
			$scope.data.dataSetID = $rootScope.dataSetID;
			$scope.data.costCenterID = $rootScope.costCenterID;
			
			$scope.data.dataSetCode = $rootScope.dataSetCode;
			$scope.data.encodingUnitCode = $rootScope.encodingUnitCode;
			
			vm.getCurrentProcessingDate();
			vm.initProcessInfo();
		}
		
		$scope.saveFinalize = function(){
			var saveFinalizeUrl = "transactions/finalize/save";
			
			alertify.confirm("Do you really want to Finalize?", function(e){
				
				if(e){
					dataAccessService.doPostData(saveFinalizeUrl, $scope.data, function(response){
						console.log(response);
						alertify.alert(response.data.messageMap.successMsg);
						vm.init();
					},function(errorResponse){
						console.log(errorResponse);
						alertify.fail(errorResponse.data.errorMsg);
					});
				}else{
					return;
				}
			});
		}
		
		$scope.saveUndoFinalize = function(){
			var saveUndoFinalizeUrl = "transactions/undofinalize/save";			
			
			alertify.confirm("Do you really want to Undo Finalize?", function(e){
				
				if(e){
					dataAccessService.doPostData(saveUndoFinalizeUrl, $scope.data, function(response){
						console.log(response);
						alertify.alert(response.data.messageMap.successMsg);
						vm.init();
					},function(errorResponse){
						console.log(errorResponse);
						alertify.fail(errorResponse.data.errorMsg);
					});
				}else{
					return;
				}
			});
		}
		
		vm.getCurrentProcessingDate = function(){
			var getCurrentProcessingDateUrl = "transactions/finalize/currentProcessingDate/"+$scope.data.dataSetID+"/"+$scope.data.costCenterID;			
					dataAccessService.doGetData(getCurrentProcessingDateUrl, null, function(response){
						console.log(response);
						$scope.data.currentProcessingDate = response.data.currentProcessingDate;
					},function(errorResponse){
						console.log(errorResponse);
					});
		}
		
		vm.initProcessInfo = function(){
			var url = 'references/processingInfo/'+$rootScope.dataSetCode+'/'+$rootScope.encodingUnitCode;
			dataAccessService.doGetData(url, null, function(response){
				console.log(response.data);
				$rootScope.session["PROCESSINFO"] = response.data.resultSet[0];
				
				$cookies.put("processDate", $rootScope.session["PROCESSINFO"].processDate);
				$cookies.put("processCode", $rootScope.session["PROCESSINFO"].processCode);
				$cookies.put("processDescription", $rootScope.session["PROCESSINFO"].processDescription);
			}, function(errorResponse){
				console.log(errorResponse.status+': '+errorResponse.headers("ERROR_MESSAGE"));
				//alertify.fail(errorResponse.status+': '+errorResponse.headers("ERROR_MESSAGE"));
			});
		}
		
		// Initialize
		vm.init();
		
	}]);
	
});