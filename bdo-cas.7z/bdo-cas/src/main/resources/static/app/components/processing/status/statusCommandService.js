'use strict';

define(function(){
	angular.module("core").provider('StatusCommandService', function(){
		this.$get =['DataAccessService', function(dataAccessService){
			var service = {
				reassignTransation: function(data, successCallBack, errorCallBack) {
					var url  = 'transactions/status/reassignTransaction';
					dataAccessService.doPostData(url, data, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				printReport: function(data, reportName, userName, successCallBack, errorCallBack) {
					var url  = 'transactions/status/'+reportName+'/'+userName;
					dataAccessService.doPostData(url, data, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				}
			}
			return service;
		}]
	});	
});