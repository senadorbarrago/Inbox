'use strict';

define(function(){
	
	console.log('refertransactionFormController.js loaded');
	var core = angular.module('core');
	
	core.registerController('refertransactionFormController',[
		'$rootScope', 
		'$scope', 
		'$uibModalInstance', 
		'ReferTransactionFormQueryService', 
		'data', 
		'DataAccessService', 
		'$filter', 
	    function($rootScope, $scope, $uibModalInstance, referTransactionFormQueryService, data, dataAccessService, $filter){
			$scope.title = 'Refer Transaction Form';
			
			var vm = this;
			var encodingUnitID = $rootScope.costCenterID;
			console.log("Encoding: " + encodingUnitID);
			
			vm.init = function(){
				console.log(data.selectedRecordList);
				$scope.dataSetID = $rootScope.dataSetID;
				
				$scope.form =  {};
				$scope.form.recordList = data.selectedRecordList;
				$scope.references = {};
				
				vm.initDatePicker();
				vm.getGroupReferences();
				vm.getNCTypeReferences();
				vm.initializeReferralDetails();
		};
		
		// DatePicker SetUp
		vm.initDatePicker = function(){
			$scope.datePicker = { };
			$scope.dateOptions = {
					startingDay : 1,
					showWeeks : false,	
					format : "yyyy-MM-dd"
				};
			$scope.dateFormat = "yyyy-MM-dd";
		}
		
		// getGroupReferences
		vm.getGroupReferences = function(){
			referTransactionFormQueryService.getGroupReferences($scope.dataSetID, function(response){
				$scope.references.groupList = response.data;			
			}, function(errorResponse){
				console.log(errorResponse);
			});
		}
		// getNCTypeReferences
		vm.getNCTypeReferences = function(){
			referTransactionFormQueryService.getNCTypeReferences($scope.dataSetID, function(response){
				$scope.references.ncTypeList = response.data;
				console.log($scope.references.ncTypeList);
			}, function(errorResponse){
				console.log(errorResponse);
			});
		}
		
		// View Referral Details
		vm.viewReferralDetails = function(transactionID){
			referTransactionFormQueryService.viewReferralDetails($rootScope.dataSetCode, transactionID, function(response){
				if(response.data.resultOverAllCount > 0){
					$scope.form = response.data.resultSet[0];
					$scope.form.recordList = data.selectedRecordList;
					$scope.form.referDateToBranch = new Date(response.data.resultSet[0].dateReferToBranch);
					$scope.form.referDateToSection = new Date(response.data.resultSet[0].dateReferToSection);
				}
			}, function(error){
				console.log(error);
			});
		}
		
		// initializeReferralDetails
		vm.initializeReferralDetails = function(){
			if(data.selectedRecordList.length === 1){
				vm.viewReferralDetails(data.selectedRecordList[0].TransactionID);
			}
		};
		
		// Initialize
		vm.init();
		
		// viewReferralDetails
		$scope.viewReferralDetails = function(transactionID){
			vm.viewReferralDetails(transactionID);
		}
		
		// Tag selected transactions for referral
		$scope.updateReferral = function(){
			console.log("updateReferral()");
			
			var updateReferralURL = "transactions/forReferral/update";
			$scope.form.recordList = data.selectedRecordList;
			console.log($scope.form);
			
			alertify.confirm("This action updates referral details. " +
					"Are you sure you want to proceed?", function(e){
				if(e){
					dataAccessService.doPostData(updateReferralURL, $scope.form, function(response){
						console.log(response);
						$uibModalInstance.close(response.data.messageMap.resultMsg);
					});
				}else{
					return false;
				}
			});
		};
	
		// refers the selected transaction/s
		$scope.referTransaction = function(){
			console.log("referTransaction()");
			if(!$scope.form.sectionID || $scope.form.sectionID === 0){
				alertify.alert("Select the designated section to refer to!");
				return false;
			}

			var updateReferralURL = "transactions/forReferral/refer";
			$scope.form.recordList = data.selectedRecordList;
			console.log($scope.form);
			
			alertify.confirm("This action transfers the selected transactions. " +
					"Are you sure you want to proceed?", function(e){
				if(e){
					dataAccessService.doPostData(updateReferralURL, $scope.form, function(response){
						console.log(response);
						$uibModalInstance.close(response.data.messageMap.resultMsg);
					});
				}else{
					return false;
				}
			});
		};
		
		// Open Calendar
		$scope.open = function(columnName, $event) {
			$event.preventDefault();
			$event.stopPropagation();
			
			if ($scope.datePicker[columnName]) {
				if ($scope.datePicker[columnName].opened) {
					$scope.datePicker[columnName].opened = false;
				}
			} else {
				$scope.datePicker = {};
				$scope.datePicker[columnName] = {};
				$scope.datePicker[columnName].opened = true;
			}
		}
		
		// Close this modal
		$scope.close = function(){
			$uibModalInstance.dismiss();
		};
	
	}]);
	
});