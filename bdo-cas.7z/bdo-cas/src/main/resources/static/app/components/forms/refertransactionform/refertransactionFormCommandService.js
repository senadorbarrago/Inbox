'use strict';

define(function(){
	angular.module("core").provider('ReferTransactionFormCommandService', function(){
		this.$get =['DataAccessService', function(dataAccessService){
			var service = {
					referTransaction: function(transactionID, successCallBack, errorCallBack) {
						var url  = 'transactions/forReferral/refertransaction/'+transactionID;
						dataAccessService.doPutData(url, null, function(response){
							successCallBack(response);
						},function(errorResponse){
							errorCallBack(errorResponse);
						});
					},
					updateReferral: function(transactionID, successCallBack, errorCallBack) {
						var url  = 'transactions/forReferral/updatereferral/'+transactionID;
						dataAccessService.doPutData(url, null, function(response){
							successCallBack(response);
						},function(errorResponse){
							errorCallBack(errorResponse);
						});
					}
				
			}
			return service;
		}]
	});	
});