'use strict';

define(function(){
	
	console.log('beginOfDayController.js loaded');
	var core = angular.module('core');
	
	core.registerController('beginOfDayController',['$rootScope', '$scope', 'DataAccessService', 'ReportFormQueryService', '$filter', function($rootScope, $scope, dataAccessService, reportFormQueryService, $filter){
		$scope.title = 'This is the Begin of Day Screen';
		$rootScope.screenName = 'BEGIN/END_OF_DAY';
		
		var vm = this;
		
		vm.init = function(){
			$scope.data = {};
			$scope.data.costCenterID = $rootScope.costCenterID;
			$scope.data.dataSetID = $rootScope.dataSetID;
			$scope.data.dataSetCode = $rootScope.dataSetCode;
			$scope.userCode = { "userCode " : [] };
			
			vm.getCurrentGLDate();
			vm.getCurrentProcessingDate();
			vm.getPreviousProcessingDate();
			vm.getBeginOfDayProcessID();
			vm.getEncodingUnit();
			vm.getUserCode();
		}
		
		$scope.saveBeginOfDay = function(){
			
			alertify.confirm("Do you really want to set Begin of Day?", function(e){
				
				if(e){
					$scope.requestStatus = "Setting Begin of Day...";
					var saveBeginOfDayUrl = "transactions/beginOfDay/save";			

					dataAccessService.doPostData(saveBeginOfDayUrl, $scope.data, function(response){
						console.log(response);
						$scope.requestStatus = "Success!";
						alertify.alert(response.data.messageMap.successMsg);
						vm.init();
					},function(errorResponse){
						console.log(errorResponse);
						alertify.fail(errorResponse.data.errorMsg);
						$scope.requestStatus = "Failed!";
					});
				}else{
					return;
				}
			});
		}
		
		$scope.saveEndOfDay = function(){
			
			$scope.form = {};
			$scope.reportParams = {};
			$scope.reportParams.userName = $rootScope.session.AUTHENTICATED_USER.username;
			$scope.reportParams.userID = $scope.userCode[0].code;
			$scope.reportParams.dataset = $rootScope.dataSetID;
			$scope.reportParams.dateFrom = $scope.data.previousProcessingDate;
			$scope.reportParams.dateTo = $scope.data.previousProcessingDate;
			$scope.reportParams.effDate = $scope.data.previousProcessingDate;
			$scope.reportParams.effDateFrom = "";
			$scope.reportParams.effDateTo = "";
			$scope.reportParams.dateOfTakeUpFrom = $scope.data.previousProcessingDate;
			$scope.reportParams.dateOfTakeUpTo = $scope.data.previousProcessingDate;
			$scope.reportParams.processingDate = $scope.data.previousProcessingDate;
			$scope.reportParams.systemDate = $filter('date')(new Date(), 'yyyyMMddhhmmssS');
			$scope.reportParams.encodingUnit = $scope.data.encodingUnit;
			$scope.reportParams.usersEncodingUnit = $scope.data.encodingUnit;
			$scope.reportParams.dateGenerated = $filter('date')($scope.data.previousProcessingDate, 'yyyyMMdd');
			$scope.reportParams.tagType = "";
			$scope.reportParams.criteria = 2;
			$scope.reportParams.currencyCode = "";
			
			$scope.reportParams.param1 = $scope.reportParams.processingDate;
			$scope.reportParams.param2 = $scope.reportParams.encodingUnit;
			
			$scope.form.costCenterID = $scope.data.costCenterID;
			$scope.form.currentGlDate = $scope.data.currentGlDate;
			$scope.form.currentProcessingDate = $scope.data.currentProcessingDate;
			$scope.form.dataSetID = $scope.data.dataSetID;
			$scope.form.dataSetCode = $scope.data.dataSetCode;
			$scope.form.encodingUnit = $scope.data.encodingUnit;
			$scope.form.previousProcessingDate = $scope.data.previousProcessingDate;
			$scope.form.processID = $scope.data.processID
			$scope.form.reportParams = $scope.reportParams;
			
			console.log($scope.form);
			
			var saveEndOfDayUrl = "transactions/endOfDay/save";	
			var getProcessIDUrl = "transactions/endOfDay/processID/"+$scope.data.dataSetID;			
			
			console.log("EncodingUnit: " + $scope.data.encodingUnit);
			
			alertify.confirm("Do you really want to set End of Day?", function(e){
				
				if(e){
					$scope.requestStatus = "Setting End of Day and Generating Reports...";
					dataAccessService.doGetData(getProcessIDUrl, null, function(response){

						console.log(response);
						
						$scope.data.processID = response.data.processID;
						dataAccessService.doPostData(saveEndOfDayUrl, $scope.form, function(response){
							
							$scope.message = response.data.messageMap;
							
							if($scope.message.successMsg!=undefined && $scope.message.successMsg!=null){
								alertify.alert($scope.message.successMsg);
								$scope.requestStatus = 'Success!';
							}else
							if($scope.message.errorMsg!=undefined && $scope.message.errorMsg!=null){
								alertify.alert($scope.message.errorMsg);
								$scope.requestStatus = "Success!";
							}
							
//							console.log(response);
//							$scope.requestStatus = "Success!";
//							alertify.alert(response.data.messageMap.successMsg);
							vm.init();
						},function(errorResponse){
							console.log(errorResponse);
							alertify.fail(errorResponse.data.errorMsg);
							$scope.requestStatus = "Failed!";
						});


						
					},function(errorResponse){
						console.log(errorResponse);
						$scope.requestStatus = "Failed!";
					});
				}else{
					return;
				}
				
			});
		}
		
		vm.getCurrentGLDate = function(){
			var getCurrentGLDateUrl = "transactions/beginOfDay/currentGlDate/"+$scope.data.dataSetID;			
			dataAccessService.doGetData(getCurrentGLDateUrl, null, function(response){
				console.log(response);
				$scope.data.currentGlDate = response.data.currentGlDate;
			},function(errorResponse){
				console.log(errorResponse);
			});
		}
		
		vm.getCurrentProcessingDate = function(){
			var getCurrentProcessingDateUrl = "transactions/beginOfDay/currentProcessingDate/"+$scope.data.dataSetID+"/"+$scope.data.costCenterID;			
			dataAccessService.doGetData(getCurrentProcessingDateUrl, null, function(response){
				console.log(response);
				$scope.data.currentProcessingDate = response.data.currentProcessingDate;
			},function(errorResponse){
				console.log(errorResponse);
			});
		}
		
		vm.getPreviousProcessingDate = function(){
			var getPreviousProcessingDateUrl = "transactions/beginOfDay/previousProcessingDate/"+$scope.data.dataSetID+"/"+$scope.data.costCenterID;			
			dataAccessService.doGetData(getPreviousProcessingDateUrl, null, function(response){
				console.log(response);
				$scope.data.previousProcessingDate = response.data.previousProcessingDate;
			},function(errorResponse){
				console.log(errorResponse);
			});
		}
		
		vm.getBeginOfDayProcessID = function(){
			var getProcessIDUrl = "transactions/beginOfDay/processID/"+$scope.data.dataSetID;			
			dataAccessService.doGetData(getProcessIDUrl, null, function(response){
				console.log(response);
				$scope.data.processID = response.data.processID;
			},function(errorResponse){
				console.log(errorResponse);
			});
		}
		
		vm.getEndOfDayProcessID = function(){
			var getProcessIDUrl = "transactions/endOfDay/processID/"+$scope.data.dataSetID;			
			dataAccessService.doGetData(getProcessIDUrl, null, function(response){
				console.log(response);
				$scope.data.processID = response.data.processID;
			},function(errorResponse){
				console.log(errorResponse);
			});
		}
		
		vm.getEncodingUnit = function(){
			var getEncodingUnitUrl = "transactions/endOfDay/encodingUnit/"+$scope.data.costCenterID;			
			dataAccessService.doGetData(getEncodingUnitUrl, null, function(response){
				console.log(response);
				$scope.data.encodingUnit = response.data.encodingUnit;
			},function(errorResponse){
				console.log(errorResponse);
			});
		}
		
		vm.getUserCode = function(){
			reportFormQueryService.getUserCode($rootScope.dataSetCode, function(response){
				console.log('getUserCode');
				console.log(response.data);
				$scope.userCode = response.data;
				
			},function(error){
				console.log(error);
			});
		}
		vm.init();
		
	}]);
	
});