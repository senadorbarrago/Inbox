'use strict';

define(function(){
	console.log('$uibModal.js loaded');
	var core = angular.module('core');
	
	core.registerController('controlTotalsController', [ '$rootScope', '$scope', '$uibModal', 'DataAccessService', 'ngTableParams', 
		function($rootScope, $scope, $uibModal, dataAccessService, ngTableParams){
		
		$rootScope.screenName = 'PROCESSING --> Control Totals';
		var vm = this;
		
		function loadPage() {
			$scope.tableParams = new ngTableParams({
						page: 1,
						count: 25
					},
					{	getData: function ($defer, params) {
						$scope.data.dataSetCode = $rootScope.dataSetCode;
						$scope.data.encodingUnitCode = $rootScope.encodingUnitCode;
						if(!$scope.data.selectedUser){
							$scope.data.selectedUser = '';
						}
						$scope.data.pageIndex = params.page();
						$scope.data.pageSize = params.count();
						
						var url  = 'controlTotals/actionable';
						console.log('DATA:');
						console.log($scope.data);
						return dataAccessService.doPostData(url, $scope.data, function(response){
							console.log(response);
							$scope.form = response.data;
							$scope.rows = response.resultSet;
							$scope.columns = $scope.columns;
							params.total($scope.form.resultOverAllCount);
							console.log("params.total: " + $scope.form.resultOverAllCount);
							$defer.resolve($scope.rows);
						},function(errorResponse){
							console.log(errorResponse);
						});
					}
				}
			
			);
		};
		
		vm.init = function(){
			$scope.reference = {};
			$scope.data = {};
			$scope.data.dataSetCode = $rootScope.dataSetCode;
			$scope.data.encodingUnitCode = $rootScope.encodingUnitCode;
			console.log($scope.data);
			vm.getProcessorList();
			loadPage();
		}
		
		vm.getProcessorList = function(){
			console.log('vm.getProcessorList');
			var data  = {
			     	'username' : $rootScope.session['AUTHENTICATED_USER'].username,
			     	'roleCode' : $rootScope.session['AUTHENTICATED_USER'].activeMembership.role.code,
			     	'groupCode' : $rootScope.session['AUTHENTICATED_USER'].activeMembership.group.code,
				}; 
			
			console.log(data);
			dataAccessService.doQuery('ProcessorListQueryModel', data, function(response){
				$scope.reference.processorList = response.data.resultSet;
				console.log($scope.reference.processorList);
				
				if($scope.reference.processorList && $scope.reference.processorList.length === 1){
					$scope.data.selectedUser = $scope.reference.processorList[0].code;
				}
				
			},function(errorResponse){
				console.log(errorResponse);
			});
		}
		vm.init();
		
		$scope.data = {};
		
		$scope.selectAll = function(){
			var toggleStatus = $scope.form.isAllSelected;
			console.log(toggleStatus);
			angular.forEach($scope.form.resultSet, function(record){
				record.selected = toggleStatus;
			});
			
		}
		
		$scope.doChangeSelection = function(record){
			record.selected = !record.selected;
			if(!record.selected){
				$scope.form.isAllSelected = false;
			}
		}
		
		$scope.doShowControlTotalsForm = function(controlTotalsID){
			var modalInstance = $uibModal.open({
				animation: true,
				backdrop: 'static',
				templateUrl: 'app/components/forms/controltotals/controlTotalsForm.html',
				controller: 'controlTotalsFormController',
				size: 'md',
				resolve:{
					load: ['$q', function($q){
						var defered = $q.defer();
						require(['app/components/forms/controltotals/controlTotalsFormController'], function(){
							defered.resolve();
						});
						return defered.promise;
					}],
					data : function(){
						var data = {};
						data.batchSheetOnly = true;
						console.log('controlTotalsID: '+controlTotalsID);
						if(controlTotalsID && controlTotalsID > 0){
							data.controlTotalsID = controlTotalsID;
						}
						console.log('ZZZZZ');
						console.log(data);
						return data;
					}
				}
			});
			modalInstance.result.then(function(x){
				$scope.tableParams.reload();
			}, 
			function() {				
				// dismissed
				console.log("dismissed");
			});
			return modalInstance.result;
		};
		
		$scope.doFilter = function(){
			console.log($scope.data);
			//Reload Paginated Request
			$scope.tableParams.reload();
		};
		
		$scope.doShowAll = function(){
			$scope.data.selectedUser = '';
			console.log($scope.data);
			//Reload Paginated Request
			$scope.tableParams.reload();
		};
	}]);
	
});