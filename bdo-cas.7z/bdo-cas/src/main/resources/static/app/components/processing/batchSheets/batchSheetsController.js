'use strict';

define(function(){
	console.log('batchSheetsController.js loaded');
	var core = angular.module('core');
	
	core.registerController('batchSheetsController', [ '$rootScope', '$scope', '$uibModal', 'BatchSheetsQueryService', 'BatchSheetsCommandService', 'DataAccessService', 'ngTableParams', '$filter', 
		function($rootScope, $scope, $uibModal, batchSheetsQueryService, batchSheetsCommandService, dataAccessService, ngTableParams, $filter){
		$scope.title = 'This is the Batch Sheets Screen';
		$rootScope.screenName = 'PROCESSING --> BATCH SHEETS';
		var vm = this;
		
		$scope.data = {};
		$scope.userCode = { "userCode " : [] };
		$scope.currencyShortDescriptions = { "currencyShortDescriptions " : [] };
		$scope.currencyShortDescription = "";
		
		function loadPage() {
			$scope.tableParams = new ngTableParams({
						page: 1,
						count: 25
					},
					{getData: function ($defer, params) {
						$scope.data.pageIndex = params.page();
						$scope.data.pageSize = params.count();
						//$scope.data.selectedUsername;
						return batchSheetsQueryService.getBatchSheetList($scope.data).success(function (response) {
								$scope.form = response;
								params.total($scope.form.resultOverAllCount);
								console.log($scope.form);
								console.log($scope.form.columns);
								$defer.resolve($scope.form.resultSet);
							})
							.error(function (response) {
								console.log(response);
							});
					}
				}
			
			);
		};
		
		vm.init = function() {
			$scope.data.dataSetID = $rootScope.dataSetID;
			$scope.data.dataSetCode = $rootScope.dataSetCode;
			$scope.data.encodingUnitCode = $rootScope.encodingUnitCode;
			$scope.reference = {};
			$scope.userProcessInfo = { "userProcessInfo " : [] };
			loadPage();
			
			batchSheetsQueryService.getProcessors(function(response){
				console.log(response);
				$scope.reference.processorList = response.data.resultSet;
				
				if($scope.reference.processorList && $scope.reference.processorList.length === 1){
					$scope.data.selectedUser = $scope.reference.processorList[0].code;
				}
			},function(errorResponse){
				console.log(errorResponse);
			});
			
			batchSheetsQueryService.getUserCode($rootScope.dataSetCode, function(response){
				console.log(response.data);
				$scope.userCode = response.data;
			},function(error){
				console.log(error);
			});
			
			//Get currencies with short descriptions
			var getCurrencyShortDescUrl = 'references/currencyShortDesc/'+$rootScope.dataSetCode;
			dataAccessService.doGetData(getCurrencyShortDescUrl, null, function(response){
				console.log(response.data);
				$scope.currencyShortDescriptions = response.data;
				
			},function(error){
				console.log(error);
			});
			
			//Get userParams
			batchSheetsQueryService.getUserProcessInfo($rootScope.dataSetCode, function(response){
				console.log(response.data);
				$scope.userProcessInfo = response.data;
				
			},function(error){
				console.log(error);
			});
		}
		// Initialize
		vm.init();
		
		$scope.selectAll = function(){
			var toggleStatus = $scope.form.isAllSelected;
			console.log(toggleStatus);
			angular.forEach($scope.form.resultSet, function(record){
				record.selected = toggleStatus;
			});
		}
		
		$scope.doChangeSelection = function(record){
			record.selected = !record.selected;
			if(!record.selected){
				$scope.form.isAllSelected = false;
			}
		}
		
		$scope.doShowBatchSheetForm = function(){
			var modalInstance = $uibModal.open({
				animation: true,
				templateUrl: 'app/components/forms/batchsheetform/batchSheetForm.html',
				controller: 'batchSheetFormController',
				size: 'lg',
				resolve:{
					load: ['$q', function($q){
						var defered = $q.defer();
						require(['app/components/forms/batchsheetform/batchSheetFormController'], function(){
							defered.resolve();
						});
						return defered.promise;
					}]
				}
			});
			return modalInstance.result;
			
		};
		
		$scope.doShowAddRemarksForm = function(){
			var modalInstance = $uibModal.open({
				animation: true,
				templateUrl: 'app/components/forms/remarks/remarksForm.html',
				controller: 'remarksFormController',
				size: 'md',
				resolve:{
					load: ['$q', function($q){
						var defered = $q.defer();
						require(['app/components/forms/remarks/remarksFormController'], function(){
							defered.resolve();
						});
						return defered.promise;
					}]
				}
			});
			return modalInstance.result;
			
		};
		
		$scope.showTakeUps = function(batchID) {
			console.log('showTakeUps: '+batchID);
			batchSheetsQueryService.getTakeUpsByBatchSheetID(batchID, function(response){
				console.log(response);
				var modalInstance = $uibModal.open({
					animation: true,
					templateUrl: 'app/components/processing/batchSheets/transactionTakeUpList.html',
					controller: 'transactionTakeUpListController',
					size: 'lg',
					resolve:{
						load: ['$q', function($q){
							var defered = $q.defer();
							require(['app/components/processing/batchSheets/transactionTakeUpListController'], function(){
								defered.resolve();
							});
							return defered.promise;
						}],
						transactionTakeUps : function(){
							return response.data;
						}
					}
				});
				return modalInstance.result;
			},function(errorResponse){
				console.log(errorResponse);
			});
		}
		
		$scope.showJournalEntries = function(batchID) {
			var modalInstance = $uibModal.open({
				animation: true,
				templateUrl: 'app/components/processing/batchSheets/journalEntriesByBatchSheetID.html',
				controller: 'journalEntriesByBatchSheetIDController',
				size: 'lg',
				resolve:{
					load: ['$q', function($q){
						var defered = $q.defer();
						require(['app/components/processing/batchSheets/journalEntriesByBatchSheetIDController'], function(){
							defered.resolve();
						});
						return defered.promise;
					}],
					data : function(){
						var data = {}; 
						data.batchSheetID = batchID;
						return data;
					}
				}
			});
			return modalInstance.result;
		}
		
		$scope.showOtherAdjustments = function(batchID){
			var modalInstance = $uibModal.open({
				animation: true,
				templateUrl: 'app/components/forms/batchsheetform/otherAdjustmentsForm.html',
				controller: 'otherAdjustmentsFormController',
				size: 'lg',
				resolve:{
					load: ['$q', function($q){
						var defered = $q.defer();
						require(['app/components/forms/batchsheetform/otherAdjustmentsFormController'], function(){
							defered.resolve();
						});
						return defered.promise;
					}],
					data : function(){
						var data = {}; 
						data.batchSheetID = batchID;
						return data;
					}
				}
			});
			return modalInstance.result;
		};
		
		$scope.showControlTotals = function(controlTotalsID) {
			var modalInstance = $uibModal.open({
				animation: true,
				templateUrl: 'app/components/forms/controltotals/controlTotalsForm.html',
				controller: 'controlTotalsFormController',
				size: 'md',
				resolve:{
					load: ['$q', function($q){
						var defered = $q.defer();
						require(['app/components/forms/controltotals/controlTotalsFormController'], function(){
							defered.resolve();
						});
						return defered.promise;
					}],
					data : function(){
						var data = {};	
						data.batchSheetOnly = true;
						console.log('controlTotalsID: '+controlTotalsID);
						if(controlTotalsID && controlTotalsID > 0){
							data.controlTotalsID = controlTotalsID;
						}
						console.log('ZZZZZ');
						console.log(data);
						return data;
					}
				}
			});
			return modalInstance.result;
		}
		
		$scope.printBatchSheetID = function(batchID, bookCode, currencyCode, processingDate, batchSheetType) {
			
			console.log(batchSheetType);
			
			var user = $rootScope.session["AUTHENTICATED_USER"];
			var reportCode = null;
			var reportName = null;
			var exists = false;
			var reportType = 'RPT004';
			
			$scope.getCurrencyShortDesc(currencyCode);
			
			if(batchSheetType === 'ALL'){
				reportType = 'RPT006';
			}else{
				reportType = 'RPT004';
			}
			
			angular.forEach($rootScope.reports, function(value, key) {
				
				if(!exists){
					if (value.code === reportType) {
						reportCode = value.code;
						reportName = value.name;
						exists = true;
					}
				}
			});
			
			var reportUrl = 'reports/create/'+reportName+bookCode+'_pdf';
			var downloadUrl = 'reports/download/'+reportName+bookCode+'_pdf';
			console.log('URL: ' + reportUrl);
			
			var reportparams = {};
			
			reportparams["userID"] = $scope.userCode[0].code;
			reportparams["reportID"] = reportCode;
			reportparams["dataset"] = $scope.dataSetID;
			reportparams["dataSetCode"] = $rootScope.dataSetCode;
			reportparams["effDate"] = processingDate;
			reportparams["bookCode"] = bookCode;
			reportparams["batchSheetID"] = batchID;
			reportparams["currencyCode"] = currencyCode;

			reportparams["bookDesc"] = bookCode;
			reportparams["currencyDesc"] = $scope.currencyShortDescription;
			
			reportparams["systemDate"] = $filter('date')(new Date(), 'yyyyMMddhhmmssS');
			reportparams["processingDate"] = $filter('date')(new Date(processingDate), 'yyyyMMdd');
			reportparams["usersEncodingUnit"] = $scope.userProcessInfo[0].code;
			
			
			console.log(reportparams["userID"] + ', ' + reportparams["reportID"] + ', ' + reportparams["dataset"] + ', ' + 
					reportparams["effDate"] + ', ' + reportparams["bookCode"] + ', ' + reportparams["batchSheetID"]);
			
			alertify.confirm("Do you really want to print BatchSheet Report?", function(e){
				
				if(e){
					dataAccessService.doPostData(reportUrl, reportparams, function(response){
						console.log(response);
						if(response.data.messageMap.successMsg!=undefined && response.data.messageMap.successMsg!=null){
							alertify.alert(response.data.messageMap.successMsg);
//							alertify.confirm('BatchSheet Report successfully generated. Do you want to download report?', function(e) {
//								if (e) {
//									console.log(downloadUrl+'?file='+response.data.messageMap.filename);
//									window.location.href=downloadUrl+'?file='+response.data.messageMap.filename;
//								}else{
//									return;
//								}
//							});
						}else
						if(response.data.messageMap.errorMsg!=undefined && response.data.messageMap.errorMsg!=null){
							alertify.alert('BatchSheet Report generation failed.');
							console.log(response.data.messageMap.errorMsg);
						}
						
					},function(errorResponse){
						console.log(errorResponse);
						alertify.alert('BatchSheet Report generation failed.');
					});
				}else{
					return;
				}
				



			});
		};
		
		$scope.open = function(columnName, $event) {
			$event.preventDefault();
			$event.stopPropagation();
			
			if ($scope.datePicker[columnName]) {
				if ($scope.datePicker[columnName].opened) {
					$scope.datePicker[columnName].opened = false;
				}
			} else {
				$scope.datePicker = {};
				$scope.datePicker[columnName] = {};
				$scope.datePicker[columnName].opened = true;
			}
		}
		
		$scope.doSubmitBatchSheet = function(){
			
			var selectedItems = vm.getSelectedItems($scope.form.resultSet);
			
			console.log("No. of Selected Items: " + selectedItems.length);
			console.log(selectedItems);
			if(selectedItems.length == 0){
				alertify.alert("Please select items first in order to proceed with this action");
			}else{
				
				var invalidRecords = '';
				for(var i = 0; i < selectedItems.length; i++){
					var status = selectedItems[i]['Status'];
					console.log(status);
					if(status !== 'For Update'){
						invalidRecords = invalidRecords+selectedItems[i]['ID']+'\n';
					}
				}
				if(invalidRecords){
					alertify.alert("Only batch sheets with status 'for Update' are valid for submission for approval." +
							"Remove the following invalid records from the selection in order to proceed:\n" +
							invalidRecords);
					return false;
				}
				
				alertify.confirm("This action submits the selected batch sheets for approval. " +
						"Are you sure you want to proceed?", function(e){
						if(e){
							for(var i = 0; i < selectedItems.length; i++){
								var data = {};
								data.batchSheetID = selectedItems[i]['ID'];
								data.dataSetCode = $rootScope.dataSetCode;
								data.encodingUnitCode = $rootScope.encodingUnitCode;
								batchSheetsCommandService.submit(data, function(response){
									console.log(response.data);
									$scope.tableParams.reload();
									alertify.alert(response.data.messageMap.successMsg);
									//alertify.alert("The selected batch sheet/s has been successfully submitted.");
								}, function(error){
									console.log(error);
									alertify.fail(error.data.errorMsg);
								});
							}
						}else{
							return;
						}
					});
			}
		}
		
		$scope.doApproveBatchSheet = function(){
			
			var selectedItems = vm.getSelectedItems($scope.form.resultSet);
			
			console.log("No. of Selected Items: " + selectedItems.length);
			console.log(selectedItems);
			if(selectedItems.length == 0){
				alertify.alert("Please select items first in order to proceed with this action");
			}else{
				
				var invalidRecords = '';
				for(var i = 0; i < selectedItems.length; i++){
					var status = selectedItems[i]['Status'];
					console.log(status);
					if(status !== 'For Approval'){
						invalidRecords = invalidRecords+selectedItems[i]['ID']+'\n';
					}
				}
				if(invalidRecords){
					alertify.alert("Only batch sheets with status 'for Approval' are valid for approval." +
							"Remove the following invalid records from the selection in order to proceed:\n" +
							invalidRecords);
					return false;
				}
				
				alertify.confirm("This action approves the selected batch sheets. " +
						"Are you sure you want to proceed?", function(e){
						if(e){
							for(var i = 0; i < selectedItems.length; i++){
								var data = {};
								data.batchSheetID = selectedItems[i]['ID'];
								data.dataSetCode = $rootScope.dataSetCode;
								data.encodingUnitCode = $rootScope.encodingUnitCode;
								batchSheetsCommandService.approve(data, function(response){
									console.log(response.data);
									$scope.tableParams.reload();
									alertify.alert(response.data.messageMap.successMsg);
									//alertify.alert("The selected batch sheet/s has been successfully approved.");
								}, function(error){
									console.log(error);
									alertify.fail(error.data.errorMsg);
								});
							}
						}else{
							return;
						}
					});
			}
		}
		
		$scope.doUndoApproveBatchSheet = function(){
			
			var selectedItems = vm.getSelectedItems($scope.form.resultSet);
			
			console.log("No. of Selected Items: " + selectedItems.length);
			console.log(selectedItems);
			if(selectedItems.length == 0){
				alertify.alert("Please select items first in order to proceed with this action");
			}else{
				
				var invalidRecords = '';
				for(var i = 0; i < selectedItems.length; i++){
					var status = selectedItems[i]['Status'];
					console.log(status);
					if(status !== 'Approved' && status !== 'For Approval'){
						invalidRecords = invalidRecords+selectedItems[i]['ID']+'\n';
					}
				}
				if(invalidRecords){
					alertify.alert("Only batch sheets with status 'Approved' and 'For Approval' are valid for tagging as 'For Update'." +
							"Remove the following invalid records from the selection in order to proceed:\n" +
							invalidRecords);
					return false;
				}
				
				alertify.confirm("This action returns the selected batch sheets for update. " +
						"Are you sure you want to proceed?", function(e){
						if(e){
							for(var i = 0; i < selectedItems.length; i++){
								var data = {};
								data.batchSheetID = selectedItems[i]['ID'];
								data.dataSetCode = $rootScope.dataSetCode;
								data.encodingUnitCode = $rootScope.encodingUnitCode;
								batchSheetsCommandService.undoapprove(data, function(response){
									console.log(response.data);
									$scope.tableParams.reload();
									alertify.alert(response.data.messageMap.successMsg);
									//alertify.alert("The selected batch sheet/s are successfully tagged as 'For Update'");
								}, function(error){
									console.log(error);
									alertify.fail(error.messageMap.errorMsg);
								});
							}
						}else{
							return;
						}
					});
			}
		}
		
				
		$scope.doFilter = function(){
			console.log($scope.data);
			//Reload Paginated Request
			$scope.tableParams.reload();
		};
		
		$scope.doShowAll = function(){
			$scope.data.selectedUsername = '';
			console.log($scope.data);
			//Reload Paginated Request
			$scope.tableParams.reload();
		};
		
		$scope.doShowPrepareBatchSheetForm = function(){
			var modalInstance = $uibModal.open({
				animation: true,
				templateUrl: 'app/components/forms/batchsheetform/prepareBatchSheetForm.html',
				controller: 'prepareBatchSheetFormController',
				size: 'lg',
				resolve:{
					load: ['$q', function($q){
						var defered = $q.defer();
						require(['app/components/forms/batchsheetform/prepareBatchSheetFormController'], function(){
							defered.resolve();
						});
						return defered.promise;
					}]
				}
			});
			modalInstance.result.then(
				function(message) {
					//Reload Paginated Request
					$scope.tableParams.reload();
				}, 
				function() {				
					// dismissed
					console.log("dismissed");
				}
			);
			return modalInstance.result;
			
		};
		
		$scope.doShowAddRemarksForm = function(){
			$scope.batchIDs = [];
				
			for(var i = 0; i < $scope.form.resultSet.length; i++){
				var selected = $scope.form.resultSet[i].selected;
				console.log(selected);
				if(selected === true){
					var batchID = $scope.form.resultSet[i]['ID'];
					$scope.batchIDs.push(batchID);
				}
			}
			
			$scope.batchSize = $scope.batchIDs.length;
		
			console.log($scope.batchIDs.length);
			
			var modalInstance = $uibModal.open({
				animation: true,
				templateUrl: 'app/components/forms/remarks/remarksForm.html',
				controller: 'remarksFormController',
				size: 'lg',
				keyboard: false,
				resolve:{
					load: ['$q', function($q){
						var defered = $q.defer();
						require(['app/components/forms/remarks/remarksFormController'], function(){
							defered.resolve();
						});
						return defered.promise;
					}],
					data : function(){
						var data = {}; 
						data.batchIDs = $scope.batchIDs;
						data.sourceType = 'BS';
						return data;
					}
				}
			});
			return modalInstance.result;
			
		};
		
		$scope.viewRemarks = function(batchID){
			
			console.log('BatchID: ' + batchID);
			
			$scope.batchIDs = [];
			
			$scope.batchIDs.push(batchID);
			
			$scope.batchSize = $scope.batchIDs.length;
			
			console.log($scope.batchIDs.length);
			
			var modalInstance = $uibModal.open({
				animation: true,
				templateUrl: 'app/components/forms/remarks/remarksForm.html',
				controller: 'remarksFormController',
				size: 'lg',
				keyboard: false,
				resolve:{
					load: ['$q', function($q){
						var defered = $q.defer();
						require(['app/components/forms/remarks/remarksFormController'], function(){
							defered.resolve();
						});
						return defered.promise;
					}],
					data : function(){
						var data = {}; 
						data.batchIDs = $scope.batchIDs;
						data.sourceType = 'BS';
						return data;
					}
				}
			});
			return modalInstance.result;
		};
		
		// Get selected items
		vm.getSelectedItems = function(items){
			var selectedItems = [];
			for(var i = 0; i < items.length; i++){
				var selected = items[i].selected;
				if(selected === true){
					selectedItems.push(items[i]);
				}
			}
			return selectedItems;
		}
		
		$scope.doAddRemarks = function(){
			
			var selectedItems = vm.getSelectedItems($scope.form.resultSet);
			console.log('No. of Selected Items: ' + selectedItems.length);
			
			if(selectedItems.length == 0){
				alertify.alert("Please select item/s first in order to proceed with this action");
			}else{
				$scope.doShowAddRemarksForm();
			}
		};
		
		$scope.getCurrencyShortDesc = function(currencyCode){
			
			console.log($scope.currencyShortDescriptions);
			
			var exists = false;
			
			angular.forEach($scope.currencyShortDescriptions, function(value, key) {
				
				if(!exists){
					if (value.code === currencyCode) {
						
						$scope.currencyShortDescription = (value.desc);
						
						exists = true;
					}
				}
				
			});
			
			console.log("CurrencyShortDescription: " + $scope.currencyShortDescription);
		};
		
	}]);
	
});