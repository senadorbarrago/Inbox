'use strict';

define(function(){
	var core = angular.module('core');
	
	core.registerController('predefinedEntriesDefinitionController',['$rootScope', '$scope', '$uibModalInstance', '$uibModal', 'data', 'DataAccessService', '$filter',
	                                                     function($rootScope, $scope, $uibModalInstance, $uibModal, data, dataAccessService, $filter){
	    $scope.title = 'Predefined Entries Definition Form';
		
		var vm = this;

		vm.init = function(){
			$scope.form = {};
			$scope.data = {};
			$scope.data.pdeActionTag = "";
			$scope.datePicker = { };
			$scope.dateOptions = {
					startingDay : 1,
					showWeeks : false,	
					format : "yyyy-MM-dd"
				};
			$scope.dateFormat = "yyyy-MM-dd";
			
			$scope.data.dataSetID = $rootScope.dataSetID;
			$scope.data.dataSetCode = $rootScope.dataSetCode;
			$scope.data.predefinedEntryID = data.predefinedEntryID;
			$scope.data.predefinedEntriesID = data.predefinedEntryID;
			$scope.data.pdedID = 0;
			
			console.log(data.predefinedEntryID);
			
			vm.getPredefinedEntriesDefinition();
			vm.getJournalEntryFields();
		}
		
		$scope.open = function(columnName, $event) {
			$event.preventDefault();
			$event.stopPropagation();
			
			if ($scope.datePicker[columnName]) {
				if ($scope.datePicker[columnName].opened) {
					$scope.datePicker[columnName].opened = false;
				}
			} else {
				$scope.datePicker = {};
				$scope.datePicker[columnName] = {};
				$scope.datePicker[columnName].opened = true;
			}
		}
		
		$scope.process = function(){
			console.log($scope.data.forwardRates);
			console.log($scope.data.glDate);
			var saveGLDateUrl = "transactions/glDate/save";			
			
			if(!$scope.data.glDate){
				alertify.alert("Please select a GL Date in order to proceed");
				return;
			}else{
				alertify.confirm("Do you really want to set GL Date?", function(e){
					
					if(e){
						dataAccessService.doPostData(saveGLDateUrl, $scope.data, function(response){
							console.log(response);
							alertify.alert(response.data.messageMap.successMsg);
							vm.init();
						},function(errorResponse){
							console.log(errorResponse);
							alertify.fail(errorResponse.data.errorMsg);
						});
					}else{
						return;
					}
				});
			}
			
		}
		
		
		vm.getPredefinedEntriesDefinition = function(){
			
			var url = "transactions/predefinedEntries/predefinedEntriesDefinition/"+ $scope.data.dataSetCode + "/"+$scope.data.predefinedEntryID;		
			dataAccessService.doGetData(url, null, function(response){
				console.log(response);
				$scope.predefinedEntriesDefinition = response.data;
			},function(errorResponse){
				console.log(errorResponse);
			});
		}
		
		//Get currencies
		vm.getCurrenciesByDataSetCode = function(){
			var url = 'references/currencyByDataSetCode/'+$rootScope.dataSetCode;
			dataAccessService.doGetData(url, null, function(response){
				console.log(response.data);
				$scope.currencies = response.data;
			},function(errorResponse){
				errorCallBack(errorResponse);
			});
		};
		
		//Get journal entry fields
		vm.getJournalEntryFields = function(){
			var url = 'references/journalEntryFields/'+$rootScope.dataSetCode;
			dataAccessService.doGetData(url, null, function(response){
				console.log(response.data);
				$scope.journalEntryFields = response.data;
			},function(errorResponse){
				errorCallBack(errorResponse);
			});
		};
		
		vm.init();
		
		$scope.addPDED = function(){
			
			console.log("Add Predefined Entries Definition.");
			$scope.data.pdeActionTag = "ADD";
			$scope.setAttribute($scope.data.pdeActionTag)
			
			console.log($scope.data);
		};
		
		$scope.editPDED = function(){
			
			console.log("Edit Predefined Entries Definition.");
			$scope.data.pdeActionTag = "UPDATE";
			
			if(!$scope.selectedRecord){
				alertify.alert("Please select an item first in order to proceed with this action.");
				return false;
			}else {
				console.log("OK");
				$scope.setAttribute($scope.data.pdeActionTag)

				console.log($scope.data);
			}
			
		};
		
		$scope.deletePDED = function(){
			
			console.log("Delete Predefined Entries Definition.");
			$scope.data.pdeActionTag = "DELETE";

			if(!$scope.selectedRecord){
				alertify.alert("Please select an item first in order to proceed with this action.");
				return false;
			}else {
				console.log("OK");
				$scope.setAttribute($scope.data.pdeActionTag)

				console.log($scope.data);
				
				var deletePredefinedEntriesDefinitionUrl = 'transactions/predefinedEntriesDefinition/setup';
				alertify.confirm("Do you really want to delete definition for this predefined entry?", function(e){
						
					if(e){
						dataAccessService.doPostData(deletePredefinedEntriesDefinitionUrl, $scope.data, function(response){
							console.log(response);
							alertify.alert(response.data.messageMap.successMsg);
							vm.init();
						},function(errorResponse){
							console.log(errorResponse);
							alertify.fail(errorResponse.data.errorMsg);
						});
					}else{
						return;
					}
					
					$scope.getPredefinedEntriesDefinition();
				});
				$scope.setAttribute("");
			}
		};
		
		$scope.restorePDED = function(){
			
			console.log("Restore Predefined Entries Definition.");
			$scope.data.pdeActionTag = "RESTORE";

			if(!$scope.selectedRecord){
				alertify.alert("Please select an item first in order to proceed with this action.");
				return false;
			}else {
				console.log("OK");
				$scope.setAttribute($scope.data.pdeActionTag)

				console.log($scope.data);
				
				var restorePredefinedEntriesDefinitionUrl = 'transactions/predefinedEntriesDefinition/setup';
				alertify.confirm("Do you really want to restore definition for this predefined entry?", function(e){
						
					if(e){
						dataAccessService.doPostData(restorePredefinedEntriesDefinitionUrl, $scope.data, function(response){
							console.log(response);
							alertify.alert(response.data.messageMap.successMsg);
							vm.init();
						},function(errorResponse){
							console.log(errorResponse);
							alertify.fail(errorResponse.data.errorMsg);
						});
					}else{
						return;
					}
					
					$scope.getPredefinedEntriesDefinition();
				});
				$scope.setAttribute("");
			}
		};
		
		$scope.savePDED = function(pdeActionTag){
			
			console.log("Save Predefined Entries Definition.");
			console.log("pdeActionTag: " + pdeActionTag);
			console.log($scope.data);
			
			var savePredefinedEntriesDefinitionUrl = 'transactions/predefinedEntriesDefinition/setup';
			alertify.confirm("Do you really want to save definition for this predefined entry?", function(e){
					
				if(e){
					dataAccessService.doPostData(savePredefinedEntriesDefinitionUrl, $scope.data, function(response){
						console.log(response);
						alertify.alert(response.data.messageMap.successMsg);
						vm.init();
					},function(errorResponse){
						console.log(errorResponse);
						alertify.fail(errorResponse.data.errorMsg);
					});
				}else{
					return;
				}
				
				$scope.getPredefinedEntriesDefinition();
			});
			
			$scope.setAttribute("");
		};
		
		// Get selected items
		vm.getSelectedItems = function(items){
			var selectedItems = [];
			for(var i = 0; i < items.length; i++){
				var selected = items[i].selected;
				if(selected === true){
					selectedItems.push(items[i]);
				}
			}
			return selectedItems;
		}
		
		$scope.setAttribute = function(action){

			if(action === 'ADD'){
				$("#recordNo").attr("disabled", false);
				$("#journalEntryField").attr("disabled", false);
				$("#value1").attr("disabled", false);
				$("#value2").attr("disabled", false);
				$("#save").show();
			}else if(action === 'UPDATE'){
				$("#recordNo").attr("disabled", false);
				$("#journalEntryField").attr("disabled", false);
				$("#value1").attr("disabled", false);
				$("#value2").attr("disabled", false);
				$("#save").show();
			}else{
				$("#recordNo").attr("disabled", "disabled");
				$("#journalEntryField").attr("disabled", "disabled");
				$("#value1").attr("disabled", "disabled");
				$("#value2").attr("disabled", "disabled");
				$("#save").hide();
			}
		}
		
		$scope.setAttributeDisable = function(){

				$("#recordNo").attr("disabled", "disabled");
				$("#journalEntryField").attr("disabled", "disabled");
				$("#value1").attr("disabled", "disabled");
				$("#value2").attr("disabled", "disabled");
				$("#save").hide();
		}
		
		$scope.validate = function(action, selectedItems){

			if(action === 'UPDATE' || action === 'DELETE'){
				if(selectedItems.length == 0){
					alertify.alert("Please select an item first in order to proceed with this action");
				}else if(selectedItems.length > 1){
					alertify.alert("Please one at a time in order to proceed with this action");
				}else {
					console.log("OK");
				}
				
			}else{
				$("#recordNo").attr("disabled", "disabled");
				$("#journalEntryField").attr("disabled", "disabled");
				$("#value1").attr("disabled", "disabled");
				$("#value2").attr("disabled", "disabled");
				$("#save").hide();
			}
		}
		
		$scope.setSelectedRecord = function(index){
			$scope.selectedRecord = $scope.predefinedEntriesDefinition.resultSet[index];
			console.log($scope.selectedRecord);
			
			$scope.data.pdedID = $scope.selectedRecord.id;
			$scope.data.predefinedEntriesID = $scope.selectedRecord.predefinedEntriesID;
			$scope.data.recordNo = $scope.selectedRecord.recordNo;
			$scope.data.journalFieldID = $scope.selectedRecord.journalFieldID;
			$scope.data.journalFieldCode = $scope.selectedRecord.journalFieldCode;
			$scope.data.value = $scope.selectedRecord.value;
			$scope.data.isDeleted = $scope.selectedRecord.isDeleted;
			
			$scope.getPredefinedEntriesDefinitionValue();
		}
		
		$scope.getPredefinedEntries = function(){
			
			if($scope.data.currencyCode === '000'){
				var bookCode = '1';
			}else{
				var bookCode = '2';
			}
			
			var url = 'references/predefinedEntries/'+$scope.data.dataSetID+'/'+bookCode+'/'+$scope.data.currencyCode;
			dataAccessService.doGetData(url, null, function(response){
				console.log(response.data);
				$scope.predefinedEntries = response.data;
			},function(errorResponse){
				errorCallBack(errorResponse);
			});
			
			$scope.setAttributeDisable();
		}
		
		$scope.getPredefinedEntriesDefinition = function(){
			
			var url = "transactions/predefinedEntries/predefinedEntriesDefinition/"+ $scope.data.dataSetCode + "/"+$scope.data.predefinedEntryID;		
			dataAccessService.doGetData(url, null, function(response){
				console.log(response);
				$scope.predefinedEntriesDefinition = response.data;
			},function(errorResponse){
				console.log(errorResponse);
			});
			
			$scope.setAttributeDisable();
		}
		
		$scope.getPredefinedEntriesDefinitionValue = function(){
			
			var url = "transactions/predefinedEntries/predefinedEntriesDefinitionValue/"+$scope.data.journalFieldCode;		
			dataAccessService.doGetData(url, null, function(response){
				console.log(response);
				$scope.predefinedEntriesDefinitionValues = response.data.resultSet;
				$scope.data.fieldType = $scope.predefinedEntriesDefinitionValues[0].fieldType;
				console.log($scope.data.fieldType);
			},function(errorResponse){
				console.log(errorResponse);
			});
		}
		
		$scope.cancel = function() {
			alertify.confirm("This action cancels any changes or updates in this predefined entry. " +
					"Are you sure you want to proceed?", function(e){
					if(e){
						$uibModalInstance.dismiss();
					}else{
						return;
					}
				});
		};
		
	}]);
	
});