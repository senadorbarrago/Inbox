'use strict';

define(function(){
	console.log('$uibModal.js loaded');
	var core = angular.module('core');
	
	core.registerController('statusController', [ '$rootScope', '$scope', '$uibModal', 'DataAccessService', 'ngTableParams', 'StatusQueryService', 'StatusCommandService', '$filter',  
		function($rootScope, $scope, $uibModal, dataAccessService, ngTableParams, statusQueryService, statusCommandService, $filter){
		
		$rootScope.screenName = 'PROCESSING --> Status';
		var vm = this;
		
		function loadPage() {
			
			$scope.tableParams = new ngTableParams({
						page: 1,
						count: 25
					},
					{	getData: function ($defer, params) {
						$scope.data.dataSetCode = $rootScope.dataSetCode;
						$scope.data.encodingUnitCode = $rootScope.encodingUnitCode;
						if(!$scope.data.selectedUser){
							$scope.data.selectedUser = $rootScope.session.AUTHENTICATED_USER.username;
						}
						$scope.data.pageIndex = params.page();
						$scope.data.pageSize = params.count();
						
						var url  = 'status/actionable';
						console.log('DATA:');
						console.log($scope.data);
						return dataAccessService.doPostData(url, $scope.data, function(response){
							console.log(response);
							$scope.form = response.data;
							$scope.rows = response.resultSet;
							$scope.columns = $scope.columns;
							params.total($scope.form.resultOverAllCount);
							console.log("params.total: " + $scope.form.resultOverAllCount);
							$defer.resolve($scope.rows);
						},function(errorResponse){
							console.log(errorResponse);
						});
					}
				}
			
			);
		};
		
		vm.getGroupUser = function(){
			console.log('vm.getGroupUser()');
			statusQueryService.getProcessors(function(response){
				$scope.references.processorList = response.data.resultSet;
				if($scope.references.processorList && $scope.references.processorList.length === 1){
					$scope.data.selectedUser = $scope.references.processorList[0].code;
				}
				
				console.log($scope.references.processorList);
				
			}, function(errorResponse){
				console.log(errorResponse);
			});
		}
		
		//Get userParams
		vm.getUserProcessInfo = function(){
			statusQueryService.getUserProcessInfo($rootScope.dataSetCode, function(response){
				$scope.userProcessInfo = response.data;		
			}, function(errorResponse){
				console.log(errorResponse);
			});
		}
		
		//Get userCode
		vm.getUserCode = function(){
			statusQueryService.getUserCode($rootScope.dataSetCode, function(response){
				$scope.userCode = response.data;
			}, function(errorResponse){
				console.log(errorResponse);
			});
		}
		
		vm.init = function(){
			$scope.reportparameters = {};
			$scope.userProcessInfo = { "userProcessInfo " : [] };
			$scope.userCode = { "userCode " : [] };
			$scope.reference = {};
			$scope.data = {};
			$scope.references = {};
			
			vm.getGroupUser();
			vm.getUserProcessInfo();
			vm.getUserCode();
			loadPage();
			console.log($scope.data);
		}
		
		vm.init();
		
		$scope.data = {};
		
		$scope.selectAll = function(){
			var toggleStatus = $scope.form.isAllSelected;
			console.log(toggleStatus);
			angular.forEach($scope.form.resultSet, function(record){
				record.selected = toggleStatus;
			});
			
		}
		
		$scope.doFilter = function(){
			console.log($scope.data);
			//Reload Paginated Request
			$scope.tableParams.reload();
		};
		
		$scope.doShowAll = function(){
			$scope.data.selectedUser = '';
			console.log($scope.data);
			//Reload Paginated Request
			$scope.tableParams.reload();
		};
		
		$scope.reassignTransaction = function(){
			
			var selectedItems = vm.getSelectedItems($scope.form.resultSet);
			console.log(selectedItems);
			console.log('Source: ' + $scope.data.source);
			console.log('Recipient: ' + $scope.data.recipient);
			
			$scope.reportparameters["reportID"] = "49";
			$scope.reportparameters["dataset"] = $rootScope.dataSetID;
			$scope.reportparameters["effDate"] = $scope.userProcessInfo[0].desc;
			$scope.reportparameters["encodingUnit"] = $scope.userProcessInfo[0].code;
			$scope.reportparameters["criteria"] = 1;
			
			$scope.reportparameters["source"] = $scope.data.source;
			$scope.reportparameters["recipient"] = $scope.data.recipient;
			
			$scope.reportparameters["source_reportName"] = "TransactionReassignSRC_xlsx";
			$scope.reportparameters["recipient_reportName"] = "TransactionReassignRES_xlsx";
			$scope.reportparameters["userID"] = $scope.userCode[0].code;
			$scope.reportparameters["processingDate"] = $filter('date')(new Date($scope.userProcessInfo[0].desc), 'yyyyMMdd')
			$scope.reportparameters["systemDate"] = $filter('date')(new Date(), 'yyyyMMddhhmmssS')
			$scope.reportparameters["usersEncodingUnit"] = $scope.userProcessInfo[0].code;
			
			if($scope.data.source === '' || $scope.data.source === undefined || $scope.data.source === null){
				alertify.alert("Please input source user in order to proceed with this action.");
			}
			else if($scope.data.recipient === '' || $scope.data.recipient === undefined || $scope.data.recipient === null){
				alertify.alert("Please input recipient in order to proceed with this action.");
			}
			else{
				alertify.confirm("Do you really want to reassign transaction to other processor?", function(e){
					
					if(e){
						console.log($scope.data);
						console.log($scope.reportparameters);
						//Reassign Transaction
						statusCommandService.reassignTransation($scope.data, function(response){
							console.log(response.data);
							if(response.data.messageMap.successMsg!=undefined && response.data.messageMap.successMsg!=null){
								alertify.alert(response.data.messageMap.successMsg);
								$scope.tableParams.reload();
							}else if(response.data.messageMap.errorMsg!=undefined && response.data.messageMap.errorMsg!=null){
								alertify.alert(response.data.messageMap.errorMsg);
							}
						},function(error){
							console.log(error);
						});
						//Print Source User Report
						statusCommandService.printReport($scope.reportparameters, $scope.reportparameters["source_reportName"], $scope.reportparameters["source"], function(response){
							console.log(response.data);
						},function(error){
							console.log(error);
						});
						//Print Recipient User Report
						statusCommandService.printReport($scope.reportparameters, $scope.reportparameters["recipient_reportName"], $scope.reportparameters["recipient"], function(response){
							console.log(response.data);
						},function(error){
							console.log(error);
						});
					}else{
						return;
					}
				});
			}
			
		};
		
		vm.validateSourceAndRecipient = function(){
			if(!$scope.data.source || !$scope.data.recipient){
				alertify.alert("The source/recepient fields should have valid values only");
				
				return false;
			}
			if($scope.data.source === $scope.data.recipient){
				alertify.alert("The source and recepient should not pertain to the same processor. "
					+ "Please select a different processor for the source and a different processor for the recepient "
					+ "in order to proceed.");
				
				return false;
			}
			return true;
		}
		
		// Get selected items
		vm.getSelectedItems = function(items){
			var selectedItems = [];
			for(var i = 0; i < items.length; i++){
				var selected = items[i].selected;
				if(selected === true){
					selectedItems.push(items[i]);
				}
			}
			return selectedItems;
		}
	}]);
	
});