'use strict';

define(function(){
	angular.module("core").provider('GenerateOutboundQueryService', function(){
		this.$get =['$http', 'DataAccessService', function($http, dataAccessService){
			var service = {
					getOutboundInterfaceFiles: function(dataSetID, membershipID, successCallBack, errorCallBack){
						var url = 'references/outboundInterfaceFiles/'+ dataSetID + '/' + membershipID;
						dataAccessService.doGetData(url, null, function(response){
							console.log(response.data);
							successCallBack(response);
						},function(errorResponse){
							errorCallBack(errorResponse);
						});
					},
					log: function(logData, successCallBack, errorCallBack){
						var url = 'outbound/log';
						
						return $http.post(url, logData);
					},
					generateOutboundReport: function(outboundReport, outboundParams){
						var reportUrl = 'outbound/create/'+outboundReport;
						
						return $http.post(reportUrl, outboundParams);
					}
			}
			return service;
		}]
	});	
});