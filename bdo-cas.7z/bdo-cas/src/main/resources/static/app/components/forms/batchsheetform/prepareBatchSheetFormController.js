'use strict';

define(function(){
	
	console.log('prepareBatchSheetFormController.js loaded');
	var core = angular.module('core');
	
	core.registerController('prepareBatchSheetFormController',['$rootScope', '$scope', '$uibModal', '$uibModalInstance', 'DataAccessService', '$filter',
		function($rootScope, $scope, $uibModal, $uibModalInstance, dataAccessService, $filter){
		$scope.title = 'Prepare Batch Sheet Form';
		$scope.currencyShortDescriptions = { "currencyShortDescriptions " : [] };
		$scope.currencyShortDescription = "";
		
		var vm = this;
		
		vm.init = function(){
			var dataSetID = $rootScope.dataSetID;
			var username = $rootScope.session['AUTHENTICATED_USER'].username;
			$scope.data = {};
			$scope.userCode = { "userCode " : [] };
			$scope.userProcessInfo = { "userProcessInfo " : [] };
			
			var prepareBatchSheetUrl = 'batchsheet/preparation/'+$rootScope.dataSetCode+'/'+username+'/'+$rootScope.encodingUnitCode;
//			var prepareBatchSheetSummaryUrl = 'batchsheet/preparationsummary/'+dataSetID+'/'+username+'/'+encodingUnit;
			$scope.reportparams = {};
			
			console.log(prepareBatchSheetUrl);
//			console.log(prepareBatchSheetSummaryUrl);
			
			dataAccessService.doGetData(prepareBatchSheetUrl, null, function(response){
				console.log(response);
				$scope.resultSet = response.data.resultSet;
				$scope.columns = response.data.columns;
				
				console.log($scope.resultSet);
				console.log($scope.columns);
//				dataAccessService.doGetData(prepareBatchSheetSummaryUrl, null, function(response){
//					console.log(response);
//					console.log(response.data.resultSet[0]['totalBS']);
//					console.log(response.data.resultSet[0]['totalTx']);
//					$scope.numberOfBatchSheets = response.data.resultSet[0]['totalBS'];
//					$scope.totalNoOfBatchSheetTxn= response.data.resultSet[0]['totalTx'];
//				},function(errorResponse){
//					console.log(errorResponse);
//				});
			},function(errorResponse){
				console.log(errorResponse);
			});
			
			//Get User Code
			var getUserCodeUrl = 'references/userCode/'+$rootScope.dataSetCode;
			dataAccessService.doGetData(getUserCodeUrl, null, function(response){
				console.log(response.data);
				$scope.userCode = response.data;
			},function(errorResponse){
				console.log(errorResponse);
			});
			
			//Get currencies with short descriptions
			var getCurrencyShortDescUrl = 'references/currencyShortDesc/'+$rootScope.dataSetCode;
			dataAccessService.doGetData(getCurrencyShortDescUrl, null, function(response){
				console.log(response.data);
				$scope.currencyShortDescriptions = response.data;
				
			},function(error){
				console.log(error);
			});
			
			//Get userParams
			var getUserProcessInfoUrl = 'references/userProcessInfo/'+$rootScope.dataSetCode;
			dataAccessService.doGetData(getUserProcessInfoUrl, null, function(response){
				console.log(response.data);
				$scope.userProcessInfo = response.data;
				
			},function(error){
				console.log(error);
			});
		}
		
		// Initialize form
		vm.init();
		
		$scope.setSelectedRecord = function(index){
			$scope.selectedRecord = $scope.resultSet[index];
			console.log($scope.selectedRecord);
		}
		
		$scope.doShowControlTotalsForm = function(batchSheetOnly){
			if(!batchSheetOnly){
				if(!$scope.selectedRecord){
					alertify.alert("Please select a batch sheet to be created in order to proceed with this action");
					return false;
				}
			}
			
			
			
			var modalInstance = $uibModal.open({
				animation: true,
				backdrop: 'static',
				templateUrl: 'app/components/forms/batchsheetform/controlTotalsForm.html',
				controller: 'controlTotalsFormController',
				size: 'lg',
				resolve:{
					load: ['$q', function($q){
						var defered = $q.defer();
						require(['app/components/forms/batchsheetform/controlTotalsFormController2'], function(){
							defered.resolve();
						});
						return defered.promise;
					}],
					data : function(){
						var data = {};
						    data.batchSheetOnly = batchSheetOnly;
							data.selectedRecord = $scope.selectedRecord;
						return data;
					}
				}
			});
			
			modalInstance.result.then(function(x){
				vm.init();
			}, 
			function() {				
				// dismissed
				console.log("dismissed");
			});
			
			
			return modalInstance.result;
		};
		
		$scope.doPrintBatchSheet = function(index){
			
			var bookDesc;
			var bookCode;
			var batchSheetType;
			var reportCode = null;
			var reportName = null;
			var exists = false;
			var reportType = 'RPT004';
			
			$scope.selectedRecord = $scope.resultSet[index];
			bookDesc = $scope.selectedRecord["Book"];
			batchSheetType = $scope.selectedRecord["Batchsheet Type"];
			
			$scope.getCurrencyShortDesc($scope.selectedRecord["Currency Code"]);
			
			if(batchSheetType === 'ALL'){
				reportType = 'RPT006';
			}else{
				reportType = 'RPT004';
			}
			
			angular.forEach($rootScope.reports, function(value, key) {
				
				if(!exists){
					if (value.code === reportType) {
						reportCode = value.code;
						reportName = value.name;
						exists = true;
					}
				}
			});
			
			console.log(reportCode + " : " + reportName);
			
			if(bookDesc === 'RBU'){
				bookCode = '1';
			}else
			if(bookDesc === 'FCDU'){
				bookCode = '2';
			}else{
				bookCode = '';
			}
			
			$scope.reportparams["userID"] = $scope.userCode[0].code;
			$scope.reportparams["userName"] = $rootScope.session['AUTHENTICATED_USER'].username;
			$scope.reportparams["dataset"] = $rootScope.dataSetID;
			$scope.reportparams["dataSetCode"] = $rootScope.dataSetCode;
			$scope.reportparams["reportID"] = reportCode;
			$scope.reportparams["processingDate"] = $filter('date')(new Date($scope.selectedRecord["Processing Date"]), 'yyyyMMdd');
			$scope.reportparams["systemDate"] = $filter('date')(new Date(), 'yyyyMMddhhmmssS');
			$scope.reportparams["usersEncodingUnit"] = $scope.userProcessInfo[0].code;
			
			$scope.reportparams["effDate"] = $scope.selectedRecord["Processing Date"];
			$scope.reportparams["bookCode"] = bookCode;
			$scope.reportparams["currencyID"] = $scope.selectedRecord["Currency ID"];
			$scope.reportparams["currencyCode"] = $scope.selectedRecord["Currency Code"];
			$scope.reportparams["batchSheetID"] = "";
			$scope.reportparams["bookDesc"] = $scope.selectedRecord["Book"];
			$scope.reportparams["currencyDesc"] = $scope.currencyShortDescription;
		
			console.log($scope.reportparams);
			
			var reportUrl = 'batchsheet/preparation/'+reportName+bookDesc+'_pdf';
			var downloadUrl = 'reports/download/'+reportName+bookDesc+'_pdf';
			console.log('URL: ' + reportUrl);
			
			alertify.confirm("Do you really want to print a BatchSheet Report?", function(e){
				
				if(e){
					dataAccessService.doPostData(reportUrl, $scope.reportparams, function(response){
						console.log(response);
						alertify.alert(reportName + 'Report successfully generated.');
//							alertify.confirm('Report successfully generated. Do you want to download report?', function(e) {
//								if (e) {
//									console.log(downloadUrl+'?file='+response.data.filename);
//									window.location.href=downloadUrl+'?file='+response.data.filename;
//								}else{
//									return;
//								}
//							});
						
					},function(errorResponse){
						console.log(errorResponse);
						alertify.alert(reportName + ' Report Generation Failed.');
					});
				}else{
					return;
				}
				
			});
		};
		
		$scope.save = function(){
			console.log($scope.data);
			console.log($scope.selectedRecord);
			
			if(!$scope.selectedRecord){
				alertify.alert("Please select a batch sheet to be prepared.");
				return false;
			}
			
			
			alertify.confirm("This action creates this batch sheet for approval. " +
					"Are you sure you want to proceed?", function(e){
				if(e){			
					var url = "batchsheet/save/";	
					$scope.data.encodingUnitCode = $rootScope.encodingUnitCode;
					$scope.data.dataSetCode = $rootScope.dataSetCode;
					$scope.data.effectiveDate = $scope.selectedRecord['Processing Date'];
					$scope.data.bookCodeID = $scope.selectedRecord['Book ID'];
					$scope.data.currencyID = $scope.selectedRecord['Currency ID'];
					console.log($scope.data);
					dataAccessService.doPostData(url, $scope.data, function(response){
						console.log(response);
						alertify.alert(response.data.messageMap['successMsg']);
						$uibModalInstance.close($scope.data);
					},function(errorResponse){
						console.log(errorResponse);
						alertify.alert(errorResponse.data.errorMsg);
					});
			
				}
			});
			
		};
		
		$scope.close = function() {
			alertify.confirm("This action closes the form you are viewing. " +
					"Are you sure you want to proceed?", function(e){
					if(e){
						$uibModalInstance.dismiss();
					}else{
						return;
					}
				});
		};
		
		$scope.getCurrencyShortDesc = function(currencyCode){
			
			console.log($scope.currencyShortDescriptions);
			
			var exists = false;
			
			angular.forEach($scope.currencyShortDescriptions, function(value, key) {
				
				if(!exists){
					if (value.code === currencyCode) {
						
						$scope.currencyShortDescription = (value.desc);
						
						exists = true;
					}
				}
				
			});
			
			console.log("CurrencyShortDescription: " + $scope.currencyShortDescription);
		};
		
		
	}]);
	
});