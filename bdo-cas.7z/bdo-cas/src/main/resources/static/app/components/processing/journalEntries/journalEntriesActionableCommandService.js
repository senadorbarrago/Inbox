'use strict';

define(function(){
	angular.module("core").provider('JournalEntriesActionableCommandService', function(){
		this.$get =['DataAccessService', function(dataAccessService){
			var service = {
				submitForm: function(batchIDs, successCallBack, errorCallBack) {
					var url  = "journalentry/submit";
					dataAccessService.doPostData(url, batchIDs, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				approveForm: function(batchIDs, successCallBack, errorCallBack) {
					var url  = "journalentry/approve";
					dataAccessService.doPostData(url, batchIDs, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				denyForm: function(batchIDs, successCallBack, errorCallBack) {
					var url  = "journalentry/deny";
					dataAccessService.doPostData(url, batchIDs, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				deleteForm: function(batchIDs, successCallBack, errorCallBack) {
					var url  = "journalentry/delete";
					dataAccessService.doPostData(url, batchIDs, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				}
			}
			return service;
		}]
	});	
});