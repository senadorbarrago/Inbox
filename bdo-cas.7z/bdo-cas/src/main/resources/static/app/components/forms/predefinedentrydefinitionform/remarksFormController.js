'use strict';

define(function(){
	
	console.log('remarksFormController.js loaded');
	var core = angular.module('core');
	
	core.registerController('remarksFormController', ['$rootScope', '$scope', '$uibModalInstance', 'DataAccessService', 'data', '$http', 'RemarksFormQueryService', 
	                                                  function($rootScope, $scope, $uibModalInstance, dataAccessService, data, $http, remarksFormQueryService){
		$scope.title = 'Remarks';
		$scope.batchIDs = data.batchIDs;
		$scope.sourceType = data.sourceType;
		$scope.user = $rootScope.session["AUTHENTICATED_USER"];
		$scope.membership = $rootScope.session['AUTHENTICATED_USER'].activeMembership.membershipID;
		console.log($scope.membership);
		var vm = this;
	
		vm.init = function(){
			console.log($scope.batchIDs);
			$scope.initializeRemarks();
		}
		
		$scope.doAddRemarks = function() {
			
			$scope.addRemarksParam = {};
				
			console.log("batchAddRemarks()");
			
			$scope.addRemarksParam["dataset"] = $rootScope.dataSetID;
			$scope.addRemarksParam["sourceID"] = $scope.batchIDs;
			$scope.addRemarksParam["sourceType"] = $scope.sourceType;
			$scope.addRemarksParam["remarks"] = $scope.txtAddRemarks;
			$scope.addRemarksParam["membershipID"] = $scope.membership.id;
			$scope.addRemarksParam["userName"] = $scope.user.username;
			
			if($scope.txtAddRemarks != '' && $scope.txtAddRemarks != null){
				remarksFormQueryService.batchAddRemarks($scope.addRemarksParam)
				.then(function(response){
					console.log("remarksFormQueryService: batchAddRemarks()");
					console.log(response);
					$scope.txtAddRemarks = '';
					$scope.initializeRemarks();
				}).catch(function(error){
					console.log(error);
				});
			}
			
			
			
		};
		
		$scope.initializeRemarks = function(){
			
			if($scope.batchIDs.length === 1){
				
				console.log("initializeRemarks()");
				
				remarksFormQueryService.viewRemarks($rootScope.dataSetID, $scope.batchIDs[0], $scope.sourceType, function(response){
					console.log("remarksFormQueryService: viewRemarks()");
					console.log(response);
					$scope.txtRemarks = response.data.resultSet
				}, function(error){
					console.log(error);
				});
			} else{
				
				console.log("not initializeRemarks()");
			}
		};
		
		$scope.close = function(){
			$uibModalInstance.close();
		};
		
		vm.init();
	
	}]);
});