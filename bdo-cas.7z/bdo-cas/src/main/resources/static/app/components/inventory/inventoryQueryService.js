'use strict';

define(function(){
	angular.module("core").provider('InventoryQueryService', function(){
		this.$get =['$http', 'DataAccessService', function($http, dataAccessService){
			var service = {
				getInventoryList: function(data, successCallBack, errorCallBack) {
					var url  = 'inventory/result';
					return $http.post(url, data);
				},
				getColumnList: function(dataSetID, recordProfileID, successCallBack, errorCallBack) {
					var url  = 'transactions/columns/'+dataSetID+'/'+recordProfileID;
					dataAccessService.doGetData(url, null, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getTransactionsInventory: function(dataSetCode, pageIndex, pageSize, searchCriteria, successCallBack, errorCallBack) {
					var url  = 'inventory/transactions/'+dataSetCode+'/'+pageIndex+'/'+pageSize+'/';
					dataAccessService.doPostData(url, searchCriteria, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getTakeUpsInventory: function(dataSetCode, pageIndex, pageSize, searchCriteria, successCallBack, errorCallBack) {
					var url  = 'inventory/takeUps/'+dataSetCode+'/'+pageIndex+'/'+pageSize+'/';
					dataAccessService.doPostData(url, searchCriteria, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getJournalEntriesInventory: function(dataset, recordProfileID, pageIndex, pageSize, searchCriteria, successCallBack, errorCallBack) {
					var url  = 'inventory/journalEntries/'+dataset+'/'+recordProfileID+'/'+pageIndex+'/'+pageSize+'/';
					dataAccessService.doPostData(url, searchCriteria, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getBatchSheetsInventory: function(dataSetCode, pageIndex, pageSize, searchCriteria, successCallBack, errorCallBack) {
					var url  = 'inventory/batchSheet/'+dataSetCode+'/'+pageIndex+'/'+pageSize+'/';
					dataAccessService.doPostData(url, searchCriteria, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				generateNCReport: function(dataSetCode, pageIndex, pageSize, searchCriteria, successCallBack, errorCallBack) {
					var reportCode = "TransactionInventory_csv";
					var url  = 'inventory/transactions/generate/'+reportCode+"/"+dataSetCode+'/'+pageIndex+'/'+pageSize+'/';
					dataAccessService.doPostData(url, searchCriteria, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				generateJEReport: function(dataset, recordProfileID, pageIndex, pageSize, searchCriteria, successCallBack, errorCallBack) {
					var reportCode = "JournalEntryInventory_csv";
					var url  = 'inventory/journalEntries/generate/'+reportCode+"/"+recordProfileID+"/"+dataset+'/'+pageIndex+'/'+pageSize+'/';
					dataAccessService.doPostData(url, searchCriteria, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				}
			}
			return service;
		}]
	});	
});