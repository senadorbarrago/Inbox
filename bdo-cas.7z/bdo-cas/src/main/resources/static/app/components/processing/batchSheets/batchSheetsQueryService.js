'use strict';

define(function(){
	angular.module("core").provider('BatchSheetsQueryService', function(){
		this.$get =['$http', '$rootScope', 'DataAccessService', function($http, $rootScope, dataAccessService){
			var service = {
				getBatchSheetList: function(data, successCallBack, errorCallBack) {
					var url = 'batchsheet/list';
//					dataAccessService.doPostData(url, data, function(response){
//						successCallBack(response);
//					},function(errorResponse){
//						errorCallBack(errorResponse);
//					});
					return $http.post(url, data);
				},
				getBookCodeList: function(dataSetID, successCallBack, errorCallBack) {
					var url  = 'references/bookCodeByDataSetID/'+dataSetID;
					dataAccessService.doGetData(url, null, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getCurrencyReferenceListByBookCode: function(bookCode, successCallBack, errorCallBack) {
					var url  = 'references/currencyByBookCode/'+bookCode;
					dataAccessService.doGetData(url, null, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getProcessors: function(successCallBack, errorCallBack) {
					var data  = {
							     	'username' : $rootScope.session['AUTHENTICATED_USER'].username,
							     	'roleCode' : $rootScope.session['AUTHENTICATED_USER'].activeMembership.role.code,
							     	'groupCode' : $rootScope.session['AUTHENTICATED_USER'].activeMembership.group.code,
								}; 
					dataAccessService.doQuery('ProcessorListQueryModel', data, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getTakeUpsByBatchSheetID: function(batchSheetID, successCallBack, errorCallBack) {
					var url  = 'batchsheet/takeups/'+batchSheetID;
					dataAccessService.doGetData(url, null, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getColumnList: function(dataSetID, recordProfileID, successCallBack, errorCallBack) {
					var url  = 'transactions/columns/'+dataSetID+'/'+recordProfileID;
					dataAccessService.doGetData(url, null, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getUserCode: function(dataSetCode, successCallBack, errorCallBack){
					var url = 'references/userCode/'+dataSetCode;
					dataAccessService.doGetData(url, null, function(response){
						console.log(response.data);
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getUserProcessInfo: function(dataSetCode, successCallBack, errorCallBack){
					var url = 'references/userProcessInfo/'+dataSetCode;
					dataAccessService.doGetData(url, null, function(response){
						console.log(response.data);
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				}
			}
			return service;
		}]
	});	
});