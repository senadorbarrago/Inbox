'use strict';

define(function(){
	
	console.log('homeController.js loaded');
	var core = angular.module('core');
	
	core.registerController('homeController', ['$rootScope', '$scope', '$cookies', 'DataAccessService', 
		function($rootScope, $scope, $cookies, dataAccessService){
		$scope.title = 'This is the Home screen';
		$rootScope.screenName = 'Home'
	
		console.log('authenticated: '+$rootScope.session['AUTHENTICATED']);
		
		var vm = this;

		vm.init = function(){
			$rootScope.$broadcast("initializeAuthority");
//			var groupID = $rootScope.session['AUTHENTICATED_USER'].activeMembership.groupID;
//			var getDataSetUrl = 'references/dataSetByGroupID/'+groupID;
//			dataAccessService.doGetData(getDataSetUrl, null, function(response){
//				$rootScope.dataSetID = response.data[0].id;
//				$rootScope.dataSetCode = response.data[0].code;
//				$cookies.put("DATA_SET_ID", $rootScope.dataSetID);
//				$cookies.put("DATA_SET_CODE", $rootScope.dataSetCode);
//				console.log("DATA_SET_ID: "+$cookies.get('DATA_SET_ID'));
//				var getCostCenterUrl = 'references/costCenterByGroupID/'+groupID;
//				dataAccessService.doGetData(getCostCenterUrl, null, function(response){
//					$rootScope.costCenterID = response.data[0].id;
//					$rootScope.encodingUnitCode = response.data[0].code;
//					$cookies.put("COST_CENTER_ID", $rootScope.costCenterID);
//					$cookies.put("COST_CENTER_CODE", $rootScope.encodingUnitCode);
//					console.log("COST_CENTER_ID: "+$cookies.get('COST_CENTER_ID'));
//					console.log($rootScope.session);
//					vm.initProcessInfo();
//				}, function(errorResponse){
//					console.log(errorResponse.status+': '+errorResponse.headers("ERROR_MESSAGE"));
//				});
//			}, function(errorResponse){
//				console.log(errorResponse.status+': '+errorResponse.headers("ERROR_MESSAGE"));
//			});
//			
//			console.log($rootScope.session['AUTHENTICATED_USER']);
//			vm.initMenu();
//			vm.initBtn();
//			vm.initRpt();
//			vm.initOif();
//			vm.initInf();
//			
		}
		
		vm.initMenu = function(){ 
			var resourcePattern = 'menu'
			var url = 'security/resource/'+resourcePattern;
			dataAccessService.doGetData(url, null, function(response){
				console.log(response.data);
				$rootScope.session["MENU"] = response.data;
				console.log($rootScope.session["MENU"]);
//				$rootScope.apply();
//				$rootScope.$broadcast('menuAcquired', response.data);
			}, function(errorResponse){
				console.log(errorResponse.status+': '+errorResponse.headers("ERROR_MESSAGE"));
				//alertify.fail(errorResponse.status+': '+errorResponse.headers("ERROR_MESSAGE"));
			});
		}
		
		vm.initBtn = function(){
			var resourcePattern = 'btn'
			var url = 'security/resource/'+resourcePattern;
			dataAccessService.doGetData(url, null, function(response){
				console.log(response.data);
				$rootScope.session["BUTTON"] = response.data;
			}, function(errorResponse){
				console.log(errorResponse.status+': '+errorResponse.headers("ERROR_MESSAGE"));
				//alertify.fail(errorResponse.status+': '+errorResponse.headers("ERROR_MESSAGE"));
			});
		}
		
		vm.initRpt = function(){
			var resourcePattern = 'rpt'
			var url = 'security/resource/'+resourcePattern;
			dataAccessService.doGetData(url, null, function(response){
				console.log(response.data);
				$rootScope.session["REPORT"] = response.data;
			}, function(errorResponse){
				console.log(errorResponse.status+': '+errorResponse.headers("ERROR_MESSAGE"));
				//alertify.fail(errorResponse.status+': '+errorResponse.headers("ERROR_MESSAGE"));
			});
		}
		
		vm.initOif = function(){
			var resourcePattern = 'oif'
			var url = 'security/resource/'+resourcePattern;
			dataAccessService.doGetData(url, null, function(response){
				console.log(response.data);
				$rootScope.session["OUTBOUND"] = response.data;
			}, function(errorResponse){
				console.log(errorResponse.status+': '+errorResponse.headers("ERROR_MESSAGE"));
				//alertify.fail(errorResponse.status+': '+errorResponse.headers("ERROR_MESSAGE"));
			});
		}
		
		vm.initInf = function(){
			var resourcePattern = 'inf'
			var url = 'security/resource/'+resourcePattern;
			dataAccessService.doGetData(url, null, function(response){
				console.log(response.data);
				$rootScope.session["INFO"] = response.data;
			}, function(errorResponse){
				console.log(errorResponse.status+': '+errorResponse.headers("ERROR_MESSAGE"));
				//alertify.fail(errorResponse.status+': '+errorResponse.headers("ERROR_MESSAGE"));
			});
		}
		
		vm.initProcessInfo = function(){
			var url = 'references/processingInfo/'+$rootScope.dataSetCode+'/'+$rootScope.encodingUnitCode;
			dataAccessService.doGetData(url, null, function(response){
				console.log(response.data);
				$rootScope.session["PROCESSINFO"] = response.data.resultSet[0];
				
				$cookies.put("processDate", $rootScope.session["PROCESSINFO"].processDate);
				$cookies.put("processCode", $rootScope.session["PROCESSINFO"].processCode);
				$cookies.put("processDescription", $rootScope.session["PROCESSINFO"].processDescription);
			}, function(errorResponse){
				console.log(errorResponse.status+': '+errorResponse.headers("ERROR_MESSAGE"));
				//alertify.fail(errorResponse.status+': '+errorResponse.headers("ERROR_MESSAGE"));
			});
		}
		
		// Initialize
		vm.init();
		
	}]);
	
});