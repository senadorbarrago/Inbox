'use strict';

define(function(){
	console.log('jeInventoryController.js loaded');
	var core = angular.module('core');
	
	core.registerController('jeInventoryController',['$rootScope', '$scope', '$uibModal', 'DataAccessService', 'ngTableParams', '$filter', '$http', 'InventoryQueryService',  
		function($rootScope, $scope, $uibModal, dataAccessService, ngTableParams, $filter, $http, inventoryQueryService){
		$rootScope.screenName = 'Inventory --> Journal Entries';
		
		var vm = this;
		
		/**
		 * init
		 * 
		 */
		vm.init = function () {
			$scope.data = {};
			$scope.form = {};
			$scope.reference = {};
			$scope.data.inventoryCode = 'INV-002';
			$scope.data.dataSetID = $rootScope.dataSetID;
			$scope.data.dataSetCode = $rootScope.dataSetCode;
			$scope.data.costCenterID = $rootScope.costCenterID;
			$scope.data.pageSize = 50;
			$scope.data.pageIndex = 1;
			
			$scope.inventoryTypeList = [
											{
												 "heading"	: "Transactions",
												 "url"	    : "inventory/transactions",
												 "selected" : false
											 },
											 {
												 "heading"  : "Take Ups",
												 "url"	    : "inventory/takeups",
												 "selected" : false
											 },
											 {
												 "heading"  : "Journal Entries",
												 "url"	    : "inventory/journalentries",
												 "selected" : true
											 },
											 {
												 "heading"  : "Batch Sheet",
												 "url"	    : "inventory/batchsheets",
												 "selected" : false
											 }
										];
			
			//Search
			$scope.form.searchcriteria = {};
			$scope.form.searchcriteria.data = {};
			$scope.form.searchcriteria.data.filterList = [];
			$scope.form.searchcriteria.data.sortList = [];
			$scope.form.datagrid = {};
			
			vm.getFieldList();
			vm.loadPage();
		}
		
		/**
		 * Get filter field list
		 */
		vm.getFieldList= function(){
			inventoryQueryService.getColumnList($scope.data.dataSetID, 9, function(response){
				$scope.form.searchcriteria.dataFieldList = [];
				angular.forEach(response.data.resultSet, function(value, key) {
						$scope.form.searchcriteria.dataFieldList.push(value);
				});
			}, function(error){
				console.log(error);
			});
		};
		
		/**
		 * Load data grid
		 */
		vm.loadPage = function() {
			$scope.tableParams = new ngTableParams(
					{	page: 1,
						count: 25
					},
					{	getData: function ($defer, params) {
						return inventoryQueryService.getJournalEntriesInventory($scope.data.dataSetID, 40,
								params.page(), params.count(), $scope.form.searchcriteria.data, function (response) {
								$scope.form.resultmodel = response.data;
								params.total($scope.form.resultmodel.resultOverAllCount);
								$defer.resolve($scope.form.resultmodel.resultSet);
							}, function(response) {});
						}
					}
			);
		};
		
		/**
		 *  Search Panel
		 * 
		 */
		$scope.selectFilterField = function(){
			console.log($scope.form.searchcriteria.filterField);
		};
		
		/**
		 * Add Search Filter
		 */
		$scope.doAddFilter = function(){
			if(!$scope.form.searchcriteria.filterField){
				alertify.alert("Please select a filter field in order to proceed.");
				return false;
			}
			
			var record = {"id":$scope.form.searchcriteria.filterField.dataFieldID, "fieldName":$scope.form.searchcriteria.filterField.fieldName, "fieldLabel":$scope.form.searchcriteria.filterField.label , "hasRange":$scope.form.searchcriteria.filterField.hasRange, "valueFrom":"", "valueTo":""};
			var isExists = false;
			
			angular.forEach($scope.form.searchcriteria.data.filterList, function(value, key){
				if(!isExists){
					if(value.id === $scope.form.searchcriteria.filterField.dataFieldID){
						isExists = true;
					}
				}
			});
			
			if(!isExists){
				$scope.form.searchcriteria.data.filterList.push(record);
			}
		};
		
		/**
		 * Remove Search Filter
		 * 
		 */
		$scope.removeFilter = function(index){
			var item = $scope.form.searchcriteria.data.filterList[index];
			$scope.form.searchcriteria.data.filterList.splice(index, 1);
		};
		
		/**
		 * Clear Filter Fields
		 * 
		 */
		$scope.doClearFilterFields = function(){
			$scope.form.searchcriteria.filterField = {};
			$scope.form.searchcriteria.data.filterList = [];
		};
		
		/**
		 * Select Sort Field
		 * 
		 */
		$scope.selectSortField = function(){
			console.log($scope.form.searchcriteria.sortField);
		};
		
		/**
		 * Add Sort Field
		 * 
		 */
		$scope.doAddSort = function(){
			if(!$scope.form.searchcriteria.sortField){
				alertify.alert("Please select a sort field in order to proceed.");
				return false;
			}
			
			var record = {"id":$scope.form.searchcriteria.sortField.dataFieldID, "fieldName":$scope.form.searchcriteria.sortField.fieldName, "fieldLabel":$scope.form.searchcriteria.sortField.label, "order":"1", "valueFrom":"ASC"};
			var isExists = false;
			
			angular.forEach($scope.form.searchcriteria.data.sortList, function(value, key){
				if(!isExists){
					if(value.id === $scope.form.searchcriteria.sortField.dataFieldID){
						isExists = true;
					}
				}
			});
			
			if(!isExists){
				$scope.form.searchcriteria.data.sortList.push(record);
			}
		};
		
		/**
		 * Remove Sort Field
		 * 
		 */
		$scope.removeSort = function(index){
			var item = $scope.form.searchcriteria.data.sortList[index];
			$scope.form.searchcriteria.data.sortList.splice(index, 1);
		};
		
		/**
		 * Clear Sort Fields
		 * 
		 */
		$scope.doClearSortFields = function(){
			$scope.form.searchcriteria.sortField = {};
			$scope.form.searchcriteria.data.sortList = [];			
		};
		
		/**
		 * Clear all filter and sort fields
		 * 
		 */
		$scope.doClearAll = function(){
			$scope.doClearFilterFields();
			$scope.doClearSortFields();
		};
		
		/**
		 * Show all records
		 */
		$scope.doShowAll = function(){
			$scope.doClearAll();
			
			// Reset pageSize and pageIndex
			$scope.tableParams.page(1);
			$scope.tableParams.count(25);

			//Reload Paginated Request
			$scope.tableParams.reload();
		}
		
		/**
		 * Search for record/s
		 * 
		 */
		$scope.doSearch = function(){			
			//Revert to page 1
			$scope.tableParams.page(1);
			//Reload Paginated Request
			$scope.tableParams.reload();
		};
		
		/**
		 * Call init()
		 * 
		 */ 
		vm.init();		
		
		/**
		 * Generate report
		 * 
		 */ 
		$scope.doGenerateReport = function(){
			inventoryQueryService.generateJEReport($scope.data.dataSetID, 9,
						1, 1000000, $scope.form.searchcriteria.data, function (response) {
			 	$scope.resultMessage = response.data;
				$scope.message = $scope.resultMessage.messageMap;
				
				if($scope.message.successMsg!=undefined && $scope.message.successMsg!=null){
					alertify.alert($scope.message.successMsg);
					$scope.requestStatus = $scope.reportDescription + ' generation successful!';
					
				}else if($scope.message.errorMsg!=undefined && $scope.message.errorMsg!=null){
					alertify.alert($scope.message.errorMsg);
					$scope.requestStatus = $scope.reportDescription + ' generation failed!';
				}
				
			},function(errorResponse){
				alertify.alert('Error Occurred.');
				$scope.requestStatus = $scope.reportDescription + ' generation failed!';
			});
		};
		
		/**
		 * Show journal entry form
		 * 
		 */
		$scope.doShowJournalEntryForm = function(batchID){
			var modalInstance = $uibModal.open({
				animation: true,
				backdrop: 'static',
				templateUrl: 'app/components/forms/journalentryform/viewJournalEntryForm.html',
				controller: 'journalEntryFormController',
				size: 'lg',
				resolve:{
					data:function(){
						var data = {};
						data.header = {};
						data.header.batchID = batchID;
						data.sourceType = 'JE';
						data.fromInventory = true;
						return data;
					},
					load: ['$q', function($q){
						var defered = $q.defer();
						require(['app/components/forms/journalentryform/journalEntryFormController'], function(){
							defered.resolve();
						});
						return defered.promise;
					}]
				}
			});
			
			modalInstance.result.then(
				function(message) {
					//Reload Paginated Request
					$scope.tableParams.reload();
				}, 
				function() {				
					// dismissed
					console.log("dismissed");
				}
			);
			return modalInstance.result;
			
		};
		
	}]);
	
});