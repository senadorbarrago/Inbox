'use strict';

define(function(){
	
	console.log('generateOutboundController.js loaded');
	var core = angular.module('core');
	
	core.registerController('generateOutboundController', ['$rootScope', '$scope', 'DataAccessService', 'JournalEntryFormQueryService', 'GenerateOutboundQueryService', '$filter', function($rootScope, $scope, dataAccessService, journalEntryFormQueryService, generateOutboundQueryService, $filter){
		$scope.title = 'This is the Generate Outbound Screen';
		$rootScope.screenName = 'OUTBOUND_INTERFACE';
		
		$scope.user = $rootScope.session["AUTHENTICATED_USER"];
		$scope.membership = $rootScope.session['AUTHENTICATED_USER'].activeMembership.membershipID;

		$scope.dataset = $rootScope.dataSetID;
		
		var vm = this;
		
		vm.init = function(){
			
			console.log('generateOutboundController: init() called');
			console.log($rootScope.outbounds);
			
			
			$scope.outboundParams = {};
			$scope.outboundName = null;
			$scope.outboundDesc = null;
			$scope.outboundReport = null;
			$scope.outboundCode = null;
			$scope.resultMessage = [];
			$scope.message = [];
			$scope.outboundICode = '';
			$scope.outboundIDesc = '';
			$scope.outboundFiles = $rootScope.outbounds;
			$scope.outboundInterfaces = {};
			
			//Get Outbound Files
//			generateOutboundQueryService.getOutboundInterfaceFiles($scope.dataset, $scope.membership, function(response){
//				console.log('get Outbound Interface Files:');
//				console.log(response.data);
//				$scope.outboundFiles = response.data.resultSet;
//				$scope.outbounds = $scope.outboundFiles;
//				
//			},function(error){
//				console.log(error);
//			});
			
			//Get Encoding Units
			journalEntryFormQueryService.getEncodingUnits(function(response){
				console.log('getEncodingUnits');
				console.log(response.data);
				$scope.encodingUnits = response.data;
				
			},function(error){
				console.log(error);
			});
			
			//Get BookCodes
			journalEntryFormQueryService.getBookCodeByDataSet($rootScope.dataSetCode, function(response){
				console.log('getBookCode');
				$scope.bookCodes = response.data;
				console.log($scope.bookCodes);
				
			},function(error){
				console.log(error);
			});
			
			
			generateOutboundQueryService.getOutboundInterfaceFiles($scope.dataset, $scope.membership, function(response){
				console.log('getOIF');
				$scope.outboundInterfaces = response.data.resultSet;
				console.log($scope.outboundInterfaces);
				
			},function(error){
				console.log(error);
			});
			
			
			// Date Picker Setup
			$scope.datePicker = { };
			$scope.dateOptions = {
					startingDay : 1,
					showWeeks : false,	
					format : "yyyy-MM-dd"
			};
			
			$scope.currentDate = $rootScope.session["PROCESSINFO"].processDate;
			
			console.log("Current Date: " + $scope.currentDate);
		};
		
		vm.init();
		
		$scope.open = function(columnName, $event){
			
			$event.preventDefault();
			$event.stopPropagation();
			
			if ($scope.datePicker[columnName]) {
				if ($scope.datePicker[columnName].opened) {
					$scope.datePicker[columnName].opened = false;
				}
			} else {
				$scope.datePicker = {};
				$scope.datePicker[columnName] = {};
				$scope.datePicker[columnName].opened = true;
			}
		};
		
		$scope.doViewFile = function(){
			
			console.log("doViewFile");
			
			console.log("UserName: " + $scope.user.username);
			console.log("Dataset: " + $scope.dataset);
			console.log("OutboundFileID: " + $scope.outboundProfileID);
			console.log("EncodingUnit: " + $scope.encodingUnit);
			console.log("Book Code: " + $scope.bookCode);
			console.log("Processed Date: " + $scope.glDate);
			
		};
		
		$scope.doGenerateFile = function(){
			
			console.log("doGenerateFile()");

			$scope.outboundParameters["userName"] = $scope.user.username;
			$scope.outboundParameters["dataset"] = $scope.dataset;
			$scope.outboundParameters["outboundProfileID"] = $scope.outboundProfileID;
			$scope.outboundParameters["reportID"] = $scope.outboundProfileID;
			$scope.outboundParameters["outboundFileName"] = $scope.outboundName;
			$scope.outboundParameters["proofList"] = $scope.outboundReport;
			$scope.outboundParameters["dateGenerated"] = $filter('date')($scope.outboundParams['processingDate'], 'yyyyMMdd');
			if($scope.outboundParameters["bookCode"] === undefined || $scope.outboundParameters["bookCode"] === null){
				$scope.outboundParameters["bookCode"] = "";
			}
			
			$scope.outboundParameters["recordProfileID"] = $scope.outboundProfileID;
			$scope.outboundParameters["param1"] = $scope.outboundParams['processingDate'];
			$scope.outboundParameters["param2"] = $scope.outboundParams['encodingUnit'];
			$scope.outboundParameters["param3"] = $scope.outboundCode;
			
			console.log($scope.outboundParams);
			console.log($scope.outboundParameters);
			
			//Outbound File Generation
			var outboundUrl = 'outbound/create/'+$scope.outboundName;
			
			alertify.confirm("Do you really want to Generate Outbound File?", function(e){
				
				if(e){
					console.log('Ooo--------------------------->Generating<---------------------------ooO');
					$scope.requestStatus = $scope.outboundDesc + ' generation ongoing...';
					dataAccessService.doPostData(outboundUrl, $scope.outboundParameters, function(response){
						console.log(response);
						$scope.resultMessage = response.data;
						$scope.message = $scope.resultMessage.messageMap;
						
						if($scope.message.successMsg){
							alertify.alert($scope.message.successMsg);
							$scope.requestStatus = $scope.outboundDesc + ' generation successful!';
						}else
						if($scope.message.errorMsg){
							alertify.alert($scope.message.errorMsg);
							$scope.requestStatus = $scope.outboundDesc + ' generation failed!';
						}
						
					},function(errorResponse){
						console.log(errorResponse);
						alertify.alert($scope.outboundDesc + ' generation failed.');
						$scope.requestStatus = $scope.outboundDesc + ' generation failed!';
					});
					
				}else{
					return;
				}
			});
			
		};
		
		// Get outbound parameters from the config file
		$scope.getOutboundParams = function(){
			
			$scope.parameters = null;
			$scope.parametersStr = null;
			$scope.outboundParams = {};
			$scope.logParams = {};
			$scope.encodingUnit = null;
			$scope.bookCode = null;
			$scope.glDate = null;
			
			$scope.requestStatus = '';
			
			var outboundProfileID = $scope.outboundProfileID;
			var exists = false;
			
			angular.forEach($scope.outboundInterfaces, function(value, key){
				
				if(!exists){
					if(outboundProfileID == value.profileID){
						console.log(outboundProfileID + '=' + value.profileID);
						$scope.outboundName = value.reportCode;
						$scope.outboundCode = value.code;
						$scope.outboundDesc = value.description;
						$scope.outboundReport = value.report;
						$scope.parametersStr = value.parameters;
						console.log("Interface File Name: " + $scope.outboundName);
						
						exists = true;
					}
				}
				
			});
			
			$scope.parameters = angular.fromJson($scope.parametersStr);
			console.log($scope.parameters);
			
			$scope.options = [];
			angular.forEach($scope.parameters, function(value, key){
				
				if(value.name === 'criteria'){
					$scope.options = (value.options);
				}
				
				if(value.type === 'date' && value.value === 'default'){
					
					$scope.outboundParams[value.name] = new Date($scope.currentDate);
				}
				
				if(value.isField === 'false' && value.value === 'none'){
					$scope.outboundParams[value.name] = '';
				}
			});
			
			/*
			angular.forEach($scope.outboundFiles, function(value, key){
				
				if(!exists){
					if(outboundProfileID === value.profileID){
						$scope.outboundName = value.code;
						$scope.outboundCode = value.resource;
						$scope.outboundDesc = value.description;
						$scope.outboundReport = value.report;
						console.log("Interface File Name: " + $scope.outboundName);
						
						exists = true;
					}
				}
				
			});
			
			console.log('[outbound-config-file.json]');
			var outboundCode = null;
			var parameters = null;
			var outboundExists = false;
			var outboundExists = false;
			
			angular.forEach($rootScope.outbounds, function(value, key){
				
				if(!outboundExists){
					if (value.description === $scope.outboundDesc) {
						$scope.parameters = [];
						$scope.outboundICode = value.code;
						$scope.outboundIDesc = value.description;
						
						$scope.parameters = (value.parameters);
						console.log(value.parameters);
						$scope.options = [];
						angular.forEach($scope.parameters, function(value, key){
							
							if(value.name === 'criteria'){
								$scope.options = (value.options);
							}
							
							if(value.type === 'date' && value.value === 'default'){
								
								$scope.outboundParams[value.name] = new Date($scope.currentDate);
							}
							
							if(value.isField === 'false' && value.value === 'none'){
								$scope.outboundParams[value.name] = '';
							}
						});
						outboundExists = true;
					}
				}
				
			});*/
			
			$scope.requestStatus = '';
		};
		
		// check the parameters if has undefined
		$scope.validateParams = function(){
			
			console.log('validateParams()');
			
			$scope.isValid = false;
			$scope.invalidFields = '';
			var invalidCount = 0;
			
			angular.forEach($scope.parameters, function(value, key){
				
				if(value.isField === 'true'){
					console.log(' -' + value.name + '=' + $scope.outboundParams[value.name]);
					if($scope.outboundParams[value.name] === undefined){
						invalidCount = invalidCount + 1;
						$scope.invalidFields = $scope.invalidFields + value.name + ', ';
					}
				}
			});
			
			if(invalidCount === 0){
				$scope.isValid = true;
			}else{
				$scope.isValid = false;
				$scope.invalidFields = $scope.invalidFields.slice(0, $scope.invalidFields.length-2);
			}
		};
		
		$scope.formatParams = function(){
			
			console.log('formatParams()');
			
			$scope.outboundParameters = angular.copy($scope.outboundParams);
			
			angular.forEach($scope.parameters, function(value, key){
				
				if(value.type === 'date'){
					$scope.outboundParameters[value.name] = $filter('date')($scope.outboundParameters[value.name], 'MM/dd/yyyy');
				}
			});
		};
		
		$scope.doGenerate = function(){
			
			var stext = "[{ \"name\" : \"encodingUnit\", \"label\" : \"Encoding Unit:\", \"type\" : \"select\", \"isField\" : \"true\"  },{ \"name\" : \"processingDate\", \"label\" : \"Processing Date:\", \"type\" : \"date\", \"isField\" : \"true\", \"value\" : \"default\" }]";
				
			console.log(stext);
				
			var sjson = angular.fromJson(stext);
				
			console.log(sjson);
			
			console.log($scope.outboundFiles);
			console.log($scope.outboundInterfaces);
			
			console.log("doGenerate()");
			console.log($scope.outboundParams);
			
			if($scope.outboundProfileID != "" && $scope.outboundProfileID != null){
				
				$scope.validateParams();
				$scope.formatParams();
				$scope.setProperties();
				if($scope.isValid === true){
					$scope.setProperties();
					$scope.doGenerateFile();
				}else{
					alertify.alert("Please select " + $scope.invalidFields + ".");
				}
				
			}else{
				alertify.alert("Please select an interface file!");
			}
		};
		
		$scope.setProperties = function(){
			
			console.log('test()');
			
			angular.forEach($scope.outboundInterfaces, function(value, key){
				
				if(value.code === $scope.outboundCode){
					$scope.outboundParameters['fileNameConvention'] = value.fileNameConvention;
					$scope.outboundParameters['destinationPath'] = value.destinationPath;
				}
			});
		};
		
	}]);
	
});