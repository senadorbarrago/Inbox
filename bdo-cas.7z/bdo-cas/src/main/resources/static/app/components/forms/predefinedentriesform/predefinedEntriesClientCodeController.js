'use strict';

define(function(){
	var core = angular.module('core');
	
	core.registerController('predefinedEntriesClientCodeController',['$rootScope', '$scope', '$uibModalInstance', '$uibModal', 'data', 'DataAccessService', '$filter',
	                                                     function($rootScope, $scope, $uibModalInstance, $uibModal, data, dataAccessService, $filter){
	    $scope.title = 'Predefined Entries Client Code Form';
		
		var vm = this;

		vm.init = function(){
			$scope.form = {};
			$scope.data = {};
			$scope.data.actionTag = "";
			$scope.datePicker = { };
			$scope.dateOptions = {
					startingDay : 1,
					showWeeks : false,	
					format : "yyyy-MM-dd"
				};
			$scope.dateFormat = "yyyy-MM-dd";
			
			$scope.data.id = 0;
			$scope.data.dataSetID = $rootScope.dataSetID;
			$scope.data.dataSetCode = $rootScope.dataSetCode;
			$scope.data.predefinedEntryID = data.predefinedEntryID;
			$scope.data.predefinedEntriesID = data.predefinedEntryID;
			
			console.log($scope.data.predefinedEntryID);
			console.log($scope.data.predefinedEntriesID);
			
			vm.getPredefinedEntriesClientCode();
			vm.getClientCodes();
		}
		
		$scope.open = function(columnName, $event) {
			$event.preventDefault();
			$event.stopPropagation();
			
			if ($scope.datePicker[columnName]) {
				if ($scope.datePicker[columnName].opened) {
					$scope.datePicker[columnName].opened = false;
				}
			} else {
				$scope.datePicker = {};
				$scope.datePicker[columnName] = {};
				$scope.datePicker[columnName].opened = true;
			}
		}
		
		vm.getPredefinedEntriesClientCode = function(){
			
			var url = "transactions/predefinedEntries/predefinedEntriesClientCode/"+ $scope.data.dataSetCode + "/"+$scope.data.predefinedEntryID;		
			dataAccessService.doGetData(url, null, function(response){
				console.log(response);
				$scope.predefinedEntriesClientCode = response.data;
			},function(errorResponse){
				console.log(errorResponse);
			});
		}
		
		vm.getClientCodes = function(){
			
			var url = "references/clientCodes/"+ $scope.data.dataSetCode;		
			dataAccessService.doGetData(url, null, function(response){
				console.log(response);
				$scope.clientCodes = response.data;
			},function(errorResponse){
				console.log(errorResponse);
			});
		}
		
		//Get currencies
		vm.getCurrenciesByDataSetCode = function(){
			var url = 'references/currencyByDataSetCode/'+$rootScope.dataSetCode;
			dataAccessService.doGetData(url, null, function(response){
				console.log(response.data);
				$scope.currencies = response.data;
			},function(errorResponse){
				errorCallBack(errorResponse);
			});
		};
		
		//Get journal entry fields
		vm.getJournalEntryFields = function(){
			var url = 'references/journalEntryFields/'+$rootScope.dataSetCode;
			dataAccessService.doGetData(url, null, function(response){
				console.log(response.data);
				$scope.journalEntryFields = response.data;
			},function(errorResponse){
				errorCallBack(errorResponse);
			});
		};
		
		vm.init();
		
		$scope.addPDED = function(){
			
			console.log("Add Predefined Entries Client Code.");
			$scope.data.actionTag = "ADD";
			$scope.setAttribute($scope.data.actionTag)
			
			console.log($scope.data);
		};
		
		$scope.editPDED = function(){
			
			console.log("Edit Predefined Entries Client Code.");
			$scope.data.actionTag = "UPDATE";
			
			if(!$scope.selectedRecord){
				alertify.alert("Please select an item first in order to proceed with this action.");
				return false;
			}else {
				console.log("OK");
				$scope.setAttribute($scope.data.actionTag)

				console.log($scope.data);
			}
			
		};
		
		$scope.deletePDED = function(){
			
			console.log("Delete Predefined Entries Client Code.");
			$scope.data.actionTag = "DELETE";

			if(!$scope.selectedRecord){
				alertify.alert("Please select an item first in order to proceed with this action.");
				return false;
			}else {
				console.log("OK");
				$scope.setAttribute($scope.data.actionTag)

				console.log($scope.data);
				
				var deletePredefinedEntriesClientCodeUrl = 'transactions/predefinedEntriesClientCode/setup';
				alertify.confirm("Do you really want to delete definition for this predefined entry?", function(e){
						
					if(e){
						dataAccessService.doPostData(deletePredefinedEntriesClientCodeUrl, $scope.data, function(response){
							console.log(response);
							alertify.alert(response.data.messageMap.successMsg);
							vm.init();
						},function(errorResponse){
							console.log(errorResponse);
							alertify.fail(errorResponse.data.errorMsg);
						});
					}else{
						return;
					}
					
					vm.getPredefinedEntriesClientCode();
				});
				$scope.setAttribute("");
			}
		};
		
		$scope.restorePDED = function(){
			
			console.log("Restore Predefined Entries Client Code.");
			$scope.data.actionTag = "RESTORE";

			if(!$scope.selectedRecord){
				alertify.alert("Please select an item first in order to proceed with this action.");
				return false;
			}else {
				console.log("OK");
				$scope.setAttribute($scope.data.actionTag)

				console.log($scope.data);
				
				var restorePredefinedEntriesClientCodeUrl = 'transactions/predefinedEntriesClientCode/setup';
				alertify.confirm("Do you really want to restore definition for this predefined entry?", function(e){
						
					if(e){
						dataAccessService.doPostData(restorePredefinedEntriesClientCodeUrl, $scope.data, function(response){
							console.log(response);
							alertify.alert(response.data.messageMap.successMsg);
							vm.init();
						},function(errorResponse){
							console.log(errorResponse);
							alertify.fail(errorResponse.data.errorMsg);
						});
					}else{
						return;
					}
					
					vm.getPredefinedEntriesClientCode();
				});
				$scope.setAttribute("");
			}
		};
		
		$scope.savePDEClientCode = function(actionTag){
			
			console.log("Save Predefined Entries Client Code.");
			console.log("actionTag: " + actionTag);
			console.log($scope.data);
			
			var savePredefinedEntriesClientCodeUrl = 'transactions/predefinedEntriesClientCode/setup';
			alertify.confirm("Do you really want to save client code for this predefined entry?", function(e){
					
				if(e){
					dataAccessService.doPostData(savePredefinedEntriesClientCodeUrl, $scope.data, function(response){
						console.log(response);
						alertify.alert(response.data.messageMap.successMsg);
						vm.init();
					},function(errorResponse){
						console.log(errorResponse);
						alertify.fail(errorResponse.data.errorMsg);
					});
				}else{
					return;
				}
				
				vm.getPredefinedEntriesClientCode();
			});
			
			$scope.setAttribute("");
		};
		
		// Get selected items
		vm.getSelectedItems = function(items){
			var selectedItems = [];
			for(var i = 0; i < items.length; i++){
				var selected = items[i].selected;
				if(selected === true){
					selectedItems.push(items[i]);
				}
			}
			return selectedItems;
		}
		
		$scope.setAttribute = function(action){

			if(action === 'ADD'){
				$("#clientCodeID").attr("disabled", false);
				$("#save").show();
			}else if(action === 'UPDATE'){
				$("#clientCodeID").attr("disabled", false);
				$("#save").show();
			}else{
				$("#clientCodeID").attr("disabled", "disabled");
				$("#save").hide();
			}
		}
		
		$scope.setAttributeDisable = function(){

				$("#clientCodeID").attr("disabled", "disabled");
				$("#save").hide();
		}
		
		$scope.validate = function(action, selectedItems){

			if(action === 'UPDATE' || action === 'DELETE'){
				if(selectedItems.length == 0){
					alertify.alert("Please select an item first in order to proceed with this action");
				}else if(selectedItems.length > 1){
					alertify.alert("Please one at a time in order to proceed with this action");
				}else {
					console.log("OK");
				}
				
			}else{
				$("#clientCodeID").attr("disabled", "disabled")
				$("#save").hide();
			}
		}
		
		$scope.setSelectedRecord = function(index){
			$scope.selectedRecord = $scope.predefinedEntriesClientCode.resultSet[index];
			console.log($scope.selectedRecord);
			
			$scope.data.id = $scope.selectedRecord.id;
			$scope.data.clientCodeID = $scope.selectedRecord.clientID;
			$scope.data.isDeleted = $scope.selectedRecord.isDeleted;
			
			console.log($scope.data);
		}
		
		$scope.cancel = function() {
			alertify.confirm("This action cancels any changes or updates in this predefined entry. " +
					"Are you sure you want to proceed?", function(e){
					if(e){
						$uibModalInstance.dismiss();
					}else{
						return;
					}
				});
		};
		
	}]);
	
});