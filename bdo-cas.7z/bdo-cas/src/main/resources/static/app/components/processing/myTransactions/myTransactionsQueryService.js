'use strict';

define(function(){
	angular.module("core").provider('MyTransactionsQueryService', function(){
		this.$get =['$http', 'DataAccessService', function($http, dataAccessService){
			var service = {
				getMyTransactionsList: function(dataSetCode, pageIndex, pageSize, searchcriteria, successCallBack, errorCallBack) {
					var url  = 'transactions/mytxn/'+dataSetCode+'/'+pageIndex+'/'+pageSize+'/';
					dataAccessService.doPostData(url, searchcriteria, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getColumnList: function(dataSetID, recordProfileID, successCallBack, errorCallBack) {
					var url  = 'transactions/columns/'+dataSetID+'/'+recordProfileID;
					dataAccessService.doGetData(url, null, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				}, 
				getGroupUsers: function(dataSetID, successCallBack, errorCallBack){
					var url = 'references/groupUsers/'+dataSetID;
					dataAccessService.doGetData(url, null, function(response){
						console.log(response.data);
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				}
			}
			return service;
		}]
	});	
});