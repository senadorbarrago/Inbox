'use strict';

define(function(){
	angular.module("core").provider('RemarksFormQueryService', function(){
		this.$get =['$http', 'DataAccessService', function($http, dataAccessService){
			var service = {
				addRemarks: function(addRemarksData) {
					var url  = 'remarks/add';
					return $http.post(url, addRemarksData);
				},
				viewRemarks: function(dataset, sourceID, sourceType, successCallBack, errorCallBack) {
					var url  = 'remarks/view/' + dataset + '/' + sourceID + '/' + sourceType;

					dataAccessService.doGetData(url, null, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				batchAddRemarks: function(addRemarksData) {
					var url  = 'remarks/batchAdd';
					return $http.post(url, addRemarksData);
				}
				
			}
			return service;
		}]
	});	
});