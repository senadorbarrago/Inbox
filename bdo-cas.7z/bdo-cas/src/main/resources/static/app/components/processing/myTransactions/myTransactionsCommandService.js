'use strict';

define(function(){
	angular.module("core").provider('MyTransactionsCommandService', function(){
		this.$get =['DataAccessService', function(dataAccessService){
			var service = {
				returnToInbox: function(takeUpIDs, successCallBack, errorCallBack) {
					var url  = "transactions/mytxn/returntoinbox";
					dataAccessService.doPostData(url, takeUpIDs, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				}, 
				reassignTakeup: function(data, successCallBack, errorCallBack) {
					var url  = 'transactions/mytxn/reassigntakeup';
					dataAccessService.doPostData(url, data, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				}
			}
			return service;
		}]
	});	
});