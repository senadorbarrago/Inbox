'use strict';

define(function(){
	
	console.log('holidayController.js loaded');
	var core = angular.module('core');
	
	core.registerController('holidayController', function($rootScope, $scope){
		$scope.title = 'This is the Holiday Screen';
		$rootScope.screenName = 'HOLIDAY_MAINTENANCE';
	});
	
});