'use strict';

define(function(){
	
	console.log('extractedOutboundController.js loaded');
	var core = angular.module('core');
	
	core.registerController('extractedOutboundController', ['$rootScope', '$scope', 'DataAccessService', 'JournalEntryFormQueryService', function($rootScope, $scope, dataAccessService, journalEntryFormQueryService){
		$scope.title = 'This is the Extracted Outbound Screen';
		$rootScope.screenName = 'OUTBOUND_INTERFACE';
		
		$scope.user = $rootScope.authenticatedUser;
		$scope.dataset = $rootScope.dataSetID;
		
		var vm = this;
		
		vm.init = function(){
			
			console.log('extractedOutboundController: init() called');
			console.log($rootScope.outbounds);
			
			$scope.outbounds = $rootScope.outbounds;
			
			//Get Encoding Units
			journalEntryFormQueryService.getEncodingUnits(function(response){
				console.log('getEncodingUnits');
				console.log(response.data);
				$scope.encodingUnits = response.data;
				
			},function(error){
				console.log(error);
			});
			
			// Date Picker Setup
			$scope.datePicker = { };
			$scope.dateOptions = {
					startingDay : 1,
					showWeeks : false,	
					format : "yyyy-MM-dd"
			};
			
		};
		
		vm.init();
		
		$scope.open = function(columnName, $event){
			
			$event.preventDefault();
			$event.stopPropagation();
			
			if ($scope.datePicker[columnName]) {
				if ($scope.datePicker[columnName].opened) {
					$scope.datePicker[columnName].opened = false;
				}
			} else {
				$scope.datePicker = {};
				$scope.datePicker[columnName] = {};
				$scope.datePicker[columnName].opened = true;
			}
		};
		
		$scope.doDownloadProoflist = function(){
			
			console.log("doDownloadProoflist");
			
			console.log("UserName: " + $scope.user.username);
			console.log("Dataset: " + $scope.dataset);
			console.log("OutboundFileID: " + $scope.outboundFileCode);
			console.log("EncodingUnit: " + $scope.encodingUnit);
			console.log("Processed Date: " + $scope.glDate);
			
		};
		
	}]);
	
});