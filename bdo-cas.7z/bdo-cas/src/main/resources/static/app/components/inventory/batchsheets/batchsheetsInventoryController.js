'use strict';

define(function(){
	console.log('batchsheetsInventoryController.js loaded');
	var core = angular.module('core');
	
	core.registerController('batchsheetsInventoryController',['$rootScope', '$scope', '$uibModal', 'DataAccessService', 'ngTableParams', '$filter', '$http', 'InventoryQueryService',  
		function($rootScope, $scope, $uibModal, dataAccessService, ngTableParams, $filter, $http, inventoryQueryService){
		$rootScope.screenName = 'Inventory --> Batch Sheets';
		
		var vm = this;
		
		/**
		 * init
		 * 
		 */
		vm.init = function () {
			$scope.data = {};
			$scope.form = {};
			$scope.reference = {};
			$scope.data.inventoryCode = 'INV-003';
			$scope.data.dataSetID = $rootScope.dataSetID;
			$scope.data.dataSetCode = $rootScope.dataSetCode;
			$scope.data.costCenterID = $rootScope.costCenterID;
			$scope.data.encodingUnitCode = $rootScope.encodingUnitCode;
			$scope.data.pageSize = 50;
			$scope.data.pageIndex = 1;
			$scope.data.selectedUser = '';
			$scope.data.processingDateFrom = '';
			
			// DatePicker
			$scope.datePicker = { };
			$scope.dateOptions = {
					startingDay : 1,
					showWeeks : false,	
					format : "yyyy-MM-dd"
				};
			$scope.dateFormat = "yyyy-MM-dd";
			
			$scope.inventoryTypeList = [
											{
												 "heading"	: "Transactions",
												 "url"	    : "inventory/transactions",
												 "selected" : false
											 },
											 {
												 "heading"  : "Take Ups",
												 "url"	    : "inventory/takeups",
												 "selected" : false
											 },
											 {
												 "heading"  : "Journal Entries",
												 "url"	    : "inventory/journalentries",
												 "selected" : false
											 },
											 {
												 "heading"  : "Batch Sheet",
												 "url"	    : "inventory/batchsheets",
												 "selected" : true
											 }
										];
			vm.doGetGroupMembers();
			
			//Search
			$scope.form.datagrid = {};
			$scope.tableParams.reload();
		}
		
		/**
		 * Data Grid
		 */
		$scope.tableParams = new ngTableParams(
				{	page: 1,
					count: 25
				},
				{	getData: function ($defer, params) {
					return inventoryQueryService.getBatchSheetsInventory($scope.data.dataSetCode,
							params.page(), params.count(), $scope.data, function (response) {
							$scope.form.resultmodel = response.data;
							params.total($scope.form.resultmodel.resultOverAllCount);
							$defer.resolve($scope.form.resultmodel.resultSet);
						}, function(response) {});
					}
				}
		);
		
		/**
		 * Get Section Members for Officer
		 */
		vm.doGetGroupMembers = function(){
			var data  = {
			     	'username' : $rootScope.session['AUTHENTICATED_USER'].username,
			     	'roleCode' : $rootScope.session['AUTHENTICATED_USER'].activeMembership.role.code,
			     	'groupCode' : $rootScope.session['AUTHENTICATED_USER'].activeMembership.group.code,
				}; 
			dataAccessService.doQuery('ProcessorListQueryModel', data, function(response){
				$scope.reference.processorList = response.data.resultSet;
				if($scope.reference.processorList.length === 1){	
					$scope.data.selectedUser = $scope.reference.processorList[0].code;
				}
			},function(errorResponse){
				console.log(errorResponse);
			});
		}
		
		/**
		 * Call Initialize
		 */
		vm.init();
		
		$scope.doSearch = function(){
			if($scope.data.processingDateFrom === '' || $scope.data.processingDateFrom === undefined){
				alertify.alert("Please enter the Processing Date");
				return;
			}
			
			$scope.tableParams.reload();
		}
		
		/**
		 * Clear filters
		 */
		$scope.clearAll = function(){
			$scope.data.processingDateFrom = '';
			if($scope.reference.processorList.length > 1){	
				$scope.data.selectedUser = '';
			}
		}
		
		/**
		 * Open Calendar
		 */
		$scope.open = function(columnName, $event) {
			$event.preventDefault();
			$event.stopPropagation();
			
			if ($scope.datePicker[columnName]) {
				if ($scope.datePicker[columnName].opened) {
					$scope.datePicker[columnName].opened = false;
				}
			} else {
				$scope.datePicker = {};
				$scope.datePicker[columnName] = {};
				$scope.datePicker[columnName].opened = true;
			}
		}
	}]);
});