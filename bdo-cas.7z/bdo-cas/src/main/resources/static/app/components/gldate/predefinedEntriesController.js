'use strict';

define(function(){
	var core = angular.module('core');
	
	core.registerController('predefinedEntriesController',[ '$rootScope', '$scope', '$uibModal', 'DataAccessService', '$filter', 
		function($rootScope, $scope, $uibModal, dataAccessService, $filter){
		$rootScope.screenName = 'Predefined Entries';
		
		var vm = this;

		vm.init = function(){
			$scope.form = {};
			$scope.data = {};
			$scope.data.rateID = 0;
			$scope.data.forwardRates = true;
			$scope.data.dataSetID = 0.00;
			$scope.data.pdeActionTag = "";
			$scope.datePicker = { };
			$scope.dateOptions = {
					startingDay : 1,
					showWeeks : false,	
					format : "yyyy-MM-dd"
				};
			$scope.dateFormat = "yyyy-MM-dd";
			
			$scope.data.dataSetID = $rootScope.dataSetID;
			$scope.data.dataSetCode = $rootScope.dataSetCode;
			$scope.currencyCode = "none";
			$scope.pdeTypeCode = "none";
			
//			vm.getBookCodeByDataSetCode();
			vm.getPDEType();
			vm.getCurrencies();
			vm.getPredefinedEntries();
		}
		
		//Get bookCode
		vm.getBookCodeByDataSetCode = function(){
			var url = 'references/bookCodeByDataSet/'+$rootScope.dataSetCode;
			dataAccessService.doGetData(url, null, function(response){
				console.log(response.data);
				$scope.bookCodes = response.data;
			},function(errorResponse){
				errorCallBack(errorResponse);
			});
		};
		
		vm.getPDEType = function(){
			
			var url = 'references/pdeTypeByDataSetCode/'+$rootScope.dataSetCode;
			dataAccessService.doGetData(url, null, function(response){
				console.log(response.data);
				$scope.pdeTypes = response.data;
			},function(errorResponse){
				errorCallBack(errorResponse);
			});
		}
		
		vm.getPredefinedEntries = function(){
			
			var url = "transactions/predefinedEntries/"+"none"+"/"+"none";		
			dataAccessService.doGetData(url, null, function(response){
				console.log(response.data);
				$scope.predefinedEntries = response.data;
			},function(errorResponse){
				console.log(errorResponse);
				$scope.predefinedEntries = null;
			});
		}
		
		vm.getCurrencies = function(){
			
			var url = 'references/currencyByDataSetCode/'+$rootScope.dataSetCode;
			dataAccessService.doGetData(url, null, function(response){
				console.log(response.data);
				$scope.currencies = response.data;
			},function(errorResponse){
				errorCallBack(errorResponse);
			});
		}
		
		vm.init();
		
		// Get selected items
		vm.getSelectedItems = function(items){
			var selectedItems = [];
			for(var i = 0; i < items.length; i++){
				var selected = items[i].selected;
				if(selected === true){
					selectedItems.push(items[i]);
				}
			}
			return selectedItems;
		}
		
		$scope.setSelectedRecord = function(index){
			$scope.selectedRecord = $scope.predefinedEntries.resultSet[index];
			console.log($scope.selectedRecord);
			
			$scope.data.predefinedEntryID = $scope.selectedRecord.id;
			$scope.data.dataSetDesc = $scope.selectedRecord.dataSetDesc;
			$scope.data.isDeleted = $scope.selectedRecord.isDeleted;
			$scope.data.pdeCode = $scope.selectedRecord.pdeCode;
			$scope.data.pdeDesc = $scope.selectedRecord.pdeDesc;
			$scope.data.bookCode = $scope.selectedRecord.bookCode;
			$scope.data.currencyCode = $scope.selectedRecord.currencyCode;
			$scope.data.pdeDetail = $scope.selectedRecord.pdeDetail;
			$scope.data.pdeType = $scope.selectedRecord.pdeTypeCode;
			$scope.data.recordProfileID = $scope.selectedRecord.recordProfileID;
			$scope.data.dataFieldColumnID = $scope.selectedRecord.dataFieldColumnID;
			$scope.data.withBinding = $scope.selectedRecord.withBinding;
		}
		
		$scope.getCurrencies = function(){
			
			var url = 'references/currencyByBookCode/'+$scope.bookCode;
			dataAccessService.doGetData(url, null, function(response){
				console.log(response.data);
				$scope.currencies = response.data;
			},function(errorResponse){
				errorCallBack(errorResponse);
			});
		}
		
		$scope.getPredefinedEntries = function(){
			
			var url = "transactions/predefinedEntries/"+$scope.currencyCode+"/"+$scope.pdeTypeCode;		
			dataAccessService.doGetData(url, null, function(response){
				console.log(response.data);
				$scope.predefinedEntries = response.data;
			},function(errorResponse){
				console.log(errorResponse);
				$scope.predefinedEntries = null;
			});
		}
		
		$scope.doShowPredefinedEntryDefinitionForm = function(predefinedEntryID){
			
			console.log('predefinedEntryID: ' + predefinedEntryID);
			
			var modalInstance = $uibModal.open({
				animation: true,
				backdrop: 'static',
				templateUrl: 'app/components/forms/predefinedentriesform/predefinedEntriesDefinitionForm.html',
				controller: 'predefinedEntriesDefinitionController',
				size: 'md',
				resolve:{
					load: ['$q', function($q){
						var defered = $q.defer();
						require(['app/components/forms/predefinedentriesform/predefinedEntriesDefinitionController'], function(){
							defered.resolve();
						});
						return defered.promise;
					}],
					data : function(){
						var data = {}; 
						data.predefinedEntryID = predefinedEntryID;
						return data;
					}
				}
			});
			modalInstance.result.then(function(message){
				alertify.alert(message);
				vm.init();
			}, 
			function() {				
				// dismissed
				console.log("dismissed");
				vm.init();
			});
			return modalInstance.result;
		}
		
		$scope.doShowPredefinedEntryClientCodeForm = function(predefinedEntryID){
			
			console.log('predefinedEntryID: ' + predefinedEntryID);
			
			var modalInstance = $uibModal.open({
				animation: true,
				backdrop: 'static',
				templateUrl: 'app/components/forms/predefinedentriesform/predefinedEntriesClientCodeForm.html',
				controller: 'predefinedEntriesClientCodeController',
				size: 'md',
				resolve:{
					load: ['$q', function($q){
						var defered = $q.defer();
						require(['app/components/forms/predefinedentriesform/predefinedEntriesClientCodeController'], function(){
							defered.resolve();
						});
						return defered.promise;
					}],
					data : function(){
						var data = {}; 
						data.predefinedEntryID = predefinedEntryID;
						return data;
					}
				}
			});
			modalInstance.result.then(function(message){
				alertify.alert(message);
				vm.init();
			}, 
			function() {				
				// dismissed
				console.log("dismissed");
				vm.init();
			});
			return modalInstance.result;
		}
		
		$scope.doShowPredefinedEntryBindingForm = function(predefinedEntryID, recordProfileID, dataFieldColumnID, bindID){
			
			console.log('predefinedEntryID: ' + predefinedEntryID);
			
			var modalInstance = $uibModal.open({
				animation: true,
				backdrop: 'static',
				templateUrl: 'app/components/forms/predefinedentriesform/predefinedEntriesBindingForm.html',
				controller: 'predefinedEntriesBindingController',
				size: 'md',
				resolve:{
					load: ['$q', function($q){
						var defered = $q.defer();
						require(['app/components/forms/predefinedentriesform/predefinedEntriesBindingController'], function(){
							defered.resolve();
						});
						return defered.promise;
					}],
					data : function(){
						var data = {}; 
						data.bindID = bindID;
						data.predefinedEntryID = predefinedEntryID;
						data.recordProfileID = recordProfileID;
						data.dataFieldColumnID = dataFieldColumnID;
						return data;
					}
				}
			});
			modalInstance.result.then(function(message){
				alertify.alert(message);
				vm.init();
			}, 
			function() {				
				// dismissed
				console.log("dismissed");
				vm.init();
			});
			return modalInstance.result;
		}
		
		/*
		 * Functions
		 */
		
		//Add
		$scope.addPDE = function(){
			
			console.log("Add Predefined Entry.");
			$scope.data.pdeActionTag = "ADD";
			
			console.log($scope.data);
			
			var modalInstance = $uibModal.open({
				animation: true,
				backdrop: 'static',
				templateUrl: 'app/components/forms/predefinedentriesform/predefinedEntriesAddForm.html',
				controller: 'predefinedEntriesAddController',
				size: 'md',
				resolve:{
					load: ['$q', function($q){
						var defered = $q.defer();
							require(['app/components/forms/predefinedentriesform/predefinedEntriesAddController'], function(){
							defered.resolve();
						});
						return defered.promise;
					}],
					data : function(){
						var data = {};
						return data;
					}
				}
				});
				modalInstance.result.then(function(message){
				alertify.alert(message);
				vm.init();
			}, 
			function() {
				// dismissed
				console.log("dismissed");
				vm.init();
			});
			return modalInstance.result;
		};
		
		//Edit
		$scope.editPDE = function(index){
			
			console.log("Edit Predefined Entry.");
			$scope.data.pdeActionTag = "UPDATE";
			
			$scope.setSelectedRecord(index);

			console.log($scope.data);
				
			var modalInstance = $uibModal.open({
				animation: true,
				backdrop: 'static',
				templateUrl: 'app/components/forms/predefinedentriesform/predefinedEntriesEditForm.html',
				controller: 'predefinedEntriesEditController',
				size: 'md',
				resolve:{
					load: ['$q', function($q){
						var defered = $q.defer();
							require(['app/components/forms/predefinedentriesform/predefinedEntriesEditController'], function(){
							defered.resolve();
						});
						return defered.promise;
					}],
					data : function(){
						var data = {}; 
							data.predefinedEntryID = $scope.data.predefinedEntryID;
							data.bookCode = $scope.data.bookCode;
							data.currencyCode = $scope.data.currencyCode;
							data.pdeDesc = $scope.data.pdeDesc;
							data.pdeDetail = $scope.data.pdeDetail;
							data.pdeTypeCode = $scope.data.pdeType;
							data.recordProfileID = $scope.data.recordProfileID;
							data.dataFieldColumnID = $scope.data.dataFieldColumnID;
						return data;
					}
				}
				});
				modalInstance.result.then(function(message){
				alertify.alert(message);
				vm.init();
			}, 
			function() {
				// dismissed
				console.log("dismissed");
				vm.init();
			});
			return modalInstance.result;
			
		};
		
		//Delete
		$scope.deletePDE = function(){
			
			console.log("Delete Predefined Entries Definition.");
			$scope.data.pdeActionTag = "DELETE";

			if(!$scope.selectedRecord){
				alertify.alert("Please select an item first in order to proceed with this action.");
				return false;
			}else {
				console.log("OK");

				console.log($scope.data);
				
				var deletePredefinedEntriesDefinitionUrl = 'transactions/predefinedEntries/setup';
				alertify.confirm("Do you really want to delete definition for this predefined entry?", function(e){
						
					if(e){
						dataAccessService.doPostData(deletePredefinedEntriesDefinitionUrl, $scope.data, function(response){
							console.log(response);
							alertify.alert(response.data.messageMap.successMsg);
							vm.init();
						},function(errorResponse){
							console.log(errorResponse);
							alertify.fail(errorResponse.data.errorMsg);
						});
					}else{
						return;
					}
				});
			}
		};
		
		//Restore
		$scope.restorePDE = function(){
			
			console.log("Restore Predefined Entries Definition.");
			$scope.data.pdeActionTag = "RESTORE";

			if(!$scope.selectedRecord){
				alertify.alert("Please select an item first in order to proceed with this action.");
				return false;
			}else {
				console.log("OK");

				console.log($scope.data);
				
				var restorePredefinedEntriesDefinitionUrl = 'transactions/predefinedEntries/setup';
				alertify.confirm("Do you really want to restore definition for this predefined entry?", function(e){
						
					if(e){
						dataAccessService.doPostData(restorePredefinedEntriesDefinitionUrl, $scope.data, function(response){
							console.log(response);
							alertify.alert(response.data.messageMap.successMsg);
							vm.init();
						},function(errorResponse){
							console.log(errorResponse);
							alertify.fail(errorResponse.data.errorMsg);
						});
					}else{
						return;
					}
				});
			}
		};
		
	}]);
	
});