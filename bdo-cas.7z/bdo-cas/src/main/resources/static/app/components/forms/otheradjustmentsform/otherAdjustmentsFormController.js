'use strict';

define(function(){
	
	console.log('otherAdjustmentsFormController.js loaded');
	var core = angular.module('core');
	
	core.registerController('otherAdjustmentsFormController',['$rootScope', '$scope', '$uibModalInstance', 'DataAccessService', 'data', 
			function($rootScope, $scope, $uibModalInstance, dataAccessService, data){
		$scope.title = 'Other Adjustments Form';
		var vm = this;
		
		vm.init = function(){
			console.log("OtherAdjustments init():");
			console.log(data);
			// DatePicker SetUp
			$scope.datePicker = [{'opened' : false}];
			$scope.dateOptions = {
					startingDay : 1,
					showWeeks : false,	
					format : "yyyy-MM-dd"
				};
			// Without Existing BatchSheet
			$scope.fields = [
								{'label' : 'Actual Date of NC', 'code' : 'NC_DATE', 'dataType' : 'Date'},
								{'label' : 'Transaction Type', 'code' : 'TRAN_TYPE', 'dataType' : 'Reference'},
								{'label' : 'Reference No', 'code' : 'REF_NO', 'dataType' : 'String'},
								{'label' : 'PN No.', 'code' : 'PN', 'dataType' : 'String'},
								{'label' : 'Client Name', 'code' : 'CLIENT', 'dataType' : 'String'},
								{'label' : 'Debit Amount', 'code' : 'DR', 'dataType' : 'number'},
								{'label' : 'Credit Amount', 'code' : 'CR', 'dataType' : 'number'},
								{'label' : 'Remarks', 'code' : 'REMARKS', 'dataType' : 'String'},
							];
			
			$scope.references = {};
			vm.getTransactionTypeList();
			
			
			$scope.data = {};
			console.log(data.batchSheetID);
			$scope.data.controlTotalsID = data.controlTotalsID;
			
			if(data.batchSheetID){
				$scope.batchSheetID = data.batchSheetID;
			}else{
				$scope.batchSheetID = 0;
			}
			console.log('ZZZ: '+data.controlTotalsID);
			console.log('XXX: '+$scope.batchSheetID);
			if(data.controlTotalsID && data.controlTotalsID > 0){
				console.log(data.controlTotalsID);
				// BatchSheet Header Info
				var url = 'batchsheet/headerInfo/'+data.batchSheetID;
				dataAccessService.doGetData(url, null, function(response){
					console.log(response);
					if(response.data.resultOverAllCount && response.data.resultOverAllCount > 0){
						$scope.statusCode = response.data.resultSet[0].statusCode;
					}else{
						$scope.statusCode = '';
					}
				},function(errorResponse){
					console.log(errorResponse);
				});
				console.log('HERE 1');
				// With Existing Control Totals
				$scope.data.batchSheetID = data.batchSheetID;
				$scope.data.controlTotalsID = data.controlTotalsID;
				var url = 'otheradjustments/details/'+$scope.data.controlTotalsID;
				dataAccessService.doGetData(url, null, function(response){
					console.log(response);
					$scope.data.resultSet = response.data.resultSet;
					if(response.data.resultOverAllCount && response.data.resultOverAllCount > 0){
						$scope.hasOtherAdjustments = true;
						for(var index = 0; $scope.data.resultSet.length > index; index++){
							$scope.data.resultSet[index]['NC_DATE'] = new Date($scope.data.resultSet[index]['NC_DATE']);
							$scope.datePicker.push({'opened' : false});
						}
					}else{
						$scope.data.resultSet = [];
						$scope.hasOtherAdjustments = false;
						//record template
						var record = {};			
						$scope.data.resultSet.push(record);
					}
				},function(errorResponse){
					console.log(errorResponse);
				});
			}else{
				
				$scope.data = {};
				$scope.data.resultSet = [];
				$scope.hasOtherAdjustments = false;
				//record template
				var record = {};			
				$scope.data.resultSet.push(record);
			}
			console.log('HERRE');
			console.log($scope.references.transactionTypeList);
		};
		
		// Get TransactionTypeList
		vm.getTransactionTypeList = function(){
			var dataSetCode = $rootScope.dataSetCode;
			var queryCode = 'TransactionTypeQueryModel';
			var data = {'dataSetCode' : dataSetCode};
			
			dataAccessService.doQuery(queryCode, data, function(response){
				console.log(response);
				$scope.references.transactionTypeList = response.data.resultSet;
			},function(errorResponse){
				console.log(errorResponse);
			});
		}
		
		// Initialize
		vm.init();
		
		
		$scope.addRecord = function(){
			//record template
			var lastRecordIndex = $scope.data.resultSet.length - 1;
			var currentRecord = $scope.data.resultSet[lastRecordIndex];
			var isValid = true;
			
			if(!currentRecord['NC_DATE'] || !currentRecord['PN'] ||
					!currentRecord['CLIENT'] || 
						(!currentRecord['DR']|| !currentRecord['CR'])|| 
						!currentRecord['TRAN_TYPE']){
				alertify.alert("Please complete the details of current other adjustment record before adding a new record");
				return false;
			}
			
			angular.forEach($scope.data.resultSet, function(value, key){

				var currentRecord = $scope.data.resultSet[key];
				
				console.log("currentRecord['DR']" + currentRecord['DR']);
				console.log("currentRecord['CR']" + currentRecord['CR']);
				
				if($scope.validateNumericInput(currentRecord['DR']) === 'invalid' || 
						$scope.validateNumericInput(currentRecord['CR']) === 'invalid'){
					isValid = false;
					console.log("isValid = false");
				}
			});
			
			if(!isValid){
				alertify.alert("Amount's maximum whole number must be 14 digits only.");
				return false;
			}else{
				if(!currentRecord['REF_NO']){
					currentRecord['REF_NO'] = '';
				}
				
				console.log(lastRecordIndex);
				console.log(currentRecord);
				
				var record = {};
				$scope.datePicker.push({'opened' : false});
				$scope.data.resultSet.push(record);
				
				console.log($scope.data.resultSet);
			}
		}
		
		$scope.removeRecord = function(index){
			$scope.data.resultSet.splice(index, 1);
			$scope.datePicker.splice(index, 1);
		}
		
		$scope.computeDebitGrandTotal = function(){
			$scope.data.totalDebitAmount = 0.00;
			if($scope.data.resultSet !== undefined){
				for(var i = 0; i < $scope.data.resultSet.length; i++){
					if($scope.data.resultSet[i]['DR']){
						if(!isNaN($scope.data.resultSet[i]['DR'].replace(/,/g,''))){
							$scope.data.totalDebitAmount = parseFloat($scope.data.totalDebitAmount) + parseFloat($scope.data.resultSet[i]['DR'].replace(/,/g,''));
						}
					}
				}
			}
			if(isNaN($scope.data.totalDebitAmount)){
				$scope.data.totalDebitAmount = 0.00;
			}
			return $scope.roundNumber($scope.data.totalDebitAmount, 2);
		}
		
		$scope.computeCreditGrandTotal = function(){
			$scope.data.totalCreditAmount = 0.00;
			if($scope.data.resultSet !== undefined){
				for(var i = 0; i < $scope.data.resultSet.length; i++){
					if($scope.data.resultSet[i]['CR']){
						if(!isNaN($scope.data.resultSet[i]['CR'].replace(/,/g,''))){
							$scope.data.totalCreditAmount = parseFloat($scope.data.totalCreditAmount) + parseFloat($scope.data.resultSet[i]['CR'].replace(/,/g,''));
						}
					}
				}
			}
			if(isNaN($scope.data.totalCreditAmount)){
				$scope.data.totalCreditAmount = 0.00;
			}
			return $scope.roundNumber($scope.data.totalCreditAmount, 2);
		}
		
		$scope.save = function(){
			
			var recordsLength = $scope.data.resultSet.length;
			var invalidColumns = 0;
			var isValid = true;
			
			console.log(recordsLength);
			console.log($scope.data.resultSet);
			
			angular.forEach($scope.data.resultSet, function(value, key){

				var currentRecord = $scope.data.resultSet[key];
				
				if(!currentRecord['NC_DATE'] || !currentRecord['PN'] ||
						!currentRecord['CLIENT'] || 
							(!currentRecord['DR']|| !currentRecord['CR'])|| 
							!currentRecord['TRAN_TYPE']){
					invalidColumns = invalidColumns + 1;
					return false;
				}
				
				console.log("currentRecord['DR']" + currentRecord['DR']);
				console.log("currentRecord['CR']" + currentRecord['CR']);
				
				if($scope.validateNumericInput(currentRecord['DR']) === 'invalid' || 
						$scope.validateNumericInput(currentRecord['CR']) === 'invalid'){
					isValid = false;
					console.log("isValid = false");
				}
			});
			
			if($scope.data.resultSet.length === 0){
				alertify.alert("Invalid other adjustment record. Correct the other adjustments first in order to proceed with this action.");
				return;
			}else if(invalidColumns > 0){
				alertify.alert("Please complete the details of current other adjustment record before saving the record.");
				return;
			}else if(!isValid){
				alertify.alert("Amount's maximum whole number must be 14 digits only.");
				return false;
			}else{
				alertify.confirm("This action saves the other adjustments encoded with this transaction. " +
						"Are you sure you want to proceed?", function(e){
					if(e){
						for(var i = 0; $scope.data.resultSet.length > i; i++){
							$scope.data.resultSet[i]['DR'] = $scope.data.resultSet[i]['DR'].replace(/,/g,'');
							$scope.data.resultSet[i]['CR'] = $scope.data.resultSet[i]['CR'].replace(/,/g,'');
							console.log($scope.data.resultSet[i]['DR']);
							console.log($scope.data.resultSet[i]['CR']);
						}	
						
						$scope.data.totalCreditAmount = parseFloat(Math.round($scope.data.totalCreditAmount * 100.00) / 100.00).toFixed(2);
						$scope.data.totalDebitAmount =  parseFloat(Math.round($scope.data.totalDebitAmount * 100.00) / 100.00).toFixed(2);
						
						console.log($scope.data);
						console.log($scope.data.totalCreditAmount);
						console.log($scope.data.totalDebitAmount);
						$uibModalInstance.close($scope.data);
					}
				});
			}
		};
		
		$scope.remove = function(){
			if($scope.data.resultSet.length === 0){
				alertify.alert("Invalid other adjustment record. Correct the other adjustments first in order to proceed with this action");
				return;
			}else{
				alertify.confirm("This action deletes the other adjustments encoded with this transaction. " +
						"Are you sure you want to proceed?", function(e){
						if(e){
							var url = 'otheradjustments/remove/';
							$scope.data.dataSetCode = $rootScope.dataSetCode;
							$scope.data.encodingUnitCode = $rootScope.encodingUnitCode;
							console.log($scope.data);
							dataAccessService.doPostData(url, $scope.data, function(response){
								console.log(response);
								alertify.alert(response.data.messageMap['successMsg']);
								//vm.init();
								var data = {};
								data.totalCreditAmount = '0.00';
								data.totalDebitAmount = '0.00';
								
								$uibModalInstance.close(data);
							},function(errorResponse){
								console.log(errorResponse);
								alertify.alert(errorResponse.data.errorMsg);
							});
							
						}
					});
			}	
			
		};
		
		$scope.open = function(index, $event) {
			$event.preventDefault();
			$event.stopPropagation();
			console.log(index);
			angular.forEach($scope.datePicker, function(value, key){
				value.opened = false;
			});
			$scope.datePicker[index].opened = true;
			console.log($scope.datePicker);
		}
		
		$scope.close = function() {
			alertify.confirm("This action cancels any changes or updates in other adjustments.  " +
					"Are you sure you want to proceed?", function(e){
					if(e){
						$uibModalInstance.dismiss();
					}else{
						return;
					}
				});
		};
		
		$scope.roundNumber = function(num, scale) {
			if(!("" + num).includes("e")) {
				return +(Math.round(num + "e+" + scale)  + "e-" + scale);
			} else {
				var arr = ("" + num).split("e");
				var sig = ""
				if(+arr[1] + scale > 0) {
					sig = "+";
				}
				return +(Math.round(+arr[0] + "e" + sig + (+arr[1] + scale)) + "e-" + scale);
			}
		}
		
		/**
		 * 
		 */
		$scope.restrictLargeNumericInput = function(amount, $event, idx){
			console.log('idx: ' + idx);
			var isValid = vm.restrictNumericInput(amount, $event, idx);
			console.log('$scope.restrictLargeNumericInput: '+isValid);
			console.log('$event.keyCode: '+$event.keyCode);
			if(isValid === 'invalid'){
				if($event.keyCode === 0) { 
					$event.preventDefault();
					return false;
				}
			}
		}
		
		/**
		 * 
		 */
		vm.restrictNumericInput = function(amount, $event, idx){
			var decimalCount =  vm.countDecimals(amount);
			var integerCount =  vm.countIntegers(amount);
			var totalDigitCount = decimalCount + integerCount;
			var numericType = $scope.select(amount, idx);
			
			console.log('AMOUNT: ' + amount);
			console.log('DECIMAL COUNT: ' + decimalCount);
			console.log('INTEGER COUNT: ' + integerCount);
			console.log('TOTAL COUNT: ' + totalDigitCount);
			
			if(numericType === 'Integer'){
				if(integerCount > 13 || decimalCount > 2){
					return 'invalid';
				}else{
					return 'valid';
				}
			}else if(numericType === 'Decimal'){
				if(decimalCount > 1){
					return 'invalid';
				}else{
					return 'valid';
				}
			}else if(numericType === 'Numeric_Dot'){
				if ((window.event ? $event.keyCode : $event.which !== 46)) {
					console.log('DOT_ONLY & DELETE');
					return 'invalid';
				}else{
					return 'valid';
				}
			}else if(numericType === 'Decimal_Dot'){
				if ((window.event ? $event.keyCode : $event.which !== 8)) {
					console.log('DOT_ONLY & DELETE');
					return 'invalid';
				}else{
					return 'valid';
				}
			}
		};
		
		/**
		 * 
		 */
		$scope.validateNumericInput = function(amount){
			var decimalCount =  vm.countDecimals(amount);
			var integerCount =  vm.countIntegers(amount);
			var totalDigitCount = decimalCount + integerCount;
			
			console.log('AMOUNT: ' + amount);
			console.log('DECIMAL COUNT: ' + decimalCount);
			console.log('INTEGER COUNT: ' + integerCount);
			console.log('TOTAL COUNT: ' + totalDigitCount);
			
			if(totalDigitCount > 16 || integerCount > 14){
				return 'invalid';
			}else{
				return 'valid';
			}
		};
		
		/**
		 * 
		 */
		vm.countDecimals = function (value) {
		    if(Math.floor(value) === value) return 0;
		    if(value.toString().indexOf(".") !== -1){
		    	return value.toString().split(".")[1].length || 0;
		    }else{
		    	return 0;
		    }
		    
		};
		
		/**
		 * 
		 */
		vm.countIntegers = function (value) {
			var valueStr = value.toString();
			
			if(valueStr.indexOf(".") !== -1){
				var valueIndex = valueStr.indexOf('.');
				var valueLatest = valueStr.substring(0, valueIndex);
				return valueLatest.length;
			}else{
				return valueStr.length;
			}
		};
		
		$scope.select = function(value, idx){
			
			var valueStr = value.toString();
			var dotIndex = valueStr.indexOf(".");
			var cursorPosition = $("#"+idx).prop("selectionStart");
			var numericType = ''; 
			
			console.log("DOT POSITION: " + dotIndex);
			console.log("CURSOR POSITION: " + cursorPosition);
			
			var valueofIndex = valueStr.charAt(parseInt(cursorPosition));
			
			console.log(valueofIndex);
			
			if(dotIndex >= 0){
				if(cursorPosition <= dotIndex){
					console.log("Integer");
					numericType = 'Integer';
				}else{
					console.log("Decimal");
					numericType = 'Decimal';
				}
			}else if(dotIndex === -1 && cursorPosition === 14){
				console.log("Numeric_Dot");
				numericType = 'Numeric_Dot';
			}else{
				console.log("Integer");
				numericType = 'Integer';
			}
			
			return numericType;
		};
		
	}]);
	
});