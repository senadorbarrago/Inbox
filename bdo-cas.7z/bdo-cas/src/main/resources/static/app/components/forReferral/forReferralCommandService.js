'use strict';

define(function(){
	angular.module("core").provider('ForReferralCommandService', function(){
		this.$get =['DataAccessService', function(dataAccessService){
			var service = {
				grabTransaction: function(transactionID, successCallBack, errorCallBack) {
					var url  = 'transactions/forReferral/grabtransaction/'+transactionID;
					dataAccessService.doPutData(url, null, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				}
			}
			return service;
		}]
	});	
});