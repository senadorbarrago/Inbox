'use strict';

define(function(){
	console.log('loginController.js loaded');
	var core = angular.module('core');
	
	core.registerController('loginController', ['$scope', '$location', '$rootScope', '$cookies', '$uibModal', 'DataAccessService', 
		function($scope, $location, $rootScope, $cookies, $uibModal, dataAccessService){		
		console.log('core.register.controller');
		
		$scope.title = 'Login Screen';
		
		var vm = this;
		vm.init = function(){
			//$rootScope.session['AUTHENTICATED'] = false;
			$scope.username = '';
			$scope.password = ''
		}
		// Initialize
		vm.init();
		
		$scope.keyDown = function(value){			
			console.log("keyDown()");
			console.log(value);
		    if(value.keyCode == 19) {
		        var modalInstance = $uibModal.open({
					animation: true,
					templateUrl: 'app/shared/controlcenter/controlCenter.html',
					controller: 'controlCenterController',
					size: 'lg',
					keyboard: false,
					resolve:{
						load: ['$q', function($q){
							var defered = $q.defer();
							require(['app/shared/controlcenter/controlCenterController'], function(){
								defered.resolve();
							});
							return defered.promise;
						}]
					}
				});
				return modalInstance.result;
		    }
		};
		
		$scope.loginUser = function(event){
			event.preventDefault();
			console.log('$scope.loginUser()');
			console.log($rootScope.session);
			if($scope.username.trim() === '' || $scope.password.trim() === ''){
				alertify.alert("Please completely fill up authentication fields");
				return;
			}else{
				var authenticationDetails = $("#loginForm").serialize();
				console.log(authenticationDetails);
				
				dataAccessService.doPostTransformedData("login", authenticationDetails, function(response){
					var defaultSuccessUrl = response.headers("defaultSuccessUrl");
					if(!defaultSuccessUrl){
						defaultSuccessUrl = '/home';
					}
					dataAccessService.doGetData("authenticatedUser", null, function(response){
						console.log(response.data);
						$rootScope.watchTimeout();
						
						$rootScope.session['AUTHENTICATED'] = true;
						$rootScope.session['AUTHENTICATED_USER'] = response.data;
						$rootScope.session['CURRENT_PAGE'] = $scope.defaultUrl;
						$cookies.put("AUTHENTICATED", true);
						$cookies.put("CURRENT_PAGE", $scope.defaultUrl);
						
						$location.path(defaultSuccessUrl);
					}, function(errorResponse){
						console.log(errorResponse.header.ERROR_MESSAGE);
						alertify.fail(errorResponse.headers("ERROR_MESSAGE"));
						//alertify.fail(errorResponse.data.message);
					});
				},function(errorResponse){
					console.log(errorResponse.data);
					alertify.fail(errorResponse.headers("ERROR_MESSAGE"))
				});
			}
		};
	}]);
	
});