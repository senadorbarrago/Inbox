/**
 * 
 */
package com.bdo.itdis.bdocas.transaction;

import java.util.HashMap;
import java.util.Map;


/**
 * @author c150819004
 *
 */

public class EndOfDayTest {

	public Object doSetEndOfDayTest(){ 
		
		Map<String, Object> data = new HashMap<>();
		
		data.put("datasetID", 1);
		
		return null;
	}
}
