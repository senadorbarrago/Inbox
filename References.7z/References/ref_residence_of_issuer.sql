﻿INSERT INTO ref_residence_of_issuer(code, description, created_by, date_created)VALUES('1','Resident','ITRS',NOW());
INSERT INTO ref_residence_of_issuer(code, description, created_by, date_created)VALUES('2','Non-resident','ITRS',NOW());
