﻿INSERT INTO ref_remittance_channel(code, description, created_by, date_created)VALUES('1','Bank branch/overseas office','ITRS',NOW());
INSERT INTO ref_remittance_channel(code, description, created_by, date_created)VALUES('2','Money Transfer Operator','ITRS',NOW());
INSERT INTO ref_remittance_channel(code, description, created_by, date_created)VALUES('3','Agent and Tie-up','ITRS',NOW());
INSERT INTO ref_remittance_channel(code, description, created_by, date_created)VALUES('4','Correspondent Bank','ITRS',NOW());
