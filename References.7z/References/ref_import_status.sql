﻿INSERT INTO ref_import_status(code, description, created_by, date_created)VALUES('1','Amendment','ITRS',NOW());
INSERT INTO ref_import_status(code, description, created_by, date_created)VALUES('2','Self-funded','ITRS',NOW());
INSERT INTO ref_import_status(code, description, created_by, date_created)VALUES('3','Sight','ITRS',NOW());
INSERT INTO ref_import_status(code, description, created_by, date_created)VALUES('4','Deferred/Usance','ITRS',NOW());
INSERT INTO ref_import_status(code, description, created_by, date_created)VALUES('5','Revision/Extension','ITRS',NOW());
INSERT INTO ref_import_status(code, description, created_by, date_created)VALUES('6','New','ITRS',NOW());
INSERT INTO ref_import_status(code, description, created_by, date_created)VALUES('7','Cancellation','ITRS',NOW());
