﻿INSERT INTO ref_book(code, description, created_by, date_created)VALUES('1','Foreign Regular','ITRS',NOW());
INSERT INTO ref_book(code, description, created_by, date_created)VALUES('2','FCDU/EFCDU','ITRS',NOW());
INSERT INTO ref_book(code, description, created_by, date_created)VALUES('3','Foreign Office','ITRS',NOW());
INSERT INTO ref_book(code, description, created_by, date_created)VALUES('4','Peso Accounts','ITRS',NOW());
