﻿INSERT INTO ref_registration_type(code, description, created_by, date_created)VALUES('1','Registered Investment','ITRS',NOW());
INSERT INTO ref_registration_type(code, description, created_by, date_created)VALUES('2','Unregistered Investment','ITRS',NOW());
