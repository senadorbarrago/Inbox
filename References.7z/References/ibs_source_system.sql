﻿INSERT INTO ibs_source_system(code, description, created_by, date_created)VALUES('GLX','GLFX-Legacy','ITRS',NOW());
INSERT INTO ibs_source_system(code, description, created_by, date_created)VALUES('FRS','Financial Reporting System','ITRS',NOW());
