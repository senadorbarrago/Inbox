﻿INSERT INTO ref_dealing_code(code, description, created_by, date_created)VALUES('1','with philippine Dealing   System (PDS)','ITRS',NOW());
INSERT INTO ref_dealing_code(code, description, created_by, date_created)VALUES('2','Outside PDS','ITRS',NOW());
