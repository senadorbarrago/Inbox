﻿INSERT INTO ref_credit_facility(code, description, created_by, date_created)VALUES('MLT','Medium and Long-term','ITRS',NOW());
INSERT INTO ref_credit_facility(code, description, created_by, date_created)VALUES('ST','Short-term','ITRS',NOW());
