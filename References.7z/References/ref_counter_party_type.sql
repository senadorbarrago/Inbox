﻿INSERT INTO ref_counter_party_type(code, description, created_by, date_created)VALUES('1','Non-resident bank','ITRS',NOW());
INSERT INTO ref_counter_party_type(code, description, created_by, date_created)VALUES('2','Non-resident non-bank','ITRS',NOW());
INSERT INTO ref_counter_party_type(code, description, created_by, date_created)VALUES('3','Central bank','ITRS',NOW());
INSERT INTO ref_counter_party_type(code, description, created_by, date_created)VALUES('4','Local Banks, including branches of Foreign Banks in the Philippines','ITRS',NOW());
INSERT INTO ref_counter_party_type(code, description, created_by, date_created)VALUES('6','Resident non-bank','ITRS',NOW());
