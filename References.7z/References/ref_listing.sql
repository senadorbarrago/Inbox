﻿INSERT INTO ref_listing(code, description, created_by, date_created)VALUES('1','PSE-listed','ITRS',NOW());
INSERT INTO ref_listing(code, description, created_by, date_created)VALUES('2','Unlisted','ITRS',NOW());
