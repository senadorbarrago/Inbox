﻿INSERT INTO ref_data_status(code, description, created_by, date_created)VALUES('STATUS-001','VALID','ITRS',NOW());
INSERT INTO ref_data_status(code, description, created_by, date_created)VALUES('STATUS-002','FOR APPROVAL','ITRS',NOW());
INSERT INTO ref_data_status(code, description, created_by, date_created)VALUES('STATUS-003','INVALID-Missing Required Fields','ITRS',NOW());
INSERT INTO ref_data_status(code, description, created_by, date_created)VALUES('STATUS-004','INVALID-Reference not Existing','ITRS',NOW());
INSERT INTO ref_data_status(code, description, created_by, date_created)VALUES('STATUS-005','INVALID-Field Length','ITRS',NOW());
INSERT INTO ref_data_status(code, description, created_by, date_created)VALUES('STATUS-006','INVALID-Field Data Type','ITRS',NOW());
INSERT INTO ref_data_status(code, description, created_by, date_created)VALUES('STATUS-007','INVALID-For Report Correction','ITRS',NOW());
INSERT INTO ref_data_status(code, description, created_by, date_created)VALUES('STATUS-008','INVALID-For Ammendment','ITRS',NOW());
INSERT INTO ref_data_status(code, description, created_by, date_created)VALUES('STATUS-009','INVALID-With Duplicate Record','ITRS',NOW());
