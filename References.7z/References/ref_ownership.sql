﻿INSERT INTO ref_ownership(code, description, created_by, date_created)VALUES('1','Bank''s own transaction','ITRS',NOW());
INSERT INTO ref_ownership(code, description, created_by, date_created)VALUES('2','Client''s transaction','ITRS',NOW());
