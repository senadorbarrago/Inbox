﻿INSERT INTO ref_mode_of_payment(code, description, created_by, date_created)VALUES('1','Letter of Credit (L/C)','ITRS',NOW());
INSERT INTO ref_mode_of_payment(code, description, created_by, date_created)VALUES('2','Document Against Payment (D/P)','ITRS',NOW());
INSERT INTO ref_mode_of_payment(code, description, created_by, date_created)VALUES('3','Cash Against Payment (CAD)','ITRS',NOW());
INSERT INTO ref_mode_of_payment(code, description, created_by, date_created)VALUES('4','Document Against Acceptance (D/A)','ITRS',NOW());
INSERT INTO ref_mode_of_payment(code, description, created_by, date_created)VALUES('6','Direct Remittance (DR)','ITRS',NOW());
INSERT INTO ref_mode_of_payment(code, description, created_by, date_created)VALUES('7','Export Advances','ITRS',NOW());
INSERT INTO ref_mode_of_payment(code, description, created_by, date_created)VALUES('9','Open Account (O/A)','ITRS',NOW());
INSERT INTO ref_mode_of_payment(code, description, created_by, date_created)VALUES('10','Advance Payment/Down Payment','ITRS',NOW());
INSERT INTO ref_mode_of_payment(code, description, created_by, date_created)VALUES('11','Self - Funded','ITRS',NOW());
