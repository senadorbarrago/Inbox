package com.bdo.itd.projects.bdocors.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BdoCorsWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(BdoCorsWebApplication.class, args);
	}
}
