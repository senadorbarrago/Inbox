'use strict';

define(function(){
		// Create core module
		var core = angular.module('core', ['ngRoute', 'ngCookies', 'ui.bootstrap', 'ui.select', 'ngSanitize', 'ngIdle', 'reportFormModule', 'ngmodel.format']);
		
		core.directive("scrollGroup", function() {
			return function(scope, element, attrs) {
				element.bind("scroll", function(e) {
					var prop = "[scroll-group-header='" + attrs.scrollGroup + "']";
					var hdrs = angular.element(document.querySelectorAll(prop));
					angular.forEach(hdrs, function(value, key) {
						value.scrollLeft = element[0].scrollLeft;
					});
				});
			};			
		});
		
		core.config(['$routeProvider', '$httpProvider', '$controllerProvider', '$cookiesProvider', '$locationProvider', 'KeepaliveProvider', 'IdleProvider',
			function($routeProvider, $httpProvider, $controllerProvider, $cookiesProvider, $locationProvider, KeepaliveProvider, IdleProvider){
			console.log('core.config');
			
			IdleProvider.idle(840);
			IdleProvider.timeout(10);
			KeepaliveProvider.interval(300);
			KeepaliveProvider.http('/bcas/healthCheck');
			
			// ControllerProvider Configuration
//			core.register = {
//					controller : $controllerProvider.register
//			};
			
			core.registerController = $controllerProvider.register;
			
			// Route Configuration
			$routeProvider
				.when('/',{
					controller: 'loginController',
					templateUrl: 'app/components/security/login.html',
					resolve:{
						load: function($q, $rootScope) {
							return resolveDependencies($q, $rootScope, ['app/components/security/loginController']);
						}	
					}				
				})
				.when('/home', {
					controller: 'homeController',
					templateUrl: 'app/components/home/home.html',
					resolve:{
						load: function($q, $rootScope, $location) {
							return resolveDependencies($q, $rootScope, ['app/components/home/homeController']);
						}
					}
				})
				.when('/glDate', {
					controller: 'glDateController',
					templateUrl: 'app/components/gldate/glDate.html',
					resolve:{
						load: function($q, $rootScope, $location) {
							return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/gldate/glDateController']);
						}
					}
				})
				.when('/rate', {
					controller: 'rateController',
					templateUrl: 'app/components/gldate/rate.html',
					resolve:{
						load: function($q, $rootScope, $location) {
							return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/gldate/rateController']);
						}
					}
				})
				.when('/predefinedEntries', {
					controller: 'predefinedEntriesController',
					templateUrl: 'app/components/gldate/predefinedEntries.html',
					resolve:{
						load: function($q, $rootScope, $location) {
							return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/gldate/predefinedEntriesController']);
						}
					}
				})
				.when('/finalize', {
					controller: 'finalizeController',
					templateUrl: 'app/components/finalize/finalize.html',
					resolve:{
						load: function($q, $rootScope, $location) {
							return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/finalize/finalizeController']);
						}
					}
				})
				.when('/beginOfDay', {
					controller: 'beginOfDayController',
					templateUrl: 'app/components/beginofday/beginOfDay.html',
					resolve:{
						load: function($q, $rootScope, $location) {
							return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/beginofday/beginOfDayController']);
						}
					}
				})
				.when('/forReferral', {
					controller: 'forReferralController',
					templateUrl: 'app/components/forReferral/forReferral.html',
					resolve:{
						load: function($q, $rootScope, $location) {
							return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/forReferral/forReferralController']);
						}
					}
				})
				.when('/processing/transactionInbox', {
					controller: 'transactionInboxController',
					templateUrl: 'app/components/processing/transactionInbox/transactionInbox.html',
					resolve:{
						load: function($q, $rootScope, $location) {
							return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/processing/transactionInbox/transactionInboxController']);
						}
					}
				})
				.when('/processing/myTransactions', {
					controller: 'myTransactionsController',
					templateUrl: 'app/components/processing/myTransactions/myTransactions.html',
					resolve:{
						load: function($q, $rootScope, $location) {
							return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/processing/myTransactions/myTransactionsController']);
						}
					}
				})
				.when('/processing/journalEntries', {
					controller: 'journalEntriesController',
					templateUrl: 'app/components/processing/journalEntries/journalEntries.html',
					resolve:{
						load: function($q, $rootScope, $location) {
							return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/processing/journalEntries/journalEntriesController']);
						}
					}
				})
				.when('/processing/controlTotals', {
					controller: 'controlTotalsController',
					templateUrl: 'app/components/processing/controlTotals/controlTotals.html',
					resolve:{
						load: function($q, $rootScope, $location) {
							return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/processing/controlTotals/controlTotalsController']);
						}
					}
				})
				.when('/processing/batchSheets', {
					controller: 'batchSheetsController',
					templateUrl: 'app/components/processing/batchSheets/batchSheets.html',
					resolve:{
						load: function($q, $rootScope, $location) {
							return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/processing/batchSheets/batchSheetsController']);
						}
					}
				})
				.when('/processing/status', {
					controller: 'statusController',
					templateUrl: 'app/components/processing/status/status.html',
					resolve:{
						load: function($q, $rootScope, $location) {
							return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/processing/status/statusController']);
						}
					}
				})
				.when('/processing/forReferral', {
					controller: 'forReferralController',
					templateUrl: 'app/components/processing/forReferral/forReferral.html',
					resolve:{
						load: function($q, $rootScope, $location) {
							return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/processing/forReferral/forReferralController']);
						}
					}
				})

				.when('/inventory/transactions', {
					controller: 'transactionInventoryController',
					templateUrl: 'app/components/inventory/transactions/transactionInventory.html',
					resolve:{
						load: function($q, $rootScope, $location) {
							return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/inventory/transactions/transactionInventoryController']);
						}
					}
				})
				.when('/inventory/takeups', {
					controller: 'takeUpsInventoryController',
					templateUrl: 'app/components/inventory/takeups/takeUpsInventory.html',
					resolve:{
						load: function($q, $rootScope, $location) {
							return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/inventory/takeups/takeUpsInventoryController']);
						}
					}
				})
				.when('/inventory/journalentries', {
					controller: 'jeInventoryController',
					templateUrl: 'app/components/inventory/journalentries/jeInventory.html',
					resolve:{
						load: function($q, $rootScope, $location) {
							return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/inventory/journalentries/jeInventoryController']);
						}
					}
				})
				.when('/inventory/batchsheets', {
					controller: 'batchsheetsInventoryController',
					templateUrl: 'app/components/inventory/batchsheets/batchsheetsInventory.html',
					resolve:{
						load: function($q, $rootScope, $location) {
							return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/inventory/batchsheets/batchsheetsInventoryController']);
						}
					}
				})
				.when('/reports', {
					controller: 'reportsController',
					templateUrl: 'app/components/reports/reports.html',
					resolve:{
						load: function($q, $rootScope, $location) {
							return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/reports/reportsController']);
						}
					}
				})
				.when('/outbound/generateOutbound', {
					controller: 'generateOutboundController',
					templateUrl: 'app/components/outbound/generateOutbound/generateOutbound.html',
					resolve:{
						load: function($q, $rootScope, $location) {
							return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/outbound/generateOutbound/generateOutboundController']);
						}
					}
				})
				.when('/outbound/extractedOutbound', {
					controller: 'extractedOutboundController',
					templateUrl: 'app/components/outbound/extractedOutbound/extractedOutbound.html',
					resolve:{
						load: function($q, $rootScope, $location) {
							return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/outbound/extractedOutbound/extractedOutboundController']);
						}
					}
				})
				.when('/inbound/available', {
					controller: 'availableFilesController',
					templateUrl: 'app/components/inbound/inboundAvailable.html',
					resolve:{
						load: function($q, $rootScope, $location) {
							return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/inbound/availableFilesController']);
						}
					}
				})
				.when('/inbound/processed', {
					controller: 'processedFilesController',
					templateUrl: 'app/components/inbound/inboundProcessed.html',
					resolve:{
						load: function($q, $rootScope, $location) {
							return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/inbound/processedFilesController']);
						}				
					}

				})
				.when('/advancesearch/:code', {
					controller: 'advanceSearchController',
					templateUrl: 'app/components/advancesearch/advanceSearch.html',
					resolve:{
						load: function($q, $rootScope, $location) {
							return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/advancesearch/advanceSearchController']);
						}
					}
				})
				.when('/uploads/', {
					controller: 'uploadsController',
					templateUrl: 'app/components/uploads/uploads.html',
					resolve:{
						load: function($q, $rootScope, $location) {
							return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/uploads/uploadsController']);
						}
					}
				})
				.otherwise("/home");
			
//			if(window.history && window.history.pushState){
//				// Enable HTML5
//				$locationProvider.html5Mode({
//					enabled: true,
//					requireBase: false
//				});
//			}
			
			// Resource access with Authentication
			var resolveDependenciesWithAuthentication = function($q, $rootScope, $location, dependencies) {
				var defer = $q.defer();
				if ($rootScope.session['AUTHENTICATED'] === true) {
					require(dependencies, function() {
						defer.resolve();
						$rootScope.$apply();
					});
					return defer.promise;
				} else {
					console.log("not authenticated")
					$location.path("/");
					return $q.reject("/");
				}
			};
			// Resource access without Authentication
			var resolveDependencies = function($q, $rootScope, dependencies) {
				var defer = $q.defer();
				require(dependencies, function() {
					defer.resolve();
					$rootScope.$apply();
				});
				return defer.promise;
			};
			
			//$locationProvider.html5Mode(true);
			//$locationProvider.hashPrefix('');
			
			$httpProvider.defaults.headers.common["X-Requested-With"] = 'XMLHttpRequest';
			$httpProvider.defaults.headers.common["Cache-Control"] = "no-cache";
			$httpProvider.defaults.headers.common["Pragma"] = "no-cache";
		}]);
		
		core.run(['$rootScope', '$uibModal', '$uibModalStack', '$location', '$cookies', '$window', 'DataAccessService', 'Idle',
			function($rootScope, $uibModal, $uibModalStack, $location, $cookies, $window, dataAccessService, Idle){
			
			// Initialize Session
			$rootScope.session = {};
			console.log($rootScope.session);
			$rootScope.showSpinner = false;
			
			// App Information
			dataAccessService.doGetData("app/appinfo.json", null, function(response){
				$rootScope.appInfo = response.data;
			},function(errorResponse){
				console.log(errorResponse);
			});
			
			// Menu Resources
			dataAccessService.doGetData("app/config/menuConfig.json", null, function(response){
				console.log(response);
				$rootScope.menus = response.data.menu;
			},function(errorResponse){
				console.log(errorResponse);
			});
			
			// Report Resources
			dataAccessService.doGetData("app/config/report-config.json", null, function(response){
				console.log(response);
				$rootScope.reports = response.data.reports;
			},function(errorResponse){
				console.log(errorResponse);
			});
			
			// Oubound Config
			dataAccessService.doGetData("app/config/outbound-files-config.json", null, function(response){
				console.log(response);
				$rootScope.outbounds = response.data.outbounds;
			},function(errorResponse){
				console.log(errorResponse);
			});
			
			// Resource Permission
			$rootScope.hasResourcePermission = function(resourceID){
				if($rootScope.session['AUTHENTICATED_USER']){
					var resourceList = $rootScope.session['AUTHENTICATED_USER'].activeMembership.resourceList;
					for(var i = 0; i < resourceList.length; i++){
						if(resourceList[i].securedItemCode === resourceID){
							return true;
						}
					}
				}
			};	

			$rootScope.$on("initializeAuthority", function() {
				console.log("initializeAuthority");
				$rootScope.httpException = false;
				
				// Business Permission
				var groupCode = {
									'groupCode' : $rootScope.session['AUTHENTICATED_USER'].activeMembership.group.code
								};
				
				dataAccessService.doQuery('DataSetByGroupCodeQueryModel', groupCode, function(response){
					console.log(response);
					$rootScope.dataSetID = response.data.resultSet[0].id;
					$rootScope.dataSetCode = response.data.resultSet[0].code;
					$cookies.put("DATA_SET_ID", $rootScope.dataSetID);
					$cookies.put("DATA_SET_CODE", $rootScope.dataSetCode);
					
					dataAccessService.doQuery('CostCenterByGroupCodeQueryModel', groupCode, function(response){
						$rootScope.costCenterID = response.data.resultSet[0].id;
						$rootScope.encodingUnitCode = response.data.resultSet[0].code;
						$cookies.put("COST_CENTER_ID", $rootScope.costCenterID);
						$cookies.put("COST_CENTER_CODE", $rootScope.encodingUnitCode);
						
						$rootScope.refreshProcessInfo();
						
						$location.path('/home');
					}, function(errorResponse){
						$rootScope.costCenterID = null;
						$rootScope.encodingUnitCode = null;
						$cookies.remove("COST_CENTER_ID");
						$cookies.remove("COST_CENTER_CODE");
						console.log(errorResponse.status+': '+errorResponse.headers("ERROR_MESSAGE"));
					});
					}, function(errorResponse){
						$rootScope.dataSetID = null;
						$rootScope.dataSetCode = null;
						$cookies.remove("DATA_SET_ID");
						$cookies.remove("DATA_SET_CODE");
						console.log(errorResponse.status+': '+errorResponse.headers("ERROR_MESSAGE"));
					});
				
			});
			
			$rootScope.$on("$locationChangeStart", function(event, next, current) {
				var i = next.lastIndexOf("#"); 
				if ( i > -1) {
					$cookies.put("CURRENT_PAGE", next.substring(i+1));
					$rootScope.currentPage = next.substring(i+1);
					$uibModalStack.dismissAll();
				} else {
					$cookies.put("CURRENT_PAGE", "/home");
					$rootScope.currentPage = "/home";
					$uibModalStack.dismissAll();
				}
				
				console.log("$rootScope.currentPage: "+$rootScope.currentPage);
			});	
			
			
			$rootScope.$on("$locationChangeSuccess", function(event, next, current) {
				if (next.indexOf("/reference") !== -1) {
					window.location.href= "#/maintenance/bcas";
				}
			});		
			
			/**
			 * 
			 */
			let removeAllCookies = function(){
				var cookies = $cookies.getAll();
				angular.forEach(cookies, function (v, k) {
				    $cookies.remove(k);
				});
			}
			
			/**
			 * 
			 */
			let getAuthenticatedUser = function(){
				dataAccessService.doGetData("authenticatedUser", null, function(response){
					if(response.headers('Content-Type').indexOf("application/json") == -1) {
						$rootScope.session = {};
						removeAllCookies();
						$location.path('/');
						alertify.fail("Forbidden: Session already expired.");
					}else{
						
						console.log(response.data);
						$rootScope.session['AUTHENTICATED_USER'] = response.data;
						
						$rootScope.session['CURRENT_PAGE'] = $cookies.get("CURRENT_PAGE");
						$location.path($cookies.get("CURRENT_PAGE"));						
						$rootScope.dataSetID = parseFloat($cookies.get("DATA_SET_ID"));
						$rootScope.costCenterID = $cookies.get("COST_CENTER_ID");
						$rootScope.dataSetCode = $cookies.get("DATA_SET_CODE");
						$rootScope.encodingUnitCode = $cookies.get("COST_CENTER_CODE");
						
						$rootScope.session["PROCESSINFO"]= {};
						$rootScope.session["PROCESSINFO"].processDate = $cookies.get("processDate");
						$rootScope.session["PROCESSINFO"].processCode = $cookies.get("processCode");
						$rootScope.session["PROCESSINFO"].processDescription = $cookies.get("processDescription");
					}
				},function(errorResponse){
					$rootScope.session = {};
					removeAllCookies();
					$location.path('/');
					alertify.fail("Forbidden: Session already expired.");
				});
			}
			
			// Restores session data from cookie repository during after page request
			if($cookies.get("AUTHENTICATED") === "true"){
				$location.path($cookies.get("CURRENT_PAGE"));
				$rootScope.session['AUTHENTICATED']  = true;
				getAuthenticatedUser();
			}
			
			$rootScope.doRMF = function(){
				dataAccessService.doGetData("rmf", null, function(response){
					console.log("Reference Maintenance");
					console.log(response.data.redirectUrl);
					window.location.href= response.data.redirectUrl;
				},function(errorResponse){
					console.log(errorResponse);
				});
			}
			
			// Logout
			$rootScope.logout = function(){
				dataAccessService.doPostData("logout", null, function(response){
					$rootScope.unWatchTimeout();
					$uibModalStack.dismissAll();
					alertify.alert("You have successfully logged out from BCAS", function(e){
						removeAllCookies();
						$rootScope.session = {};
						$location.path('/');
					});					
				},function(errorResponse){
					console.log(errorResponse);
				});
			}
			
			// Process Info
			$rootScope.refreshProcessInfo = function(){
				var data = {
							 'dataSetCode' : $rootScope.dataSetCode,
							 'encodingUnitCode' : $rootScope.encodingUnitCode
							};
				dataAccessService.doQuery('ProcessingStateQueryModel', data, function(response){
					console.log(response.data);
					$rootScope.session["PROCESSINFO"] = response.data.resultSet[0];
					
					$cookies.put("processDate", $rootScope.session["PROCESSINFO"].processDate);
					$cookies.put("processCode", $rootScope.session["PROCESSINFO"].processCode);
					$cookies.put("processDescription", $rootScope.session["PROCESSINFO"].processDescription);
				}, function(errorResponse){
					$rootScope.session["PROCESSINFO"] = null;
					$cookies.remove("processDate");
					$cookies.remove("processCode");
					$cookies.remove("processDescription");
					console.log(errorResponse.status+': '+errorResponse.headers("ERROR_MESSAGE"));
				});
			}
			
			// Show Assigned Logical Branch
			$rootScope.showAssignedLogicalBranchForm= function(){
				var modalInstance = $uibModal.open({
					animation: true,
					templateUrl: 'app/shared/assignedlogicalbranch/assignedLogicalBranch.html',
					controller: 'assignedLogicalBranchController',
					
					keyboard: false,
					resolve:{
						load: ['$q', function($q){
							var defered = $q.defer();
							require(['app/shared/assignedlogicalbranch/assignedLogicalBranchController'], function(){
								defered.resolve();
							});
							return defered.promise;
						}]
					}
				});
				return modalInstance.result;
			}
			
			/**
			 *  Session Timeout Watcher
			 * 
			 */
			if($rootScope.session['AUTHENTICATED'] &&
					$rootScope.session['AUTHENTICATED'] === true){
				Idle.watch();
			}else{
				Idle.unwatch();
			}
			
			$rootScope.watchTimeout = function(){
				Idle.watch();
			}
			
			$rootScope.unWatchTimeout = function(){
				Idle.unwatch();
			}
			
			let closeModals = function(){
				if($rootScope.warning){
					$rootScope.warning.close();
					$rootScope.warning = null;
				}
			}
			
			$rootScope.$on('IdleStart', function(){
				closeModals();
				$rootScope.warning = $uibModal.open({
					templateUrl: 'warning-dialog.html',
					windowsClass: 'modal-danger'
				});
			});
			
			$rootScope.$on('IdleEnd', function(){
				closeModals();
			});
			
			$rootScope.$on('IdleTimeout', function(){
				closeModals();
				$rootScope.logout();
				Idle.watch();
			});
			
			$rootScope.$on('KeepAlive', function(){
				alertify.alert('Im Alive!!!');
			});
			
			
			Number.prototype.toFixedSpecial = function(n) {
				console.log('Number.prototype.toFixedSpecial: '+n);
				var str = this.toFixed(n);
			    if (str.indexOf('e+') < 0)
			        return str;
			    	
			    // if number is in scientific notation, pick (b)ase and (p)ower
			    return str.replace('.', '').split('e+').reduce(function(p, b) {
			        return p + Array(b - p.length + 2).join(0);
			    }) + '.' + Array(n + 1).join(0);
			};
			
			
		}]);
		
		// Load Dependencies
		require(['serviceIndex', 'directiveIndex'], function(serviceIndex, directiveIndex){
			console.log('core.require');
			require(serviceIndex, function(){
				require(directiveIndex, function(){
					angular.bootstrap(document, ['core']);
				});
			});
		});
		
});
