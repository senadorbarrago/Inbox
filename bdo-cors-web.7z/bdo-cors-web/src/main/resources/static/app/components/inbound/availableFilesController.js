'use strict';

define(function(){
	console.log('availableFilesController.js loaded');
	var core = angular.module('core');
	
	core.registerController('availableFilesController',['$rootScope','$scope', 'DataAccessService', 
	    function($rootScope, $scope, dataAccessService){
		$scope.title = 'This is the Available Files screen';
		$rootScope.screenName = 'Inbound --> For Loading'
		
		var vm = this,
		
		// URL
		URL_FOR_LOADING 				 = 'inboundinterface/forLoading',
		URL_COPY_INBOX_FILES_TO_SOURCE   = 'inboundinterface/forLoading/copy',
		URL_REMOVE_FILES_FROM_SOURCE     = 'inboundinterface/forLoading/remove',
		URL_LOAD_SOURCE_FILES            = 'inboundinterface/forLoading/loadsourcefile';
		
		// Initialize Data
		vm.init = function(){
			$scope.data = {};
			$scope.data.dataSetCode = $rootScope.dataSetCode;
			$scope.data.membershipCode = $rootScope.session['AUTHENTICATED_USER'].activeMembership.code;
			$scope.dataSet = $rootScope.dataSetID;
			
			// Table Header 
			$scope.tableHeader = ['Select', 'File Name', 'File Path', 'Size', 'Date Created'];
			
			vm.doGetDefaultInboxContents();
			vm.doGetDefaultSourceContents();
		};
		
		// Private functions
		vm.doGetDefaultInboxContents = function(dirCode){
			var data = {};
			data = angular.copy($scope.data);
			data.dirCode = "INB";
			dataAccessService.doPostData(URL_FOR_LOADING, data, function(response){
				console.log(response);
				$scope.inboxdata = response.data;
				// Add additional selection element
				angular.forEach($scope.inboxdata.resultSet, function(value, key){
					value["Selected"] = false;
				});
			},function(errorResponse){
				alertify.alert(errorResponse.data.errorMsg);
				console.log(errorResponse);
			});
		}
		vm.doGetDefaultSourceContents = function(){
			var data = {};
			data = angular.copy($scope.data);
			data.dirCode = "SRC";
			dataAccessService.doPostData(URL_FOR_LOADING, data, function(response){
				$scope.sourcedata = response.data;
				// Add additional selection element
				angular.forEach($scope.sourcedata.resultSet, function(value, key){
					value["Selected"] = false;
				});
			},function(errorResponse){
				console.log(errorResponse);
			});
		}
		// UI Validations
		vm.checkIfHasSelection = function(list){
			for(var index = 0; index < list.length; index++){
				if(list[index]["Selected"]){
					return true;
				}
			}
			return false;
		}
		vm.init();
		
		$scope.doCopySelectedFile = function(){
			var inboxdatacopy = angular.copy($scope.inboxdata.resultSet);
			var hasSelection = vm.checkIfHasSelection(inboxdatacopy);
			
			if(!hasSelection){
				alertify.alert("Please select a file to be copied in order to proceed");
			}else{
				alertify.confirm("This action copies the selected files from the inbound directory. " +
						"Are you sure you want to proceed?", function(e){
					if(e){
						angular.forEach(inboxdatacopy, function(value, key){
							if(value["Selected"]){
								var selectedFileName = value["Path"]+"\\"+value["File Name"];
								console.log(selectedFileName);
								var selectedFile = {
													"selectedFile" : selectedFileName,
													"dataSetCode" : $scope.dataSetCode
													};
								
								dataAccessService.doPostData(URL_COPY_INBOX_FILES_TO_SOURCE, selectedFile, function(response){
									console.log("Success....");
									value["Selected"] = false;
									vm.doGetDefaultSourceContents();
									alertify.alert(response.data.messageMap.successMsg, function(e){});
								}, function(errorResponse){
									vm.doGetDefaultSourceContents();
									console.log(errorResponse);
								});
							}
						});
					}
				});	
			}
		};
		
		$scope.doRemoveSelectedFiles = function(){
			var sourcedatacopy = angular.copy($scope.sourcedata.resultSet);
			var hasSelection = vm.checkIfHasSelection(sourcedatacopy);
			
			if(!hasSelection){
				alertify.alert("Please select a file to be removed in order to proceed");
			}else{
				alertify.confirm("This action removes the selected files from the directory. " +
								"Are you sure you want to proceed?", function(e){
					if(e){
						angular.forEach(sourcedatacopy, function(value, key){
							console.log(value["Selected"]);
							if(value["Selected"]){
								var selectedFileName = value["Path"]+"\\"+value["File Name"];
								console.log(selectedFileName);
								var selectedFile = {
													"selectedFile" : selectedFileName
													};
								dataAccessService.doPostData(URL_REMOVE_FILES_FROM_SOURCE, selectedFile, function(response){
									value["Selected"] = false;
									vm.doGetDefaultSourceContents();
									alertify.alert(response.data.messageMap.successMsg, function(e){});
								}, function(errorResponse){
									vm.doGetDefaultSourceContents();
									console.log(errorResponse);
								});
							}
						});
					}else{
						return;
					}
				});
			}
		};
		
		$scope.doLoadSelectedFile = function(){
			var sourcedatacopy = angular.copy($scope.sourcedata.resultSet);
			var hasSelection = vm.checkIfHasSelection(sourcedatacopy);
			
			if(!hasSelection){
				alertify.alert("Please select a file to be loaded in order to proceed");
				return false;
			}else{
				alertify.confirm("This action loads the selected files from the source folder. " +
								"Are you sure you want to proceed?", function(e){
				if(e){
						var sourceFileList = [];
						angular.forEach(sourcedatacopy, function(value, key){
							if(value["Selected"]){
								var selectedFileName = value["File Name"];
								console.log(selectedFileName);
								sourceFileList.push(selectedFileName);
							}
						});
						
						var data = {};
						data.sourceFileList = sourceFileList;
						data.dataSetCode = $rootScope.dataSetCode;
						
						dataAccessService.doPostData(URL_LOAD_SOURCE_FILES, data, function(response){
							vm.doGetDefaultSourceContents();
							console.log('HEEERRRRE');
							alertify.alert(response.data.messageMap.successMsg, function(e){});
						}, function(errorResponse){
							console.log(errorResponse);
							alertify.alert(errorResponse.data.errorMsg, function(e){});
							vm.doGetDefaultSourceContents();
							
						});
						
					}else{
						return;
					}
				});
			}
		};
		
		$scope.open = function(columnName, $event){
			
			$event.preventDefault();
			$event.stopPropagation();
			
			if ($scope.datePicker[columnName]) {
				if ($scope.datePicker[columnName].opened) {
					$scope.datePicker[columnName].opened = false;
				}
			} else {
				$scope.datePicker = {};
				$scope.datePicker[columnName] = {};
				$scope.datePicker[columnName].opened = true;
			}
		}
		
	}]);
});