'use strict';

define(function(){
	angular.module('core').registerController('inboundController', ['$rootScope', '$scope', function($rootScope, $scope){
		$rootScope.screenName = 'INBOUND_INTERFACE';
		
	}]);
});