'use strict'

define(function(){
	console.log('restrictPatternDirective.js loaded');
	
	var core = angular.module('core');
	
	core.directive('restrictPattern', function(){

		function link(scope, elem, attrs, ngModel) {
	          ngModel.$parsers.push(function(viewValue) {
	        	
	        	if(viewValue === null){
	        		viewValue = '';
	        	}  
	        	
	        	var reg = /^[^"]*$/;
	            // if view values matches regexp, update model value
	            if (viewValue.match(reg)) {
	              return viewValue;
	            }
	            // keep the model value as it is
	            console.log("ngModel.$modelValue=" + ngModel.$modelValue);
	            
	            var transformedValue = ngModel.$modelValue;
	            ngModel.$setViewValue(transformedValue);
	            ngModel.$render();
	            return transformedValue;
	          });
	      }

	      return {
	          restrict: 'A',
	          require: 'ngModel',
	          link: link
	      };
	});
});