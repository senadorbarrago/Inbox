'use strict'

define(function(){
	console.log('MoneyDirective.js loaded');
	
	var core = angular.module('core');
	
	core.directive('moneyFormat', ['$filter', function($filter){
		return {
	        link:function(scope,ele,attrs){
	            ele.bind('keypress',function(e){
	            	console.log($(ele[0]).val());
	            	 $(ele[0]).val($filter('currency')( $(ele[0]).val(), '', 2));
	            });
	        }
	    };
	}]);
	
	return core;
});