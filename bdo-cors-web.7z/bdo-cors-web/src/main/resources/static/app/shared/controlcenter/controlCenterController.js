'use strict';

define(function(){
	
	console.log('controlCenterController.js loaded');
	var core = angular.module('core');
	
	core.registerController('controlCenterController', ['$rootScope', '$scope', '$uibModalInstance', 'DataAccessService', 
			function($rootScope, $scope, $uibModalInstance, dataAccessService){
		$scope.title = 'Control Center X';
		
		var vm = this;
	
		vm.init = function(){
			
			
		}
		vm.init();
		
		$scope.doExecute = function() {
			console.log('doExecute()');
			var url = "controlcenter/execute";
			console.log($scope.data.sql)
			dataAccessService.doPostData(url, $scope.data, function(response){
				console.log(response);
				alertify.alert(response.data.message);
			}, function(errorResponse){
				alertify.fail(errorResponse.data.errorMsg);
			});
			
			
		};
		
		$scope.doQuery = function() {
			console.log('doQuery()');
			var url = "controlcenter/query";
			console.log($scope.data.sql)
			dataAccessService.doPostData(url, $scope.data, function(response){
				console.log(response);
				$scope.form = response.data;
			}, function(errorResponse){
				alertify.fail(errorResponse.data.errorMsg);
			});
		};
		
		$scope.close = function(){
			$uibModalInstance.close();
		};
		
		
	
	}]);
});