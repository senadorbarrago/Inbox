package com.bdo.itd.util.security.test.authentication;

import javax.inject.Inject;
import javax.inject.Named;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.bdo.itd.util.eua.authentication.EuaAuthenticationClient;
import com.bdo.itd.util.eua.authentication.entities.AuthenticationResponseEntity;
import com.bdo.itd.util.eua.inquiry.EuaInquiryClient;
import com.bdo.itd.util.security.domain.models.Resource;
import com.bdo.itd.util.security.domain.models.UserProfile;
import com.bdo.itd.util.security.domain.services.IAuthenticationService;
import com.bdo.itd.util.security.domain.services.UserAuthenticationException;

@ContextConfiguration({"classpath:securityContext.xml", "classpath:applicationContext.xml"})
@Transactional  
@RunWith(SpringJUnit4ClassRunner.class)  
public class EuaAuthenticationTest {
	
	@Inject
	@Named("euaAuthenticationService")
	private IAuthenticationService euaAthenticationService;
	
	@Inject
	@Named("euaAuthenticationClient")
	private EuaAuthenticationClient euaAuthenticationClient;
	
	@Inject
	@Named("euaInquiryClient")
	private EuaInquiryClient euaInquiryClient;
	
	@Ignore
	@Test(expected = UserAuthenticationException.class)
	public void testInvalidCredentials() throws UserAuthenticationException{
		euaAthenticationService.doAuthenticate("c140618008", "Pa$$w0rd");
	}
	
	@Ignore
	@Test
	public void testValidCredentials() throws UserAuthenticationException{
		UserProfile userProfile = euaAthenticationService.doAuthenticate("c140618008", "Pa$$w0rd007");
		for(GrantedAuthority authority : userProfile.getActiveMembership().getResourceList()){
			Resource resource = (Resource) authority;
			System.out.println("resourceCode: "+resource.getCode());
			System.out.println("securedItemCode: "+resource.getSecuredItemCode());
		}
	}
	
	@Ignore
	@Test
	public void testEUAuthentication() throws UserAuthenticationException{
		AuthenticationResponseEntity responseEntity =  euaAuthenticationClient.authenticate("c140618008", "Pa$$w0rd007");
		System.out.println(responseEntity);
		System.out.println(responseEntity.toJson());
		System.out.println(responseEntity.getMenus());
		System.out.println(responseEntity.toString());
	}
	
	@Ignore
	@Test
	public void testEUInquiry() throws UserAuthenticationException{
		euaInquiryClient.getApplicationUser("c150819004", "c150819004");
	}
}
