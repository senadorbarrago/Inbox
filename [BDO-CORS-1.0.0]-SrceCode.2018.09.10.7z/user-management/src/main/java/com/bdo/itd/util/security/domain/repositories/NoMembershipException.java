package com.bdo.itd.util.security.domain.repositories;

import com.bdo.itd.util.security.SecurityException;

/**
 * @author c140618008
 *
 */
public class NoMembershipException extends SecurityException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 307626752921076540L;

	/**
	 * @param message
	 */
	public NoMembershipException(String message) {
		super(message);
	}
	
	/**
	 * @param cause
	 */
	public NoMembershipException(Throwable cause) {
		super(cause);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public NoMembershipException(String message, Throwable cause) {
		super(message, cause);
	}	
}
