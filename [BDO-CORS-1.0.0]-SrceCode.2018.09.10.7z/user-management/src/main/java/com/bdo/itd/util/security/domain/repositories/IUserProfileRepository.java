package com.bdo.itd.util.security.domain.repositories;

import com.bdo.itd.util.security.domain.models.Membership;
import com.bdo.itd.util.security.domain.models.UserProfile;

/**
 * @author c140618008
 *
 */
public interface IUserProfileRepository {
	
	/**
	 * @param username
	 * @param activeMembership
	 * @return
	 * @throws UserNotFoundException
	 * @throws NoMembershipException
	 */
	public UserProfile findUserProfileByUsername(String username, Membership activeMembership) throws UserNotFoundException, NoMembershipException;
	
}
