package com.bdo.itd.util.security.domain.models;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;

/**
 * 
 * @author c140618008
 *
 */
public class Membership{
	
	/**
	 * 
	 */
	private final long membershipID;
	
	/**
	 * 
	 */
	private final String code;
	/**
	 * 
	 */
	private final Group group;
	/**
	 * 
	 */
	private final Role role;
	/**
	 * 
	 */
	private List<GrantedAuthority> resourceList;
	/**
	 * 
	 * @param code
	 * @param group
	 * @param role
	 * @param resourceList
	 */
	public Membership(long membershipID, String code, Group group, Role role) {
		super();
		this.membershipID = membershipID;
		this.code = code;
		this.group = group;
		this.role = role;
	}
	
	public long getMembershipID() {
		return membershipID;
	}

	/**
	 * 
	 * @return
	 */
	public String getCode() {
		return code;
	}
	/**
	 * 
	 * @return
	 */
	public Group getGroup() {
		return group;
	}
	/**
	 * 
	 * @return
	 */
	public Role getRole() {
		return role;
	}
	
	public void addResource(Resource resource){
		if(this.resourceList == null){
			this.resourceList = new ArrayList<GrantedAuthority>();
		}
		resourceList.add(resource);
	}
	
	/**
	 * @param resourceList
	 */
	public void setResourceList(List<GrantedAuthority> resourceList) {
		this.resourceList = resourceList;
	}
	
	/**
	 * 
	 * @return
	 */
	public List<GrantedAuthority> getResourceList() {
		return Collections.unmodifiableList(resourceList);
	}
}
