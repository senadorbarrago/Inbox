package com.bdo.itd.util.security.domain.services;

import com.bdo.itd.util.security.SecurityException;

/**
 * @author c140618008
 *
 */
public class UserAuthorizationException extends SecurityException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2905065470925718320L;
	
	/**
	 * @param message
	 */
	public UserAuthorizationException(String message) {
		super(message);
	}

	/**
	 * @param cause
	 */
	public UserAuthorizationException(Throwable cause) {
		super(cause);
	}
	
	/**
	 * @param message
	 * @param cause
	 */
	public UserAuthorizationException(String message, Throwable cause) {
		super(message, cause);
	}
}