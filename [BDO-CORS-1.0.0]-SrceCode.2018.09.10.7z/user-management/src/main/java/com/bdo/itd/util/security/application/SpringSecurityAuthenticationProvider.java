package com.bdo.itd.util.security.application;

import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.dao.AbstractUserDetailsAuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;

import com.bdo.itd.util.logger.LoggerUtility;
import com.bdo.itd.util.logger.LoggerUtilityFactory;
import com.bdo.itd.util.security.domain.models.UserProfile;
import com.bdo.itd.util.security.domain.services.IAuthenticationService;
import com.bdo.itd.util.security.domain.services.UserAuthenticationException;


/**
 * @author c140618008
 *
 */
public class SpringSecurityAuthenticationProvider extends AbstractUserDetailsAuthenticationProvider{
	
	/**
	 * 
	 */
	private static final LoggerUtility LOGGER = 
			LoggerUtilityFactory.createLoggerUtility(SpringSecurityAuthenticationProvider.class);

	/**
	 * 
	 */
	private final IAuthenticationService authenticationService;
	
	/**
	 * @param authenticationService
	 */
	public SpringSecurityAuthenticationProvider(IAuthenticationService authenticationService) {
		super();
		this.authenticationService = authenticationService;
	}

	@Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		LOGGER.info(this.getClass()+"-authenticate(): " + authentication.getPrincipal().toString());
		Authentication successAuthentication = null;
		
		try{
        	String presentedUsername = authentication.getPrincipal().toString();
        	String presentedPassword = authentication.getCredentials().toString();
        	
        	UserProfile userProfile = authenticationService.doAuthenticate(presentedUsername, presentedPassword);
        	
            Object principalToReturn = userProfile;
            
            successAuthentication =  createSuccessAuthentication(principalToReturn, authentication, userProfile);
        }catch(UserAuthenticationException ex){
        	throw new BadCredentialsException(ex.getMessage(), ex);
        }catch(AuthenticationException | SecurityException ex){
            throw ex;
        }
		
		return successAuthentication;
    }    

	@Override
	protected void additionalAuthenticationChecks(UserDetails arg0, UsernamePasswordAuthenticationToken arg1)
			throws AuthenticationException {}

	@Override
	protected UserDetails retrieveUser(String arg0, UsernamePasswordAuthenticationToken arg1)
			throws AuthenticationException {
		return null;
	}
}