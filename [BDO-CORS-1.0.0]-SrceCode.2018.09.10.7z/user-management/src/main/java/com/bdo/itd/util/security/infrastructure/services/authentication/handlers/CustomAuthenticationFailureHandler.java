package com.bdo.itd.util.security.infrastructure.services.authentication.handlers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;

import com.bdo.itd.util.persistence.DataAccessInterface;

/**
 * 
 * @author 
 *
 */
public class CustomAuthenticationFailureHandler implements AuthenticationFailureHandler {
	
	/**
	 * 
	 */
	private final DataAccessInterface dataAccessService;
	
	/**
	 * 
	 */
	private final String defaultFailureUrl;
	
	/**
	 * 
	 */
	private final int errorStatusCode;
	
	/**
	 * 
	 */
	private final boolean withLocalAudit;
	
	/**
	 * 
	 */
	private final String applicationName;
	
	/**
	 * 
	 */
	private final String instanceName;
	
	/**
	 * 
	 */
	private final String actionCode;
	
	/**
	 * 
	 */
	private final String status;
	
	public CustomAuthenticationFailureHandler(DataAccessInterface dataAccessService, String defaultFailureUrl,
			int errorStatusCode, boolean withLocalAudit, String applicationName, String instanceName, String actionCode,
			String status) {
		super();
		this.dataAccessService = dataAccessService;
		this.defaultFailureUrl = defaultFailureUrl;
		this.errorStatusCode = errorStatusCode;
		this.withLocalAudit = withLocalAudit;
		this.applicationName = applicationName;
		this.instanceName = instanceName;
		this.actionCode = actionCode;
		this.status = status;
	}

	/**
	 * 
	 */
	@Override
	public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response, AuthenticationException authEx)
			throws IOException, ServletException {
		System.out.println("onAuthenticationFailure()");
		StringBuilder errorMessage = new StringBuilder(authEx.getMessage());
		try{
			if(withLocalAudit){
				String sp = "dbo.spAddAuditDetails ?,?,?,?,?,?,?,?,?,?";
				List<Object> paramList = new ArrayList<>();
				paramList.add(applicationName);
				paramList.add(instanceName);
				paramList.add(request.getParameter("username"));
				paramList.add("");
				paramList.add("");
				paramList.add(actionCode);
				paramList.add(request.getParameter("username"));
				paramList.add(status);
				paramList.add(request.getRemoteAddr());
				paramList.add("");
				
				dataAccessService.executeSQLUpdate(sp, paramList.toArray());
			}
		}catch(Exception ex){
			errorMessage.append(";\n");
			errorMessage.append(ex.getMessage());
		}
		response.setHeader("ERROR_MESSAGE", errorMessage.toString());
		response.setHeader("defaultFailureUrl", defaultFailureUrl);
		response.setStatus(errorStatusCode);
	}
	
}
