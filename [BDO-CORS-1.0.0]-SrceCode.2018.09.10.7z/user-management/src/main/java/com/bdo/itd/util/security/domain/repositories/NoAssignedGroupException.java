package com.bdo.itd.util.security.domain.repositories;

import com.bdo.itd.util.security.SecurityException;

/**
 * @author c140618008
 *
 */
public class NoAssignedGroupException extends SecurityException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 307626752921076540L;

	/**
	 * @param message
	 */
	public NoAssignedGroupException(String message) {
		super(message);
	}
	
	/**
	 * @param cause
	 */
	public NoAssignedGroupException(Throwable cause) {
		super(cause);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public NoAssignedGroupException(String message, Throwable cause) {
		super(message, cause);
	}	
}
