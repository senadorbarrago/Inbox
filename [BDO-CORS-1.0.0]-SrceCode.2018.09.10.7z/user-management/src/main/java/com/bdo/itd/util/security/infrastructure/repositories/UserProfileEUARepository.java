package com.bdo.itd.util.security.infrastructure.repositories;

import com.bdo.itd.util.eua.inquiry.EuaInquiryClient;
import com.bdo.itd.util.eua.inquiry.entities.ApplicationUserEntity;
import com.bdo.itd.util.persistence.DataAccessInterface;
import com.bdo.itd.util.security.domain.models.Membership;
import com.bdo.itd.util.security.domain.models.UserProfile;
import com.bdo.itd.util.security.domain.repositories.IUserProfileRepository;
import com.bdo.itd.util.security.domain.repositories.NoMembershipException;
import com.bdo.itd.util.security.domain.repositories.UserNotFoundException;

/**
 * 
 * @author c140618008
 *
 */
public class UserProfileEUARepository implements IUserProfileRepository {
	
	/**
	 * 
	 */
	private final EuaInquiryClient euaInquiryClient;
	
	/**
	 * 
	 */
	private final DataAccessInterface dataAccessService;

	/**
	 * @param euaInquiryClient
	 * @param dataAccessService
	 */
	public UserProfileEUARepository(EuaInquiryClient euaInquiryClient, DataAccessInterface dataAccessService) {
		super();
		this.euaInquiryClient = euaInquiryClient;
		this.dataAccessService = dataAccessService;
	}

	@Override
	public UserProfile findUserProfileByUsername(String username, Membership membership) 
			throws UserNotFoundException, NoMembershipException {
		ApplicationUserEntity applicationUserEntity =  euaInquiryClient.getApplicationUser(username, username);
		
		UserProfile userProfile = new UserProfile(username, applicationUserEntity.getUserDetailsDTO().getLastName(),
				applicationUserEntity.getUserDetailsDTO().getFirstName(), applicationUserEntity.getUserDetailsDTO().getMiddleName(),
					membership);
		this.updateUserProfile(userProfile);
		return userProfile;
	}

	/**
	 * @param userProfile
	 */
	private void updateUserProfile(UserProfile userProfile) {
		String sp = "dbo.secUpdateUserProfile ?,?,?,?,?";
		
		dataAccessService.executeSQLUpdate(sp, new Object[]{userProfile.getUsername(), userProfile.getLastname(),
				userProfile.getFirstname(), userProfile.getMiddlename(), userProfile.getActiveMembership().getCode()});
		
	}
}
