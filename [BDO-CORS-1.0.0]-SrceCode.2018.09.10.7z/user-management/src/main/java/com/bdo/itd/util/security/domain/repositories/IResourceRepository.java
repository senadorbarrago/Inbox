package com.bdo.itd.util.security.domain.repositories;

import java.util.List;

import com.bdo.itd.util.security.domain.models.Resource;

/**
 * @author c140618008
 *
 */
public interface IResourceRepository {
	
	/**
	 * @param membership
	 * @return
	 */
	public List<Resource> findResourcesByMembership(String membershipCode);
	
	/**
	 * @param resource
	 */
	public void addResource(String resourceCode, String membershipCode, String user);
	
	/**
	 * @param resourceList
	 */
	public void removeResource(List<String> resourceCodeList, String membershipCode, String user);
	
}
