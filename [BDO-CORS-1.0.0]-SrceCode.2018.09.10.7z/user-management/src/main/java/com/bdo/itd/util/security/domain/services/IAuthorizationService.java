package com.bdo.itd.util.security.domain.services;

import java.util.List;
import java.util.Map;

import com.bdo.itd.util.security.domain.models.Resource;

/**
 * @author c140618008
 *
 */
public interface IAuthorizationService {
	
	/**
	 * @param params
	 * @return
	 * @throws UserAuthorizationException
	 */
	public List<Resource> getAuthorizedResources(Map<String, Object> params)
		throws UserAuthorizationException;
	
}
