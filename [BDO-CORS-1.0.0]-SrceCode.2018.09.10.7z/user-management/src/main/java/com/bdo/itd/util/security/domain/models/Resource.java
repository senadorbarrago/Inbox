package com.bdo.itd.util.security.domain.models;

import org.springframework.security.core.GrantedAuthority;

/**
 * 
 * @author c140618008
 *
 */
public class Resource implements GrantedAuthority{	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6783704361931298744L;
	/**
	 * 
	 */
	private final String code;
	/**
	 * 
	 */
	private final String securedItemCode;
	/**
	 * 
	 * @param code
	 * @param securedItemCode
	 */
	public Resource(String code, String securedItemCode) {
		super();
		this.code = code;
		this.securedItemCode = securedItemCode;
	}
	/**
	 * 
	 * @return
	 */
	public String getCode() {
		return code;
	}
	/**
	 * 
	 * @return
	 */
	public String getSecuredItemCode() {
		return securedItemCode;
	}
	
	@Override
	public String getAuthority() {
		return securedItemCode;
	}
}
