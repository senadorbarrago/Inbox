package com.bdo.itd.util.security.domain.repositories;

import com.bdo.itd.util.security.domain.models.Membership;

/**
 * @author c140618008
 *
 */
public interface IMembershipRepository {
	
	/**
	 * @return
	 * @throws NoMembershipException
	 */
	public Membership findMembershipByGroupAndRole(String group, String role) throws NoMembershipException;
	
	/**
	 * @param username
	 * @return
	 * @throws NoMembershipException
	 */
	public Membership findMembershipByUsername(String username) throws NoMembershipException;
}
