package com.bdo.itd.util.security.infrastructure.repositories;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.bdo.itd.util.persistence.DataAccessInterface;
import com.bdo.itd.util.security.domain.models.Resource;
import com.bdo.itd.util.security.domain.repositories.IResourceRepository;

/**
 * @author c140618008
 *
 */
public class ResourceDatabaseRepository implements IResourceRepository {
	
	/**
	 * 
	 */
	private final DataAccessInterface dataAccessService;
	
	/**
	 * @param dataAccessService
	 */
	public ResourceDatabaseRepository(DataAccessInterface dataAccessService) {
		super();
		this.dataAccessService = dataAccessService;
	}
	
	
	@Override
	public List<Resource> findResourcesByMembership(String membershipCode) {
		String sql = "dbo.secFindResourcesByMembershipCode ?";
		
		List<Resource> resourceList = new ArrayList<>();
		
		List<LinkedHashMap<String, Object>> resultSet = dataAccessService.executeSQLStoredProcedure(sql, new Object[]{membershipCode});
		if(resultSet != null && !resultSet.isEmpty()){
			for(Map<String, Object> row : resultSet){
				Resource resource = new Resource(row.get("code").toString(), row.get("securedItemCode").toString());
				resourceList.add(resource);
			}
		}
		return resourceList;
	}

	@Override
	public void addResource(String resourceCode, String membershipCode, String user) {
		String sql = "dbo.secAddResource ?,?,?";
		dataAccessService.executeSQLUpdate(sql, new Object[]{resourceCode, membershipCode, user});
	}

	@Override
	public void removeResource(List<String> resourceCodeList, String membershipCode, String user) {
		String sql = "dbo.secFindResourcesByMembershipCode ?";
		List<LinkedHashMap<String, Object>> resultSet = dataAccessService.executeSQLStoredProcedure(sql, new Object[]{membershipCode});
		
		if(resultSet != null && !resultSet.isEmpty()){
			String deleteCommand = "dbo.secDeleteResource ?, ?";
			
			mainloop:
			for(Map<String, Object> row : resultSet){
				String rscCode = row.get("code").toString();
				for(String resourceCode : resourceCodeList){
					if(resourceCode.equals(rscCode)){
						continue mainloop;
					}
				}
				dataAccessService.executeSQLUpdate(deleteCommand, new Object[]{rscCode, user});
			}
		}
		
	}
		
}
