package com.bdo.itd.util.security.infrastructure.services.authentication;

import java.util.ArrayList;
import java.util.List;

import com.bdo.itd.util.eua.authentication.EuaAuthenticationClient;
import com.bdo.itd.util.eua.authentication.EuaAuthenticationClientException;
import com.bdo.itd.util.eua.authentication.EuaAuthenticationException;
import com.bdo.itd.util.eua.authentication.entities.AuthenticationResponseEntity;
import com.bdo.itd.util.eua.authentication.models.Menu;
import com.bdo.itd.util.eua.inquiry.EuaInquiryClientException;
import com.bdo.itd.util.logger.LoggerUtility;
import com.bdo.itd.util.logger.LoggerUtilityFactory;
import com.bdo.itd.util.security.domain.models.Group;
import com.bdo.itd.util.security.domain.models.Membership;
import com.bdo.itd.util.security.domain.models.Resource;
import com.bdo.itd.util.security.domain.models.UserProfile;
import com.bdo.itd.util.security.domain.repositories.IGroupRepository;
import com.bdo.itd.util.security.domain.repositories.IMembershipRepository;
import com.bdo.itd.util.security.domain.repositories.IResourceRepository;
import com.bdo.itd.util.security.domain.repositories.IUserProfileRepository;
import com.bdo.itd.util.security.domain.repositories.NoAssignedGroupException;
import com.bdo.itd.util.security.domain.repositories.NoMembershipException;
import com.bdo.itd.util.security.domain.repositories.UserNotFoundException;
import com.bdo.itd.util.security.domain.services.IAuthenticationService;
import com.bdo.itd.util.security.domain.services.UserAuthenticationException;
import com.bdo.itd.util.validation.ValidationException;


/**
 * @author c140618008
 *
 */
public class EUAAuthenticationService implements IAuthenticationService{
	
	/**
	 * 
	 */
	private static final LoggerUtility LOGGER = 
			LoggerUtilityFactory.createLoggerUtility(EUAAuthenticationService.class);
	
	/**
	 * 
	 */
	private final EuaAuthenticationClient euaAuthenticationClient;
	
	/**
	 * 
	 */
	private final IUserProfileRepository userProfileRepository;
	
	/**
	 * 
	 */
	private final IGroupRepository groupRepository;
	
	/**
	 * 
	 */
	private final IMembershipRepository membershipRepository;
	
	/**
	 * 
	 */
	private final IResourceRepository resourceRepository;
	
	/**
	 * 
	 */
	private final boolean syncAuthority;
	
	/**
	 * @param euaAuthenticationClient
	 * @param userProfileRepository
	 * @param groupRepository
	 * @param membershipRepository
	 * @param resourceRepository
	 */
	public EUAAuthenticationService(EuaAuthenticationClient euaAuthenticationClient,
			IUserProfileRepository userProfileRepository, IGroupRepository groupRepository,
				IMembershipRepository membershipRepository, IResourceRepository resourceRepository,
					boolean syncAuthority) {
		super();
		this.euaAuthenticationClient = euaAuthenticationClient;
		this.userProfileRepository = userProfileRepository;
		this.groupRepository = groupRepository;
		this.membershipRepository = membershipRepository;
		this.resourceRepository = resourceRepository;
		this.syncAuthority = syncAuthority;
	}

	@Override
	public UserProfile doAuthenticate(String username, String password) throws UserAuthenticationException {
		try{
			LOGGER.info("doAuthenticate(String username, String password)");
			
			AuthenticationResponseEntity responseEntity =  euaAuthenticationClient.authenticate(username, password);
			
			Membership membership = this.getMembership(responseEntity, username);
			
			this.initializeAuthority(membership, responseEntity, username);
			
			UserProfile userProfile = userProfileRepository.findUserProfileByUsername(username, membership);
			
			return userProfile;
		}catch(EuaAuthenticationException | EuaAuthenticationClientException | UserNotFoundException | 
					NoAssignedGroupException | NoMembershipException | ValidationException | EuaInquiryClientException ex){
			LOGGER.error(ex.getMessage(), ex);
			throw new UserAuthenticationException(ex.getMessage(), ex);
		}	
	}
	
	/**
	 * @param responseEntity
	 * @param username
	 * @return
	 * @throws NoAssignedGroupException
	 * @throws NoMembershipException
	 */
	private Membership getMembership(AuthenticationResponseEntity responseEntity, String username) throws NoAssignedGroupException,
		NoMembershipException{

		Membership membership = null;
		if(syncAuthority){
			Group group = groupRepository.findGroupByUser(username);
			membership = membershipRepository.findMembershipByGroupAndRole(group.getCode(),
					responseEntity.getGroupCode());
		}else{
			membership = membershipRepository.findMembershipByUsername(username);
		}
		
		return membership;
	}
	
	/**
	 * @param membershipCode
	 * @param responseEntity
	 */
	private void initializeAuthority(Membership membership, AuthenticationResponseEntity responseEntity, String username) {
		if(syncAuthority){
			// Sync resources
			List<String> resourceCodeList = buildResourceCodeList(responseEntity);
			this.syncResources(resourceCodeList, membership.getCode(), username);
		}
		// Grant resource authority to membership
		this.grantResourcesToMembership(membership);
	}
	
	/**
	 * @param responseEntity
	 * @return
	 */
	private List<String> buildResourceCodeList(AuthenticationResponseEntity responseEntity){
		List<String> resourceCodeList = new ArrayList<>();
		
		for (Menu menu : responseEntity.getMenus()) {
			if ("Permissions".equalsIgnoreCase(menu.getMenuCode())) {
				for (Menu sub : menu.getSubMenus()) {
					for (Menu resource : sub.getSubMenus()) {
						resourceCodeList.add(resource.getMenuCode());
					}
				}
			}
		}
		return resourceCodeList;
	}
	
	/**
	 * @param resourceCodeList
	 * @param membershipCode
	 * @param user
	 */
	private void syncResources(List<String> resourceCodeList, String membershipCode, String user){
		// Remove obsolete resources 
		resourceRepository.removeResource(resourceCodeList, membershipCode, user);
		// Add/Update resources
		for(String resourceCode : resourceCodeList){
			resourceRepository.addResource(resourceCode, membershipCode, user);
		}
	}
	
	/**
	 * @param membership
	 */
	private void grantResourcesToMembership(Membership membership){
		List<Resource> resourceList = resourceRepository.findResourcesByMembership(membership.getCode());
		
		for(Resource resource : resourceList){
			membership.addResource(resource);
		}
	}
	
	
}
