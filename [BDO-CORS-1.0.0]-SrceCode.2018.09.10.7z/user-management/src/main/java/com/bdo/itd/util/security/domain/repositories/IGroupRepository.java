package com.bdo.itd.util.security.domain.repositories;

import com.bdo.itd.util.security.domain.models.Group;

/**
 * @author c140618008
 *
 */
public interface IGroupRepository {
	
	/**
	 * @param user
	 * @return
	 * @throws NoAssignedGroupException
	 */
	public Group findGroupByUser(String user) throws NoAssignedGroupException;
	
}
