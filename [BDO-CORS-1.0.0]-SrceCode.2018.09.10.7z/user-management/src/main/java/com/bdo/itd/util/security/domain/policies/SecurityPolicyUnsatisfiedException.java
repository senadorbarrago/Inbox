package com.bdo.itd.util.security.domain.policies;

import com.bdo.itd.util.security.SecurityException;

/**
 * @author c140618008
 *
 */
public class SecurityPolicyUnsatisfiedException extends SecurityException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 307626752921076540L;
	
	/**
	 * @param message
	 */
	public SecurityPolicyUnsatisfiedException(String message) {
		super(message);
	}
	
	/**
	 * @param cause
	 */
	public SecurityPolicyUnsatisfiedException(Throwable cause) {
		super(cause);
	}
	
	/**
	 * @param message
	 * @param cause
	 */
	public SecurityPolicyUnsatisfiedException(String message, Throwable cause) {
		super(message, cause);
	}	
}
