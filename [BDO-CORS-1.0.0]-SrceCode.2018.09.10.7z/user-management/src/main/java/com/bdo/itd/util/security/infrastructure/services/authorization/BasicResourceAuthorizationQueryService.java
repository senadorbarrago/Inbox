package com.bdo.itd.util.security.infrastructure.services.authorization;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.bdo.itd.util.persistence.DataAccessInterface;
import com.bdo.itd.util.security.domain.models.Resource;
import com.bdo.itd.util.security.domain.services.IAuthorizationService;
import com.bdo.itd.util.security.domain.services.UserAuthorizationException;

/**
 * @author c140618008
 *
 */
public class BasicResourceAuthorizationQueryService implements IAuthorizationService {
	
	/**
	 * 
	 */
	private final DataAccessInterface dataAccessService;
	
	/**
	 * @param dataAccessService
	 */
	public BasicResourceAuthorizationQueryService(DataAccessInterface dataAccessService) {
		super();
		this.dataAccessService = dataAccessService;
	}

	@Override
	public List<Resource> getAuthorizedResources(Map<String, Object> params)
			throws UserAuthorizationException {
		List<Resource> resourceList = new ArrayList<>();
		
		String query = "dbo.spSecFindResourcesByType ?,?";
		Object resourceTypeCode = params.get("resourceTypeCode");
		Object membershipCode = params.get("membershipCode");
		
		List<LinkedHashMap<String, Object>> result = dataAccessService.executeSQLStoredProcedure(query, 
				new Object[]{resourceTypeCode, membershipCode});
		
		if(result != null && !result.isEmpty()){
			for(Map<String, Object> row : result){
				Resource resource = new Resource(row.get("code").toString(), row.get("securedItemCode").toString());
				resourceList.add(resource);
			}
		}
		return resourceList;
	}
}
