package com.bdo.itd.util.security.domain.services;

import com.bdo.itd.util.security.SecurityException;

/**
 * @author c140618008
 *
 */
public class UserAuthenticationException extends SecurityException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6317620813065621150L;

	/**
	 * @param message
	 */
	public UserAuthenticationException(String message) {
		super(message);
	}

	/**
	 * @param cause
	 */
	public UserAuthenticationException(Throwable cause) {
		super(cause);
	}
	
	/**
	 * @param message
	 * @param cause
	 */
	public UserAuthenticationException(String message, Throwable cause) {
		super(message, cause);
	}
}
