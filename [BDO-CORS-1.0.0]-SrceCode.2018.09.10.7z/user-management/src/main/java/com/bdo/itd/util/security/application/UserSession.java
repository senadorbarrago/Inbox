package com.bdo.itd.util.security.application;

import org.springframework.security.core.context.SecurityContextHolder;

import com.bdo.itd.util.security.domain.models.Membership;
import com.bdo.itd.util.security.domain.models.UserProfile;


/**
 * @author c140618008
 *
 */
public class UserSession {
    
    /**
     * @return
     */
    public static UserProfile getUserProfile(){
    	return ((UserProfile)((SecurityContextHolder.getContext().getAuthentication().getPrincipal())));
    }
    
    /**
     * @return
     */
    public static String getUsername(){
        return ((UserProfile)((SecurityContextHolder.getContext().getAuthentication().getPrincipal()))).getUsername();
    }
    
    /**
     * @return
     */
    public static String getFullname(){
        return ((UserProfile)((SecurityContextHolder.getContext().getAuthentication().getPrincipal()))).getFullname();
    }
    
    /**
     * @return
     */
    public static String getShortname(){
        return ((UserProfile)((SecurityContextHolder.getContext().getAuthentication().getPrincipal()))).getShortname();
    }
    
    /**
     * @return
     */
    public static Membership getActiveAuthority(){
        return ((UserProfile)((SecurityContextHolder.getContext().getAuthentication().getPrincipal()))).getActiveMembership();
    }
    
    /**
     * @return
     */
    public static String getGroupCode(){
        return ((UserProfile)((SecurityContextHolder.getContext().getAuthentication().getPrincipal()))).getActiveMembership().getGroup().getCode();
    }
    
    /**
     * @return
     */
    public static String getRoleCode(){
        return ((UserProfile)((SecurityContextHolder.getContext().getAuthentication().getPrincipal()))).getActiveMembership().getRole().getCode();
    }
}
