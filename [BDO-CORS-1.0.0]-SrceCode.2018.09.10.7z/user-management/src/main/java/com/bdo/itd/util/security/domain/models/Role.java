package com.bdo.itd.util.security.domain.models;

/**
 * 
 * @author c140618008
 *
 */
public class Role {
	/**
	 * 
	 */
	private final String code;
	/**
	 * 
	 */
	private final String description;
	/**
	 * 
	 * @param code
	 * @param description
	 */
	public Role(String code, String description) {
		super();
		this.code = code;
		this.description = description;
	}
	/**
	 * 
	 * @return
	 */
	public String getCode() {
		return code;
	}
	/**
	 * 
	 * @return
	 */
	public String getDescription() {
		return description;
	}	
}
