package com.bdo.itd.util.security;

/**
 * @author c140618008
 *
 */
public abstract class SecurityException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4727009520485101158L;
	/**
	 * 
	 */
	private Throwable cause;
	/**
	 * 
	 */
	private String message;
	
	/**
	 * @param message
	 */
	public SecurityException(String message) {
		super(message);
		this.message = message;
	}
	
	/**
	 * @param cause
	 */
	public SecurityException(Throwable cause) {
		super(cause);
		this.cause = cause;
		this.message = cause.getMessage();
	}

	/**
	 * @param message
	 * @param cause
	 */
	public SecurityException(String message, Throwable cause) {
		super(message, cause);
		this.cause = cause;
		this.message = message;
	}

	@Override
	public Throwable getCause() {
		return this.cause;
	}
	
	@Override
	public String getMessage() {
		return this.message;
	}	
}
