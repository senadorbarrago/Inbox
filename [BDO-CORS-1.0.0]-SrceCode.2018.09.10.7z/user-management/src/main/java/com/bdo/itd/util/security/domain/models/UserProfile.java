package com.bdo.itd.util.security.domain.models;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;

/**
 * 
 * @author c140618008
 *
 */
public class UserProfile extends User {	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8012508202906889816L;
	/**
	 * 
	 */
	private final String username;
	/**
	 * 
	 */
	private final String lastname;
	/**
	 * 
	 */
	private final String firstname;
	/**
	 * 
	 */
	private final String middlename;
	/**
	 * 
	 */
	private final String fullname;
	/**
	 * 
	 */
	private String shortname;
	/**
	 * 
	 */
	private final Membership activeMembership;
	
	/**
	 * @param username
	 * @param lastname
	 * @param firstname
	 * @param middlename
	 * @param membership
	 */
	public UserProfile(String username, String lastname, String firstname, String middlename, Membership membership) {
		super(username, "", Collections.emptyList());
		
		this.username = username;
		this.lastname = lastname;
		this.firstname = firstname;
		this.middlename = middlename;
		this.fullname = lastname+", "+firstname+" "+middlename;
		this.activeMembership = membership;
	}

	/**
	 * @return
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String getUsername() {
		return username;
	}

	/**
	 * @return
	 */
	public String getLastname() {
		return lastname;
	}

	/**
	 * @return
	 */
	public String getFirstname() {
		return firstname;
	}

	/**
	 * @return
	 */
	public String getMiddlename() {
		return middlename;
	}

	/**
	 * @return
	 */
	public String getFullname() {
		return fullname;
	}
	
	/**
	 * @return
	 */
	public String getShortname() {
		return shortname;
	}
	
	/**
	 * @param shortname
	 */
	public void setShortname(String shortname) {
		this.shortname = shortname;
	}

	/**
	 * @return
	 */
	public Membership getActiveMembership() {
		return activeMembership;
	}
}
