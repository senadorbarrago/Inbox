package com.bdo.itd.util.security.domain.repositories;

import com.bdo.itd.util.security.SecurityException;

/**
 * @author c140618008
 *
 */
public class UserNotFoundException extends SecurityException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8666496217190313879L;

	/**
	 * @param message
	 */
	public UserNotFoundException(String message) {
		super(message);
	}

	/**
	 * @param cause
	 */
	public UserNotFoundException(Throwable cause) {
		super(cause);
	}
	
	/**
	 * @param message
	 * @param cause
	 */
	public UserNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}
}
