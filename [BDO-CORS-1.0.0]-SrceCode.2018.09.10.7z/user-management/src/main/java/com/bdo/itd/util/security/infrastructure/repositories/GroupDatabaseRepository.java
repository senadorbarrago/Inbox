package com.bdo.itd.util.security.infrastructure.repositories;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.bdo.itd.util.persistence.DataAccessInterface;
import com.bdo.itd.util.security.domain.models.Group;
import com.bdo.itd.util.security.domain.repositories.IGroupRepository;
import com.bdo.itd.util.security.domain.repositories.NoAssignedGroupException;

/**
 * @author c140618008
 *
 */
public class GroupDatabaseRepository implements IGroupRepository {
	
	/**
	 * 
	 */
	private final DataAccessInterface dataAccessService;

	/**
	 * @param dataAccessService
	 */
	public GroupDatabaseRepository(DataAccessInterface dataAccessService) {
		super();
		this.dataAccessService = dataAccessService;
	}		

	@Override
	public Group findGroupByUser(String user) throws NoAssignedGroupException {
		String sql = "dbo.secFindGroupByUser ?";
		
		List<LinkedHashMap<String, Object>> result = dataAccessService.executeSQLStoredProcedure(sql, new Object[]{user});
		
		Group group = null;
		if(result != null && !result.isEmpty()){
			for(Map<String, Object> row : result){
				group = new Group((String)row.get("groupCode"), (String)row.get("groupDesc"));
				break;
			}
		}else{
			throw new NoAssignedGroupException("No group found for the supplied username. Contact the User Administrator.");
		}
		
		return group;
	}

}
