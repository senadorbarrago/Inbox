package com.bdo.itd.util.security.infrastructure.repositories;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.bdo.itd.util.logger.LoggerUtility;
import com.bdo.itd.util.logger.LoggerUtilityFactory;
import com.bdo.itd.util.persistence.DataAccessInterface;
import com.bdo.itd.util.security.domain.models.Group;
import com.bdo.itd.util.security.domain.models.Membership;
import com.bdo.itd.util.security.domain.models.Role;
import com.bdo.itd.util.security.domain.repositories.IMembershipRepository;
import com.bdo.itd.util.security.domain.repositories.NoMembershipException;
import com.bdo.itd.util.validation.Validator;

/**
 * @author c140618008
 *
 */
public class MembershipDatabaseRepository implements IMembershipRepository {
	
	/**
	 * 
	 */
	private static final LoggerUtility LOGGER = 
			LoggerUtilityFactory.createLoggerUtility(MembershipDatabaseRepository.class);
	
	/**
	 * 
	 */
	private final DataAccessInterface dataAccessService;
	
	/**
	 * @param dataAccessService
	 */
	public MembershipDatabaseRepository(DataAccessInterface dataAccessService) {
		super();
		this.dataAccessService = dataAccessService;
	}

	@Override
	public Membership findMembershipByGroupAndRole(String group, String role) throws NoMembershipException {
		LOGGER.info(this.getClass()+"-findMembershipByGroupAndRole(String group, String role): "+group+"; "+role);
		Validator.validateNotNullOrEmpty(group);
		Validator.validateNotNullOrEmpty(role);
		
		String sql = "dbo.secFindMembershipByGroupAndRole ?,?";
		
		List<LinkedHashMap<String, Object>> result = dataAccessService.executeSQLStoredProcedure(sql, new Object[]{group, role});
		
		Membership membership = null;
		if(result != null && !result.isEmpty()){
			for(Map<String, Object> row : result){
				membership = new Membership((Long)row.get("membershipID"),
					(String)row.get("code"), new Group((String)row.get("groupCode"), (String)row.get("groupDesc")), 
						new Role((String)row.get("roleCode"), (String)row.get("roleDesc")));
				break;
			}
		}else{
			throw new NoMembershipException("No membership found for the supplied group and role. Contact the User Administrator.");
		}
		
		return membership;
	}

	@Override
	public Membership findMembershipByUsername(String username) throws NoMembershipException {
		LOGGER.info(this.getClass()+"-findMembershipByUsername(String username): "+username);
		Validator.validateNotNullOrEmpty(username);
		
		String sql = "dbo.secFindMembershipByUsername ?";
		
		List<LinkedHashMap<String, Object>> result = dataAccessService.executeSQLStoredProcedure(sql, new Object[]{username});
		
		Membership membership = null;
		if(result != null && !result.isEmpty()){
			for(Map<String, Object> row : result){
				membership = new Membership((Long)row.get("membershipID"),
					(String)row.get("code"), new Group((String)row.get("groupCode"), (String)row.get("groupDesc")), 
						new Role((String)row.get("roleCode"), (String)row.get("roleDesc")));
				break;
			}
		}else{
			throw new NoMembershipException("No membership found for the supplied username and role. Contact the User Administrator.");
		}
		
		return membership;
	}
	
	
}
