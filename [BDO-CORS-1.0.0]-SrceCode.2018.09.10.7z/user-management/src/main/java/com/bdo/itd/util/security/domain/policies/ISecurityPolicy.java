package com.bdo.itd.util.security.domain.policies;

import java.util.Map;

/**
 * @author c140618008
 *
 */
public interface ISecurityPolicy {
	
	/**
	 * @param parameterMap
	 * @throws SecurityPolicyUnsatisfiedException
	 */
	public void isSatisfiedBy(Map<String, Object> parameterMap) throws SecurityPolicyUnsatisfiedException;
	
}
