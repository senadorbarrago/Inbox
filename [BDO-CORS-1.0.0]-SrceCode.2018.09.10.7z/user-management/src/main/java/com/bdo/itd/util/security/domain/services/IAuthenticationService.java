package com.bdo.itd.util.security.domain.services;

import com.bdo.itd.util.security.domain.models.UserProfile;

/**
 * @author c140618008
 *
 */
public interface IAuthenticationService {
	
	/**
	 * @param username
	 * @param password
	 * @return
	 * @throws UserAuthenticationException
	 */
	public UserProfile doAuthenticate(String username, String password) throws UserAuthenticationException;
	
}
