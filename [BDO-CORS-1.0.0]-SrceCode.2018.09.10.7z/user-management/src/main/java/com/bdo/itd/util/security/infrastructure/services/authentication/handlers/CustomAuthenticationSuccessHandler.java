package com.bdo.itd.util.security.infrastructure.services.authentication.handlers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

import com.bdo.itd.util.persistence.DataAccessInterface;
import com.bdo.itd.util.security.application.UserSession;

/**
 * @author c140618008
 *
 */
public class CustomAuthenticationSuccessHandler implements AuthenticationSuccessHandler {
	
	/**
	 * 
	 */
	private final DataAccessInterface dataAccessService;
	
	/**
	 * 
	 */
	private final String defaultSuccessUrl;
	
	/**
	 * 
	 */
	private final int successStatusCode;
	
	/**
	 * 
	 */
	private final boolean withLocalAudit;
	
	/**
	 * 
	 */
	private final String applicationName;
	
	/**
	 * 
	 */
	private final String instanceName;
	
	/**
	 * 
	 */
	private final String actionCode;
	
	/**
	 * 
	 */
	private final String status;
	
	/**
	 * 
	 * @param dataAccessService
	 * @param defaultSuccessUrl
	 * @param successStatusCode
	 * @param withLocalAudit
	 * @param applicationName
	 * @param instanceName
	 * @param actionCode
	 * @param status
	 */
	public CustomAuthenticationSuccessHandler(DataAccessInterface dataAccessService, String defaultSuccessUrl,
			int successStatusCode, boolean withLocalAudit, String applicationName, String instanceName,
			String actionCode, String status) {
		super();
		this.dataAccessService = dataAccessService;
		this.defaultSuccessUrl = defaultSuccessUrl;
		this.successStatusCode = successStatusCode;
		this.withLocalAudit = withLocalAudit;
		this.applicationName = applicationName;
		this.instanceName = instanceName;
		this.actionCode = actionCode;
		this.status = status;
	}

	/**
	 * 
	 */
	@Override
	public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, 
			Authentication authentication)
			throws IOException, ServletException {
		System.out.println("onAuthenticationSuccess()");
		
		if(withLocalAudit){
			String sp = "dbo.spAddAuditDetails ?,?,?,?,?,?,?,?,?,?";
			List<Object> paramList = new ArrayList<>();
			paramList.add(applicationName);
			paramList.add(instanceName);
			paramList.add(UserSession.getUsername());
			paramList.add(UserSession.getFullname());
			paramList.add(UserSession.getActiveAuthority().getRole().getCode());
			paramList.add(actionCode);
			paramList.add(UserSession.getUsername());
			paramList.add(status);
			paramList.add(request.getRemoteAddr());
			paramList.add("");
			
			dataAccessService.executeSQLUpdate(sp, paramList.toArray());
		}
		
		response.setHeader("defaultSuccessUrl", defaultSuccessUrl);
		response.setStatus(successStatusCode);
	}
}
