package com.bdo.itd.projects.bdocors.inboundinterface;

//@RunWith(SpringRunner.class)
//@SpringBootTest
public class InboundInterfaceManagementApplicationTests {

	//@Test
	public void contextLoads() {
	}

}
