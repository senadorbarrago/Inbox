package com.bdo.itd.projects.bdocors.inboundinterface.application.query;

import java.io.File;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bdo.itd.projects.bdocors.inboundinterface.domain.WorkingFolder;
import com.bdo.itd.projects.bdocors.inboundinterface.infrastructure.repository.IWorkingFolderRepository;
import com.bdo.itd.projects.bdocors.inboundinterface.infrastructure.utilities.FolderScanner;
import com.bdo.itd.util.cqrs.query.IQuery;
import com.bdo.itd.util.cqrs.query.QueryException;
import com.bdo.itd.util.cqrs.query.QueryParam;
import com.bdo.itd.util.cqrs.query.ResultModel;

/**
 * @author c140618008
 *
 */
@Service
public class FolderContentsQueryModel implements IQuery {	
	
	/**
	 * 
	 */
	private final IWorkingFolderRepository workingFolderRepository;
	
	/**
	 * 
	 */
	@Value(value = "${data-format.date.default}")
	private String dateFormat;	
	
	/**
	 * @param workingFolderRepository
	 * 
	 */
	@Autowired
	public FolderContentsQueryModel(IWorkingFolderRepository workingFolderRepository) {
		super();
		this.workingFolderRepository = workingFolderRepository;
	}

	@Override
	public ResultModel doQuery(QueryParam queryParam) throws QueryException {
		String context = (String)queryParam.getParam("context");
		String sourceFolderCode = (String)queryParam.getParam("sourceFolderCode");
		
		WorkingFolder sourceFolder = workingFolderRepository.findByCodeAndContextAndIsDeleted(sourceFolderCode, context, false);
		
		return getFolderContents(new File(sourceFolder.getPath()));
	}
	
	/**
	 * @param directory
	 * @return
	 */
	private ResultModel getFolderContents(File directory) {
		DateFormat formatter = new SimpleDateFormat(dateFormat);
		List<LinkedHashMap<String, Object>> fileList = new ArrayList<>();
		
		File[] files = FolderScanner.scanFolder(directory);  
		
		if(files != null && files.length > 0){
			for(File file : files){
				LinkedHashMap<String, Object> fileRow = new LinkedHashMap<>();
				
				fileRow.put("File Name", file.getName());
				fileRow.put("Path", directory.getAbsolutePath());
				fileRow.put("Size", new BigDecimal(Math.incrementExact(file.length()/1024)));				
				fileRow.put("Date Created", formatter.format(file.lastModified()));
				fileList.add(fileRow);
				
			}
		}
		
		ResultModel resultModel = new ResultModel(fileList, 
				fileList != null && !fileList.isEmpty() ? fileList.size() : 0);
		
		return resultModel;
	}
	
}
