package com.bdo.itd.projects.bdocors.inboundinterface.infrastructure.repository;

import java.util.List;

import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.querydsl.binding.QuerydslBinderCustomizer;
import org.springframework.data.querydsl.binding.QuerydslBindings;
import org.springframework.data.querydsl.binding.SingleValueBinding;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.bdo.itd.projects.bdocors.inboundinterface.domain.QWorkingFolder;
import com.bdo.itd.projects.bdocors.inboundinterface.domain.WorkingFolder;
import com.querydsl.core.types.dsl.StringExpression;
import com.querydsl.core.types.dsl.StringPath;

/**
 * @author c140618008
 *
 */
@Repository
public interface IWorkingFolderRepository extends PagingAndSortingRepository<WorkingFolder, Long>, 
	QuerydslPredicateExecutor<WorkingFolder>, QuerydslBinderCustomizer<QWorkingFolder> {
	
	/**
	 * @param code
	 * @param context
	 * @param isDeleted
	 * @return
	 */
	public WorkingFolder findByCodeAndContextAndIsDeleted(String code, String context, boolean isDeleted);
	
	
	/**
	 * @param context
	 * @param isDeleted
	 * @return
	 */
	public List<WorkingFolder> findByContextAndIsDeleted(String context, boolean isDeleted);
	
	/**
	 * 
	 */
	default public void customize(QuerydslBindings bindings, QWorkingFolder root) {
		bindings.bind(String.class).first((SingleValueBinding<StringPath, String>) StringExpression::containsIgnoreCase);
		bindings.excluding(root.id);
	}
	
}
