package com.bdo.itd.projects.bdocors.inboundinterface.infrastructure.services;

import java.util.Map;

/**
 * @author c140618008
 *
 */
public interface IServiceCommunicator {
	
	/**
	 * @param params
	 * @return
	 * @throws ServiceCommunicatorException
	 */
	public Map<String, Object> doCommunicate(Map<String, Object> params) throws ServiceCommunicatorException;
	
}
