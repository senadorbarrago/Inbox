package com.bdo.itd.projects.bdocors.inboundinterface.infrastructure.services;

import java.util.Map;

import com.bdo.itd.service.client.ServiceClient;
import com.bdo.itd.util.map.ParameterMap;
import com.bdo.itd.util.map.ParameterMapBuilder;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author c140618008
 *
 */
public class ITDServiceCommunicator implements IServiceCommunicator {
	
	/**
	 * 
	 */
	private final ServiceClient client; 
	
	/**
	 * @param client
	 */
	public ITDServiceCommunicator(ServiceClient client) {
		super();
		this.client = client;
	}

	@Override
	public Map<String, Object> doCommunicate(Map<String, Object> params) throws ServiceCommunicatorException {
		try {
			String applicationName = String.valueOf(params.get("applicationName"));
			String action = String.valueOf(params.get("action"));
			String profile = String.valueOf(params.get("profile"));
			boolean async = Boolean.parseBoolean(params.get("async").toString());
			
			ParameterMap parameterMap = ParameterMapBuilder.instance()
					.add("applicationName", applicationName)
					.add("action", action)
					.add("profile", profile)
					.add("async", async)
					.add("data", convertMapToString(params))
					.build();
			
			return client.execute(parameterMap).map();
		}catch(JsonProcessingException ex) {
			throw new ServiceCommunicatorException(ex, ex.getMessage());
		}
	}
	
	/**
	 * @param paramaterMap
	 * @return
	 * @throws JsonProcessingException
	 */
	private String convertMapToString(Map<String, Object> paramaterMap)throws JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		return objectMapper.writeValueAsString(paramaterMap);
		
	}
}
