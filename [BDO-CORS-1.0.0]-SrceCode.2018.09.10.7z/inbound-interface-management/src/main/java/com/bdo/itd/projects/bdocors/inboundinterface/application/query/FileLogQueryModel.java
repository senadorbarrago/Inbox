package com.bdo.itd.projects.bdocors.inboundinterface.application.query;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.bdo.itd.projects.bdocors.inboundinterface.domain.FileLog;
import com.bdo.itd.projects.bdocors.inboundinterface.domain.FileLogStatus;
import com.bdo.itd.projects.bdocors.inboundinterface.domain.QFileLog;
import com.bdo.itd.projects.bdocors.inboundinterface.infrastructure.repository.IFileLogRepository;
import com.bdo.itd.projects.bdocors.inboundinterface.infrastructure.utilities.DateConverterUtility;
import com.bdo.itd.util.cqrs.query.APageableQueryModel;
import com.bdo.itd.util.cqrs.query.IQuery;
import com.bdo.itd.util.cqrs.query.QueryException;
import com.bdo.itd.util.cqrs.query.QueryParam;
import com.bdo.itd.util.cqrs.query.ResultModel;
import com.querydsl.core.BooleanBuilder;
import com.querydsl.core.types.Predicate;

@Service
public class FileLogQueryModel extends APageableQueryModel implements IQuery {
	
	/**
	 * 
	 */
	private final int defaultPageIndex = 1;
	
	/**
	 * 
	 */
	private final int defaultPageSize = 50;
	
	/**
	 * 
	 */
	@Value(value = "${data-format.date.default}")
	private String dateFormat;
	
	/**
	 * 
	 */
	private final IFileLogRepository fileLogRepository;
	
	/**
	 * @param dateFormat
	 * @param fileLogRepository
	 */
	@Autowired
	public FileLogQueryModel(IFileLogRepository fileLogRepository) {
		super();
		this.fileLogRepository = fileLogRepository;
	}

	@Override
	public ResultModel doQuery(QueryParam queryParam) throws QueryException {
		try {
			Predicate predicate = this.buildPredicate(queryParam);
			
			int pageIndex = this.getPagination(queryParam.getParam("pageIndex"), defaultPageIndex);
			int pageSize = this.getPagination(queryParam.getParam("pageSize"), defaultPageSize);
			
			return query(predicate, pageIndex, pageSize);
			
		}catch(ParseException ex) {
			throw new QueryException(ex);
		}
	}
	
	
	/**
	 * @param queryParam
	 * @return
	 */
	private Predicate buildPredicate(QueryParam queryParam) throws ParseException{
		BooleanBuilder builder = new BooleanBuilder();
		QFileLog qfileLog = new QFileLog("fileLog");
		
		if(hasValue(queryParam.getParam("context"))) {
			String context = String.valueOf(queryParam.getParam("context"));
			
			builder.and(qfileLog.context.eq(context));
		}
		
		if(hasValue(queryParam.getParam("transactionDateFrom"))) {
			Date transactionDateFrom = DateConverterUtility.toDate(queryParam.getParam("transactionDateFrom").toString(), dateFormat);
			builder.and(qfileLog.dateCreated.goe(transactionDateFrom));
		}
		
		if(hasValue(queryParam.getParam("transactionDateTo"))) {
			Date transactionDateTo = DateConverterUtility.toDate(queryParam.getParam("transactionDateTo").toString(), dateFormat);
			builder.and(qfileLog.dateCreated.loe(transactionDateTo));
		}
		
		if(hasValue(queryParam.getParam("fileLogStatus"))) {
			FileLogStatus fileLogStatus = Enum.valueOf(FileLogStatus.class, String.valueOf(queryParam.getParam("fileLogStatus")));
			
			builder.and(qfileLog.status.eq(fileLogStatus));
		}
		
		builder.and(qfileLog.isDeleted.eq(false));
		
		return builder.getValue();
	}
	
	/**
	 * @param object
	 * @return
	 */
	private boolean hasValue(Object object) {
		if(object != null && !object.toString().isEmpty()) {
			return true;
		}else {
			return false;
		}
	}
	
	/**
	 * @param object
	 * @param defaultValue
	 * @return
	 */
	private int getPagination(Object object, int defaultValue) {
		if(hasValue(object)) {
			return Integer.parseInt(object.toString());
		}else {
			return defaultValue;
		}
	}
	
	/**
	 * @param predicate
	 * @param pageIndex
	 * @param pageSize
	 * @return
	 */
	private ResultModel query(Predicate predicate, int pageIndex, int pageSize) {
		Iterable<FileLog> fileLogList = fileLogRepository.findAll(predicate, gotoPage(pageIndex, pageSize, Sort.Direction.DESC, 
				"dateCreated"));
		
		long overAllCount = fileLogRepository.count(predicate);
		
		List<LinkedHashMap<String, Object>> resultSet = new ArrayList<>();
		
		for(FileLog fileLog : fileLogList) {
			LinkedHashMap<String, Object> row = new LinkedHashMap<>();
			row.put("ID", fileLog.getId());
			row.put("File Name", fileLog.getFilename());
			row.put("Source Profile", fileLog.getSourceProfile().getCode());
			row.put("Status", fileLog.getStatus().name());
			row.put("statusID", fileLog.getStatus());
			row.put("Loaded By", fileLog.getDateCreated());
			row.put("Date Loaded", fileLog.getCreatedBy());
			row.put("Last Modified By", fileLog.getDateLastModified());
			row.put("Date Last Modified", fileLog.getLastModifiedBy());
			
			resultSet.add(row);
		}		
		return new ResultModel(resultSet, overAllCount);
	}
}
