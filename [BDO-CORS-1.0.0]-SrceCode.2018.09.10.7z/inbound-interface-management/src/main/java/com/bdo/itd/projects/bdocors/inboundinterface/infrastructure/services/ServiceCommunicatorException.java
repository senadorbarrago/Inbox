package com.bdo.itd.projects.bdocors.inboundinterface.infrastructure.services;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author c140618008
 *
 */
@Data
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class ServiceCommunicatorException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3645960313367032955L;
	
	/**
	 * 
	 */
	private final Throwable cause;
	
	/**
	 * 
	 */
	private String message;
}
