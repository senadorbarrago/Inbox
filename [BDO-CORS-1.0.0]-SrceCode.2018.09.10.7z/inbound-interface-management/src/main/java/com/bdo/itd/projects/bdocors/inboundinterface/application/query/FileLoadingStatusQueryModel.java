package com.bdo.itd.projects.bdocors.inboundinterface.application.query;

import org.springframework.stereotype.Service;

import com.bdo.itd.util.cqrs.query.IQuery;
import com.bdo.itd.util.cqrs.query.QueryException;
import com.bdo.itd.util.cqrs.query.QueryParam;
import com.bdo.itd.util.cqrs.query.ResultModel;

@Service
public class FileLoadingStatusQueryModel implements IQuery {

	@Override
	public ResultModel doQuery(QueryParam queryParam) throws QueryException {
		// TODO Auto-generated method stub
		return null;
	}

}
