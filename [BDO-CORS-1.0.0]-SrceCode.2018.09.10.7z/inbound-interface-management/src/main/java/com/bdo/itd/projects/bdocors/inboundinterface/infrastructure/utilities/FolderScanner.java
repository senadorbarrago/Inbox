package com.bdo.itd.projects.bdocors.inboundinterface.infrastructure.utilities;

import java.io.File;

/**
 * @author c140618008
 *
 */
public class FolderScanner {

	/**
	 * 
	 */
	public static File[] scanFolder(File directory) {
		if(!directory.isDirectory()) {
			throw new IllegalArgumentException("The supplied diirectory "+directory.getAbsolutePath()+" is not a valid directory");
		}
		return directory.listFiles();
	}
}
