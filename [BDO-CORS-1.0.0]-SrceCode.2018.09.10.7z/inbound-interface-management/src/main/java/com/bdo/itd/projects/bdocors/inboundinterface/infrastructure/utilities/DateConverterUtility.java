package com.bdo.itd.projects.bdocors.inboundinterface.infrastructure.utilities;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;



/**
 * @author c140618008
 *
 */
public class DateConverterUtility {
	
	/**
	 * @param date
	 * @param format
	 * @return
	 * @throws ParseException
	 */
	public static Date toDate(String date, String format) throws ParseException{
		DateFormat formatter = new SimpleDateFormat(format);
		
		return date != null ? formatter.parse(date) : null;
	}
	
	
	/**
	 * @param date
	 * @param format
	 * @return
	 */
	public static String toString(Date date, String format) {
		DateFormat formatter = new SimpleDateFormat(format);
		
		return date != null ? formatter.format(date) : "";
	}
}
