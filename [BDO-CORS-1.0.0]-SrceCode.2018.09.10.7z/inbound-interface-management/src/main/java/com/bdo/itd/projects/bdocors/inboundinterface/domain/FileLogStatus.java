package com.bdo.itd.projects.bdocors.inboundinterface.domain;

/**
 * @author c140618008
 *
 */
public enum FileLogStatus {
	
	/**
	 * 
	 */
	LOADED,
	
	
	/**
	 * 
	 */
	UNLOADED	
	
}
