package com.bdo.itd.projects.bdocors.inboundinterface;

import org.springframework.boot.SpringApplication;

//@SpringBootApplication
public class InboundInterfaceManagementApplication {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SpringApplication.run(InboundInterfaceManagementApplication.class, args);
	}
}
