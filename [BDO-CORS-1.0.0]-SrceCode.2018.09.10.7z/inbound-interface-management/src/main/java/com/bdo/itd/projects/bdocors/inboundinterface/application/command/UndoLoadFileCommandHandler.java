package com.bdo.itd.projects.bdocors.inboundinterface.application.command;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bdo.itd.projects.bdocors.inboundinterface.infrastructure.services.IServiceCommunicator;
import com.bdo.itd.projects.bdocors.inboundinterface.infrastructure.utilities.DateConverterUtility;
import com.bdo.itd.util.cqrs.command.ACommandHandler;
import com.bdo.itd.util.cqrs.command.BasicCommand;
import com.bdo.itd.util.cqrs.command.CommandMessage;
import com.bdo.itd.util.cqrs.command.ICommand;
import com.bdo.itd.util.cqrs.command.UnableToProcessCommandException;

@Service
public class UndoLoadFileCommandHandler extends ACommandHandler {
	
	/**
	 * 
	 */
	private final IServiceCommunicator serviceCommunicator;
	
	/**
	 * 
	 */
	@Value(value = "${application.name}")
	private String applicationName;
	
	/**
	 * 
	 */
	@Value(value = "${itdservices.load-service.actions.load.name")
	private String action;	
	
	/**
	 * 
	 */
	@Value(value = "${itdservices.load-service.actions.load.async}")
	private boolean async;
	
	/**
	 * 
	 */
	@Value(value = "${data-format.date.default}")
	private String dateFormat;
	
	/**
	 * 
	 */
	@Value(value = "${itdservices.load-service.actions.load.undoload-profile}")
	private String undoloadprofile;
	
	/**
	 * @param serviceCommunicator
	 * 
	 */
	@Autowired
	public UndoLoadFileCommandHandler(IServiceCommunicator serviceCommunicator) {
		super();
		this.serviceCommunicator = serviceCommunicator;
	}

	@Override
	public CommandMessage doHandle(ICommand command) throws UnableToProcessCommandException {
		// Extract command data
		BasicCommand basicCommand = (BasicCommand)command;
		
		// Build service parameters
		Map<String, Object> parameterMap = this.buildServiceParameterMap(basicCommand);
		
		// Communicate with service
		return commandMessageFactory.createCustomMessage(serviceCommunicator.doCommunicate(parameterMap));
	}
	
	private Map<String, Object> buildServiceParameterMap(BasicCommand basicCommand){
		
		Map<String, Object> parameterMap = new HashMap<>();
		parameterMap.put("applicationName", applicationName);
		parameterMap.put("action", action);
		parameterMap.put("async", async);
		parameterMap.put("profile", undoloadprofile);
		parameterMap.put("systemDate", DateConverterUtility.toString(Calendar.getInstance().getTime(), dateFormat));
		parameterMap.putAll(basicCommand.map());
		
		return parameterMap;
	}

}
