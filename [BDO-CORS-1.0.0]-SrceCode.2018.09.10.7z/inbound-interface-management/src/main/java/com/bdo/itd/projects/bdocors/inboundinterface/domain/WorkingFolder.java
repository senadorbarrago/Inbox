package com.bdo.itd.projects.bdocors.inboundinterface.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
@RequiredArgsConstructor
@NoArgsConstructor(access=AccessLevel.PROTECTED)
@Entity
@Table(name="conf_working_folder")
public class WorkingFolder extends BaseEntity {
	
	/**
	 * 
	 */
	@Column(name="code")
	@NonNull 
	private String code;
	
	/**
	 * 
	 */
	@Column(name="description")
	@NonNull 
	private String description;
	
	/**
	 * 
	 */
	@Column(name="path")
	@NonNull 
	private String path;
	
	/**
	 * 
	 */
	@Column(name="context")
	@NonNull 
	private String context;
	
}
