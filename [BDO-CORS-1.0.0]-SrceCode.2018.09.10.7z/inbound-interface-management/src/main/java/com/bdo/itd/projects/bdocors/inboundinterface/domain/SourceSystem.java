package com.bdo.itd.projects.bdocors.inboundinterface.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
@RequiredArgsConstructor
@NoArgsConstructor(access=AccessLevel.PROTECTED)
@Entity
@Table(name="ibs_source_system")
public class SourceSystem extends BaseEntity {
	
	/**
	 * 
	 */
	@Column(name="code")
	@NonNull 
	private String code;
	
	/**
	 * 
	 */
	@Column(name="description")
	@NonNull 
	private String description;
	
	/**
	 * 
	 */
	@Column(name="context")
	@NonNull 
	private String context;
	
}
