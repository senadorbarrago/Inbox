package com.bdo.itd.projects.bdocors.inboundinterface.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
@RequiredArgsConstructor
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Entity
@Table(name = "ibs_file_log")
public class FileLog extends BaseEntity {
	
	/**
	 * 
	 */
	@Column(name = "filename")
	@NonNull 
	private String filename;
	
	/**
	 * 
	 */
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "fk_source_profile")
	@NonNull 
	private SourceProfile sourceProfile;
	
	/**
	 * 
	 */
	@Column(name = "status")
	@NonNull 
	private FileLogStatus status;
	
	/**
	 * 
	 */
	@Column(name = "context")
	@NonNull 
	private String context;
	
}
