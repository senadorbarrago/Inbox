package com.bdo.itd.projects.bdocors.inboundinterface.application.command;

import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bdo.itd.projects.bdocors.inboundinterface.domain.SourceProfile;
import com.bdo.itd.projects.bdocors.inboundinterface.domain.WorkingFolder;
import com.bdo.itd.projects.bdocors.inboundinterface.infrastructure.repository.ISourceProfileRepository;
import com.bdo.itd.projects.bdocors.inboundinterface.infrastructure.repository.IWorkingFolderRepository;
import com.bdo.itd.projects.bdocors.inboundinterface.infrastructure.services.IServiceCommunicator;
import com.bdo.itd.projects.bdocors.inboundinterface.infrastructure.utilities.DateConverterUtility;
import com.bdo.itd.util.cqrs.command.ACommandHandler;
import com.bdo.itd.util.cqrs.command.BasicCommand;
import com.bdo.itd.util.cqrs.command.CommandMessage;
import com.bdo.itd.util.cqrs.command.ICommand;
import com.bdo.itd.util.cqrs.command.UnableToProcessCommandException;

/**
 * @author c140618008
 *
 */
@Service
public class LoadFileCommandHandler extends ACommandHandler {
	
	/**
	 * 
	 */
	private final IServiceCommunicator serviceCommunicator;
	
	/**
	 * 
	 */
	private final IWorkingFolderRepository workingFolderRepository;
	
	/**
	 * 
	 */
	private final ISourceProfileRepository sourceProfileRepository;
	
	/**
	 * 
	 */
	@Value(value = "${application.name}")
	private String applicationName;
	
	/**
	 * 
	 */
	@Value(value = "${itdservices.load-service.actions.load.name")
	private String action;	
	
	/**
	 * 
	 */
	@Value(value = "${itdservices.load-service.actions.load.async}")
	private boolean async;
	
	/**
	 * 
	 */
	@Value(value = "${data-format.date.default}")
	private String dateFormat;
	
	/**
	 * @param serviceCommunicator
	 * @param workingFolderRepository
	 * @param sourceProfileRepository
	 */
	@Autowired
	public LoadFileCommandHandler(IServiceCommunicator serviceCommunicator,
			IWorkingFolderRepository workingFolderRepository, ISourceProfileRepository sourceProfileRepository) {
		super();
		this.serviceCommunicator = serviceCommunicator;
		this.workingFolderRepository = workingFolderRepository;
		this.sourceProfileRepository = sourceProfileRepository;
	}

	@Override
	public CommandMessage doHandle(ICommand command) throws UnableToProcessCommandException {
		// Extract command data
		BasicCommand basicCommand = (BasicCommand)command;
		String context = basicCommand.getStringValue("context");
		
		List<WorkingFolder> workingFolderList = this.findWorkingFolders(context);
		List<SourceProfile> sourceProfleList = this.findSourceProfiles(context);
		
		String filename = basicCommand.getStringValue("sourceFile");
		
		// Match corresponding sourceProfile
		SourceProfile sourceProfile = this.findMatchSourceProfile(filename, sourceProfleList);
		
		// Build service parameters
		Map<String, Object> parameterMap = this.buildServiceParameterMap(basicCommand, sourceProfile, workingFolderList);
		
		// Communicate with service
		return commandMessageFactory.createCustomMessage(serviceCommunicator.doCommunicate(parameterMap));
	}
	
	/**
	 * @param context
	 * @return
	 */
	private List<WorkingFolder> findWorkingFolders(String context){
		return workingFolderRepository.findByContextAndIsDeleted(context, false);
	}
	
	/**
	 * @param context
	 * @return
	 */
	private List<SourceProfile> findSourceProfiles(String context){
		return sourceProfileRepository.findByContextAndIsDeleted(context, false);
	}
	
	/**
	 * @param filename
	 * @param sourceProfileList
	 * @return
	 */
	private SourceProfile findMatchSourceProfile(String filename, List<SourceProfile> sourceProfileList) {
		for(SourceProfile sourceProfile : sourceProfileList) {
			Pattern pattern = Pattern.compile(sourceProfile.getFilenamePattern());
			Matcher match = pattern.matcher(filename);
			if (match.matches()) {
			    return sourceProfile;
			} 
		}
		
		throw new UnableToProcessCommandException("The selected filename "+filename+" has no corresponding source profile "
				+ "configuration. Please coordinate with the system administrator.", null);
	}
	
	/**
	 * @param context
	 * @param filename
	 * @param username
	 * @param sourceProfile
	 * @param workingFolderList
	 * @return
	 */
	private Map<String, Object> buildServiceParameterMap(BasicCommand basicCommand, 
			SourceProfile sourceProfile, List<WorkingFolder> workingFolderList){
		
		Map<String, Object> parameterMap = new HashMap<>();
		parameterMap.put("applicationName", applicationName);
		parameterMap.put("action", action);
		parameterMap.put("async", async);
		
		parameterMap.put("sourceProfile", sourceProfile.getCode());
		parameterMap.put("profile", sourceProfile.getFileConfig());
		for(WorkingFolder workingFolder : workingFolderList) {
			parameterMap.put(workingFolder.getCode(), workingFolder.getPath());
		}
		
		parameterMap.put("systemDate", DateConverterUtility.toString(Calendar.getInstance().getTime(), dateFormat));
		parameterMap.putAll(basicCommand.map());
		
		return parameterMap;
	}
}
