'use strict';

define(function(){
	
	console.log('reportsController.js loaded');
	var core = angular.module('core');
	
	core.registerController('reportsController', ['$rootScope', '$scope', 'DataAccessService', 'JournalEntryFormQueryService', 'ReportFormQueryService', '$filter', function($rootScope, $scope, dataAccessService, journalEntryFormQueryService, reportFormQueryService, $filter){
			
		$scope.title = 'This is the Reports Screen';
		$rootScope.screenName = 'REPORTS';
		$scope.report = { "parameters " : [] };
		$scope.values = { "values " : [] };
		$scope.encodingUnits = { "encodingUnits " : [] };
		$scope.groupUsers = { "groupUsers " : [] };
		$scope.secGroups = { "secGroup " : [] };
		$scope.bookCodes = { "bookCodes " : [] };
		$scope.tagTypes = { "tagTypes " : [] };
		$scope.glGroups = { "glGroups " : [] };
		$scope.currencies = { "currencies " : [] };
		$scope.currenciesbyBook = { "currencies " : [] };
		$scope.userCode = { "userCode " : [] };
		$scope.effectiveMonths = { "effectiveMonths " : [] };
		$scope.effectiveYears = { "effectiveYears " : [] };
		$scope.userCode = { "userCode " : [] };
		$scope.interfaceFiles = { "interfaceFiles " : [] };
		$scope.currenciesByDataSetCode = { "currencies " : [] };
		$scope.currencyShortDescriptions = { "currencyShortDescriptions " : [] };
		$scope.currencyShortDescription = "";
		$scope.reportCode = "";
		$scope.reportName = "";
		$scope.reportID = "";
		$scope.bookDesc = "";
		$scope.reportTypeValue = "_pdf";
		$scope.userProcessInfo = { "userProcessInfo " : [] };
		$scope.sampleList = [];
		
		var vm = this;
		
		vm.init = function () {
			console.log('reportsController: init() called');
			console.log("Reports:" + $rootScope.reports);
			console.log($rootScope);
			
			$scope.reportparams = {};
			$scope.reportparameters = {};
			$scope.reportDescription = '';
			$scope.reports = $rootScope.reports;
			$scope.sampleList = [];
			//Get Encoding Units
			journalEntryFormQueryService.getEncodingUnits(function(response){
				console.log('getEncodingUnits');
				console.log(response.data);
				$scope.encodingUnits = response.data;
				
			},function(error){
				console.log(error);
			});
			
			//Get Group Users
			reportFormQueryService.getGroupUsers($rootScope.dataSetID, function(response){
				console.log('getGroupUsers');
				console.log(response.data);
				$scope.groupUsers = response.data;
				
			},function(error){
				console.log(error);
			});
			
			//Get BookCodes
			journalEntryFormQueryService.getBookCodeByDataSet($rootScope.dataSetCode, function(response){
				console.log('getBookCode');
				$scope.bookCodes = response.data;
				console.log($scope.bookCodes);
				
			},function(error){
				console.log(error);
			});
			
			//Get TagTypes
			reportFormQueryService.getTagTypes($rootScope.dataSetCode, function(response){
				console.log('getTagTypes');
				$scope.tagTypes = response.data;
				console.log($scope.tagTypes);
				
			},function(error){
				console.log(error);
			});
			
			//Get GL Groups
			journalEntryFormQueryService.getGLGroupByDataSetID($rootScope.dataSetID, function(response){
				console.log('getGLGroup');
				$scope.glGroups = response.data;
				console.log($scope.glGroups);
				
			},function(error){
				console.log(error);
			});
			
			//Get SecGroups
			journalEntryFormQueryService.getGroupByDataSetID($rootScope.dataSetID, function(response){
				console.log('getSecGroup');
				$scope.secGroups = response.data;
				console.log($scope.secGroups);
			},function(error){
				console.log(error);
			});
			
			//Get currency by bookCode
			$scope.getCurrencyReferenceListByBookCode = function(){
				var url  = 'references/currencyByBookCodeID/'+$scope.reportparams['bookCode'];
				dataAccessService.doGetData(url, null, function(response){
					$scope.currenciesbyBook = response.data;
				},function(errorResponse){
					errorCallBack(errorResponse);
				});
			};
			
			//Get Group Users
			reportFormQueryService.getUserCode($rootScope.dataSetCode, function(response){
				console.log('getUserCode');
				console.log(response.data);
				$scope.userCode = response.data;
				
			},function(error){
				console.log(error);
			});
			
			//Get currencies
			reportFormQueryService.getCurrenciesByDataSetCode($rootScope.dataSetCode, function(response){
				console.log(response.data);
				$scope.currencies = response.data;
				
			},function(error){
				console.log(error);
			});
			
			//Get currencies with short descriptions
			reportFormQueryService.getCurrencyShortDesc($rootScope.dataSetCode, function(response){
				console.log(response.data);
				$scope.currencyShortDescriptions = response.data;
				
			},function(error){
				console.log(error);
			});
			
			//Get userParams
			reportFormQueryService.getUserProcessInfo($rootScope.dataSetCode, function(response){
				console.log(response.data);
				$scope.userProcessInfo = response.data;
				
			},function(error){
				console.log(error);
			});
			
			//Get effective months
			reportFormQueryService.getEffectiveMonths($rootScope.dataSetCode, function(response){
				console.log(response.data);
				$scope.effectiveMonths = response.data;
				
			},function(error){
				console.log(error);
			});
			
			//Get effective years
			reportFormQueryService.getEffectiveYears($rootScope.dataSetCode, function(response){
				console.log(response.data);
				$scope.effectiveYears = response.data;
				
			},function(error){
				console.log(error);
			});
			
			//Get Loaded Interface Files
			$scope.PDEdata = {};
			if($rootScope.session["PROCESSINFO"].processDate != undefined || $rootScope.session["PROCESSINFO"].processDate != null){
				console.log('PDE Defined');
				$scope.PDEdata["dateFrom"] = $filter('date')(new Date($rootScope.session["PROCESSINFO"].processDate), 'yyyy/MM/dd');
				$scope.PDEdata["dateTo"] = $filter('date')(new Date($rootScope.session["PROCESSINFO"].processDate), 'yyyy/MM/dd');
				$scope.currentDate = $rootScope.session["PROCESSINFO"].processDate;
			}else{
				console.log('PDE Undefined');
				$scope.PDEdata["dateFrom"] = $filter('date')(new Date(), 'yyyy/MM/dd');
				$scope.PDEdata["dateTo"] = $filter('date')(new Date(), 'yyyy/MM/dd');
				$scope.currentDate = $filter('date')(new Date(), 'yyyy/MM/dd')
				
			}
			
			$scope.PDEdata["recordTypeTag"] = "PDEDetails";
			
			console.log("PDEdata");
			console.log($scope.PDEdata);
			console.log($scope.currentDate);
			
			reportFormQueryService.getInterfaceFiles($rootScope.dataSetCode, $scope.PDEdata, function(response){
				console.log('getInterfaceFiles');
				console.log(response.data);
				$scope.interfaceFiles = response.data;
				
			},function(error){
				console.log(error);
			});
			
			// Date Picker Setup
			$scope.datePicker = { };
			
			$scope.dateOptions = {
					startingDay : 1,
					showWeeks : false,	
					format : "yyyy-MM-dd"
				};
			
			$scope.dateFormat = "yyyy-MM-dd";
			
		};
		// Initialize
		vm.init();
		
		$scope.doGenerateReport = function(){
			
				console.log("doGenerateReport()");
			
				$scope.user = $rootScope.session["AUTHENTICATED_USER"];
				
				console.log($scope.user);
				
				if($scope.reportparameters.bookCode === '1' && $scope.reportCode != 'RPT013'){
					$scope.bookDesc = 'RBU';
				}else
				if($scope.reportparameters.bookCode === '2' && $scope.reportCode != 'RPT013'){
					$scope.bookDesc = 'FCDU';
				}else{
					$scope.bookDesc = '';
				}
				
				if($scope.reportparameters["currencyCode"] === '000'){
					$scope.reportparameters["bookDescByCurrency"] = 'RBU'
				}else{
					$scope.reportparameters["bookDescByCurrency"] = 'FCDU'
				}
				
				//reportparameters
				if($scope.reportparameters["user"]!=undefined && $scope.reportparameters["user"]!="" && $scope.reportparameters["user"]!=null ){
					$scope.reportparameters["userName"] = $scope.reportparameters["user"];
				}else{
					$scope.reportparameters["userName"] = $scope.user.username;
				}
				$scope.reportparameters["userID"] = $scope.userCode[0].code;
				$scope.reportparameters["reportID"] = $scope.reportCode;
				$scope.reportparameters["dataset"] = $scope.dataSetID;
				$scope.reportparameters["dataSetCode"] = $rootScope.dataSetCode;
				$scope.reportparameters["processingDate"] = $filter('date')(new Date($scope.userProcessInfo[0].desc), 'yyyyMMdd')
				$scope.reportparameters["systemDate"] = $filter('date')(new Date(), 'yyyyMMddhhmmssS')
				$scope.reportparameters["bookDesc"] = $scope.bookDesc;
				$scope.reportparameters["currencyDesc"] = $scope.currencyShortDescription;
				$scope.reportparameters["usersEncodingUnit"] = $scope.userProcessInfo[0].code;
				if($scope.reportCode === 'RPT004' || $scope.reportCode === 'RPT006'){
					$scope.reportparameters["batchSheetID"] = '';
				}
				
				if($scope.reportCode === 'RPT025' || $scope.reportCode === 'RPT026'){
						if($scope.reportparams.criteriaMap.code === 'all'){
							$scope.reportparameters["filename"] = '';
							$scope.reportparameters["fileCode"] = 'ALL';
						}else{
							$scope.reportparameters["filename"] = $scope.reportparameters["filenameMap"].desc;
							$scope.reportparameters["fileCode"] = $scope.reportparameters["filenameMap"].code;
						}
				}
				
				// URL
				var reportDescription = $scope.reportDescription;
				var reportUrl = 'reports/create/'+$scope.reportName+$scope.bookDesc+$scope.reportTypeValue;
				var downloadUrl = 'reports/download/'+$scope.reportName+$scope.bookDesc+$scope.reportTypeValue;
				
				$scope.data = {};
				
				$scope.requestStatus = $scope.reportDescription + ' generation ongoing...';
				
				console.log($scope.reportparams);
				console.log($scope.reportparameters);		
				
				console.log('Ooo--------------------------->Generating<---------------------------ooO');
				dataAccessService.doPostData(reportUrl, $scope.reportparameters, function(response){
					console.log(response);
					$scope.resultMessage = response.data;
					$scope.message = $scope.resultMessage.messageMap;
					
					if($scope.message.successMsg!=undefined && $scope.message.successMsg!=null){
						alertify.alert($scope.message.successMsg);
						$scope.requestStatus = $scope.reportDescription + ' generation successful!';
//						alertify.confirm('Report successfully generated. Do you want to download report?', function(e) {
//							if (e) {
//								window.location.href=downloadUrl+'?file=' + $scope.message.filename;
//							}else{
//								return;
//							}
//						});
					}else
					if($scope.message.errorMsg!=undefined && $scope.message.errorMsg!=null){
						alertify.alert($scope.message.errorMsg);
						$scope.requestStatus = $scope.reportDescription + ' generation failed!';
					}
					
				},function(errorResponse){
					console.log(errorResponse);
					alertify.alert('Error Occurred.');
					$scope.requestStatus = $scope.reportDescription + ' generation failed!';
				});
				
		};
		
		$scope.getReportParams = function(){
			
			$scope.reportparams = {};
			$scope.interfaceFiles = { "interfaceFiles " : [] };
			$scope.currenciesbyBook = { "currencies " : [] };
			var reportDescription = $scope.reportDescription;
			var reportCode = null;
			var parameters = null;
			var exists = false;
			var exists1 = false;
			
			$scope.reports = $rootScope.reports;
			
			angular.forEach($scope.reports, function(value, key) {
				
				if(!exists){
					if (value.description === reportDescription) {
						$scope.parameters = [];
						$scope.reportCode = value.code;
						$scope.reportName = value.name;
						$scope.isCSV = 'false';
						$scope.isPDF = 'false';
						$scope.isXLS = 'false';
						
						$scope.parameters = (value.parameters);
						
						$scope.options = [];
						angular.forEach($scope.parameters, function(value, key){
							
							if(value.name === 'criteria'){
								$scope.options = (value.options);
							}
							
							if(value.type === 'date' && value.value === 'default'){
								$scope.reportparams[value.name] = new Date($scope.currentDate);
							}
							
							if(value.type === 'select' && value.isField === 'true' && value.disabled === true){
								$scope.reportparams[value.name] = '';
							}
							
							if(value.type === 'select' && value.isField === 'true' && value.disabled === true && value.name === 'user'){
								$scope.reportparams[value.name] = undefined;
							}
							
							if(value.type === 'variable' && value.isField === 'false'){
								$scope.reportparams[value.name] = value.value;
							}
							
							if(value.name === 'reportTag'){
								$scope.options = (value.options);
							}
							
							if(value.name === 'isCSV'){
								$scope.isCSV = (value.value);
							}
							
							if(value.name === 'isPDF'){
								$scope.isPDF = (value.value);
							}
							
							if(value.name === 'isXLS'){
								$scope.isXLS = (value.value);
							}
						});
						
						exists = true;
					}
				}
			});
			
			if($scope.reportDescription == 'Automated Predefined Entries Detailed Report' || $scope.reportDescription == 'Automated Predefined Entries Summary Report'){
				$scope.getLoadedPDEFiles();
			}
			
			$scope.requestStatus = '';
			
			console.log("$scope.isCSV: " + $scope.isCSV);
			console.log("$scope.isPDF: " + $scope.isPDF);
			console.log("$scope.isXLS: " + $scope.isXLS);
		};
		
		$scope.enableCriteria = function(){
			
			console.log($scope.reportparams.criteriaMap);
			
			$scope.reportparams.criteria = $scope.reportparams.criteriaMap.id;
			var criteriaSelected = $scope.reportparams.criteriaMap.code;
			
			if(criteriaSelected === 'usr'){
				
				angular.forEach($scope.parameters, function(value, key){
					
					if(value.name === 'user'){
						value.disabled = false;
					} else
					if(value.name === 'encodingUnit'){
						value.disabled = true;
						$scope.reportparams[value.name] = "";
					} else
					if(value.name === 'secGroup'){
						value.disabled = true;
						$scope.reportparams[value.name] = "";
					} else
					if(value.name === 'filename'){
						value.disabled = true;
					}
				});
			}
			else if(criteriaSelected === 'grp'){
				
				angular.forEach($scope.parameters, function(value, key){
					
					if(value.name === 'user'){
						value.disabled = true;
						$scope.reportparams[value.name] = undefined;
					} else
					if(value.name === 'encodingUnit'){
						value.disabled = true;
					} else
					if(value.name === 'secGroup'){
						value.disabled = false;
					} else
					if(value.name === 'filename'){
						value.disabled = true;
						$scope.reportparams[value.name] = "";
					}
				});
			}
			else if(criteriaSelected === 'enc'){
				
				angular.forEach($scope.parameters, function(value, key){
					
					if(value.name === 'user'){
						value.disabled = true;
						$scope.reportparams[value.name] = undefined;
					} else
					if(value.name === 'encodingUnit'){
						value.disabled = false;
					} else
					if(value.name === 'secGroup'){
						value.disabled = true;
					} else
					if(value.name === 'filename'){
						value.disabled = true;
						$scope.reportparams[value.name] = "";
					}
				});
			}
			else if(criteriaSelected === 'fle'){
				
				angular.forEach($scope.parameters, function(value, key){
					
					if(value.name === 'user'){
						value.disabled = true;
						$scope.reportparams[value.name] = undefined;
					} else
					if(value.name === 'encodingUnit'){
						value.disabled = true;
					} else
					if(value.name === 'secGroup'){
						value.disabled = true;
					} else
					if(value.name === 'filename'){
						value.disabled = false;
						$scope.reportparams[value.name] = "";
					}
				});
			}
			else{
				
				$scope.reportparams.disabled = true;
				angular.forEach($scope.parameters, function(value, key){
					if(value.name === 'encodingUnit'){
						value.disabled = true;
						$scope.reportparams[value.name] = "";
					}
					if(value.name === 'secGroup'){
						value.disabled = true;
						$scope.reportparams[value.name] = "";
					}
					if(value.name === 'user'){
						value.disabled = true;
						$scope.reportparams[value.name] = undefined;
					}
					if(value.name === 'filename'){
						value.disabled = true;
						$scope.reportparams[value.name] = "";
					}
				});
			}
		};
		
		$scope.open = function(columnName, $event){
			
			$event.preventDefault();
			$event.stopPropagation();
			
			if ($scope.datePicker[columnName]) {
				if ($scope.datePicker[columnName].opened) {
					$scope.datePicker[columnName].opened = false;
				}
			} else {
				$scope.datePicker = {};
				$scope.datePicker[columnName] = {};
				$scope.datePicker[columnName].opened = true;
			}
		}
		
		$scope.validateParams = function(){
			
			console.log('validateParams()');
			
			$scope.isValid = false;
			$scope.invalidFields = '';
			var invalidCount = 0;
			
			angular.forEach($scope.parameters, function(value, key){
				
				if(value.isField === 'true' && value.disabled != true){
					console.log(' -' + value.name + '=' + $scope.reportparams[value.name]);
					if($scope.reportparams[value.name] === undefined || $scope.reportparams[value.name] === null){
						invalidCount = invalidCount + 1;
						$scope.invalidFields = $scope.invalidFields + value.name + ', ';
					}
				}
			});
			
			if(invalidCount === 0){
				$scope.isValid = true;
			}else{
				$scope.isValid = false;
				$scope.invalidFields = $scope.invalidFields.slice(0, $scope.invalidFields.length-2);
			}
			
			console.log('invalidCount: ' + invalidCount);
			console.log('isValid: ' + $scope.isValid);
		}
		
		$scope.formatParams = function(){
			
			console.log('formatParams()');
			
			$scope.reportparameters = angular.copy($scope.reportparams);
			angular.forEach($scope.parameters, function(value, key){
				
				if(value.type === 'date'){
					$scope.reportparameters[value.name] = $filter('date')($scope.reportparameters[value.name], 'MM/dd/yyyy');
				}
			});
			console.log($scope.reportparameters);
		};
		
		
		$scope.doGenerate = function(){
			
			console.log("doGenerate()");
			console.log($scope.reportparams);
			
			$scope.getCurrencyShortDesc($scope.reportparams["currencyCode"]);
			
			alertify.confirm("Do you really want to generate report?", function(e){
							
				if(e){
					if ($scope.reportDescription != "" && $scope.reportDescription != null){
						$scope.validateParams();
						$scope.formatParams();
						if($scope.isValid === true){
							$scope.validateReportType();
						}else{
							alertify.alert("Please select " + $scope.invalidFields);
						}
						
					} else {
						alertify.alert("Please select a report!");
					}
				}else{
					return;
				}
				
			});
				
		};
		
		$scope.validateReportType = function(){
			
			console.log('Report Type: ' + $scope.reportType);
			
			$scope.reportTypeValue = "_pdf";
			
			if ($scope.reportType === '0'){
				$scope.reportTypeValue = "_csv";
			} else if ($scope.reportType === '1'){
				$scope.reportTypeValue = "_pdf";
			} else if ($scope.reportType === '2'){
				$scope.reportTypeValue = "_xlsx";
			} else{
				$scope.reportTypeValue = "invalid";
			}
			
			console.log('Report Type Value: ' + $scope.reportTypeValue);
			
			if ($scope.reportTypeValue != "invalid"){
				$scope.doGenerateReport();
			} else {
				alertify.alert("Invalid Report Type!");
			}
		};
		
		$scope.clear = function(columnName){
			
			$scope.reportparams[columnName] = "";

		};
		
		$scope.getLoadedPDEFiles = function(){
			
			console.log("doTest()");
			console.log($scope.reportparams);
			console.log($scope.reportparams["effDate"]);
			console.log($scope.reportparams["recordTypeTag"]);
			
			if($scope.reportDescription == 'Automated Predefined Entries Detailed Report' || $scope.reportDescription == 'Automated Predefined Entries Summary Report'){
				$scope.PDEdata = {};
				$scope.PDEdata["dateFrom"] = $filter('date')(new Date($scope.reportparams["effDate"]), 'yyyy/MM/dd');
				$scope.PDEdata["dateTo"] = $filter('date')(new Date($scope.reportparams["effDate"]), 'yyyy/MM/dd');
				$scope.PDEdata["recordTypeTag"] = $scope.reportparams["recordTypeTag"];
				
				console.log("PDEdata");
				console.log($scope.PDEdata);
				
				reportFormQueryService.getInterfaceFiles($rootScope.dataSetCode, $scope.PDEdata, function(response){
					console.log('getInterfaceFiles');
					console.log(response.data);
					$scope.interfaceFiles = response.data;
					
				},function(error){
					console.log(error);
				});
			}
			
		};
		
		$scope.getCurrencyShortDesc = function(currencyCode){
			
			console.log($scope.currencyShortDescriptions);
			
			var exists = false;
			
			angular.forEach($scope.currencyShortDescriptions, function(value, key) {
				
				if(!exists){
					if (value.code === currencyCode) {
						
						$scope.currencyShortDescription = (value.desc);
						
						exists = true;
					}
				}
				
			});
			
			console.log("CurrencyShortDescription: " + $scope.currencyShortDescription);
		};
		
		$scope.setReportTag = function(){
			
			console.log($scope.reportparams.reportTagMap);
			
			$scope.reportparams.reportTag = $scope.reportparams.reportTagMap.code;
			$scope.reportparams.reportType = "Details";
			
			console.log("$scope.reportparams.reportTag: " + $scope.reportparams.reportTag);
		
		};
		
		$scope.setMonth = function(){
			
			console.log($scope.reportparams.monthMap);
			
			$scope.reportparams.month = $scope.reportparams.monthMap.id;
			$scope.reportparams.monthCode = $scope.reportparams.monthMap.code;
			$scope.reportparams.monthMap.additionalDetail = '';
			
			console.log("$scope.reportparams.reportTag: " + $scope.reportparams.reportTag);
		
		};
		
	}]);
	
});