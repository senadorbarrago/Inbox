'use strict';

define(function(){
	var core = angular.module('core');
	
	core.registerController('inboundInterfaceController',['$rootScope','$scope', 'ngTableParams', 'DataAccessService', 
	    function($rootScope, $scope, ngTableParams, dataAccessService){

		// Title and Module Description
		var vm = this;
		vm.title = 'Inbound Interface Screen';
		
		// Initialize Data
		vm.init = function(){
			$scope.data = {};
			$scope.data.dataSetCode = $rootScope.dataSetCode;
			
			// Table Header 
			$scope.tableHeader = ['Select', 'File Name', 'File Path', 'Size', 'Date Created'];
			$scope.fileHistoryHeader = ['Select', 'File Log ID', 'File Name', 'Date Loaded', 'Loaded By', 'Status'];
					
			vm.doGetDefaultSourceContents();
			vm.doGetFileLogHistory();
		};
		
		vm.doGetDefaultSourceContents = function(){
			console.log("vm.doGetDefaultSourceContents()");
			var data = {};
			data = angular.copy($scope.data);
			data.sourceFolderCode = "SRC";
			
			dataAccessService.doQuery('folderContentsQueryModel', data, function(response){
				vm.sourceFolderData = response.data;
				console.log(vm.sourceFolderData);
			},function(errorResponse){
				console.log(errorResponse);
			});
		}

		/**
		 * 
		 */
		vm.doGetFileLogHistory = function(){
			console.log("doGetFileLogHistory()");

			$scope.fileLogHistoryTable = new ngTableParams({
                page: 1,
                count: 10
            }, {
                getData: function ($defer, params) {
                	console.log("getData()");
//                	var queryCode = "fileLogQueryModel";
//                	var url = "query/"+queryCode;
//                	console.log('params.count(): '+ params.count());
//                	console.log('params.page(): '+ params.page());
//                	
//                	var data = {
//                				'transactionDateFrom' : '',
//                				'transactionDateTo' : '',
//                				'fileLogStatus' :'',
//                				'pageIndex' : params.page(),
//        						'pageSize': params.count()
//        			   	   	   };
//                	
//                	console.log(data);
//
//                	return dataAccessService.doQuery(queryCode, data, function(response){
//			        			console.log('productPage');
//			        			console.log(response);
//			        			vm.fileLogHistoryData = {};
//			        			vm.fileLogHistoryData.resultSet = response.data.resultSet;
//			        			vm.fileLogHistoryData.columns = response.data.columns;
//			        			
//			        			params.total(response.data.resultOverAllCount);
//			        			$defer.resolve(vm.fileLogHistoryData.resultSet);
//			        		}, function(errorResponse){
//			    				console.log(errorResponse);
//			    			});
                	
                }
            
            });
			console.log('$scope.fileLogHistoryTable');
			console.log($scope.fileLogHistoryTable);
		};
		
		
		$scope.fileLogHistoryTable = new ngTableParams({
            page: 1,
            count: 10
        }, {
            getData: function ($defer, params) {
            	console.log("getData()");
//            	var queryCode = "fileLogQueryModel";
//            	var url = "query/"+queryCode;
//            	console.log('params.count(): '+ params.count());
//            	console.log('params.page(): '+ params.page());
//            	
//            	var data = {
//            				'transactionDateFrom' : '',
//            				'transactionDateTo' : '',
//            				'fileLogStatus' :'',
//            				'pageIndex' : params.page(),
//    						'pageSize': params.count()
//    			   	   	   };
//            	
//            	console.log(data);
//
//            	return dataAccessService.doQuery(queryCode, data, function(response){
//		        			console.log('productPage');
//		        			console.log(response);
//		        			vm.fileLogHistoryData = {};
//		        			vm.fileLogHistoryData.resultSet = response.data.resultSet;
//		        			vm.fileLogHistoryData.columns = response.data.columns;
//		        			
//		        			params.total(response.data.resultOverAllCount);
//		        			$defer.resolve(vm.fileLogHistoryData.resultSet);
//		        		}, function(errorResponse){
//		    				console.log(errorResponse);
//		    			});
            	
            }
        });
        
        
        
		// UI Validations
		vm.checkIfHasSelection = function(list){
			for(var index = 0; index < list.length; index++){
				if(list[index]["Selected"]){
					return true;
				}
			}
			return false;
		}
		vm.init();
		
		$scope.doLoadSelectedFile = function(){
			var sourcedatacopy = angular.copy($scope.sourcedata.resultSet);
			var hasSelection = vm.checkIfHasSelection(sourcedatacopy);
			
			if(!hasSelection){
				alertify.alert("Please select a file to be loaded in order to proceed");
				return false;
			}else{
				alertify.confirm("This action loads the selected files from the source folder. " +
								"Are you sure you want to proceed?", function(e){
				if(e){
						var sourceFileList = [];
						angular.forEach(sourcedatacopy, function(value, key){
							if(value["Selected"]){
								var selectedFileName = value["File Name"];
								console.log(selectedFileName);
								sourceFileList.push(selectedFileName);
							}
						});
						
						var data = {};
						data.sourceFileList = sourceFileList;
						data.dataSetCode = $rootScope.dataSetCode;
						
						dataAccessService.doPostData(URL_LOAD_SOURCE_FILES, data, function(response){
							vm.doGetDefaultSourceContents();
							console.log('HEEERRRRE');
							alertify.alert(response.data.messageMap.successMsg, function(e){});
						}, function(errorResponse){
							console.log(errorResponse);
							alertify.alert(errorResponse.data.errorMsg, function(e){});
							vm.doGetDefaultSourceContents();
							
						});
						
					}else{
						return;
					}
				});
			}
		};
		
		$scope.open = function(columnName, $event){
			
			$event.preventDefault();
			$event.stopPropagation();
			
			if ($scope.datePicker[columnName]) {
				if ($scope.datePicker[columnName].opened) {
					$scope.datePicker[columnName].opened = false;
				}
			} else {
				$scope.datePicker = {};
				$scope.datePicker[columnName] = {};
				$scope.datePicker[columnName].opened = true;
			}
		}
		
	}]);
});