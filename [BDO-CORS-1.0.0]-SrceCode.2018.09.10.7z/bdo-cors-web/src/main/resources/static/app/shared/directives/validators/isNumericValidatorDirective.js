'use strict'

define(function(){
	console.log('isNumericValidatorDirective.js loaded');
	
	var core = angular.module('core');
	
	core.directive('numeric', function(){
		return function(scope, element, attrs) {
	        $(element[0]).numericInput({allowFloat:true, min:0 });
	    };
	});
	
	return core;
});