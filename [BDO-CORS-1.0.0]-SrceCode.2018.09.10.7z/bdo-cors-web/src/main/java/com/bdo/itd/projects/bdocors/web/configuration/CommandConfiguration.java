package com.bdo.itd.projects.bdocors.web.configuration;

import java.util.Collections;
import java.util.Map;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.bdo.itd.util.cqrs.command.BasicCommandBus;
import com.bdo.itd.util.cqrs.command.ICommandBus;
import com.bdo.itd.util.cqrs.command.ICommandHandler;

/**
 *
 * @author a014000098
 *
 */
@Configuration
public class CommandConfiguration implements BeanDefinitionRegistryPostProcessor {
        
    /**
     *
     */
    private ConfigurableListableBeanFactory beanFactory;
    
    /**
     *
     * @param commandHandlerMap
     * @return
     */
    @Bean
    public ICommandBus commandBus() {
        
        Map<String, ICommandHandler> commandBusMap = Collections.unmodifiableMap(
                beanFactory.getBeansOfType(ICommandHandler.class));
        
        for(String key : commandBusMap.keySet()){
        	System.out.println(String.format("Adding handler [%s] to command bus.", key));
        }
        
        return new BasicCommandBus(commandBusMap);
    }
	
    /**
     *
     */
    @Override
    public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry beanDefinitionRegistry)
            throws BeansException {
        
    }
    
    /**
     *
     */
    @Override
    public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory)
            throws BeansException {
        this.beanFactory =  beanFactory;        
    }
    
}
