package com.bdo.itd.projects.bdocors.web.controllers;

import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.cqrs.query.IQueryModelProvider;
import com.bdo.itd.util.cqrs.query.QueryParam;
import com.bdo.itd.util.cqrs.query.ResultModel;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping(value = "/query")
public class QueryController extends AbstractController {
	
	/**
	 * 
	 */
	private final IQueryModelProvider queryModelProvider;

	/**
	 * @param queryModelProvider
	 */
	@Inject
	public QueryController(IQueryModelProvider queryModelProvider) {
		super();
		this.queryModelProvider = queryModelProvider;
	}
	
	/**
	 * @param commandCode
	 * @param data
	 * @param request
	 * @return
	 * @throws JsonProcessingException 
	 */
	@RequestMapping(value = "/{queryCode}", method = RequestMethod.POST)
	public Object doQuery(@PathVariable(name = "queryCode") String queryCode, 
			@RequestBody Map<String, Object> data, HttpServletRequest request) throws JsonProcessingException{
		System.out.println(this.getClass()+": "+"doQuery()");
		
//		if(SecurityContextHolder.getContext().getAuthentication() != null &&
//				 SecurityContextHolder.getContext().getAuthentication().isAuthenticated() && 
//				 //when Anonymous Authentication is enabled
//				 !(SecurityContextHolder.getContext().getAuthentication() 
//				          instanceof AnonymousAuthenticationToken) ){
//			data.put("authenticatedUserID", UserSession.getUserID());
//			data.put("authenticatedUsername", UserSession.getUsername());
//			data.put("authenticatedUserFullname", UserSession.getUserProfile().getFullname());
//			data.put("authenticatedUserRoleCode", UserSession.getActiveRole().getCode());
//		}
		
		data.put("usr", "c140618008");
		data.put("context", "ITRS");
		System.out.println("queryCode: "+queryCode);
		System.out.println("data: "+data);
		
		ResultModel resultModel = queryModelProvider.getQuerymodel(queryCode)
				.doQuery(new QueryParam(data));
		
		ObjectMapper mapper = new ObjectMapper();
		
		String jsonObject = mapper.writeValueAsString(resultModel);
	    System.out.println(jsonObject);
		
		return jsonObject;
	}
	
}
	