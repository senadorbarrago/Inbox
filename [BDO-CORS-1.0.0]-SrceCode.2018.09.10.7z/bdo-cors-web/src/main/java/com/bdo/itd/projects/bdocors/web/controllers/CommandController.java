package com.bdo.itd.projects.bdocors.web.controllers;

import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.cqrs.command.CommandFactory;
import com.bdo.itd.util.cqrs.command.CommandMessage;
import com.bdo.itd.util.cqrs.command.ICommand;
import com.bdo.itd.util.cqrs.command.ICommandBus;

/**
 * @author senadorbarrago
 *
 */
@RestController
@RequestMapping(value = "/command")
public class CommandController extends AbstractController{
	
	/**
	 * 
	 */
	private final ICommandBus commandBus;
	
	/**
	 * @param commandBus
	 */
	@Inject
	public CommandController(ICommandBus commandBus) {
		super();
		this.commandBus = commandBus;
	}

	/**
	 * @param commandCode
	 * @param data
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/{commandCode}", method = RequestMethod.POST)
	public Object doCommand(@PathVariable(name = "commandCode") String commandCode, 
			@RequestBody Map<String, Object> data, HttpServletRequest request){
		System.out.println(this.getClass()+": "+"doCommand()");
		
//		if(SecurityContextHolder.getContext().getAuthentication() != null &&
//				 SecurityContextHolder.getContext().getAuthentication().isAuthenticated() && 
//				 //when Anonymous Authentication is enabled
//				 !(SecurityContextHolder.getContext().getAuthentication() 
//				          instanceof AnonymousAuthenticationToken) ){
//			data.put("usr", UserSession.getUserID());
//			data.put("usr", UserSession.getUsername());
//			data.put("authenticatedUserFullname", UserSession.getUserProfile().getFullname());
//			data.put("authenticatedUserRoleCode", UserSession.getActiveRole().getCode());
//		}
		
		data.put("usr", "c140618008");
		
		System.out.println("commandCode: "+commandCode);
		System.out.println("data: "+data);
		
		ICommand command = CommandFactory.create(commandCode, data);
		CommandMessage message = commandBus.doPublish(command);
		
		return message;
	}
	
}
