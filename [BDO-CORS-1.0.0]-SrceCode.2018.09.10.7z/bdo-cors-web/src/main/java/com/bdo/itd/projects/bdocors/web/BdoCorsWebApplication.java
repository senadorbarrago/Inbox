package com.bdo.itd.projects.bdocors.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author c140618008
 *
 */
@SpringBootApplication
public class BdoCorsWebApplication {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SpringApplication.run(BdoCorsWebApplication.class, args);
	}
}
