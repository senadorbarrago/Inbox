package com.bdo.itd.projects.bdocors.web.configuration;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.bdo.itd.projects.bdocors.inboundinterface.infrastructure.services.IServiceCommunicator;
import com.bdo.itd.projects.bdocors.inboundinterface.infrastructure.services.ITDServiceCommunicator;
import com.bdo.itd.service.client.ServiceClient;
import com.bdo.itd.service.client.ServiceClientImpl;
import com.bdo.itd.service.client.model.ServiceDefinition;
import com.bdo.itd.service.client.model.ServiceDefinitionFactory;
import com.bdo.itd.util.crypt.Hmac;
import com.bdo.itd.util.crypt.HmacType;
import com.bdo.util.rest.http.client.ProtocolType;
import com.bdo.util.rest.http.client.RestClient;
import com.bdo.util.rest.http.client.RestClientFactory;

@Configuration
@ComponentScan({"com.bdo.itd.projects.bdocors"})
@EntityScan({"com.bdo.itd.projects.bdocors.inboundinterface.domain"})
@EnableJpaRepositories({"com.bdo.itd.projects.bdocors.inboundinterface.infrastructure.repository"})
public class ApplicationConfig {
	
	/**
	 * 
	 */
	@Value("${itdservices.rest-client.protocol-type}")
	private ProtocolType protocolType;
	
	/**
	 * 
	 */
	@Value("${itdservices.hmac.type}")
	private HmacType hmacType;
	
	/**
	 * 
	 */
	@Value("${itdservices.load-service.secret-key}")
	private String loadServiceSecretKey;
	
	/**
	 * 
	 */
	@Value("${itdservices.load-service.service-definition}")
	private Resource loadServiceDefinition;
	
	/**
	 * 
	 */
	@Value("${itdservices.load-service.service-definition-property}")
	private Resource loadServiceDefinitionProperty;
	
	/**
	 * @return
	 */
	@Bean
	public IServiceCommunicator loadServiceCommunicator() throws IOException {
		RestClient restClient = RestClientFactory.createClient(protocolType);
		Hmac serviceHmac = Hmac.createInstance(hmacType, loadServiceSecretKey);
		ServiceDefinition serviceDefinition = ServiceDefinitionFactory.createInstance(loadServiceDefinition.getFile(), 
				loadServiceDefinitionProperty.getFile());
		
		ServiceClient serviceClient = new ServiceClientImpl(restClient, serviceHmac, serviceDefinition);
		
		return new ITDServiceCommunicator(serviceClient);
	}
	
}
