/**
 * 
 */
'use strict'

define([], function () {
    angular.element(function() {
          angular.bootstrap(document, ['core']);
        });
});

