/**
 * 
 */
'use strict';
define(function(){
	var orderModule = angular.module('orderModule', ['ngTable', 'ui.bootstrap', 'ngAlertify', 'utilitiesModule']);
	console.log('orderModule');
	
	orderModule.config(['$controllerProvider', function ($controllerProvider) {
    	console.log('orderModule.config');
		// Module Registration
		orderModule.register = {
				controller : $controllerProvider.register
		};
    }]);
	
	
	orderModule.run(['DataAccessService', '$rootScope', function(dataAccessService, $rootScope){
		// MyDashBoard
		var url = 'app/config/myDashBoard.json';
		dataAccessService.doGetData(url, null, function(response){
			console.log(response);
			$rootScope.myDashBoard =  response.data.myDashBoard;
		}, function(errorResponse){
			alert(response);
			$scope.close();
		});	
    }])
	
});