/**
 * 
 */
'use strict';
define(function(){
	var adminModules = angular.module('adminModules');
	console.log('Loading individualProfileFormController');
	
	adminModules.register.controller('companyProfileFormController', ['$rootScope', '$scope', 
		'$http', 'DataAccessService',  'alertify', '$location',
		function ($rootScope, $scope, $http, dataAccessService, alertify, $location){
    	console.log('adminModules.controller');
    	var vm = this;
    	
    	vm.init = function(){
    		console.log('companyProfileFormController.init()');
    		
    		$scope.formTitle = 'Profile';
    		
    		$scope.form = {};
    		
    		vm.loadForm();
    		$scope.reference = {};
    		vm.getCountryReferenceList();
    		vm.getRegionReferenceList();
    		vm.getStatusReferenceList();
    		vm.getSupplierReferenceList();
    	};
    	
    	vm.getCountryReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllCountryQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('QueryModel');
    			console.log(response);
    			$scope.reference.countryList = response.data.resultSet;
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	};
    	
    	vm.getRegionReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllRegionQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('findAllRegionQueryModel');
    			console.log(response);
    			$scope.reference.regionList = response.data.resultSet;
    		}, function(errorResponse){
    			console.log(errorResponse);
			});
    	};
    	
    	vm.getSupplierReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllSupplierReferencesQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('QueryModel');
    			console.log(response);
    			$scope.reference.supplierList = response.data.resultSet;
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	};
    	
    	vm.getStatusReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllUserStatusQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('Status');
    			console.log(response);
    			$scope.reference.statusList =  response.data.resultSet;
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	}
    	
    	
    	vm.loadForm = function(){
    		var data = {'id' : $rootScope.session['AUTHENTICATED_USER'].userID};
    		
    		var queryCode = "findClientByIDQueryModel";
    		var url = "query/"+queryCode;
    		console.log(data);
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('QueryModel');
    			console.log(response);
    			$scope.form = response.data.resultSet[0];
    		}, function(errorResponse){
    			console.log(errorResponse);
			});
    		
    	};
    	
       	vm.validate = function(){
    		var isValid = true;
    		var errorMessage = 'Please provide the necessary required fields in order to proceed:<br />';
    		
    		if(!$scope.form.username){
    			isValid = false;
    			errorMessage = errorMessage+'Username <br />';
    		}
    		if(!$scope.form.firstname){
    			isValid = false;
    			errorMessage = errorMessage+'Firstname <br />';
    		}
    		if(!$scope.form.lastname){
    			isValid = false;
    			errorMessage = errorMessage+'Lastname <br />';
    		}
    		if(!$scope.form.email){
    			isValid = false;
    			errorMessage = errorMessage+'Email <br />';
    		}
    		if(!$scope.form.contactNumber){
    			isValid = false;
    			errorMessage = errorMessage+'Contact Number <br />';
    		}
    		if(!$scope.form.supplier || $scope.form.supplier.length === 0 ){
    			console.log($scope.form.supplier);
    			isValid = false;
    			errorMessage = errorMessage+'Company Name </br>';
			}else{
				angular.forEach($scope.form.supplier, function(value, key){
					if(!value){
						isValid = false;
	        			errorMessage = errorMessage+key+' </br>';
					}
				});
			}
    		
    		if($scope.form.sameAddress === false){
	    		if(!$scope.form.addressLine){
	    			isValid = false;
	    			errorMessage = errorMessage+'(Billing) Address Line <br />';
	    		}
	    		if(!$scope.form.region){
	    			isValid = false;
	    			errorMessage = errorMessage+'(Billing) Region <br />';
	    		}
	    		if(!$scope.form.city){
	    			isValid = false;
	    			errorMessage = errorMessage+'(Billing) City <br />';
	    		}
	    		if(!$scope.form.postal){
	    			isValid = false;
	    			errorMessage = errorMessage+'(Billing) Postal <br />';
	    		}
	    		if(!$scope.form.country || $scope.form.country.length === 0 ){
	    			console.log($scope.form.country);
	    			isValid = false;
	    			errorMessage = errorMessage+'(Billing) Country <br />';
				}else{
					angular.forEach($scope.form.country, function(value, key){
						if(!value){
							isValid = false;
		        			errorMessage = errorMessage+key+' <br />';
						}
					});
				}
	    		
    		}
    		
    		if(!$scope.form.addressLine2){
    			isValid = false;
    			errorMessage = errorMessage+'(Shipping) Address Line <br />';
    		}
    		if(!$scope.form.region2){
    			isValid = false;
    			errorMessage = errorMessage+'(Shipping) Region <br />';
    		}
    		if(!$scope.form.city2){
    			isValid = false;
    			errorMessage = errorMessage+'(Shipping) City <br />';
    		}
    		if(!$scope.form.postal2){
    			isValid = false;
    			errorMessage = errorMessage+'(Shipping) Postal <br />';
    		}
    		if(!$scope.form.country2 || $scope.form.country2.length === 0 ){
    			console.log($scope.form.country2);
    			isValid = false;
    			errorMessage = errorMessage+'(Shipping) Country <br />';
			}else{
				angular.forEach($scope.form.country2, function(value, key){
					if(!value){
						isValid = false;
	        			errorMessage = errorMessage+key+' <br />';
					}
				});
			}
    		
    		
    		if(isValid == false){
    			alertify.alert(errorMessage);
    			return false;
    		}
    		// Valid
    		return true;
    	};
    	
    	
    	vm.init();
    	
    	
		$scope.update = function(){
			
				if(!vm.validate()){
	    			return false;
	    		}
	    		
	    		var answer = confirm('This action will update your account profile. Are you sure'+
	    				' you want to proceed?');
	    		
	    		if(answer){
	    			$scope.form.lastModifiedBy = "ADMINISTRATOR";
	        		
	        		var data = $scope.form;
	        		console.log(data);
	        		
	        		var commandCode = "updateClientCommandHandler";
	        		var url = "command/"+commandCode;
	        		
	        		dataAccessService.doPostData(url, data, function(response){
	        			console.log(response);
	        			alertify.alert('Your account has been successfully updated!');
	        		}, function(errorResponse){
	        			console.log(errorResponse);
	        			alertify.alert(errorResponse	);
	    			});
	    		}
	    	};
	    	
	    	$scope.changepass = function(){
	    		$location.path('/private/client/profile/changepass');
	    	};
	    	
	    	$scope.companyOnChange = function(){
	    		var data = {'id' : $scope.form.supplier};
	    		var queryCode = "findSupplierByIDReferencesQueryModel";
	    		var url = "query/"+queryCode;
	    		
	    		dataAccessService.doPostData(url, data, function(response){
	    			console.log('QueryModel');
	    			console.log(response);
	    			$scope.form.businessStyle = response.data.resultSet[0].businessStyle;
	    			$scope.form.companyTin = response.data.resultSet[0].companyTin;
	    		}, function(errorResponse){
					console.log(errorResponse);
				});
	    		
	    	}
    	
	}]);
	
});