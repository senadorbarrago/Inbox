/**
 * 
 */
'use strict'
define(function(){
	var orderModule = angular.module('orderModule');
	console.log('Loading homeController');
	
	orderModule.register.controller('cartController', ['$rootScope', '$scope', '$location', 'DataAccessService',  'alertify',
		function ($rootScope, $scope, $location, dataAccessService, alertify){
    	console.log('Registering cartController...');
    	
    	var vm = this;
    	
    	vm.init = function(){
    		// Redirect to Buyer Registration Page when not authenticated
    		if(!$rootScope.session['AUTHENTICATED'] || $rootScope.session['AUTHENTICATED'] === false){
    			alertify.alert('Please register first in order to start shopping in Hotel Depot. Thank You!');
    			$location.path('/public/client/individualSignup');
    		}
    		
    		$scope.cart = {};
    		$scope.cart.items = [];
    		
    		vm.loadCart();
    	}
    	
    	vm.loadCart = function(){
    		var data = {};
    		var queryCode = "findCartByUserIDQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('Cart');
    			console.log(response);    			
    			$scope.cart.items = response.data.resultSet;
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	}
    	
    	// Initialize
    	vm.init();
    	
    	$scope.addCartItemQuantity = function(item){
	  		  if(item.quantity < item.noOfStock){
	  			  if(item.quantity + item.quantityPerPack <= item.noOfStock){
	  				item.quantity = item.quantity + item.quantityPerPack;
	  			  }else{
	  				  alertify.alert("Cart items will exceeded the number of stock available!");
	  			  }
	  		  }else{
	  			  alertify.alert("Cart items will exceed the number of stock available!");
	  		  }
  	  	}
  	  
	  	$scope.subtractCartItemQuantity = function(item){
	  		  if(item.quantity > 0){
	  			console.log('TEXT 3');
	  			console.log(item.quantity);
	  			console.log(item.quantityPerPack);
	  			console.log(item.minimumOrder);
	  			console.log(item.quantity - item.quantityPerPack > 0);
	  			console.log(item.quantity - item.quantityPerPack >= item.minimumOrder);
	  			if(item.quantity - item.quantityPerPack > 0 && 
	  					item.quantity - item.quantityPerPack >= item.minimumOrder){
	  				item.quantity = item.quantity - item.quantityPerPack;
	  		  	}else{
	  		  		alertify.alert("Cart items with quantity less than the minimum order are not allowed!");
	  		  	}
	  		  }else{
	  			alertify.alert("Cart items with quantity less than the minimum order are not allowed!");
	  		  }
	  	}
    	
	  	$scope.updateCartItemQuantity = function(itemID, quantity){
    		console.log(itemID);
    		console.log(quantity);
    		
    		var data = {
    					'itemID'   : itemID,
    					'quantity' : quantity
    					};
    		
    		var commandCode = "updateItemQuantityCommandHandler";
    		var url = "command/"+commandCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log(response);
    			$rootScope.loadCartItemsCount();
    			vm.init();
    		}, function(errorResponse){
				alert(errorResponse);
			});
    	}
	  	  
	  	  
    	$scope.removeItemFromCart = function(itemID){
    		console.log(itemID);
    		var data = {
    					'itemID' : itemID
    					};
    		
    		var commandCode = "removeItemFromCartCommandHandler";
    		var url = "command/"+commandCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log(response);
    			$rootScope.loadCartItemsCount();
    			vm.init();
    		}, function(errorResponse){
				alert(errorResponse);
			});
    	}
    	
    	$scope.computeSubTotal = function(sellingPrice, discountedPrice, itemQuantity){
    		var total = 0;
    		if(discountedPrice && discountedPrice > 0.00){
    			total = discountedPrice * itemQuantity;
    		}else{
    			total = sellingPrice * itemQuantity;
    		}
    		return total;
    	}
    	
    	$scope.computeTotal = function(){
    		var total = 0;
    		if($scope.cart && $scope.cart.items){
    			angular.forEach($scope.cart.items, function(value, key){
    				if(value.discountedPrice && value.discountedPrice > 0.00){
    	    			total = total + (value.discountedPrice * value.quantity);
    	    		}else{
    	    			total = total + (value.sellingPrice * value.quantity);
    	    		}
				});
    		}
    		
    		return total;
    	}
    	
    	$scope.validatePreCheckOut = function(){
    		console.log('validatePreCheckOut');
    		
    		var data = {};
    		var queryCode = "findClientDetailsCompletenessQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('findClientDetailsCompletenessQueryModel');
    			console.log(response);    			
    			
    			var isCompleteDetails = response.data.resultSet[0].isCompleteDetails;
    			if(isCompleteDetails === true){
    				$location.path('/private/order/checkout');
    			}else{
    				alertify.alert('Please complete your details in order to proceed on your checkout');
    				$location.path('/private/client/profile').search({'src': 'checkout'});;
    			}
    			
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	}
    	
	}]);
	
});