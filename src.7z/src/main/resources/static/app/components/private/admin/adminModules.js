/**
 * 
 */
'use strict';
define(function(){
	var adminModules = angular.module('adminModules', ['ngTable', 'ui.bootstrap', 'ngAlertify', 'utilitiesModule']);
	console.log('adminModules');
	adminModules.x = 'HI';
    adminModules.config(['$controllerProvider',  
    	function ($controllerProvider) {
    		console.log('adminModules.config');
    		// Module Registration
    		adminModules.register = {
    				controller : $controllerProvider.register
    		};
    }]);  
    
    adminModules.run(['DataAccessService', '$rootScope', function(dataAccessService, $rootScope){
    	// MyDashBoard
		var url = 'app/config/myDashBoard.json';
		dataAccessService.doGetData(url, null, function(response){
			console.log(response);
			$rootScope.myDashBoard =  response.data.myDashBoard;
		}, function(errorResponse){
			console.log(errorResponse);
		});
		
    }])
});