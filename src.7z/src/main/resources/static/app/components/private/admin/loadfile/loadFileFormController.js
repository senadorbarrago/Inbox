/**
 * 
 */
'use strict';
define(function(){
	var adminModules = angular.module('adminModules');
	
	adminModules.register.controller('loadFileFormController', ['$rootScope', '$scope', 'ngTableParams', 
		'$uibModal', '$http', 'DataAccessService', 'alertify', function ($rootScope, $scope, ngTableParams, $uibModal, 
				$http, dataAccessService, alertify){
    	console.log('adminModules.controller');
    	var vm = this;
    	
    	vm.init = function(){
    		console.log('loadFileFormController.init()');
    		$rootScope.title = 'File Upload';
    		
    		$scope.form = {};   
    	};
    	
    	vm.init();
    	
    	$scope.selectFile = function (element) {
    		var files = element.files;
			for (var i = 0; i < files.length; i++) {
				$scope.form.filename = files[i].name;
				$scope.form.file = files[i];
			}
			$scope.$apply();
    	};
    	
    	$scope.uploadFile = function () {
    		
    		alertify.confirm('This action uploads the selected file ' + $scope.form.filename + 
    				'. Are you sure you want to proceed?', function(e){
    			if(e){
    				console.log('sending file...');
            		
            		var fd = new FormData();
            		fd.append('file', $scope.form.file);
    		        fd.append('loadedBy', $rootScope.session['AUTHENTICATED_USER'].username);
            
            		$rootScope.showSpinner = true;
                    
            		var url = "command/loadFileCommandHandler";
            		dataAccessService.doPostFileData(url, fd, function(response){
            			console.log(response);
            			alertify.alert("The selected file has been successfully loaded. " +
            					"Please see the proof list report for " +
            						"more details.");
            		}, function(errorResponse){
        				alertify.alert(errorResponse.data.message);
        			});
    			}
    		});
    		
    	};
    	
	}]);
	
});