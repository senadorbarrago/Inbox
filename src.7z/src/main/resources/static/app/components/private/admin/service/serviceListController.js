/**
 * 
 */
'use strict';
define(function(){
	var adminModules = angular.module('adminModules');
	console.log('Loading serviceListController');
	
	adminModules.register.controller('serviceListController', [
		'$rootScope', 
		'$scope', 
		'ngTableParams', 
		'$http', 
		'DataAccessService', 
		'$location',
		'alertify',
		function ($rootScope, $scope, ngTableParams, $http, dataAccessService, $location, alertify){
    	console.log('adminModules.controller');
    	var vm = this;
    	
    	vm.init = function(){
    		$rootScope.title = 'Services';
    		
    		$scope.form = {};
    		$scope.form.reference = {};
    		$scope.searchCriteria = {};
    		$scope.searchCriteria.showDeleted = false;
    		
    		vm.getSupplierReferenceList();		
    		vm.getStatusReferenceList();
    		vm.getProductList(); 
    		
    	};
    	
    	vm.getProductList = function(){
    		$scope.tableParams = new ngTableParams({
                page: 1,
                count: 2
            }, {
                getData: function ($defer, params) {
                	var queryCode = "productListQueryModel";
                	var url = "query/"+queryCode;

                	var data = {
                				'pageIndex' : params.page(),
        						'pageSize': params.count(),
        						'searchCriteria': $scope.searchCriteria,
        						'primaryCategory' : 'SERVICES'
        			   	   	   };
                	
                	console.log(data);

                	return dataAccessService.doPostData(url, data, function(response){
			        			console.log('productPage');
			        			console.log(response);
			        			$scope.form.resultSet = response.data.resultSet;
			        			$scope.form.columns = response.data.columns;
			        			
			        			params.total(response.data.resultOverAllCount);
			        			$defer.resolve($scope.form.resultSet);
			        		}, function(errorResponse){
			    				console.log(errorResponse);
			    			});
                }
            });
    	};
    	
    	vm.getSupplierReferenceList = function(){
    		var data = {}
    		var queryCode = "findAllSupplierReferencesQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('QueryModel');
    			console.log(response);
    			$scope.form.reference.supplierList = response.data.resultSet;
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	};
    	
    	vm.getCategoryReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllCategoryQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('QueryModel');
    			console.log(response);
    			$scope.form.reference.categoryList = response.data.resultSet;
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	};
    	
    	vm.getStatusReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllProductStatusQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('Status');
    			console.log(response);
    			$scope.form.reference.statusList =  response.data.resultSet;
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	}
    	
    	vm.init();
    	
    	$scope.search = function(){
    		$scope.tableParams.reload();
    	}
    	
    	$scope.showAll = function(){
    		$scope.searchCriteria = {};
    		$scope.searchCriteria.showDeleted = false;
    		$scope.tableParams.reload();
    	}
    	
    	$scope.viewRecord = function (id) {
    		$location.path('/private/admin/service/form/'+id);
    	};
    	
    	$scope.add = function(){
    		$location.path('/private/admin/service/form/0');
    	}
    	
    	$scope.delete = function(id){
    		var answer = confirm('This action will delete the selected item. Are you sure'+
    					'you want to proceed?');
    		if(answer){
        		var data = {'id' : id};
        		
        		var commandCode = "deleteProductCommandHandler";
        		var url = "command/"+commandCode;
        		
        		dataAccessService.doPostData(url, data, function(response){
        			console.log(response);
        			alertify.alert(response.data.messageMap['SUCCESS_MESSAGE']);
        			$scope.tableParams.reload();
        		}, function(errorResponse){
        			console.log(errorResponse);
        			alertify.alert(errorResponse.data.message);
    			});
    		}
    	};
    	
    	$scope.restore = function(id){
    		var answer = confirm('This action will restore the selected item. Are you sure'+
    					'you want to proceed?');
    		if(answer){
        		var data = {'id' : id};
        		
        		var commandCode = "restoreProductCommandHandler";
        		var url = "command/"+commandCode;
        		
        		dataAccessService.doPostData(url, data, function(response){
        			console.log(response);
        			alertify.alert(response.data.messageMap['SUCCESS_MESSAGE']);
        			$scope.tableParams.reload();
        		}, function(errorResponse){
    				console.log(errorResponse);
    				alertify.alert(errorResponse.data.message);
    			});
    		}
    	};
    	
    	
	}]);
	
	
});