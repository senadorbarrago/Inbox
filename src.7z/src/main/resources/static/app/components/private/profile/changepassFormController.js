/**
 * 
 */
'use strict';
define(function(){
	var adminModules = angular.module('adminModules');
	console.log('Loading changepassFormController');
	
	adminModules.register.controller('changepassFormController', ['$rootScope', '$scope', 
		'$http', 'DataAccessService',  'alertify', '$location',
		function ($rootScope, $scope, $http, dataAccessService, alertify, $location){
    	console.log('adminModules.controller');
    	var vm = this;
    	
    	vm.init = function(){
    		console.log('changepassFormController.init()');
    		
    		$scope.formTitle = 'Profile';
    		
    		$scope.form = {};
    		$scope.form.username = $rootScope.session['AUTHENTICATED_USER'].username;
    		
    		
    	};
    	
       	vm.validate = function(){
    		var isValid = true;
    		var errorMessage = 'Please provide the necessary required fields in order to proceed:\n';
    		
    		if(!$scope.form.oldPassword){
    			isValid = false;
    			errorMessage = errorMessage+'Old Password \n';
    		}
    		if(!$scope.form.password){
    			isValid = false;
    			errorMessage = errorMessage+'New Password \n';
    		}
    		if(!$scope.form.confirmPassword){
    			isValid = false;
    			errorMessage = errorMessage+'Confirm Password \n';
    		}
    		if($scope.form.password != $scope.form.confirmPassword){
    			isValid = false;
    			errorMessage = errorMessage+'Password not equal to Confirm Password \n';
    		}
    		
    		if(isValid == false){
    			alertify.alert(errorMessage);
    			return false;
    		}
    		// Valid
    		return true;
    	};
    	
    	
    	vm.init();
    	
    	
		$scope.update = function(){
			
				if(!vm.validate()){
	    			return false;
	    		}
	    		
	    		var answer = confirm('This action will update your account password. Are you sure'+
	    				' you want to proceed?');
	    		
	    		if(answer){
	    			$scope.form.lastModifiedBy = "ADMINISTRATOR";
	        		
	        		var data = $scope.form;
	        		console.log(data);
	        		
	        		var commandCode = "updatePasswordCommandHandler";
	        		var url = "command/"+commandCode;
	        		
	        		dataAccessService.doPostData(url, data, function(response){
	        			console.log(response);
	        			alertify.alert('Your password has been successfully updated');
	        			$location.path('/private/client/profile');
	        		}, function(errorResponse){
	        			console.log(errorResponse);
	    				alertify.alert(errorResponse.data.message);
	    			});
	    		}
	    	};
    	
    	
	}]);
	
});