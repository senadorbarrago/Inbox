/**
 * 
 */
'use strict';
define(function(){
	var orderModule = angular.module('orderModule');
	console.log('Loading askForQuotationFormController');
	
	orderModule.register.controller('askForQuotationFormController', ['$rootScope', '$scope', '$location', '$uibModalInstance', 
		'$http', 'DataAccessService',  'alertify', 'params',
		function ($rootScope, $scope, $location, $uibModalInstance, $http, dataAccessService, alertify, params){
    	console.log('askForQuotationFormController.controller');
    	var vm = this;
    	
    	vm.init = function(){
    		console.log('askForQuotationFormController.init()');
    		console.log(params);
    		
    		$scope.formTitle = 'Contact Seller';
    		$scope.form = {};
    		
    		if(params){
    			$scope.form.productID     = params.id;
    			$scope.form.productCode   = params.productCode;
    			$scope.form.productName   = params.productName;
    			$scope.form.quoteQuantity = params.moq;
    			$scope.form.quotePrice 	  = params.sellingPrice;
    			$scope.form.supplierID    = params.supplierID;
    		}
    		
    		console.log("$scope.form");
    		console.log($scope.form);
    	};    	
    	
    	vm.init();
    	
    	$scope.send = function(){
    		
    		if(!$scope.form.quoteQuantity){
    			alertify.alert("Please enter your quoted quantity");
    			return false;
    		}
    		
    		if(!$scope.form.quotePrice){
    			alertify.alert("Please enter your budget");
    			return false;
    		}
    		
    		var answer = confirm('This action will send an email request for quotation '+ 
    				'for the selected product. Are you sure you want to proceed?');
    		if(answer){
    			$scope.form.createdBy = $rootScope.session['AUTHENTICATED_USER'].username;
        		
        		
        		var data = $scope.form;
        		
        		data.contextPath =  $location.absUrl().substr(0, $location.absUrl().lastIndexOf("#"));
        		
        		console.log(data);
        		
        		var commandCode = "askForQuotationCommandHandler";
        		var url = "command/"+commandCode;
        		
        		dataAccessService.doPostData(url, data, function(response){
        			console.log(response);
        			alertify.alert(response.data.messageMap['SUCCESS_MESSAGE']);
        			$uibModalInstance.close();
        		}, function(errorResponse){
    				console.log(response);
    			});
    		}
    	};
    	
    	$scope.close = function(){
    		console.log('Close');
    		$uibModalInstance.close();
    	}
    	
    	
	}]);
	
});