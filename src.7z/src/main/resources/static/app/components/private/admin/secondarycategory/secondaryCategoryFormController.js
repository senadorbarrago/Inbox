/**
 * 
 */
'use strict';
define(function(){
	var adminModules = angular.module('adminModules');
	console.log('Loading secondaryCategoryFormController');
	
	adminModules.register.controller('secondaryCategoryFormController', [
		'$rootScope', 
		'$scope',
		'$location', 
		'DataAccessService', 
		'$routeParams',
		'alertify',
		function ($rootScope, $scope, $location, dataAccessService, $routeParams, alertify){
    	console.log('adminModules.controller');
    	var vm = this;
    	
    	vm.init = function(){
    		console.log('secondaryCategoryFormController.init()');
    		console.log($routeParams);
    		
    		$scope.formTitle = 'Secondary Category Form';
    		$scope.form = {};
    		
    		if($routeParams.id && $routeParams.id > 0){
    			vm.loadForm($routeParams.id);
    			console.log($routeParams.id);
    		}
    		
    		$scope.reference = {};
    		
    		vm.getPrimaryCategoryReferenceList();
    	};
    	
    	vm.loadForm = function(id){
    		var data = {'id' : id};
    		var queryCode = "findSecondaryCategoryByIDQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('QueryModel');
    			console.log(response);
    			$scope.form = response.data.resultSet[0];
    		}, function(errorResponse){
				console.log(errorResponse);
				alertify.alert(errorResponse.data.message);
			});
    		
    	};
    	
    	vm.getPrimaryCategoryReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllPrimaryCategoryQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('QueryModel');
    			console.log(response);
    			$scope.reference.primaryCategoryList = response.data.resultSet;
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	};
    	
    	vm.init();
    	
    	$scope.save = function(){
    		if(!$scope.form.code){
    			alertify.alert("Please enter the code");
    			return false;
    		}
    		if(!$scope.form.description){
    			alertify.alert("Please enter the description");
    			return false;
    		}
    		if(!$scope.form.primaryCategory){
    			alertify.alert("Please enter the Primary Category");
    			return false;
    		}
    		
    		var answer = confirm('This action will save the newly created item. Are you sure'+
    				'you want to proceed?');
    		
    		if(answer){
        		var data = $scope.form;
        		
        		var commandCode = "addSecondaryCategoryCommandHandler";
        		var url = "command/"+commandCode;
        		
        		dataAccessService.doPostData(url, data, function(response){
        			console.log(response);
        			alertify.alert(response.data.messageMap['SUCCESS_MESSAGE']);
        			$location.path('/private/admin/secondaryCategory/list');
        		}, function(errorResponse){
    				console.log(errorResponse);
    				alertify.alert(errorResponse.data.message);
    			});
    		}
    	};
    	
    	$scope.update = function(){
    		if(!$scope.form.code){
    			alertify.alert("Please enter the code");
    			return false;
    		}
    		if(!$scope.form.description){
    			alertify.alert("Please enter the description");
    			return false;
    		}
    		if(!$scope.form.primaryCategory){
    			alertify.alert("Please enter the Primary Category");
    			return false;
    		}
    		
    		var answer = confirm('This action will update the selected item. Are you sure'+
    				'you want to proceed?');
    		
    		if(answer){
        		var data = $scope.form;
        		
        		var commandCode = "updateSecondaryCategoryCommandHandler";
        		var url = "command/"+commandCode;
        		
        		dataAccessService.doPostData(url, data, function(response){
        			console.log(response);
        			alertify.alert(response.data.messageMap['SUCCESS_MESSAGE']);
        			$location.path('/private/admin/secondaryCategory/list');
        		}, function(errorResponse){
    				console.log(errorResponse);
    				alertify.alert(errorResponse.data.message);
    			});
    		}
    	};
    	
	}]);
	
});