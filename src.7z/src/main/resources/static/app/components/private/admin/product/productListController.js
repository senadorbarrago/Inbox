/**
 * 
 */
'use strict';
define(function(){
	var adminModules = angular.module('adminModules');
	console.log('Loading productListController');
	
	adminModules.register.controller('productListController', [
		'$rootScope', 
		'$scope', 
		'ngTableParams', 
		'$http', 
		'DataAccessService', 
		'$location',
		'alertify',
		function ($rootScope, $scope, ngTableParams, $http, dataAccessService, $location, alertify){
    	console.log('adminModules.controller');
    	var vm = this;
    	
    	vm.init = function(){
    		$rootScope.title = 'Product';
    		
    		$scope.form = {};
    		$scope.form.reference = {};
    		$scope.searchCriteria = {};
    		$scope.searchCriteria.showDeleted = false;
    		vm.getSupplierReferenceList();		
    		vm.getProductList();   
    		vm.getCategoryReferenceList();
    		vm.getBrandReferenceList();
    		vm.getStatusReferenceList();
    	};
    	
    	vm.getProductList = function(){
    		$scope.tableParams = new ngTableParams({
                page: 1,
                count: 10
            }, {
                getData: function ($defer, params) {
                	var queryCode = "productListQueryModel";
                	var url = "query/"+queryCode;
                	console.log('params.count(): '+ params.count());
                	console.log('params.page(): '+ params.page());
                	//params.count(1);
                	//params.page(2);
                	
                	var data = {'pageIndex' : params.page(),
        						'pageSize': params.count(),
        						'searchCriteria': $scope.searchCriteria,
        						'primaryCategory' : 'PRODUCTS'
        			   	   	   };
                	
                	console.log(data);

                	return dataAccessService.doPostData(url, data, function(response){
			        			console.log('productPage');
			        			console.log(response);
			        			$scope.form.resultSet = response.data.resultSet;
			        			$scope.form.columns = response.data.columns;
			        			
			        			params.total(response.data.resultOverAllCount);
			        			$defer.resolve($scope.form.resultSet);
			        		}, function(errorResponse){
			    				console.log(errorResponse);
			    			});
                	
                }
            });
    	};
    	
    	vm.getSupplierReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllSupplierReferencesQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('QueryModel');
    			console.log(response);
    			$scope.form.reference.supplierList = response.data.resultSet;
    		}, function(errorResponse){
				console.log(errorResponse);
				
			});
    	};
    	
    	vm.getCategoryReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllCategoryQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('QueryModel');
    			console.log(response);
    			$scope.form.reference.categoryList = response.data.resultSet;
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	};
    	
    	vm.getBrandReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllBrandQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('QueryModel');
    			console.log(response);
    			$scope.form.reference.brandList = response.data.resultSet;
    		}, function(errorResponse){
    			console.log(errorResponse);
			});
    	};
    	
    	$scope.getBrandBySupplierReferenceList = function(){
    		var data = {'supplierID': $scope.searchCriteria.supplierID};
    		var queryCode = "findAllBrandsBySupplierIDQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('QueryModel');
    			console.log(response);
    			$scope.form.reference.brandList = response.data.resultSet;
    		}, function(errorResponse){
    			console.log(errorResponse);
			});
    	};
    	
    	vm.getStatusReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllProductStatusQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('Status');
    			console.log(response);
    			$scope.form.reference.statusList =  response.data.resultSet;
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	}
    	
    	vm.testQuery = function(){
    		var data = {};
    		
    		var queryCode = "findAllBrandQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log(response);
    		}, function(errorResponse){
    			console.log(errorResponse);				
			});
    	}
    	
    	vm.init();
    	
    	$scope.search = function(){
    		$scope.tableParams.reload();
    	}
    	
    	$scope.showAll = function(){
    		$scope.searchCriteria = {};
    		$scope.searchCriteria.showDeleted = false;
    		$scope.tableParams.reload();
    	}
    	
    	$scope.viewRecord = function (id) {
    		$location.path('/private/admin/product/form/'+id);
    	};
    	
    	$scope.add = function(){
    		$location.path('/private/admin/product/form/0');
    	}
    	
    	$scope.delete = function(id){
    		var answer = confirm('This action will delete the selected item. Are you sure'+
    					'you want to proceed?');
    		if(answer){
        		var data = {'id' : id};
        		
        		var commandCode = "deleteProductCommandHandler";
        		var url = "command/"+commandCode;
        		
        		dataAccessService.doPostData(url, data, function(response){
        			console.log(response);
        			alertify.alert(response.data.messageMap['SUCCESS_MESSAGE']);
        			$scope.tableParams.reload();
        		}, function(errorResponse){
        			console.log(errorResponse);
        			alertify.alert(errorResponse.data.message);
    			});
    		}
    	};
    	
    	$scope.restore = function(id){
    		var answer = confirm('This action will restore the selected item. Are you sure'+
    					'you want to proceed?');
    		if(answer){
        		var data = {'id' : id};
        		
        		var commandCode = "restoreProductCommandHandler";
        		var url = "command/"+commandCode;
        		
        		dataAccessService.doPostData(url, data, function(response){
        			console.log(response);
        			alertify.alert(response.data.messageMap['SUCCESS_MESSAGE']);
        			$scope.tableParams.reload();
        		}, function(errorResponse){
    				console.log(errorResponse);
    				alertify.alert(errorResponse.data.message);
    			});
    		}
    	};
    	
    	/**
    	 * 
    	 */
    	$scope.toggleAll = function(){
    		let selectionState = $scope.form.selectAll;    	
    		console.log(selectionState);
    		angular.forEach($scope.form.resultSet, function(record){
    			record.selected = selectionState; 
    		});
    	}
    	
    	/**
    	 * 
    	 */
    	$scope.toggleSelected = function(){
    		$scope.form.selectAll = true;    	
    		
    		angular.forEach($scope.form.resultSet, function(record){
	    			if(record.selected === false){
	    				$scope.form.selectAll = false;
	    		
	    			}
    		});
    	}
    	
    	/**
    	 * 
    	 */
    	$scope.softDelete = function(){
    		let idList = [];
    		
    		angular.forEach($scope.form.resultSet, function(record){
    			if(record.selected === true && record['Deleted'] === false){
    				idList.push(record.productID);
    			} 
    		});
    		
    		if(idList.length === 0){
    			alertify.alert('Please select atleast 1 undeleted record in order to proceed.');
    			return false;
    		};
    		
    		let data = {'idList' : idList}
    		console.log(data);
    		
    		var answer = confirm('This action will delete the selected products. Are you sure'+
    				'you want to proceed?');
    		if(answer){	
        		var commandCode = "batchDeleteProductCommandHandler";
        		var url = "command/"+commandCode;
        		
        		dataAccessService.doPostData(url, data, function(response){
        			console.log(response);
        			alertify.alert(response.data.messageMap['SUCCESS_MESSAGE']);
        			$scope.tableParams.reload();
        		}, function(errorResponse){
    				alertify.alert(errorResponse.data.message);
    			});
    		};
    	}
    	
    	/**
    	 * 
    	 */
    	$scope.restoreDeleted = function(){
    		let idList = [];
    		
    		angular.forEach($scope.form.resultSet, function(record){
    			if(record.selected === true && record['Deleted'] === true){
    				idList.push(record.productID);
    			} 
    		});
    		
    		if(idList.length === 0){
    			alertify.alert('Please select atleast 1 deleted record in order to proceed.');
    			return false;
    		};
    		
    		let data = {'idList' : idList}
    		console.log(data);
    		
    		var answer = confirm('This action will restore the selected products. Are you sure'+
    				'you want to proceed?');
    		if(answer){	
        		var commandCode = "batchRestoreProductCommandHandler";
        		var url = "command/"+commandCode;
        		
        		dataAccessService.doPostData(url, data, function(response){
        			console.log(response);
        			alertify.alert(response.data.messageMap['SUCCESS_MESSAGE']);
        			$scope.tableParams.reload();
        		}, function(errorResponse){
    				alertify.alert(errorResponse.data.message);
    			});
    		};
    	}
	}]);
	
});