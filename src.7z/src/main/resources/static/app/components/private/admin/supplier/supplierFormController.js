/**
 * 
 */
'use strict';
define(function(){
	var adminModules = angular.module('adminModules');
	console.log('Loading supplierFormController');
	
	adminModules.register.controller('supplierFormController', 
			[
				'$rootScope', 
				'$scope', 
				'$http', 
				'DataAccessService', 
				'alertify', 
				'$routeParams', 
				'$location', 
		function ($rootScope, $scope, $http, dataAccessService, alertify, $routeParams, $location){
    	console.log('adminModules.controller');
    	var vm = this;
    	
    	vm.init = function(){
    		console.log('supplierFormController.init()');
    		console.log($routeParams);
    		
    		$scope.formTitle = 'Seller';
    		$scope.form = {};
    		$scope.upload = {};
    		$scope.form.sameAddress = false;
    		
    		if($routeParams.supplierID && $routeParams.supplierID > 0){
    			console.log('HERE');
    			vm.loadForm($routeParams.supplierID);
    		}
    		$scope.reference = {};
    		
    		vm.getCountryReferenceList();
    		vm.getRegionReferenceList();
    		vm.getStatusReferenceList();
    	};
    	
    	vm.getCountryReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllSupplierCountryQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('QueryModel');
    			console.log(response);
    			$scope.reference.countryList = response.data.resultSet;
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	};
    	
    	vm.getRegionReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllRegionQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('findAllRegionQueryModel');
    			console.log(response);
    			$scope.reference.regionList = response.data.resultSet;
    		}, function(errorResponse){
    			console.log(errorResponse);
			});
    	};
    	
    	vm.getStatusReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllUserStatusQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('Status');
    			console.log(response);
    			$scope.reference.statusList =  response.data.resultSet;
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	}
    	
    	
    	vm.loadForm = function(id){
    		var data = {'id' : id};
    		var queryCode = "findSupplierByIDQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('QueryModel');
    			console.log(response);
    			$scope.form = response.data.resultSet[0];
    			$scope.form.imageOld = $scope.form.image;
    		}, function(errorResponse){
				alertify.alert(errorResponse);
			});
    		
    		
    	};
    	
    	vm.validate = function(){
    		var isValid = true;
    		var errorMessage = 'Please provide the necessary required fields in order to proceed:</br>';
    		
    		if(!$scope.form.companyName){
    			isValid = false;
    			errorMessage = errorMessage+'Company Name </br>';
    		}
    		if(!$scope.form.email){
    			isValid = false;
    			errorMessage = errorMessage+'Email </br>';
    		}
    
    		if(!$scope.form.contactNumber){
    			isValid = false;
    			errorMessage = errorMessage+'Contact Number </br>';
    		}
    		
    		if(!$scope.form.businessStyle){
    			isValid = false;
    			errorMessage = errorMessage+'Business Style </br>';
    		}
    		
    		if(!$scope.form.companyTin){
    			isValid = false;
    			errorMessage = errorMessage+'Company Tin </br>';
    		}
    		
    		if($scope.form.sameAddress === false){
	    		if(!$scope.form.addressLine){
	    			isValid = false;
	    			errorMessage = errorMessage+'(Billing) Address Line </br>';
	    		}
	    		if(!$scope.form.region){
	    			isValid = false;
	    			errorMessage = errorMessage+'(Billing) Region </br>';
	    		}
	    		if(!$scope.form.city){
	    			isValid = false;
	    			errorMessage = errorMessage+'(Billing) City </br>';
	    		}
	    		if(!$scope.form.postal){
	    			isValid = false;
	    			errorMessage = errorMessage+'(Billing) Postal </br>';
	    		}
	    		if(!$scope.form.country || $scope.form.country.length === 0 ){
	    			console.log($scope.form.country);
	    			isValid = false;
	    			errorMessage = errorMessage+'(Billing) Country </br>';
				}else{
					angular.forEach($scope.form.country, function(value, key){
						if(!value){
							isValid = false;
		        			errorMessage = errorMessage+key+' </br>';
						}
					});
				}
	    		
    		}
    		
    		if(!$scope.form.addressLine2){
    			isValid = false;
    			errorMessage = errorMessage+'(Shipping) Address Line </br>';
    		}
    		if(!$scope.form.region2){
    			isValid = false;
    			errorMessage = errorMessage+'(Shipping) Region </br>';
    		}
    		if(!$scope.form.city2){
    			isValid = false;
    			errorMessage = errorMessage+'(Shipping) City </br>';
    		}
    		if(!$scope.form.postal2){
    			isValid = false;
    			errorMessage = errorMessage+'(Shipping) Postal </br>';
    		}
    		if(!$scope.form.country2 || $scope.form.country2.length === 0 ){
    			console.log($scope.form.country2);
    			isValid = false;
    			errorMessage = errorMessage+'(Shipping) Country </br>';
			}else{
				angular.forEach($scope.form.country2, function(value, key){
					if(!value){
						isValid = false;
	        			errorMessage = errorMessage+key+' </br>';
					}
				});
			}

    		if(isValid == false){
    			alertify.alert(errorMessage);
    			return false;
    		}
    		// Valid
    		return true;
    	};
    	
    	/**
    	 * Upload image and save form
    	 */
    	vm.uploadImageAndSaveForm = function () {    		
    		var fd = new FormData();
    		fd.append('file', $scope.upload.file);
    		fd.append('folder', 'HD-Sellers');
    		
    		let url = 'storage/uploadFile';
    		dataAccessService.doPostFileData(url, fd, function(response){
    			console.log(response);
    			$scope.form.image = response.data.url;
    			vm.saveForm();
    		}, function(errorResponse){
				alertify.alert(errorResponse.data.message);
			});
    	};
    	
    	/**
    	 * Save form
    	 * 
    	 */
    	vm.saveForm = function(){
			var data = $scope.form;
    		var commandCode = "addSupplierCommandHandler";
    		var url = "command/"+commandCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log(response);
    			alertify.alert(response.data.messageMap['SUCCESS_MESSAGE']);
    			$location.path('/private/admin/supplier/list');
    		}, function(errorResponse){
    			vm.deleteUpload();
    			alertify.alert(errorResponse.data.message);
			});
    	};
    	
    	/**
    	 * Delete uploaded image
    	 */
    	vm.deleteUpload = function () {
			if($scope.form.imageOld && $scope.form.image 
				&& $scope.form.imageOld !== $scope.form.image){
        		
				console.log('$scope.form.imageOld: '+$scope.form.imageOld);
				console.log('$scope.form.image: '+$scope.form.image);
				
				if($scope.form.imageOld.includes('place-holder-image-1')){
	        		return false;
	        	}
				
				var fd = new FormData();
        		fd.append('url', $scope.form.imageOld);
        		
        		let url = 'storage/deleteFile';
        		dataAccessService.doPostFileData(url, fd, function(response){
        			console.log(response);
        		}, function(errorResponse){
        			console.log(errorResponse);
    			});
			}
    	};
    	
    	/**
    	 * Update form
    	 */
    	vm.updateForm = function(){
    		var data = $scope.form;    		
            var commandCode = "updateSupplierCommandHandler";
     		
            var url = "command/"+commandCode;
     		dataAccessService.doPostData(url, data, function(response){
     			console.log(response);
     			vm.deleteUpload();
     			alertify.alert(response.data.messageMap['SUCCESS_MESSAGE']);
     			$location.path('/private/admin/supplier/list');
     		}, function(errorResponse){
     			alertify.alert(errorResponse.data.message);
 			});
	
    	};
    	
    	/**
    	 * Upload image and update form
    	 */
    	vm.uploadImageAndUpdateForm = function () {
    		var fd = new FormData();
    		
    		fd.append('file', $scope.upload.file);
    		fd.append('folder', 'HD-Sellers');
    		
    		let url = 'storage/uploadFile';
    		dataAccessService.doPostFileData(url, fd, function(response){
    			console.log(response);
    			$scope.form.image = response.data.url;
    			vm.updateForm();
    		}, function(errorResponse){
				alertify.alert(errorResponse.data.message);
			});
    	};
    	
    	/**
    	 * Initialize form
    	 * 
    	 */
    	vm.init();
    	
    	/**
    	 * Select a file to be uploaded
    	 * 
    	 */
    	$scope.selectFile = function (element) {
    		var files = element.files;
			for (var i = 0; i < files.length; i++) {
				$scope.upload.filename = files[i].name;
				$scope.upload.file = files[i];
			}
			$scope.$apply();
    	};
    	
    	/**
    	 * Save form
    	 */
    	$scope.save = function(){
    		if(!vm.validate()){
    			return false;
    		}
    		
    		alertify.confirm('This action will create a new seller account. Are you sure '+
    				'you want to proceed?', function(e){
    			if(e){
    				if($scope.upload.filename){
    					// Upload image and save form
    					vm.uploadImageAndSaveForm();
    				}else{
    					// Save form
    					vm.saveForm();
    				}
    			}
    		});
    	};
    	
    	/**
    	 * Update form
    	 */
    	$scope.update = function(){
			if(!vm.validate()){
    			return false;
    		}
    		
			alertify.confirm('This action will update the selected seller account. Are you sure'+
    				' you want to proceed?', function(e){
    			if(e){
    				if($scope.upload.filename){
    					// Upload image and update form
    					vm.uploadImageAndUpdateForm();
    				}else{
    					// Update form
    					vm.updateForm();
    				}
    			}
    		});
    	};
    	
	}]);
});