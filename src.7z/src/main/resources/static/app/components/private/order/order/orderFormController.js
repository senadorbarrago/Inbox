/**
 * 
 */
'use strict'
define(function(){
	var orderModule = angular.module('orderModule');
	console.log('Loading homeController');
	
	orderModule.register.controller('orderFormController', ['$rootScope', '$scope', '$location', 'DataAccessService',  'alertify', '$routeParams',
		function ($rootScope, $scope, $location, dataAccessService, alertify, $routeParams){
    	console.log('Registering orderFormController...');    	
    	
    	var vm = this;
    	
    	vm.init = function(){
    		$scope.form = {};
    		$scope.form.id = $routeParams.id; 
    		$scope.reference = {};
    		vm.getOrderForm();
    		vm.getOrderStatus();
    	}
    	
    	vm.getOrderForm = function(){
    		var data = {
    						'id' : $scope.form.id
    					}
    		var queryCode = "findOrderByIDQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('OrderForm');
    			console.log(response);
    			$scope.form =  response.data.resultSet[0];
    		}, function(errorResponse){
    			alertify.alert(errorResponse.data.message);
    			$location.path("/private/order/orderList");
				console.log(errorResponse);
			});
    	}
    	
    	vm.getOrderStatus = function(){
    		var data = {};
    		var queryCode = "findAllOrderStatusQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('OrderItemStatus');
    			console.log(response);
    			$scope.reference.orderStatusList =  response.data.resultSet;
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	}
    	
    	vm.init();
    	
    	$scope.computeTotal = function(){
    		var total = 0;
    		
    		if($scope.form && $scope.form.orderItemList){
    			angular.forEach($scope.form.orderItemList, function(value, key){
    				total = total + ((value['Regular Price'] - (value['Regular Price'] * value['Discount']/100)) * value['Quantity']); 
				});
    		}
    		
    		return total;
    	}
    	
    	$scope.changeOrderStatus = function(){
    		console.log('changeOrderStatus()');
    		alertify.confirm('This action will update the status of this order. Are you sure '+
			'you want to proceed?', 
				function(){
	    			var data = {
							'orderID' 		: $scope.form.id,
							'orderStatus'	: $scope.form.status,
							'contextPath'	: $location.absUrl().substr(0, $location.absUrl().lastIndexOf("#"))
					};
					console.log(data);
					
					var commandCode = "updateOrderStatusCommandHandler";
					var url = "command/"+commandCode;
					
					dataAccessService.doPostData(url, data, function(response){
						console.log(response);
						//vm.checkOverAllStatus();
						vm.getOrderForm();
						alertify.alert(response.data.messageMap['SUCCESS_MESSAGE']);
					}, function(errorResponse){
						console.log(errorResponse);
					});
    			
    			},
    			function(){
    				return false;
    			});
    	}
    	
    	vm.checkOverAllStatus = function(){
    		var status = 'RESOLVED';
    		
    		var keep = true;
    		angular.forEach($scope.form.orderItemList, function(value, key){
    			console.log(value.status);
    			if(keep){
	    			if(value.status !== 'DELIVERED' && value.status !== 'CANCELLED'){
	    				status = 'ON_QUEUE';
	    				keep = false;
	    			}
    			}
    		});
    		console.log('STATUS: '+status);
    		vm.updateOrderStatus(status);
    	}
    	
    	vm.updateOrderStatus = function(status){
    		console.log(status);
    		
			var data = {
							'id' 			: $scope.form.id,
							'orderStatus'	: status
					
			};
    		console.log(data);
    		
    		var commandCode = "updateOrderStatusCommandHandler";
    		var url = "command/"+commandCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log(response);
    			$scope.form.status = status;
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	}
    	
    	$scope.computeSubTotal = function(sellingPrice, discountedPrice, itemQuantity){
    		var total = 0;
    		if(discountedPrice && discountedPrice > 0.00){
    			total = discountedPrice * itemQuantity;
    		}else{
    			total = sellingPrice * itemQuantity;
    		}
    		return total;
    	}
    	
    	$scope.computeTotal = function(){
    		var total = 0;
    		if($scope.form && $scope.form.orderItemList){
    			angular.forEach($scope.form.orderItemList, function(value, key){
    				if(value['Discounted Price'] && value['Discounted Price'] > 0.00){
    	    			total = total + (value['Discounted Price'] * value['Quantity']);
    	    		}else{
    	    			total = total + (value['Selling Price'] * value['Quantity']);
    	    		}
				});
    		}	
    		return total;
    	}
    	
	}]);
	
});