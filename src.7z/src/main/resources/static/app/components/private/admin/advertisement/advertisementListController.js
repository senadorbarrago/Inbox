/**
 * 
 */
'use strict';
define(function(){
	var adminModules = angular.module('adminModules');
	console.log('Loading advertisementListController');
	
	adminModules.register.controller('advertisementListController', [
		'$rootScope', 
		'$scope', 
		'$location',
		'ngTableParams', 
		'DataAccessService', 
		'alertify',
		function ($rootScope, $scope, $location, ngTableParams, dataAccessService, alertify){
    	console.log('adminModules.controller');
    	var vm = this;
    	
    	vm.init = function(){
    		console.log('advertisementListController.init()');
    		$rootScope.title = 'Advertisement';
    		$scope.form = {};
    		$scope.searchCriteria = {};
    		$scope.searchCriteria.showDeleted = false;
    		vm.getQueryList();   
    	};
    	
    	vm.getQueryList = function(){
    		console.log('HEEYYY');
    		$scope.tableParams = new ngTableParams({
                page: 1,
                count: 10
            }, {
                getData: function ($defer, params) {
                	console.log('HEEYYY2');
                	var data = {
                			'pageIndex' : params.page(),
        					'pageSize': params.count(),
        					'searchCriteria': $scope.searchCriteria
        			   	   };
                	console.log('HEEYYY3');	
        		var queryCode = "advertisementListQueryModel";
        		var url = "query/"+queryCode;
        		
        		dataAccessService.doPostData(url, data, function(response){
        			console.log('QueryModel');
        			console.log(response);
        			$scope.form.resultSet = response.data.resultSet;
        			$scope.form.columns = response.data.columns;
        			params.total(response.data.resultOverAllCount);
        			$defer.resolve($scope.form.resultSet);
        		}, function(errorResponse){
    				console.log(errorResponse);
    			});
                	
                }
            });
    	};
    	
    	vm.init();
    	
    	$scope.search = function(){
    		$scope.tableParams.reload();
    	}
    	
    	$scope.showAll = function(){
    		$scope.searchCriteria = {};
    		$scope.searchCriteria.showDeleted = false;
    		$scope.tableParams.reload();
    	}
    	
    	$scope.viewRecord = function (id) {
    		$location.path('/private/admin/advertisement/form/'+id);
    	};
    	
    	$scope.add = function(){
    		$location.path('/private/admin/advertisement/form/0');
    	}
    	
    	$scope.delete = function(id){
    		var answer = confirm('This action will delete the selected item. Are you sure'+
    					'you want to proceed?');
    		if(answer){
        		var data = {'id' : id};
        		
        		var commandCode = "deleteAdvertisementCommandHandler";
        		var url = "command/"+commandCode;
        		
        		dataAccessService.doPostData(url, data, function(response){
        			console.log(response);
        			alertify.alert(response.data.messageMap['SUCCESS_MESSAGE']);
        			$scope.tableParams.reload();
        		}, function(errorResponse){
        			console.log(errorResponse);
        			alertify.alert(errorResponse.data.message);
    			});
    		}
    	};
    	
    	$scope.restore = function(id){
    		var answer = confirm('This action will restore the selected item. Are you sure'+
    					'you want to proceed?');
    		if(answer){
        		var data = {'id' : id};
        		
        		var commandCode = "restoreAdvertisementCommandHandler";
        		var url = "command/"+commandCode;
        		
        		dataAccessService.doPostData(url, data, function(response){
        			console.log(response);
        			alertify.alert(response.data.messageMap['SUCCESS_MESSAGE']);
        			$scope.tableParams.reload();
        		}, function(errorResponse){
    				console.log(errorResponse);
    				alertify.alert(errorResponse.data.message);
    			});
    		}
    	};
    	
	}]);
	
});