/**
 * 
 */
'use strict'
define(function(){
	var orderModule = angular.module('orderModule');
	console.log('Loading homeController');
	
	orderModule.register.controller('checkoutFormController', ['$rootScope', '$scope', '$uibModal', 'DataAccessService',  'alertify', '$location',
		function ($rootScope, $scope, $uibModal, dataAccessService, alertify, $location){
    	console.log('Registering checkoutFormController...');
    	
    	var vm = this;
    	
    	vm.init = function(){
    		$scope.form = {};
    		$scope.references = {};
    		$scope.cart = {};
    		
    		vm.validatePreCheckOut();
    		vm.getClientDetails();
    		vm.getClientAddress();
    		vm.loadCart();
    		vm.getPayment();
    		vm.getPaymentMethods();
    		vm.initPayPalOptions();
    	};
    	
    	vm.initPayPalOptions = function(){
    		$scope.opts = {
                    env: 'sandbox',
                    client: {
                        sandbox:    'AVRH22cKwMG8HJD5HQsuaRrTaEWu8eXrB2RKzAY32_gryYc6J6IbRdxGknI-XOHcX-y9Lilm-33FoD2b',
                        production: 'raymondtiongco-facilitator_api1.yahoo.com'
                    },
                    payment: function() {
                        var env    = this.props.env;
                        var client = this.props.client;
                        return paypal.rest.payment.create(env, client, {
                            transactions: [
                                {
                                    amount: { total: $scope.form.total, currency: 'PHP' }
                                }
                            ]
                        });
                    },
                    commit: true, // Optional: show a 'Pay Now' button in the checkout flow
                    onAuthorize: function(data, actions) {
                    	console.log('PayPalCheckOut: ');
                    	console.log(data);
                        return actions.payment.execute().then(function(result) {
                        	console.log("Result: ");
                        	console.log(result.transactions[0].related_resources[0].sale.id);
                            //$scope.placeOrder();
                        });
                    }
                };
    	}
    	
    	vm.getPaymentMethods = function(){
    		var data = {};
    		
    		var queryCode = "findAllPaymentMethodQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('FindAllPaymentMethodQueryModel:');
    			console.log(response);
    			$scope.references.paymentMethods = response.data.resultSet;
    			
    			angular.forEach($scope.references.paymentMethods, function(value, key) {
    				if(value.isDefault === true){
    					$scope.form.paymentMethod = value;
    				}
    			});
    			
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	}
    	
    	vm.getClientDetails = function(){
    		console.log('Client Details');
    		$scope.form.userID = $rootScope.session['AUTHENTICATED_USER'].userID;
    		$scope.form.fullname = $rootScope.session['AUTHENTICATED_USER'].fullname;
    	}
    	
    	vm.getClientAddress = function(){
    		var data = {};
    		
    		var queryCode = "findClientAddressInfoQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('ClientDetails:');
    			console.log(response);
    			$scope.form.shippingAddress = response.data.resultSet[0]['shippingAddressMap'];
    			$scope.form.isBillingSameAsShippingAddress = response.data.resultSet[0]['isBillingSameAsShippingAddress'];
    			if(!$scope.form.isBillingSameAsShippingAddress || 
    					$scope.form.isBillingSameAsShippingAddress === false){
    				$scope.form.billingAddress = response.data.resultSet[0]['billingAddressMap'];
    			}    			
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	}
    	
    	vm.loadCart = function(){
    		var data = {};
    		var queryCode = "findCartByUserIDQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('Cart');
    			console.log(response);    			
    			$scope.cart.items = response.data.resultSet;
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	}
    	
    	vm.getPayment = function(){
    		console.log('Payment');
    	}
    	
    	vm.validatePreCheckOut = function(){
    		console.log('validatePreCheckOut');
    		
    		var data = {};
    		var queryCode = "findClientDetailsCompletenessQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('findClientDetailsCompletenessQueryModel');
    			console.log(response);    			
    			
    			var isCompleteDetails = response.data.resultSet[0].isCompleteDetails;
    			if(isCompleteDetails === true){
    				$location.path('/private/order/checkout');
    			}else{
    				alertify.alert('Please complete your details in order to proceed on your checkout');
    				$location.path('/private/client/profile');
    			}
    			
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	}
    	
    	vm.init();
    	
    	$scope.computeSubTotal = function(sellingPrice, discountedPrice, itemQuantity){
    		var total = 0;
    		if(discountedPrice && discountedPrice > 0.00){
    			total = discountedPrice * itemQuantity;
    		}else{
    			total = sellingPrice * itemQuantity;
    		}
    		return total;
    	}
    	
    	$scope.computeTotal = function(){
    		$scope.form.total = 0.00;
    		
    		if($scope.cart && $scope.cart.items){
    			angular.forEach($scope.cart.items, function(value, key){
    				if(value.discountedPrice && value.discountedPrice > 0.00){
    					$scope.form.total = $scope.form.total + (value.discountedPrice * value.quantity);
    	    		}else{
    	    			$scope.form.total = $scope.form.total + (value.sellingPrice * value.quantity);
    	    		}
				});
    		}
    		return $scope.form.total;
    	}
    	
    	$scope.showConfirmation = function(){
    		if(!$scope.form.paymentMethod){
    			alertify.alert("Please select a payment method in order to proceed!");
    			return false;
    		}
    		var modalInstance = $uibModal.open({
    			animation: true,
    			backdrop: 'static',
    			templateUrl: 'app/components/private/order/checkout/checkoutConfirmationForm.html',
    			controller: 'checkoutConfirmationFormController',
    			size: 'md',
    			keyboard: false,
    			resolve 	 : {
    				load: ['$q', function($q){
	    					var defered = $q.defer();
	    					require(['app/components/private/order/checkout/checkoutConfirmationFormController.js'], function(){
	    						defered.resolve();
	    					});
		    			return defered.promise;
					}],
    				data	 : function(){
    					var data = $scope.form;
    					return data;
    				}
    			}
            });
            modalInstance.result.then(function(message){
                // success()
            	alertify.alert(message);
            },
            function() {                
            	// dismiss()
                console.log("dismissed");
            });
            
            return modalInstance.result;
    	}
    	
	}]);
	
});