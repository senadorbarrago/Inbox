/**
 * 
 */
'use strict'
define(function(){
	var orderModule = angular.module('orderModule');
	console.log('Loading homeController');
	
	orderModule.register.controller('wishlistController', ['$rootScope', '$scope', 'DataAccessService',  'alertify',
		function ($rootScope, $scope, dataAccessService, alertify){
    	console.log('Registering wishlistController...');
    	
    	var vm = this;
    	
    	vm.init = function(){
    		$scope.wishlist = {};
    		$scope.wishlist.items = [];
    		
    		vm.loadItems();
    	}
    	
    	vm.loadItems = function(){
    		var data = {};
    		var queryCode = "wishListQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('Cart');
    			console.log(response);    			
    			$scope.wishlist.items = response.data.resultSet;
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	}
    	// Initialize
    	vm.init();
  	    
    	$scope.removeItemFromWishList = function(itemID){
    		console.log(itemID);
    		var data = {
    					'id' : itemID
    					};
    		
    		var commandCode = "removeItemFromWishListCommandHandler";
    		var url = "command/"+commandCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log(response);
    			vm.init();
    		}, function(errorResponse){
				alert(errorResponse);
			});
    	}
    	
    	$scope.removeAllItemsFromWishList = function(){
    		var data = {};
    		
    		var commandCode = "removeAllItemsFromWishListCommandHandler";
    		var url = "command/"+commandCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log(response);
    			vm.init();
    		}, function(errorResponse){
				alert(errorResponse);
			});
    	}
    	
    	$scope.addCartItemQuantity = function(item){
	  		  if(item.quantity < item.noOfStock){
	  			  if(item.quantity + item.quantityPerPack <= item.noOfStock){
	  				item.quantity = item.quantity + item.quantityPerPack;
	  			  }else{
	  				  alertify.alert("Cart items will exceeded the number of stock available!");
	  			  }
	  		  }else{
	  			  alertify.alert("Cart items will exceed the number of stock available!");
	  		  }
	  	}
	  
	  	$scope.subtractCartItemQuantity = function(item){
	  		  if(item.quantity > 0){
	  			if(item.quantity - item.quantityPerPack > 0 && 
	  					item.quantity - item.quantityPerPack >= item.minimumOrder){
	  				item.quantity = item.quantity - item.quantityPerPack;
	  		  	}else{
	  		  		alertify.alert("Cart items with quantity less than the MOQ is not allowed!");
	  		  	}
	  		  }else{
	  			alertify.alert("Cart items with quantity less than the MOQ is not allowed!");
	  		  }
	  	}
    	
	  	$scope.addToCart = function(item){
	  		var data = {};
    		data.productID = item.productID;
    		data.quantity = item.quantity;
    		data.customerID = $rootScope.session['AUTHENTICATED_USER'].userID;
    		data.createdBy = $rootScope.session['AUTHENTICATED_USER'].username;
    		
    		console.log(data);
    		
    		var commandCode = "addItemToCartCommandHandler";
    		var url = "command/"+commandCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log(response);
    			$rootScope.loadCartItemsCount();
    			alertify.alert("The selected product/service has been successfully added to your shopping cart!");
    		}, function(errorResponse){
    			console.log(errorResponse);
				alertify.alert(errorResponse.data.message);
			});
    	}
      
	}]);
	
});