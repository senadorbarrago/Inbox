/**
 * 
 */
'use strict'
define([
//    '../app/components/private/admin/product/productListController',
//    '../app/components/private/admin/product/productFormController',
//    '../app/components/private/admin/brand/brandListController',
//    '../app/components/private/admin/brand/brandFormController',
//    '../app/components/private/admin/primarycategory/primaryCategoryListController',
//    '../app/components/private/admin/primarycategory/primaryCategoryFormController',
//    '../app/components/private/admin/secondarycategory/secondaryCategoryListController',
//    '../app/components/private/admin/secondarycategory/secondaryCategoryFormController',
//    '../app/components/private/admin/category/categoryListController',
//    '../app/components/private/admin/category/categoryFormController',
//    '../app/components/private/admin/section/sectionListController',
//    '../app/components/private/admin/section/sectionFormController',
//    '../app/components/private/admin/advertisement/advertisementListController',
//    '../app/components/private/admin/advertisement/advertisementFormController',
//    '../app/components/private/admin/user/userFormController',
//    '../app/components/private/admin/user/userListController',
//    '../app/components/private/admin/role/roleListController',
//    '../app/components/private/admin/role/roleFormController',
//    '../app/components/public/product/list/productListingController',
//    '../app/components/public/product/info/productInfoController',
//    '../app/components/private/admin/tag/tagListController',
//    '../app/components/private/admin/tag/tagFormController',
//    '../app/components/private/admin/service/serviceListController',
//    '../app/components/private/admin/service/serviceFormController'
], function () {});