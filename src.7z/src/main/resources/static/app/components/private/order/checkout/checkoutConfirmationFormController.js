/**
 * 
 */
'use strict'
define(function(){
	var orderModule = angular.module('orderModule');
	console.log('Loading checkoutConfirmationFormController');
	
	orderModule.register.controller('checkoutConfirmationFormController', ['$rootScope', '$scope', '$uibModalInstance', 'data', 'DataAccessService',  'alertify', '$location',
		function ($rootScope, $scope, $uibModalInstance, data, dataAccessService, alertify, $location){
    	console.log('Registering checkoutConfirmationFormController...');
 
    	var vm = this;
    	
    	vm.init = function(){
    		$scope.form = data;
    		console.log($scope.form);
    		$scope.form.shippingCost = 0.00;
    		
    		vm.initPayPalOptions();
    		vm.initAdditionalCharges();
    		vm.calculateOverAllTotal();
    	};
    	
    	vm.initPayPalOptions = function(){
    		$scope.opts = {
                    env: 'production',
                    client: {
                        sandbox:    'AYjaoTRH6xX06p1UQphdddV0Al0rKM68xc8QDCnmgqmtGVtIchDN5dvyiomNXd6gXAONAnlNQuD-hSLa',
                        production: 'AZ02ipxDdI457hvVEQgyHoJVzqoRf0vqzoCv_ZCChgzXyLCulN-0T0wZECKsK4hOogphy8rZGaJvS1Kx'
                    },
                    payment: function() {
                        var env    = this.props.env;
                        var client = this.props.client;
                        return paypal.rest.payment.create(env, client, {
                            transactions: [
                                {
                                    amount: { total: $scope.form.overAllTotalCost.toFixed(2), currency: 'PHP' }
                                }
                            ]
                        });
                    },
                    commit: true, // Optional: show a 'Pay Now' button in the checkout flow
                    onAuthorize: function(data, actions) {
                    	console.log('PayPalCheckOut: ');
                    	console.log(data);
                        return actions.payment.execute().then(function(result) {
                        	console.log("Result: ");
                        	console.log(result);
                        	console.log(result.transactions[0].related_resources[0].sale.id);
                            $scope.placeOrder(result.transactions[0].related_resources[0].sale.id);
                        });
                    }
                };
    	}
    	
    	// Init Additional Charges
    	vm.initAdditionalCharges = function(){
    		$scope.form.additionalCharge = 0.00;
    		$scope.form.additionalChargeDescription = "";
    		
    		var commission = $scope.form.paymentMethod.percentCommission;
    		var additionalCharge = $scope.form.paymentMethod.additionalCharge;
    		
    		if(additionalCharge && additionalCharge > 0 && !commission && commission <= 0){
    			$scope.form.additionalCharge = $scope.form.additionalCharge + additionalCharge;
    		}
    		
    		if(additionalCharge && additionalCharge > 0 && commission && commission > 0){
    			$scope.form.additionalCharge = ((additionalCharge + $scope.form.total) * commission) - $scope.form.total;
    		}
    		
    	}
    	
    	// Calculate over all total
    	vm.calculateOverAllTotal = function(){
    		$scope.form.overAllTotalCost = $scope.form.total + $scope.form.additionalCharge;  
    	}
    	
    	$scope.placeOrder = function(orderNo){
			var data = {
							'contextPath'	: $location.absUrl().substr(0, $location.absUrl().indexOf("/"))					
						};
			data.paymentMethod = $scope.form.paymentMethod.id;
    		data.orderNo = orderNo;
			
			var commandCode = "addOrderCommandHandler";
    		var url = "command/"+commandCode;
    		
    		console.log(data);
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log(response);
    			$scope.close();
    			alertify.alert(response.data.messageMap['SUCCESS_MESSAGE']);
    			$rootScope.loadCartItemsCount();
    			$location.path('/private/order/orderList');
    		}, function(errorResponse){
    			alertify.alert(response.data.message);
				console.log(errorResponse);
			});
    	}
    	
    	vm.init();
    	
    	// Close Modal
    	$scope.close = function(){
    		$uibModalInstance.dismiss();
    	}
    		
	}]);
	
});