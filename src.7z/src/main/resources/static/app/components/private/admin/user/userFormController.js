/**
 * 
 */
'use strict';
define(function(){
	var adminModules = angular.module('adminModules');
	console.log('Loading userFormController');
	
	adminModules.register.controller('userFormController', [
		'$rootScope', 
		'$scope', 
		'$location', 
		'DataAccessService',  
		'alertify', 
		'$routeParams',
		'$filter',
		function ($rootScope, $scope, $location, dataAccessService, alertify, $routeParams, $filter){
    	console.log('adminModules.controller');
    	var vm = this;
    	
    	vm.init = function(){
    		console.log('userFormController.init()');
    		
    		$scope.formTitle = 'User Form';
    		$scope.form = {};
    		$scope.form.sameAddress = false;
    		
    		if($routeParams.id && $routeParams.id > 0){
    			vm.loadForm($routeParams.id);
    		}
    		
    		$scope.reference = {};
    		vm.getRoleReferenceList();
    		vm.getStatusReferenceList();
    		vm.getSupplierReferenceList();
    		vm.getCountryReferenceList();
    		vm.getRegionReferenceList();
    	};
    	
    	
    	vm.loadForm = function(id){
    		var data = {'id' : id};
    		
    		var queryCode = "findSelectedClientByIDQueryModel";
    		var url = "query/"+queryCode;
    		console.log(data);
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('findSelectedClientByIDQueryModel');
    			console.log(response);
    			$scope.form = response.data.resultSet[0];
    			$scope.form.userID = id;
    		}, function(errorResponse){
    			console.log(errorResponse);
			});
    		
    	};
    	
    	vm.getRoleReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllRoleQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('QueryModel');
    			console.log(response);
    			$scope.reference.roleList = response.data.resultSet;
    			
    			
    		}, function(errorResponse){
    			console.log(errorResponse);
			});
    	};
    	
    	vm.getStatusReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllUserStatusQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('Status');
    			console.log(response);
    			$scope.reference.statusList =  response.data.resultSet;
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	};
    	
    	vm.getSupplierReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllSupplierReferencesQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('QueryModel');
    			console.log(response);
    			$scope.reference.supplierList = response.data.resultSet;
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	};
    	
    	vm.getCountryReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllCountryQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('QueryModel');
    			console.log(response);
    			$scope.reference.countryList = response.data.resultSet;
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	};
    	
    	vm.getRegionReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllRegionQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('findAllRegionQueryModel');
    			console.log(response);
    			$scope.reference.regionList = response.data.resultSet;
    		}, function(errorResponse){
    			console.log(errorResponse);
			});
    	};
    	
    	vm.validate = function(){
    		var isValid = true;
    		var errorMessage = 'Please provide the necessary required fields in order to proceed:</br>';
    		
    		if(!$scope.form.username){
    			isValid = false;
    			errorMessage = errorMessage+'Email </br>';
    		}
    		if(!$scope.form.firstname){
    			isValid = false;
    			errorMessage = errorMessage+'Firstname </br>';
    		}
    		if(!$scope.form.lastname){
    			isValid = false;
    			errorMessage = errorMessage+'Lastname </br>';
    		}
    		if(!$scope.form.contactNumber){
    			isValid = false;
    			errorMessage = errorMessage+'Contact Number </br>';
    		}
    		
    		
    		if($scope.form.role === 3){
	    		if(!$scope.form.supplier || $scope.form.supplier.length === 0 ){
	    			console.log($scope.form.supplier);
	    			isValid = false;
	    			errorMessage = errorMessage+'Company Name </br>';
				}else{
					angular.forEach($scope.form.supplier, function(value, key){
						if(!value){
							isValid = false;
		        			errorMessage = errorMessage+key+' </br>';
						}
					});
				}
    		}
    		
//    		if($scope.form.sameAddress === false){
//	    		if(!$scope.form.addressLine){
//	    			isValid = false;
//	    			errorMessage = errorMessage+'(Billing) Address Line </br>';
//	    		}
//	    		if(!$scope.form.region){
//	    			isValid = false;
//	    			errorMessage = errorMessage+'(Billing) Region </br>';
//	    		}
//	    		if(!$scope.form.city){
//	    			isValid = false;
//	    			errorMessage = errorMessage+'(Billing) City </br>';
//	    		}
//	    		if(!$scope.form.postal){
//	    			isValid = false;
//	    			errorMessage = errorMessage+'(Billing) Postal </br>';
//	    		}
//	    		if(!$scope.form.country || $scope.form.country.length === 0 ){
//	    			console.log($scope.form.country);
//	    			isValid = false;
//	    			errorMessage = errorMessage+'(Billing) Country </br>';
//				}else{
//					angular.forEach($scope.form.country, function(value, key){
//						if(!value){
//							isValid = false;
//		        			errorMessage = errorMessage+key+' </br>';
//						}
//					});
//				}
//	    		
//    		}
    		
//    		if(!$scope.form.addressLine2){
//    			isValid = false;
//    			errorMessage = errorMessage+'(Shipping) Address Line </br>';
//    		}
//    		if(!$scope.form.region2){
//    			isValid = false;
//    			errorMessage = errorMessage+'(Shipping) Region </br>';
//    		}
//    		if(!$scope.form.city2){
//    			isValid = false;
//    			errorMessage = errorMessage+'(Shipping) City </br>';
//    		}
//    		if(!$scope.form.postal2){
//    			isValid = false;
//    			errorMessage = errorMessage+'(Shipping) Postal </br>';
//    		}
//    		if(!$scope.form.country2 || $scope.form.country2.length === 0 ){
//    			console.log($scope.form.country2);
//    			isValid = false;
//    			errorMessage = errorMessage+'(Shipping) Country </br>';
//			}else{
//				angular.forEach($scope.form.country2, function(value, key){
//					if(!value){
//						isValid = false;
//	        			errorMessage = errorMessage+key+' </br>';
//					}
//				});
//			}
    		
    		if(isValid == false){
    			alertify.alert(errorMessage);
    			return false;
    		}
    		// Valid
    		return true;
    	};
    	
    	vm.init();
    	
//    	$scope.disableRoleField = function(){
//    		if($scope.form.role && $scope.reference.roleList){
//	    		var selectedRole = $filter('filter')($scope.reference.roleList, {id:$scope.form.role});
//				
//	    		if(selectedRole){
//	    			console.log(selectedRole[0].description.toLowerCase().indexOf('admin') !== -1);
//		    		if(selectedRole[0].description.toLowerCase().indexOf('admin') === -1){
//		    			return true;
//					}	
//	    		}
//    		}
//    		
//    	}
    	
    	$scope.save = function(){
    		if(!vm.validate()){
    			return false;
    		}
    		
    		var answer = confirm('This action will create a new administrator account. Are you sure'+
    				'you want to proceed?');
    		
    		if(answer){
    			$scope.form.createdBy = "ADMINISTRATOR";
        		
        		var data = $scope.form;
        		data.selectedusername = $scope.form.username;
        		var commandCode = "addUsersCommandHandler";
        		var url = "command/"+commandCode;
        		
        		dataAccessService.doPostData(url, data, function(response){
        			console.log(response);
        			alertify.alert('The admin account has been successfully created');
        			$location.path('/private/admin/user/list')
        		}, function(errorResponse){
        			console.log(errorResponse);
        			alertify.alert(errorResponse.data.message);
    			});
    		}
    	};
    	
    	$scope.update = function(){
    		if(!vm.validate()){
    			return false;
    		}
    		
    		var answer = confirm('This action will update the selected account. Are you sure'+
    				' you want to proceed?');
    		
    		if(answer){
    			$scope.form.lastModifiedBy = "ADMINISTRATOR";
        		
        		var data = $scope.form;
        		data.selectedusername = $scope.form.username; 
        		var commandCode = "updateClientCommandHandler";
        		var url = "command/"+commandCode;
        		
        		dataAccessService.doPostData(url, data, function(response){
        			console.log(response);
        			alertify.alert('The account has been successfully updated!');
        			$location.path('/private/admin/user/list')
        		}, function(errorResponse){
        			alertify.alert(errorResponse);
    			});
    		}
    	};
    	
    	$scope.updateClientStatus = function(){
    		
    		var answer = confirm('This action will update the status of the selected account. Are you sure'+
			' you want to proceed?');
	
			if(answer){
				var data = {};
				data.username = $scope.form.username;
				data.status = $scope.form.status;
				data.contextPath = $location.absUrl().substr(0, $location.absUrl().lastIndexOf("#"));
				
				var commandCode = "updateClientAccountCommandHandler";
				var url = "command/"+commandCode;
				
				dataAccessService.doPostData(url, data, function(response){
					console.log(response);
					alertify.alert(response.data.messageMap['SUCCESS_MESSAGE']);
				}, function(errorResponse){
					alertify.alert(errorResponse);
				});
			}
    	}
    	
    	$scope.companyOnChange = function(){
    		var data = {'id' : $scope.form.supplier};
    		var queryCode = "findSupplierByIDQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('QueryModel');
    			console.log(response);
    			$scope.form.businessStyle = response.data.resultSet[0].businessStyle;
    			$scope.form.companyTin = response.data.resultSet[0].companyTin;
    			$scope.form.sameAddress = response.data.resultSet[0].sameAddress;
    			$scope.form.addressLine = response.data.resultSet[0].addressLine;
    			$scope.form.city = response.data.resultSet[0].city;
    			$scope.form.region = response.data.resultSet[0].region;
    			$scope.form.postal = response.data.resultSet[0].postal;
    			$scope.form.country = response.data.resultSet[0].country;
    			$scope.form.addressLine2 = response.data.resultSet[0].addressLine2;
    			$scope.form.city2 = response.data.resultSet[0].city2;
    			$scope.form.region2 = response.data.resultSet[0].region2;
    			$scope.form.postal2 = response.data.resultSet[0].postal2;
    			$scope.form.companyTin2 = response.data.resultSet[0].companyTin2;
    			$scope.form.country2 = response.data.resultSet[0].country2;
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    		
    	}
    	
    	
    	$scope.roleOnChange = function(){
    		var isSupplier = false;
    		angular.forEach($scope.reference.roleList, function(value, key){
    			console.log(value);
    		
//				if(value.id === $scope.form.prevRole){
//					if(value.code === "SUPPLIER"){
//						isSupplier = true;
//					}
//				}
				
				if(value.code === "SUPPLIER"){
					isSupplier = true;
				}
			});
    		
    			if(isSupplier) {
    				$scope.form.businessStyle = "";
        			$scope.form.companyTin = "";
        			$scope.form.sameAddress = "";
        			$scope.form.addressLine = "";
        			$scope.form.city = "";
        			$scope.form.region = "";
        			$scope.form.postal = "";
        			$scope.form.country = 0;
        			$scope.form.addressLine2 = "";
        			$scope.form.city2 = "";
        			$scope.form.region2 = "";
        			$scope.form.postal2 = "";
        			$scope.form.companyTin2 = "";
        			$scope.form.country2 = 0;
        			$scope.form.supplier = 0;
    			}
    			$scope.form.prevRole = $scope.form.role;
    	}
    	
	}]);
	
});