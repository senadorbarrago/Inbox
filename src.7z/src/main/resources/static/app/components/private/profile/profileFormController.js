/**
 * 
 */
'use strict';
define(function(){
	var adminModules = angular.module('adminModules');
	console.log('Loading profileFormController');
	
	adminModules.register.controller('profileFormController', ['$rootScope', '$scope', 
		'$http', 'DataAccessService',  'alertify', '$location',
		function ($rootScope, $scope, $http, dataAccessService, alertify, $location){
    	console.log('adminModules.controller');
    	var vm = this;
    	
    	vm.init = function(){
    		console.log('profileFormController.init()');
    		
    		$scope.formTitle = 'Profile';
    		$scope.form = {};
    		
    		vm.loadForm();
    		$scope.reference = {};
    		vm.getCountryReferenceList();
    		vm.getRegionReferenceList();
    	};
    	
    	vm.getCountryReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllCountryQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('QueryModel');
    			console.log(response);
    			$scope.reference.countryList = response.data.resultSet;
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	};
    	
    	vm.getRegionReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllRegionQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('findAllRegionQueryModel');
    			console.log(response);
    			$scope.reference.regionList = response.data.resultSet;
    		}, function(errorResponse){
    			console.log(errorResponse);
			});
    	};
    	
    	vm.loadForm = function(){
    		var data = {'id' : $rootScope.session['AUTHENTICATED_USER'].userID};
    		
    		var queryCode = "findClientByIDQueryModel";
    		var url = "query/"+queryCode;
    		console.log(data);
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('QueryModel');
    			console.log(response);
    			$scope.form = response.data.resultSet[0];
    		}, function(errorResponse){
    			console.log(errorResponse);
			});
    		
    	};
    	
       	vm.validate = function(){
    		var isValid = true;
    		var errorMessage = 'Please provide the necessary required fields in order to proceed:\n';
    		
    		if(!$scope.form.username){
    			isValid = false;
    			errorMessage = errorMessage+'Username \n';
    		}
    		if(!$scope.form.firstname){
    			isValid = false;
    			errorMessage = errorMessage+'Firstname \n';
    		}
    		if(!$scope.form.lastname){
    			isValid = false;
    			errorMessage = errorMessage+'Lastname \n';
    		}
    		if(!$scope.form.companyName){
    			isValid = false;
    			errorMessage = errorMessage+'Company Name \n';
    		}
    		if(!$scope.form.email){
    			isValid = false;
    			errorMessage = errorMessage+'Email \n';
    		}
    		if(!$scope.form.contactNumber){
    			isValid = false;
    			errorMessage = errorMessage+'Contact Number \n';
    		}
    		if(!$scope.form.addressLine){
    			isValid = false;
    			errorMessage = errorMessage+'(Billing) Address Line \n';
    		}
    		if(!$scope.form.province){
    			isValid = false;
    			errorMessage = errorMessage+'(Billing) Province \n';
    		}
    		if(!$scope.form.city){
    			isValid = false;
    			errorMessage = errorMessage+'(Billing) City \n';
    		}
    		if(!$scope.form.postal){
    			isValid = false;
    			errorMessage = errorMessage+'(Billing) Postal \n';
    		}
    		if(!$scope.form.country || $scope.form.country.length === 0 ){
    			console.log($scope.form.country);
    			isValid = false;
    			errorMessage = errorMessage+'(Billing) Country \n';
			}else{
				angular.forEach($scope.form.country, function(value, key){
					if(!value){
						isValid = false;
	        			errorMessage = errorMessage+key+' \n';
					}
				});
			}
    		if(!$scope.form.addressLine2){
    			isValid = false;
    			errorMessage = errorMessage+'(Shipping) Address Line \n';
    		}
    		if(!$scope.form.province2){
    			isValid = false;
    			errorMessage = errorMessage+'(Shipping) Province \n';
    		}
    		if(!$scope.form.city2){
    			isValid = false;
    			errorMessage = errorMessage+'(Shipping) City \n';
    		}
    		if(!$scope.form.postal2){
    			isValid = false;
    			errorMessage = errorMessage+'(Shipping) Postal \n';
    		}
    		if(!$scope.form.country2 || $scope.form.country2.length === 0 ){
    			console.log($scope.form.country2);
    			isValid = false;
    			errorMessage = errorMessage+'(Shipping) Country \n';
			}else{
				angular.forEach($scope.form.country2, function(value, key){
					if(!value){
						isValid = false;
	        			errorMessage = errorMessage+key+' \n';
					}
				});
			}
    		
    		if(isValid == false){
    			alertify.alert(errorMessage);
    			return false;
    		}
    		// Valid
    		return true;
    	};
    	
    	
    	vm.init();
    	
    	
		$scope.update = function(){
			
				if(!vm.validate()){
	    			return false;
	    		}
	    		
	    		var answer = confirm('This action will update your account details. Are you sure'+
	    				' you want to proceed?');
	    		
	    		if(answer){
	    			$scope.form.lastModifiedBy = "ADMINISTRATOR";
	        		
	        		var data = $scope.form;
	        		console.log(data);
	        		
	        		var commandCode = "UpdateClientCommand";
	        		var url = "command/"+commandCode;
	        		
	        		dataAccessService.doPostData(url, data, function(response){
	        			console.log(response);
	        			alertify.alert('Your account has been successfully updated');
	        		}, function(errorResponse){
	        			console.log(errorResponse);
	        			alertify.alert(errorResponse	);
	    			});
	    		}
	    	};
    	
	}]);
	
});