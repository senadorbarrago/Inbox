/**
 * 
 */
'use strict';
define(function(){
	var adminModules = angular.module('adminModules');
	console.log('Loading brandFormController');
	
	adminModules.register.controller('brandFormController', [
		'$rootScope', 
		'$scope',
		'$location',
		'DataAccessService',  
		'alertify', 
		'$routeParams',
		'$http',
		function ($rootScope, $scope, $location, dataAccessService, alertify, $routeParams, $http){
    	console.log('adminModules.controller');
    	var vm = this;
    	
    	vm.init = function(){
    		console.log('brandFormController.init()');
    		console.log($routeParams);
    		
    		$scope.formTitle = 'Brand Form';
    		$scope.form = {};
    		$scope.upload = {};
    		$scope.reference = {};
    		
    		if($routeParams.id && $routeParams.id > 0){
    			vm.loadForm($routeParams.id);
    		}
    		
    		vm.getSupplierReferenceList();
    		
    	};
    	
    	vm.loadForm = function(id){
    		var data = {'id' : id};
    		var queryCode = "brandDetailsQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('brandDetailsQueryModel');
    			console.log(response);
    			$scope.form = response.data.resultSet[0];
    			$scope.form.imageOld = $scope.form.imageUrl;
    		}, function(errorResponse){
				console.log(errorResponse);
				alertify.alert(errorResponse.data.message);
			});
    		
    	};
    	
    	vm.getSupplierReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllSupplierReferencesQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('findAllSupplierReferencesQueryModel');
    			console.log(response);
    			$scope.reference.supplierList = response.data.resultSet;
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	};
    	
    	vm.validate = function(){
    		var isValid = true;
    		var errorMessage = 'Please provide the necessary required fields in order to proceed:</br>';
    		
    		if(!$scope.form.code){
    			isValid = false;
    			errorMessage = errorMessage+'Brand Code </br>';
    		}
    		if(!$scope.form.description){
    			isValid = false;
    			errorMessage = errorMessage+'Brand Description </br>';
    		}
    		if(!$scope.form.supplier){
    			isValid = false;
    			errorMessage = errorMessage+'Seller </br>';
    		}
    		
    		if(isValid == false){
    			alertify.alert(errorMessage);
    			return false;
    		}
    		// Valid
    		return true;
    	};
    	
    	/**
    	 * Upload image and save form
    	 */
    	vm.uploadImageAndSaveForm = function () {    		
    		var fd = new FormData();
    		fd.append('file', $scope.upload.file);
    		fd.append('folder', 'HD-Brands');
    		
    		let url = 'storage/uploadFile';
    		dataAccessService.doPostFileData(url, fd, function(response){
    			console.log(response);
    			$scope.form.imageUrl = response.data.url;
    			vm.saveForm();
    		}, function(errorResponse){
				alertify.alert(errorResponse.data.message);
			});
    	};
    	
    	/**
    	 * Save form
    	 * 
    	 */
    	vm.saveForm = function(){
			var data = $scope.form;
			var commandCode = "addBrandCommandHandler";
    		var url = "command/"+commandCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log(response);
    			alertify.alert(response.data.messageMap['SUCCESS_MESSAGE']);
    			$location.path('/private/admin/brand/list');
    		}, function(errorResponse){
    			vm.deleteUpload();
    			alertify.alert(errorResponse.data.message);
			});
    	};
    	
    	/**
    	 * Delete uploaded image
    	 */
    	vm.deleteUpload = function () {
			if($scope.form.imageOld && $scope.form.imageUrl
				&& $scope.form.imageOld !== $scope.form.imageUrl){
        		
				console.log('$scope.form.imageOld: '+$scope.form.imageOld);
				console.log('$scope.form.image: '+$scope.form.imageUrl);
				
				if($scope.form.imageOld.includes('place-holder-image-1')){
	        		return false;
	        	}
				
				var fd = new FormData();
        		fd.append('url', $scope.form.imageOld);
        		
        		let url = 'storage/deleteFile';
        		dataAccessService.doPostFileData(url, fd, function(response){
        			console.log(response);
        		}, function(errorResponse){
        			console.log(errorResponse);
    			});
			}
    	};
    	
    	/**
    	 * Update form
    	 */
    	vm.updateForm = function(){
    		var data = $scope.form;    		
            var commandCode = "updateBrandCommandHandler";
     		
            var url = "command/"+commandCode;
     		dataAccessService.doPostData(url, data, function(response){
     			console.log(response);
     			vm.deleteUpload();
     			alertify.alert(response.data.messageMap['SUCCESS_MESSAGE']);
     			$location.path('/private/admin/brand/list');
     		}, function(errorResponse){
     			alertify.alert(errorResponse.data.message);
 			});
	
    	};
    	
    	/**
    	 * Upload image and update form
    	 */
    	vm.uploadImageAndUpdateForm = function () {
    		var fd = new FormData();
    		
    		fd.append('file', $scope.upload.file);
    		fd.append('folder', 'HD-Brands');
    		
    		let url = 'storage/uploadFile';
    		dataAccessService.doPostFileData(url, fd, function(response){
    			console.log(response);
    			$scope.form.imageUrl = response.data.url;
    			vm.updateForm();
    		}, function(errorResponse){
				alertify.alert(errorResponse.data.message);
			});
    	};
    	
    	/**
    	 * Initialize form
    	 * 
    	 */
    	vm.init();
    	
    	/**
    	 * Select a file to be uploaded
    	 * 
    	 */
    	$scope.selectFile = function (element) {
    		var files = element.files;
			for (var i = 0; i < files.length; i++) {
				$scope.upload.filename = files[i].name;
				$scope.upload.file = files[i];
			}
			$scope.$apply();
    	};
    	
    	/**
    	 * Save form
    	 * 
    	 */
    	$scope.save = function(){
    		if(!vm.validate()){
    			return false;
    		}
    		
    		alertify.confirm('This action will save the newly created brand. Are you sure'+
    				'you want to proceed?', function(e){
    			if(e){
    				if($scope.upload.filename){
    					// Upload image and save form
    					vm.uploadImageAndSaveForm();
    				}else{
    					// Save form
    					vm.saveForm();
    				}
    			}
    		});
    		
    	};
    	
    	/**
    	 * Update form
    	 * 
    	 */
    	$scope.update = function(){
    		if(!vm.validate()){
    			return false;
    		}
    		
    		alertify.confirm('This action will update the selected brand. Are you sure'+
    				'you want to proceed?', function(e){
    			if(e){
    				if($scope.upload.filename){
    					// Upload image and update form
    					vm.uploadImageAndUpdateForm();
    				}else{
    					// Update form
    					vm.updateForm();
    				}
    			}
    		});
    	};
    	
	}]);
	
});