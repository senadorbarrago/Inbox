/**
 * 
 */
'use strict';
define(function(){
	var adminModules = angular.module('adminModules');
	console.log('Loading serviceFormController');
	
	adminModules.register.controller('serviceFormController', [
		'$rootScope', 
		'$scope', 
		'$http', 
		'DataAccessService', 
		'$routeParams',
		'$location',
		'alertify',
		function ($rootScope, $scope, $http, dataAccessService, $routeParams, $location, alertify){
    	console.log('adminModules.controller');
    	var vm = this;
    	
    	vm.init = function(){
    		console.log('serviceFormController.init()');
    		console.log($routeParams);
    		
    		//vm.initDatePicker();
    		
    		$scope.formTitle = 'Service Form';
    		$scope.index= 0;
    		$scope.form = {};
    		$scope.upload = {};
    		$scope.form.isSupplierVisible = false;
    		$scope.form.hasDiscountBasedOnQuantity = false;
    		$scope.form.isFreeShipping = false;
    		if($routeParams.serviceID && $routeParams.serviceID > 0){
    			vm.loadForm($routeParams.serviceID);
    			console.log($routeParams.serviceID);
    		}else{
    			$scope.form.image = 'assets/img/1.png'; // Default
    			$scope.form.categories = [];
    			$scope.form.tags = [];
    			
    			$scope.form.isSupplierVisible = true;
    			
    			vm.initializeCategory();
    			vm.initializeTag();
    		}
    		
    		$scope.reference = {};
    		
    		vm.getAvailabilityReferenceList();
    		vm.getStatusReferenceList();
    		vm.getSupplierReferenceList();
    	};
    	
    	vm.loadForm = function(id){
    		var data = {'id' : id};
    		var queryCode = "productDetailsQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('Form');
    			console.log(response);
    			$scope.form = response.data.resultSet[0];
    			
    			vm.loadFormCategories();
    			vm.loadFormTags();
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    		
    	};
    	
    	vm.loadFormCategories = function(id){
			var data = {};
    		var queryCode = "findAllCategoryQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('QueryModel');
    			console.log(response);
    			$scope.reference.categoryList = response.data.resultSet;
    			vm.initCategoryMultipleSelection();
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	};
    	
    	vm.loadFormTags = function(id){
			var data = {};
    		var queryCode = "findAllTagQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('QueryModel');
    			console.log(response);
    			$scope.reference.tagList = response.data.resultSet;
    			vm.initTagMultipleSelection();
    		}, function(errorResponse){
    			console.log(errorResponse);
			});
    	};
    	
    	vm.getAvailabilityReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllProductAvailabilityQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('Availability');
    			console.log(response);
    			$scope.reference.availabilityList =  response.data.resultSet;
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	}
    	
    	vm.getStatusReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllProductStatusQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('Status');
    			console.log(response);
    			$scope.reference.statusList =  response.data.resultSet;
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	}
    	
    	vm.getCategoryReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllCategoryQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('QueryModel');
    			console.log(response);
    			$scope.reference.categoryList = response.data.resultSet;
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	};
    	
    	vm.getBrandReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllBrandQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('QueryModel');
    			console.log(response);
    			$scope.reference.brandList = response.data.resultSet;
    		}, function(errorResponse){
    			console.log(errorResponse);
			});
    	};
    	
    	
    	vm.getSupplierReferenceList = function(){
    		var data = {};
    		//var queryCode = "findAllSupplierReferencesQueryModel";
    		var queryCode = "findAllSupplierReferencesByPermissionQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('findAllSupplierReferencesQueryModel');
    			console.log(response);
    			$scope.reference.supplierList = response.data.resultSet;
    			if($scope.reference.supplierList.length === 1){
    				$scope.form.supplier = $scope.reference.supplierList[0].id;
    			}
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	};
    	
    	vm.getRegionReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllRegionQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('findAllRegionQueryModel');
    			console.log(response);
    			$scope.reference.regionList = response.data.resultSet;
    		}, function(errorResponse){
    			console.log(errorResponse);
			});
    	};
    	
    	vm.getSellingUnitList = function(){
    		var data = {};
    		var queryCode = "findAllSellingUnitQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('QueryModel');
    			console.log(response);
    			$scope.reference.sellingUnitList = response.data.resultSet;
    		}, function(errorResponse){
    			console.log(errorResponse);
			});
    	};
    	
    	vm.getTagReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllTagQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('QueryModel');
    			console.log(response);
    			$scope.reference.tagList = response.data.resultSet;
    		}, function(errorResponse){
    			console.log(errorResponse);
			});
    	};
    	
    	vm.initializeCategory = function(){
	    	var data = {};
    		var queryCode = "findAllCategoryQueryModel";
    		var url = "query/"+queryCode;
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('QueryModel');
    			console.log(response);
    			$scope.reference.categoryList = response.data.resultSet;
    			vm.initCategoryMultipleSelection();
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	}
    	
    	vm.initializeTag = function(){
	    	var data = {};
    		var queryCode = "findAllTagQueryModel";
    		var url = "query/"+queryCode;
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('QueryModel');
    			console.log(response);
    			$scope.reference.tagList = response.data.resultSet;
    			vm.initTagMultipleSelection();
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	}
    	
    	vm.initCategoryMultipleSelection = function(){
    		$scope.reference.unselectedCategoryList = angular.copy($scope.reference.categoryList);
    		
    		if($scope.form.categories && $scope.reference.categoryList){
	    		$scope.reference.unselectedCategoryList = $scope.reference.unselectedCategoryList.filter(function(category){  		
	    			return $scope.form.categories.indexOf(category.id) === -1;
	    		});
	    		
	    		$scope.reference.selectedCategoryList = angular.copy($scope.reference.categoryList);
	    		
	    		$scope.reference.selectedCategoryList = $scope.reference.selectedCategoryList.filter(function(category){  		
	    			return $scope.form.categories.indexOf(category.id) !== -1;
	    		});
	    		
	    		console.log($scope.reference.selectedCategoryList);

    		}
    	}
    	
    	vm.initTagMultipleSelection = function(){
    		$scope.reference.unselectedTagList = angular.copy($scope.reference.tagList);
    		
    		if($scope.form.tags && $scope.reference.tagList){
	    		$scope.reference.unselectedTagList = $scope.reference.unselectedTagList.filter(function(tag){  		
	    			return $scope.form.tags.indexOf(tag.id) === -1;
	    		});
	    		
	    		$scope.reference.selectedTagList = angular.copy($scope.reference.tagList);
	    		
	    		$scope.reference.selectedTagList = $scope.reference.selectedTagList.filter(function(tag){  		
	    			return $scope.form.tags.indexOf(tag.id) !== -1;
	    		});
	    		
	    		console.log($scope.reference.selectedTagList);

    		}
    	}
    	
		// Validations
    	vm.validate = function(){
    		var isValid = true;
    		var errorMessage = 'Please provide the necessary required fields in order to proceed:<br/><br/>';
    		
    		if(!$scope.form.availability){
    			isValid = false;
    			errorMessage = errorMessage+'Availability <br/>';
    		}
    		
    		if($scope.form.isFeatured){
    			if(!$scope.form.featuredDateFrom){
    				isValid = false;
        			errorMessage = errorMessage+'Featured Date From <br/>';
    			}
    			if(!$scope.form.featuredDateFrom){
    				isValid = false;
        			errorMessage = errorMessage+'Featured Date To <br/>';
    			}
    		}
    		
    		if(!$scope.form.supplier){
    			isValid = false;
    			errorMessage = errorMessage+'Supplier <br/>';
    		}
    		    		
    		if(!$scope.form.sku){
    			isValid = false;
    			errorMessage = errorMessage+'SKU <br/>';
    		}
    		
    		if(!$scope.form.name){
    			isValid = false;
    			errorMessage = errorMessage+'Name <br/>';
    		}
    		
    		if(!$scope.form.shortDescription){
    			isValid = false;
    			errorMessage = errorMessage+'Short Description <br/>';
    		}
    		
    		if(!$scope.form.longDescription){
    			isValid = false;
    			errorMessage = errorMessage+'Long Description <br/>';
    		}
    		
    		if(!$scope.form.sellingPrice || $scope.form.sellingPrice <= 0.00){
    			isValid = false;
    			errorMessage = errorMessage+'Selling Price <br/>';
    		}
    		
    		if($scope.form.discountedPrice && $scope.form.sellingPrice){
    			if(parseFloat($scope.form.discountedPrice) >= parseFloat($scope.form.sellingPrice)){
    				alertify.alert("The discounted price should not be equal or greater than the selling price");
    				return false;
    			}
    		}
    		
    		if(!$scope.form.imageDetails || $scope.form.imageDetails.length === 0 ){
    			isValid = false;
    			errorMessage = errorMessage+'Images <br/>';
			}else{
				angular.forEach($scope.form.imageDetails, function(image, index){
					if(!image.imageUrl){
						isValid = false;
						errorMessage = errorMessage+'Image URL - record: '+index+ '<br/>';
					}else if(!image.seqNo){
						isValid = false;
	        			errorMessage = errorMessage+'Image Sequence No - record: '+index+ '<br/>';
					}
				});
			}
    		
    		if(!$scope.form.categories || $scope.form.categories.length === 0 ){
    			console.log($scope.form.categories);
    			isValid = false;
    			errorMessage = errorMessage+'Categories <br/>';
			}else{
				angular.forEach($scope.form.categories, function(value, key){
					if(!value){
						isValid = false;
	        			errorMessage = errorMessage+key+' <br/>';
					}
				});
			}
    		
    		if($scope.form.hasWarranty === true){
	    		if(!$scope.form.scope){
	    			isValid = false;
	    			errorMessage = errorMessage+'Warranty Scope <br/>';
	    		}
    		}
    		
    		if(isValid == false){
    			alertify.alert(errorMessage);
    			return false;
    		}
    		// Valid
    		return true;
    	};
    	
    	vm.validateShippingDetails = function(){
    		console.log("validateShippingDetails()");
    		for(var index = 0; $scope.form.shippingDetails.length > index; index++){
    			console.log($scope.form.shippingDetails[index].region);
				if(!$scope.form.shippingDetails[index].region){
					alertify.alert("Please supply region");
					
					return false;
				}
    			
				if($scope.form.shippingDetails[index].isFreeShipping){
					if(!$scope.form.shippingDetails[index].freeShippingMinimumOrder ||
							$scope.form.shippingDetails[index].freeShippingMinimumOrder <= 0){
						alertify.alert("Please supply the minimum order for free shipping");
						
						return false;
					}
				}else{
					if(!$scope.form.shippingDetails[index].shippingCost ||
							$scope.form.shippingDetails[index].shippingCost <= 0){
						alertify.alert("Please supply the shipping cost");
						
						return false;
					}
				}
				
				if(!$scope.form.shippingDetails[index].deliveryTime ||
						$scope.form.shippingDetails[index].deliveryTime <= 0){
					alertify.alert("Please supply delivery time");
					
					return false;
				}
			}
    		
    		return true;
    	}
    	// Initialize Page
    	vm.init();
    	
    	// Actions
    	$scope.addCategory = function(){
    		console.log($scope.unselectedItems);
    		
    		for(var index = 0; $scope.unselectedItems.length > index; index++){
    			var categoryIndex = $scope.form.categories.indexOf($scope.unselectedItems[index]);
    			if( categoryIndex === -1){
    				$scope.form.categories.push($scope.unselectedItems[index]);
    			}
    		}
    		
    		vm.initCategoryMultipleSelection();
    		console.log($scope.unselectedItems);
    	}
    	
    	$scope.removeCategory = function(){
    		//$scope.form.categories.splice(index);
    		console.log($scope.selectedItems);
    		
    		for(var index = 0; $scope.selectedItems.length > index; index++){
    			var categoryIndex = $scope.form.categories.indexOf($scope.selectedItems[index]);
    			console.log(categoryIndex);
    			if( categoryIndex !== -1){
    				$scope.form.categories.splice(categoryIndex, 1);
    			}
    		}
    		
    		vm.initCategoryMultipleSelection();
    		console.log($scope.form.categories);
    	}
        
    	$scope.addTag = function(){
    		console.log('addTag()');
    		console.log($scope.reference.unselectedTagList);
    		console.log($scope.unselectedTags);
    		console.log($scope.form.tags);
    		
    		if(!$scope.form.tags){
    			$scope.form.tags = [];
    		}
    		
    		for(var index = 0; $scope.unselectedTags.length > index; index++){
    			var tagIndex = $scope.form.tags.indexOf($scope.unselectedTags[index]);
    			if(tagIndex === -1){
    				$scope.form.tags.push($scope.unselectedTags[index]);
    			}
    		}
    		
    		vm.initTagMultipleSelection();
    		console.log($scope.unselectedTags);
    	}
    	
    	$scope.removeTag = function(){
    		console.log($scope.selectedTags);
    		for(var index = 0; $scope.selectedTags.length > index; index++){
    			var tagIndex = $scope.form.tags.indexOf($scope.selectedTags[index]);
    			console.log(tagIndex);
    			if(tagIndex !== -1){
    				$scope.form.tags.splice(tagIndex, 1);
    			}
    		}
    		
    		vm.initTagMultipleSelection();
    		console.log($scope.form.tags);
    	}
    	
    	$scope.addImage = function(){
    		if(!$scope.form.imageDetails){
    			$scope.form.imageDetails = [];
    		}
    		var image = {};
			$scope.form.imageDetails.push(image);
    		console.log($scope.form.imageDetails);
    	}
    	
    	$scope.removeImage = function(index){
    		vm.deleteUpload($scope.form.imageDetails[index].imageUrl);
    		$scope.form.imageDetails.splice(index, 1);
    	}
    	
    	$scope.addShippingDetails = function(){
    		if(vm.validateShippingDetails()){
    			var shippingDetail = {'isFreeShipping': false};
    			$scope.form.shippingDetails.push(shippingDetail);
    		}
		}
    	
    	$scope.removeShippingDetails = function(index){
    		$scope.form.shippingDetails.splice(index, 1);
    	}
    	
    	$scope.selectFile = function (element) {
    		var files = element.files;
			for (var i = 0; i < files.length; i++) {
				$scope.upload.filename = files[i].name;
				$scope.upload.file = files[i];
			}
			$scope.$apply();
			vm.uploadFile();
    	};
    	
    	$scope.selectIndex = function (index) {
    		$scope.index = index;
    	};
    	
    	vm.uploadFile = function () {
    		
			console.log('sending file...');
    		var fd = new FormData();
    		fd.append('file', $scope.upload.file);
    		fd.append('folder', 'HD-Services');
    
            $http.post("storage/uploadFile", fd, {
                    transformRequest: angular.identity,
                    headers: {
                        'Content-Type': undefined
                    }
                })
                .then(
                        function(response){
                            console.log(response);
                            $scope.form.imageDetails[$scope.index].imageUrl = response.data.url;
                        },
                        function(errResponse){
                        	alertify.alert(errResponse.data.message);
                            console.log(errResponse);
                        }
                );
    	};
    	
    	vm.deleteUpload = function (url) {
        	
			console.log('deleting file...');
    		var fd = new FormData();
    		fd.append('url', url);
    
            $http.post("storage/deleteFile", fd, {
                    transformRequest: angular.identity,
                    headers: {
                        'Content-Type': undefined
                    }
                })
                .then(
                        function(response){
                            console.log(response);
        		
                        },
                        function(errResponse){
                            console.log(errResponse);
                        }
                );
    		
    		};
    	
    	
    	$scope.save = function(){
    		if(!vm.validate()){
    			return false;
    		}
    		
    		var data = $scope.form;
    		console.log($scope.form);
    		
    		var answer = confirm('This action will save a new service. Are you sure '+
    				'you want to proceed?');
    		if(answer){
        		
        		var commandCode = "addProductCommandHandler";
        		var url = "command/"+commandCode;
        		
        		dataAccessService.doPostData(url, data, function(response){
        			console.log(response);
        			alertify.alert(response.data.messageMap['SUCCESS_MESSAGE']);
        			$location.path('/private/admin/service/list');
        		}, function(errorResponse){
        			angular.forEach($scope.form.imageDetails, function(value, key){
        				vm.deleteUpload(value.imageUrl);
        			});
        			console.log(errorResponse);
    				alertify.alert(errorResponse.data.message);
    			});
    		}
    		
    	};
    	
    	$scope.update = function(){
    		if(!vm.validate()){
    			return false;
    		}
    		
    		var data = $scope.form;
    		console.log(data);
    		
    		var answer = confirm('This action will update the selected service. Are you sure'+
    				'you want to proceed?');
    		if(answer){
        	
        		var commandCode = "updateProductCommandHandler";
        		var url = "command/"+commandCode;
        		
        		dataAccessService.doPostData(url, data, function(response){
        			console.log(response);
        			alertify.alert(response.data.messageMap['SUCCESS_MESSAGE']);
        			$location.path('/private/admin/service/list');
        		}, function(errorResponse){
        			angular.forEach($scope.form.imageDetails, function(value, key){
        				vm.deleteUpload(value.imageUrl);
        			});
        			console.log(errorResponse);
    				alertify.alert(errorResponse.data.message);
    			});
    		}
    	};
    	
    	$scope.getPercentDiscount = function(partPrice, wholePrice){
    		var discount = 0;
    		console.log('partPrice: '+partPrice);
    		console.log('wholePrice: '+wholePrice);
    		if(partPrice && partPrice > 0 && wholePrice && wholePrice > 0){
    			
    			discount = ((wholePrice - partPrice) / wholePrice) * 100;
    		}
    		
    		console.log('discount: '+discount);
    		
    		return Math.round(discount);
    	}
    	
    	$scope.setSupplierVisibility = function(){
    		if($scope.form.availability === 'FOR_QUOTATION'){
    			$scope.form.isSupplierVisible = true;
    		}
    	}
    	
    	$scope.validateImageSeqNo = function(recordNo, seqNo){
    		console.log('validateImageSeqNo()');
    		console.log(recordNo);
    		console.log(seqNo);
    		for(var index = 0; index < $scope.form.imageDetails.length; index++){
    			if(recordNo !== index){
    				console.log('index: '+index);
    				console.log('seqNo: '+$scope.form.imageDetails[index].seqNo);
    				console.log('equal: '+$scope.form.imageDetails[index].seqNo == seqNo);
    				if($scope.form.imageDetails[index].seqNo == seqNo){
    					$scope.form.imageDetails[recordNo].seqNo = '';
    					alertify.alert('Duplicate image sequence no found!');
    					return false;
    				}
    			}
    		}
    	}
    	
	}]);
	
});