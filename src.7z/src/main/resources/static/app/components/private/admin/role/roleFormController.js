/**
 * 
 */
'use strict';
define(function(){
	var adminModules = angular.module('adminModules');
	console.log('Loading roleFormController');
	
	adminModules.register.controller('roleFormController', [
		'$rootScope', 
		'$scope', 
		'$location', 
		'DataAccessService', 
		'alertify', 
		'$routeParams',
		function ($rootScope, $scope, $location, dataAccessService, alertify, $routeParams){
    	console.log('roleModules.controller');
    	var vm = this;
    	
    	vm.init = function(){
    		console.log('roleFormController.init()');
    		
    		$scope.formTitle = 'Role Form';
    		$scope.form = {};
    		
    		if($routeParams.id && $routeParams.id > 0){
    			vm.loadForm($routeParams.id);
    		}
    	};
    	
    	vm.loadForm = function(id){
    		var data = {'id' : id};
    		var queryCode = "findRoleByIDQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('QueryModel');
    			console.log(response);
    			$scope.form = response.data.resultSet[0];
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    		
    	};
    	
    	vm.init();
    	
    	$scope.save = function(){
    		if(!$scope.form.code){
    			alertify.alert("Please enter the code");
    			return false;
    		}
    		if(!$scope.form.description){
    			alertify.alert("Please enter the description");
    			return false;
    		}
    		
    		var answer = confirm('This action will save the newly created item. Are you sure'+
    				'you want to proceed?');
    		
    		if(answer){
    			$scope.form.createdBy = "ADMINISTRATOR";
        		
        		var data = $scope.form;
        		
        		var commandCode = "addRoleCommandHandler";
        		var url = "command/"+commandCode;
        		
        		dataAccessService.doPostData(url, data, function(response){
        			console.log(response);
        			alertify.alert('The item is successfully saved');
        		}, function(errorResponse){
        			alertify.alert(errorResponse);
    			});
    		}
    	};
    	
    	$scope.update = function(){
    		if(!$scope.form.code){
    			alertify.alert("Please enter the code");
    			return false;
    		}
    		if(!$scope.form.description){
    			alertify.alert("Please enter the description");
    			return false;
    		}
    		
    		var answer = confirm('This action will update the selected item. Are you sure'+
    				'you want to proceed?');
    		
    		if(answer){
    			$scope.form.lastModifiedBy = "ADMINISTRATOR";
        		
        		var data = $scope.form;
        		
        		var commandCode = "updateRoleCommandHandler";
        		var url = "command/"+commandCode;
        		
        		dataAccessService.doPostData(url, data, function(response){
        			console.log(response);
        			alertify.alert('The item is successfully updated');
        		}, function(errorResponse){
        			alertify.alert(errorResponse);
    			});
    		}
    	};
    	
    	$scope.delete = function(){
    		var answer = confirm('This action will delete the selected item. Are you sure'+
    				'you want to proceed?');	
    		if(answer){
        		var data = {'id' : $scope.form.id};
        		
        		var commandCode = "deleteRoleCommandHandler";
        		var url = "command/"+commandCode;
        		
        		dataAccessService.doPostData(url, data, function(response){
        			console.log(response);
        			alert('The item is successfully deleted');
        		}, function(errorResponse){
        			alertify.alert(errorResponse);
    			});
    		}
    	};
    	
	}]);
	
});