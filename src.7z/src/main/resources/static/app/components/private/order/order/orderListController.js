/**
 * 
 */
'use strict'
define(function(){
	var orderModule = angular.module('orderModule');
	console.log('Loading homeController');
	
	orderModule.register.controller('orderListController', ['$rootScope', '$scope', 'DataAccessService', 
			'alertify', 'ngTableParams', '$location', 
		function ($rootScope, $scope, dataAccessService, alertify, ngTableParams, $location){
    	console.log('Registering orderListController...');   
    	
    	var vm = this;
    	
    	vm.init = function(){
    		$scope.form = {};
    		$scope.reference = {};
    		$scope.searchCriteria = {};
    		
    		vm.getQueryList();
    		vm.getSupplierReferenceList();
    		vm.getOrderStatus();
    	}
    	
    	vm.getQueryList = function(){
    		$scope.tableParams = new ngTableParams({
                page: 1,
                count: 10
            }, {
                getData: function ($defer, params) {
                	var data = {'pageIndex' : params.page(),
            					'pageSize': params.count(),
            					'searchCriteria': $scope.searchCriteria
            			   	   };
                	
                	var queryCode = "findAllOrdersQueryModel";
                	var url = "query/"+queryCode;
                 dataAccessService.doPostData(url, data, function(response){
        			console.log('QueryModel *********');
        			console.log(response);
        			$scope.form.resultSet = response.data.resultSet;
        			$scope.form.columns = response.data.columns;
        			params.total(response.data.resultOverAllCount);
        			$defer.resolve($scope.form.resultSet);
        			
        		}, function(errorResponse){
    				alert(response);
    				$scope.close();
    			});
                	
                }
            });
    	};
    	
    	vm.getSupplierReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllSupplierReferencesQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('findAllSupplierReferencesQueryModel');
    			console.log(response);
    			$scope.reference.supplierList = response.data.resultSet;
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	};    	
    	
    	vm.getOrderStatus = function(){
    		var data = {};
    		var queryCode = "findAllOrderStatusQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('OrderItemStatus');
    			console.log(response);
    			$scope.reference.orderStatusList =  response.data.resultSet;
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	}
    	
    	
    	// Initialize Form
    	vm.init();
    	
    	$scope.search = function(){
    		console.log($scope.searchCriteria);
    		$scope.tableParams.reload();
    	}
    	
    	$scope.showAll = function(){
    		$scope.searchCriteria = {};
    		$scope.tableParams.reload();
    	}
    	
    	$scope.viewOrderDetails = function(orderID){
    		$location.path('/private/order/orderForm/'+orderID);
    	}
    	
    	$scope.viewPurchaseOrder = function(orderNo){
    		var data = {};
    		data.orderNo = orderNo;
    		var reportCode = "purchaseOrderDataGenerator";
    		var url = "report/"+reportCode+"/"+orderNo;
    		
    		window.location.href = url;
    		
//    		dataAccessService.doGetData(url, data, function(response){
//    			console.log('viewPurchaseOrder');
//    			console.log(response);
//    			
//    			//alert(response.data);
//    			
//    			
//    			
//    		}, function(errorResponse){
//				console.log(errorResponse);
//			});
    	}
    	
    	$scope.viewSalesInvoice = function(orderNo){
    		var data = {};
    		data.orderNo = orderNo;
    		var reportCode = "salesInvoiceDataGenerator";
    		var url = "report/"+reportCode+"/"+orderNo;
    		
    		window.location.href = url;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('viewSalesInvoice');
    			console.log(response);
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	}
	}]);
	
});