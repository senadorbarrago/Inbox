/**
 * 
 */
'use strict'
define([
    //'../app/components/public/home/homeController',
    //'../app/components/public/about/aboutController',
    //'../app/components/public/contact/contactController'
	//'../app/components/public/product/list/productListingController'
], function(){});