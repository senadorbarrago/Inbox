/**
 * 
 */
'use strict';
define(function(){
	var publicModules = angular.module('publicModules');
	console.log('Loading termsController');
	
	publicModules.register.controller('termsController', ['$rootScope', '$scope', 'DataAccessService', 'alertify',
		function ($rootScope, $scope, dataAccessService, alertify){
    	console.log('Registering termsController...');
    	var vm = this;
    	
    	vm.init = function(){
    		console.log('termsController.init()');

    	};
    	
    	vm.init();

	}]);
	
});