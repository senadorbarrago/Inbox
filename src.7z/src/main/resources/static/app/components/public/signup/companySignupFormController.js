/**
 * 
 */
'use strict';
define(function(){
	var adminModules = angular.module('adminModules');
	console.log('Loading companySignupFormController');
	
	adminModules.register.controller('companySignupFormController', [
		'$rootScope', 
		'$scope', 
		'$http', 
		'DataAccessService',  
		'alertify', 
		'$routeParams',
		'$location',
		function ($rootScope, $scope, $http, dataAccessService, alertify, $routeParams, $location){
    	console.log('adminModules.controller');
    	var vm = this;
    	
    	vm.init = function(){
    		console.log('companySignupFormController.init()');
    		
    		$scope.formTitle = 'Seller Registration';
    		$scope.form = {};
    		$scope.form.sameAddress = false;
    		
    		let companyCode = $routeParams.companyCode;
    		
    		$scope.reference = {};
    		vm.getCountryReferenceList();
    		vm.getRegionReferenceList();
    		vm.getSupplierReferenceList(companyCode);
    		
    	};
    	
    	vm.getCountryReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllCountryQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('QueryModel');
    			console.log(response);
    			$scope.reference.countryList = response.data.resultSet;
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	};
    	
    	vm.getRegionReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllRegionQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('findAllRegionQueryModel');
    			console.log(response);
    			$scope.reference.regionList = response.data.resultSet;
    		}, function(errorResponse){
    			console.log(errorResponse);
			});
    	};
    	
    	vm.getSupplierReferenceList = function(companyCode){
    		
    		var data = {'encryptedCode': companyCode};
    		var queryCode = "findAllSupplierByHashReferencesQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('findAllSupplierByHashReferencesQueryModel');
    			console.log(response);
    			$scope.reference.supplierList = response.data.resultSet;
    			$scope.form.supplier = $scope.reference.supplierList[0].id;
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	};
    	
    	vm.validate = function(){
    		var isValid = true;
    		var errorMessage = 'Please provide the necessary required fields in order to proceed:</br>';
    		
    		if(!$scope.form.username){
    			isValid = false;
    			errorMessage = errorMessage+'Email </br>';
    		}
    		if(!$scope.form.firstname){
    			isValid = false;
    			errorMessage = errorMessage+'Firstname </br>';
    		}
    		if(!$scope.form.lastname){
    			isValid = false;
    			errorMessage = errorMessage+'Lastname </br>';
    		}
    		if(!$scope.form.contactNumber){
    			isValid = false;
    			errorMessage = errorMessage+'Contact Number </br>';
    		}
    		if(!$scope.form.supplier || $scope.form.supplier.length === 0 ){
    			console.log($scope.form.supplier);
    			isValid = false;
    			errorMessage = errorMessage+'Company Name </br>';
			}else{
				angular.forEach($scope.form.supplier, function(value, key){
					if(!value){
						isValid = false;
	        			errorMessage = errorMessage+key+' </br>';
					}
				});
			}
    		
    		if(isValid == false){
    			alertify.alert(errorMessage);
    			return false;
    		}
    		// Valid
    		return true;
    	};
    	
    	
    	vm.init();
    	
    	$scope.register = function(){
    		
    		if(!vm.validate()){
    			return false;
    		}

    		var answer = confirm('This action will create your new account in Hotel Depot. Are you sure '+
			'you want to proceed?');
    		
    		if(answer){
    			$scope.form.createdBy = "ADMINISTRATOR";
    			$scope.form.contextPath = $location.absUrl();
        		
        		var data = $scope.form;
        		data.contextPath = $location.absUrl().substr(0, $location.absUrl().lastIndexOf("#"));
        		
        		var commandCode = "addCompanyCommandHandler";
        		var url = "command/"+commandCode;
        		
        		dataAccessService.doPostData(url, data, function(response){
        			console.log(response);
        			alertify.alert(response.data.messageMap['SUCCESS_MESSAGE']);
        			$location.path('/public/security/login');
        		}, function(errorResponse){
        			console.log(errorResponse);
        			alertify.alert(errorResponse.data.message);
    			});
    		}
    	};
    	
    	$scope.companyOnChange = function(){
    		var data = {'id' : $scope.form.supplier};
    		var queryCode = "findSupplierByIDQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('QueryModel');
    			console.log(response);
    			$scope.form.businessStyle = response.data.resultSet[0].businessStyle;
    			$scope.form.companyTin = response.data.resultSet[0].companyTin;
    			$scope.form.sameAddress = response.data.resultSet[0].sameAddress;
    			$scope.form.addressLine = response.data.resultSet[0].addressLine;
    			$scope.form.city = response.data.resultSet[0].city;
    			$scope.form.region = response.data.resultSet[0].region;
    			$scope.form.postal = response.data.resultSet[0].postal;
    			$scope.form.country = response.data.resultSet[0].country;
    			$scope.form.addressLine2 = response.data.resultSet[0].addressLine2;
    			$scope.form.city2 = response.data.resultSet[0].city2;
    			$scope.form.region2 = response.data.resultSet[0].region2;
    			$scope.form.postal2 = response.data.resultSet[0].postal2;
    			$scope.form.companyTin2 = response.data.resultSet[0].companyTin2;
    			$scope.form.country2 = response.data.resultSet[0].country2;
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    		
    	}
    	    	
	}]);
	
});