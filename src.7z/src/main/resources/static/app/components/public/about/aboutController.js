/**
 * 
 */
'use strict';
define(function(){
	var publicModules = angular.module('publicModules');
	console.log('Loading aboutController');
	
	publicModules.register.controller('aboutController', ['$rootScope', '$scope', 'DataAccessService', 'alertify',
		function ($rootScope, $scope, dataAccessService, alertify){
    	console.log('Registering AboutController...');
    	var vm = this;
    	
    	vm.init = function(){
    		console.log('aboutController.init()');
    		
    		$scope.form = {};
    		
    		vm.loadForm();
    		$scope.owlOptionsTestimonials = {
    	            autoPlay: 3000,
    	            stopOnHover: true,
    	            slideSpeed: 300,
    	            paginationSpeed: 600,
    	            items: 2
    	   }

    	};
    	
    	vm.loadForm = function(){
    		var data = {
    					'pageIndex' : 1,
    					'pageSize' : 100,
    		};
    		
    		var queryCode = "brandAdsListQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('findAllBrandAdsQueryModel');
    			console.log(response);
    			
    			$scope.form.brandAdsList = response.data.resultSet;   
    			
    		}, function(errorResponse){
    			alertify.alert(errorResponse);
				console.log(errorResponse);
			});
    		
    		queryCode = "findAllPartnerAdsQueryModel";
    		url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('findAllPartnerAdsQueryModel');
    			console.log(response);
    			
    			$scope.form.partnerAdsList = response.data.resultSet;   
    			
    		}, function(errorResponse){
    			alertify.alert(response);
				console.log(errorResponse);
			});
    		
    		
    	};
    	
    	vm.init();


	}]);
	
});