/**
 * 
 */
'use strict';
define(function(){
	var adminModules = angular.module('adminModules');
	console.log('Loading contactController');
	
	adminModules.register.controller('contactController', ['$rootScope', '$scope', '$http', 
		'DataAccessService', 'alertify', '$location', '$cookies',
		function ($rootScope, $scope, $http, dataAccessService, alertify, $location, $cookies){
    		console.log('adminModules.controller');
    		var vm = this;
    		
	    	vm.init = function(){
	    		console.log('contactController.init()');
	    		
	    		$scope.formTitle = 'Contact Form';
	    		$scope.form = {};
	    		
	    		vm.findMainStore();
	    	};
	    	
	    	vm.findMainStore = function(){
				var queryCode = "findMainStoreAddressInfoQueryModel";
				let data = {};
				var url = "query/" + queryCode;

				dataAccessService.doPostData(url, data, function(response) {
					$scope.form.mainStore = response.data.resultSet[0];
				}, function(errorResponse) {
					alertify.alert(response);
					console.log(errorResponse);
				});
	    	}
	    	
	    	vm.init();
	    	
	    	$scope.submit = function(){
	    		if(!$scope.form.name){
	    			alertify.alert("Please enter your name");
	    			return false;
	    		}
	    		
	    		if(!$scope.form.email){
	    			alertify.alert("Please enter your email");
	    			return false;
	    		}
	    		
	    		if(!$scope.form.subject){
	    			alertify.alert("Please enter the subject of your email");
	    			return false;
	    		}
	    		
	    		if(!$scope.form.description){
	    			alertify.alert("Please enter your message");
	    			return false;
	    		}
	    		
	    		var answer = true;
		
				if(answer){
					$scope.form.createdBy = $scope.form.email;
		    		
		    		var data = $scope.form;
		    		
		    		data.contextPath = $location.absUrl().substr(0, $location.absUrl().lastIndexOf("#"));
		    		
		    		var commandCode = "contactCommandHandler";
		    		var url = "command/"+commandCode;
		    		
		    		dataAccessService.doPostData(url, data, function(response){
		    			console.log(response);
		    			vm.init();
		    			alertify.alert('Your email has been sent. We will contact you as soon as possible. Thank you!');
		    		}, function(errorResponse){
		    			console.log(errorResponse);
	    				alertify.alert(errorResponse.data.message);
					});
				}
			};
			
	    	
    	
	}]);
	
});