/**
 * 
 */
'use strict';
define(function(){
	var publicModules = angular.module('publicModules');
	console.log('Loading supplierBrandController');
	
	publicModules.register.controller('supplierBrandController', [
		'$rootScope', 
		'$scope',
		'$location',
		'ngTableParams', 
		'DataAccessService',
		'alertify',
		'$routeParams',
		'crumble',
		function ($rootScope, $scope, $location, ngTableParams, dataAccessService, alertify, $routeParams, crumble){
    	console.log('publicModules.controller');
    	var vm = this;
    	
    	vm.init = function(){
    		console.log('supplierBrandController.init()');
    		$scope.title = $routeParams.supplierCode;
    		$scope.form = {};
    		$scope.subtitle = 'Brands'; 
    		
    		var link = {};
            link.title = $routeParams.supplierCode;
            crumble.context = {'link':link};
            
            console.log(crumble);
    		crumble.update();
            $rootScope.crumble = crumble;
           

            $scope.breadcrumb = {};
    		$scope.breadcrumb.mode = $routeParams.supplierCode;
    		
    		
    		$scope.searchCriteria = {};
    		$scope.searchCriteria.showDeleted = false;
    		$scope.searchCriteria.supplierID = $routeParams.supplierID;
    		
    		vm.getSupplierHeader();
    		vm.getSupplierBrands();   
    	};
    	
    	vm.getSupplierHeader = function(){
    		var data = { 'supplierID' : $scope.searchCriteria.supplierID};

    		var queryCode = "supplierHeaderQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('supplierBrandListQueryModel');
    			console.log(response);
    			$scope.form.supplier = response.data.resultSet[0];
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	};
    	
    	vm.getSupplierBrands = function(){
    		var data = {
    					'pageIndex' : 1,
    					'pageSize': 100,
    					'searchCriteria': $scope.searchCriteria
		   	   		};

    		var queryCode = "supplierBrandListQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('QueryModel');
    			console.log(response);
    			$scope.supplierBrandList = response.data.resultSet;
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	};
    	
    	vm.init();
    	
	}]);
	
});