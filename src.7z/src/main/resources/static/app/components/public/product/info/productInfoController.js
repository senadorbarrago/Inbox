/**
 * 
 */
'use strict';
define(function(){
	var publicModules = angular.module('adminModules');
	console.log('Loading productInfoController');
	
	publicModules.register.controller('productInfoController', [
		'$rootScope', 
		'$scope', 
		'ngTableParams',
		'$uibModal', 
		'$http', 
		'$filter',
		'DataAccessService', 
		'$routeParams',
		'$location',
		'alertify',
		function ($rootScope, $scope, ngTableParams, $uibModal, 
				$http, $filter, dataAccessService, $routeParams,$location, alertify){
    	console.log('Registering productInfoController...');
    	var vm = this;
    	
    	vm.init = function(){
    		console.log('productInfoController.init()');
    		$rootScope.title = 'Product Info';
    		var id = $routeParams.productID;
    		
    		$scope.form = {};
    		$scope.ref={};
    		$scope.filter={};
    		$scope.cart = {};
    		$scope.cart.items = [];
    		
    		vm.proceed = false;
    		vm.getProduct(id);
    		vm.loadCart();
    		
    		
    		angular.element(document.querySelector("#nav-description")).addClass("active");
    		$scope.tdClass = 'tab-pane fade in active';
    		
    		/* temp only */
			$scope.productImagesSettings = {
				autoPlay : false,
				stopOnHover : true,
				items : 6,
				navigation : false,
				lazyLoad:true,
			    itemsDesktopSmall : [960,8],
			    itemsDesktop : [1024,5],
			    itemsDesktop : [1199,5],
			    itemsDesktop : [1280,6],
			}
			
			/* temp only */
			$scope.relatedProductSettings = {
				autoPlay : 3000,
				stopOnHover : true,
				slideSpeed : 300,
				paginationSpeed : 600,
				items : 5
			}
    	};
    	
    	vm.initTabs = function(){
    		$scope.tabs = [];
    		
    		if($scope.form.longDescription){
	    		// Long Description
	    		$scope.tabs.push({
					'id'       : 'desc',
					'label'	   : 'Description',
					'active'   : false,
				});
    		}
    		
    		// Lead Time
    		$scope.tabs.push({
				'id'       : 'leadTime',
				'label'	   : 'Lead Time & Shipment',
				'active'   : false,
			});
    		
    		// Warranty
    		$scope.tabs.push({
				'id'       : 'warranty',
				'label'	   : 'Warranty',
				'active'   : false,
			});
    		
    		// Activate the first tab
    		$scope.tabs[0].active = true;
    		
    	}
    	
    	$scope.activateTab = function(tabID){
    		angular.forEach($scope.tabs, function(value, key){
    			if(value.id === tabID){
    				value.active = true;
    			}else{
    				value.active = false;
    			}
    		});
    	}
    	
    	$scope.isTabActive = function(tabID){
    		if($scope.tabs){
    			let clazz = {};
    			
    			angular.forEach($scope.tabs, function(tab){
    				if(tab.id === tabID){
	    				console.log('tab:'+ tabID);
	    				clazz = {'in' : tab.active, 'active' : tab.active};
	    			}
	    		});
    			
    			return clazz;
    		}
    	}
    	
    	$scope.scrollTo = function(id) {
    		 console.log("**** id is " + id)
    		 if(id == 'td'){
    			 angular.element(document.querySelector("#nav-description")).addClass("active");
    			 angular.element(document.querySelector("#nav-leadtime")).removeClass("active");
    			 angular.element(document.querySelector("#nav-warranty")).removeClass("active");
    			 $scope.tdClass = 'tab-pane fade in active';
    	    		 $scope.tlClass = 'tab-pane fade in ';
    	    		 $scope.twClass = 'tab-pane fade in ';
    	    		
    		 }
    		 if(id == 'tl'){
    			 angular.element(document.querySelector("#nav-description")).removeClass("active");
    			 angular.element(document.querySelector("#nav-leadtime")).addClass("active");
    			 angular.element(document.querySelector("#nav-warranty")).removeClass("active");
    			 $scope.tdClass = 'tab-pane fade in ';
    	    		 $scope.tlClass = 'tab-pane fade in active';
    	    		 $scope.twClass = 'tab-pane fade in ';
    	    		
    		 }if(id == 'tw'){
    			 angular.element(document.querySelector("#nav-description")).removeClass("active");
    			 angular.element(document.querySelector("#nav-leadtime")).removeClass("active");
    			 angular.element(document.querySelector("#nav-warranty")).addClass("active");
    			 $scope.tdClass = 'tab-pane fade in ';
    	    		 $scope.tlClass = 'tab-pane fade in ';
    	    		 $scope.twClass = 'tab-pane fade in active';
    	    		
    		 }
    	     //$location.hash(id);
    	     //$anchorScroll();
    	  }
    	
    	vm.getProduct = function(id){    		
    		var data = {'id' : id};
    		var queryCode = "productInfoQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('productDetailsQueryModel');
    			console.log(response);
    			$scope.form = response.data.resultSet[0];
    			vm.initializeCartItemQuantity();
    			vm.getRelatedProducts($scope.form.tags);
    			
    			if($scope.form.forPickUp === true){
    				vm.findMainStore();
    			}
    			
    			// Initialize tabs
    			vm.initTabs();
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    		
    	};
    	
    	vm.getRelatedProducts = function(tagIds){    		
    		var data = {
    					'tagIds' : tagIds,
    					'pageIndex' : 1,
    					'pageSize'	: 50
    					}
    		var queryCode = "relatedProductListQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('relatedProductListQueryModel');
    			console.log(response);
    			$scope.form.relatedProductList = response.data.resultSet;
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    		
    	};
    	
    	vm.findMainStore = function(){
			var queryCode = "findMainStoreAddressInfoQueryModel";
			let data = {};
			var url = "query/" + queryCode;

			dataAccessService.doPostData(url, data, function(response) {
				$scope.form.mainStore = response.data.resultSet[0];
				$scope.form.mainStore.mainStoreContactUsUrl = $location.absUrl().substr(0, $location.absUrl().lastIndexOf("#")+1)+$scope.form.mainStore.mainStoreContactUsUrl;
			}, function(errorResponse) {
				alertify.alert(response);
				console.log(errorResponse);
			});
    	}
    	
    	vm.loadBreadCrumb = function(){
    		var data = {};
    		var queryCode = "findAllCategoryQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('QueryModel : $$$$$$ Main Category');
    			console.log("Parameter : "+$routeParams.search);
    			console.log(response);
    			
    			for(var i = 0; i < response.data.resultSet.length; i++) {
    			    var data= response.data.resultSet[i];
    			    console.log("MAIN " + data.secondary);
    			    
    			    if(data.description == $routeParams.search){
    			    		$scope.catBreadCrumb = data.description;
    			    		$scope.catSecondary = data.secondary;
    			    }
    			}
    			
    			for(var i = 0; i < $scope.secCatMod.length; i++) {
    			    var data= $scope.secCatMod[i];
    			    console.log("SECONDARY "+ data.description);
    			    
    			    if(data.description == $scope.catSecondary){
    			    		$scope.secBreadCrumb = data.description;
    			    		$scope.primBreadCrumb = data.parent;
    			    }
    			}
    			
    		}, function(errorResponse){
    			console.log(errorResponse);
    		});
    	};
    	
    	vm.initializeCartItemQuantity = function(){
    	console.log('$scope.form.minimumOrder: '+$scope.form.minimumOrder);
  		  if($scope.form.availability === 'FOR_SALE'){
  			  $scope.form.cartItemQuantity = $scope.form.minimumOrder;
  		  }else{
  			  $scope.form.cartItemQuantity = 0;
  		  }
  		  console.log('$scope.form.cartItemQuantity: '+$scope.form.cartItemQuantity);
  	  	}
    	
    	
    	vm.loadCart = function(){
    		var data = {};
    		var queryCode = "findCartByUserIDQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('Cart');
    			console.log(response);    			
    			$scope.cart.items = response.data.resultSet;
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	}
    	
    	/**
      	 * 
      	 */
      	vm.showSecureAccessForm = function(mode){
    		var modalInstance = $uibModal.open({
    			animation: true,
    			backdrop: 'static',
    			templateUrl: 'app/components/public/security/secureAccessForm.html',
    			controller: 'secureAccessController',
    			size: 'md',
    			keyboard: false,
    			resolve 	 : {
    				load: ['$q', function($q){
	    					var defered = $q.defer();
	    					require(['app/components/public/security/secureAccessController.js'], function(){
	    						defered.resolve();
	    					});
		    			return defered.promise;
					}],
    				data	 : function(){
    					var data = $scope.form;
    					return data;
    				}
    			}
            });
            modalInstance.result.then(function(message){
                // success()
            	// triggered by addToCart
            	if(message !== 'close'){
	            	if(mode === 'addToCart'){
	            		$scope.addToCart($scope.form);
	            	}
	            	// triggered by contactSeller
	            	if(mode === 'contactSeller'){
	            		$scope.contactSeller($scope.form);
	            	}
            	}
            },
            function() {                
            	// dismiss()
            	console.log('dismissed');
            });
            
            return modalInstance.result; 
    	};
    	
    	vm.init();
    	
    	/**
    	 * 
    	 */
    	$scope.getPercentDiscount = function(partPrice, wholePrice){
    		var discount = 0;
    		if(partPrice && partPrice > 0 && wholePrice && wholePrice > 0){
    			discount = ((wholePrice - partPrice) / wholePrice) * 100;
    		}
    		
    		return Math.round(discount);
    	}
    	
    	/**
    	 * 
    	 */
    	$scope.addToCart = function(product){
    		// Redirect to Buyer Registration Page when not authenticated
    		if(!$rootScope.session['AUTHENTICATED'] || $rootScope.session['AUTHENTICATED'] === false){
    			vm.showSecureAccessForm('addToCart');
    		}else{
    			if(!$rootScope.hasResourcePermission('addToCartButton') ||
    				$rootScope.hasResourcePermission('addToCartButton') === false){
    				alertify.alert('Only the registered buyer can only access the shopping cart!');
    				return false;
    			}
	    		
	    		var data = {};
	    		data.productID = product.id;
	    		data.quantity = $scope.form.cartItemQuantity;
	    		data.customerID = $rootScope.session['AUTHENTICATED_USER'].userID;
	    		data.createdBy = $rootScope.session['AUTHENTICATED_USER'].username;
	    		
	    		console.log(data);
	    		
	    		var commandCode = "addItemToCartCommandHandler";
	    		var url = "command/"+commandCode;
	    		
	    		dataAccessService.doPostData(url, data, function(response){
	    			console.log(response);
	    			$rootScope.loadCartItemsCount();
	    			vm.loadCart();
	    		}, function(errorResponse){
					alertify.alert(errorResponse.data.message);
				});
    		}
    	}
    	
    	/**
    	 * 
    	 */
    	$scope.contactSeller = function (selectedObject) {
    		// Redirect to Buyer Registration Page when not authenticated
    		if(!$rootScope.session['AUTHENTICATED'] || $rootScope.session['AUTHENTICATED'] === false){
    			vm.showSecureAccessForm('contactSeller');
    		}else{
    			if(!$rootScope.hasResourcePermission('askForQuotationButton') ||
    				$rootScope.hasResourcePermission('askForQuotationButton') === false){
    				alertify.alert('Only the registered buyer can only contact seller!');
    				return false;
    			}
    		
	    	    $uibModal.open({
	    	    	templateUrl  : 'app/components/private/order/quote/askForQuotationForm.html',
	    			controller   : 'askForQuotationFormController',
	    			backdrop	 : "static",
	    			close		 : 'close',
	    			size		 : "lg",
	    			resolve 	 : {
	    				load: ['$q', function($q){
			    					var defered = $q.defer();
			    					require(['app/components/private/order/quote/askForQuotationFormController.js'], function(){
			    						defered.resolve();
			    					});
			    			return defered.promise;
						}],
	    				params	 : function(){
	    					var params = {
	    							"id" 		   : selectedObject.id,
	    							"productCode"  : selectedObject.sku,
	    							"productName"  : selectedObject.name,
	    							"moq" 		   : selectedObject.minimumOrder,
	    							"sellingPrice" : selectedObject.sellingPrice,
	    							"supplierID"   : selectedObject.supplier 
	    					}
	    					return params;
	    				}
	    			}
	    	    })
	    	    .result.then(
		            //close
		            function (result) {
		                var a = result;
		                console.log('SUCCESS');
	            },
		            //dismiss
		            function (result) {
		                var a = result;
		                console.log('DISMISSED');
	            });
    		}
    	  };
    	  
    	  $scope.addCartItemQuantity = function(){
    		  console.log('$scope.form.minimumorder: '+$scope.form.minimumOrder);
    		  if($scope.form.cartItemQuantity < $scope.form.noOfStock){
    			  if($scope.form.cartItemQuantity + $scope.form.quantityPerPack <= $scope.form.noOfStock){
    				  $scope.form.cartItemQuantity = $scope.form.cartItemQuantity + $scope.form.quantityPerPack;
    			  }else{
    				  alertify.alert("Cart items will exceeded the number of stock available!");
    			  }
    		  }else{
    			  alertify.alert("Cart items will exceed the number of stock available!");
    		  }
    	  }
    	  
    	  $scope.subtractCartItemQuantity = function(){
    		  console.log('$scope.form.cartItemQuantity: '+$scope.form.cartItemQuantity);
    		  console.log('$scope.form.quantityPerPack: '+$scope.form.quantityPerPack);
    		  console.log('$scope.form.minimumorder: '+$scope.form.minimumOrder);
    		  if($scope.form.cartItemQuantity > 0){
    			  if($scope.form.cartItemQuantity - $scope.form.quantityPerPack > 0 && 
    					  $scope.form.cartItemQuantity - $scope.form.quantityPerPack >= $scope.form.minimumOrder){
    				  $scope.form.cartItemQuantity = $scope.form.cartItemQuantity - $scope.form.quantityPerPack;
    		  	}else{
    		  		$scope.form.cartItemQuantity = 0;
    		  	}
    		  }else{
    			  $scope.form.cartItemQuantity = 0;
    		  }
    	  }
    	  
    	  $scope.removeItemFromCart = function(itemID){
      		console.log(itemID);
      		var data = {
      					'itemID' : itemID
      					};
      		
      		var commandCode = "removeItemFromCartCommandHandler";
      		var url = "command/"+commandCode;
      		
      		dataAccessService.doPostData(url, data, function(response){
      			console.log(response);
      			$rootScope.loadCartItemsCount();
      			vm.loadCart();
      		}, function(errorResponse){
  				alert(errorResponse);
  			});
      	}
    	
    	$scope.displayPrice = function(sellingPrice, discountedPrice){
    		if(discountedPrice && discountedPrice > 0.00){
    			return discountedPrice;
    		}else{
    			return sellingPrice;
    		}
    	}  
    	  
    	$scope.computeTotal = function(){
    		var total = 0;
    		if($scope.cart && $scope.cart.items){
    			angular.forEach($scope.cart.items, function(value, key){
    				if(value.discountedPrice && value.discountedPrice > 0.00){
    	    			total = total + (value.discountedPrice * value.quantity);
    	    		}else{
    	    			total = total + (value.sellingPrice * value.quantity);
    	    		}
				});
    		}
    		
    		return total;
    	}  
    	
    	$scope.addItemToWishList = function(productID){
    		if(!$rootScope.isAuthenticated()){
    			alertify.alert('Please signup first in order to continue. Thank you!');
    			$location.path("/public/security/login");
    			return false;
    		}
    		
    		console.log(productID);
    		var data = {
    					'productID' : productID
    					};
    		
    		var commandCode = "addItemToWishListCommandHandler";
    		var url = "command/"+commandCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log(response);
    			alertify.alert(response.data.messageMap['SUCCESS_MESSAGE']);
    		}, function(errorResponse){
    			console.log(errorResponse);
				alertify.alert(errorResponse.data.message);
			});
    	}
    	
    	/**
    	 * 
    	 */
    	$scope.getDiscountQuantityField = function(wholeSalePricing){
    		if(wholeSalePricing){
    			if(!wholeSalePricing.maxOrder){
    				return $filter('number')(wholeSalePricing.minOrder, 0) +' pcs and above'
    			}else{
    				return $filter('number')(wholeSalePricing.minOrder, 0) +' - '+ $filter('number')(wholeSalePricing.maxOrder, 0) +' pcs'
    			}
    		}
    	}
    	
    	
    	/**
    	 * 
    	 */
    	$scope.getWarranty = function(){
    		let warranty = 'No Warranty';
    		if($scope.form.scope){
    			warranty = $scope.form.scope +' month(s)';
    		}
    		if($scope.form.details){
    			warranty = $scope.form.scope +' - '+ $scope.form.details;
    		}
    		return warranty;
    	}
    	
    	/*
    	 * 
    	 */
    	$scope.goToProductInfo = function(id){
    		$location.path('public/product/info/'+id);
    	}
    	
    	$scope.getRelatedProductPrice = function(product){
    		if(product.discountedPrice && product.discountedPrice > 0){
    			return $filter('number')(product.discountedPrice, 2);
    		}else {
    			return $filter('number')(product.regularPrice, 2);
    		}
    	}
    	
	}]);
	
});