/**
 * 
 */
'use strict';
define(function(){
	var publicModules = angular.module('adminModules');
	console.log('Loading productListController');
	
	publicModules.register.controller('searchResultController', ['$rootScope', '$scope', 'ngTableParams', 
		'$uibModal', '$http', '$location', 'DataAccessService', '$window', 'crumble', function ($rootScope, $scope, ngTableParams, $uibModal, 
				$http, $location, dataAccessService, $window, crumble){
		
    	var vm = this;
    	
    	/**
    	 * Initialization
    	 */
    	vm.init = function(){
    		// Title
    		$rootScope.title = 'Search Result';
    		
    		// Breadcrumbs
            var link = {};
            link.title = 'Search Result';
            crumble.context = {'link':link};
    		crumble.update();
            $rootScope.crumble = crumble;
    		$scope.breadcrumb = {};
    		
    		// Form
    		$scope.form = {};
    		$scope.ref={};
    		
    		// Filter
    		vm.filter = {};
    		vm.filter.availability;
    		vm.filter.selectedBrandIds;
    		vm.filter.selectedSupplierIds;
    		vm.filter.selectedCategoryIds;
    		vm.filter.selectedTagIds;
    		vm.filter.minPrice;
    		vm.filter.maxPrice;
    		vm.filter.quantityFrom;
    		vm.filter.quantityTo;
    	
    		// Pagination
    		$scope.pagination = {};
    		if($location.search().page && $location.search().page > 1){
    			$scope.pagination.pageIndex = $location.search().page;
    		}else{
    			$scope.pagination.pageIndex = 1;
    			$location.search('page', $scope.pagination.pageIndex);
    		}
    		
    		if($location.search().pageSize && $location.search().pageSize > 1){
    			$scope.pagination.pageSize = parseInt($location.search().pageSize);
    		}else{
    			$scope.pagination.pageSize = 9;
    			$location.search('pageSize', $scope.pagination.pageSize);
    		}
    		
    		$scope.pagination.pageSizes = [9, 30, 60, 90];
    		$scope.pagination.maxSize = 3;
    		$scope.pagination.overAllCount = 0;
    		
    		// Data 
    		$scope.searchString = $location.search().q;
    		vm.getSearchResult();
    		vm.getCategoryReferenceList();
    		vm.getBrandReferenceList();
    		vm.getSupplierReferenceList();
    		vm.getTagReferenceList();
    		vm.getAvailabilityReferenceList();
    	};
    	
    	// Get Search Result
    	vm.getSearchResult = function(){
    		var data = {
    					'searchString' 		  : $scope.searchString,
    					'availability'		  : vm.filter.availability,
						'selectedBrandIds'    : vm.filter.selectedBrandIds,
						'selectedSupplierIds' : vm.filter.selectedSupplierIds,
						'selectedCategoryIds' : vm.filter.selectedCategoryIds,
						'selectedTagIds' 	  : vm.filter.selectedTagIds,
						'minPrice'			  : vm.filter.minPrice,
						'maxPrice'			  : vm.filter.maxPrice,
						'quantityFrom' 		  : vm.filter.quantityFrom,
						'quantityTo' 		  : vm.filter.quantityTo,
    					'pageIndex' 		  : $scope.pagination.pageIndex,
    					'pageSize'			  : $scope.pagination.pageSize
    				   };
    		
    		console.log(data);
    		var queryCode = "productSearchQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			$scope.form.productlists = response.data.resultSet;
    			$scope.pagination.overAllCount = response.data.resultOverAllCount;
    			console.log('$scope.pagination.overAllCount');
    			console.log($scope.pagination.overAllCount);
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	}
    	
    	/**
    	 * Reload Data
    	 */
    	$scope.reloadData = function() {
    		$location.search('page', $scope.pagination.pageIndex);
    		$location.search('pageSize', $scope.pagination.pageSize);
    		$window.scrollTo(0, 0);
    		vm.getSearchResult();
    	}; 
    	
    	/**
    	 * Filter
    	 */
    	$scope.filterResults = function(){
    		$scope.form.minPrice = angular.element('#minPrice').val();
    		$scope.form.maxPrice = angular.element('#maxPrice').val();
    			
    		var selectedCategoryIds = [];
    		
    		angular.forEach($scope.form.categories, function(category){
    			angular.forEach(category, function(value, key){
    				if(key === 'id'){
    					selectedCategoryIds.push(value);
    				}
    			});
    		});
	
    		var selectedBrandIds = [];
    		
    		angular.forEach($scope.form.brands, function(brand){
    			angular.forEach(brand, function(value, key){
    				if(key === 'id'){
    					selectedBrandIds.push(value);
    				}
    			});
    		});
    		
    		var selectedSupplierIds = [];
    		
    		angular.forEach($scope.form.suppliers, function(supplier){
    			angular.forEach(supplier, function(value, key){
    				if(key === 'id'){
    					selectedSupplierIds.push(value);
    				}
    			});
    		});
    		
    		var selectedTagIds = [];
    		
    		angular.forEach($scope.form.tags, function(tag){
    			angular.forEach(tag, function(value, key){
    				if(key === 'id'){
    					selectedTagIds.push(value);
    				}
    			});
    		});
    		
    		vm.filter.availability 		  = $scope.form.availability,
    		vm.filter.selectedBrandIds 	  = selectedBrandIds,
    		vm.filter.selectedSupplierIds = selectedSupplierIds,
    		vm.filter.selectedCategoryIds = selectedCategoryIds;
    		vm.filter.selectedTagIds 	  = selectedTagIds,
    		vm.filter.minPrice 			  = $scope.form.minPrice,
    		vm.filter.maxPrice 			  = $scope.form.maxPrice,
    		vm.filter.quantityFrom 		  = $scope.form.quantityFrom,
    		vm.filter.quantityTo 		  = $scope.form.quantityTo
    		$scope.pagination.pageIndex   = 1;
    		
    		vm.getSearchResult();
    	}
    	
    	// Get Category Reference
    	vm.getCategoryReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllCategoryQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('findAllCategoryQueryModel');
    			console.log(response);
    			$scope.ref.categoryList = response.data.resultSet;
    		}, function(errorResponse){
    			console.log(errorResponse);
			});
    	};
    	
    	// Get Brand Reference
    	vm.getBrandReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllBrandQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('findAllBrandQueryModel');
    			console.log(response);
    			$scope.ref.brandList = response.data.resultSet;
    		}, function(errorResponse){
    			console.log(errorResponse);
			});
    	};
    	// Get Supplier Reference
    	vm.getSupplierReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllSupplierReferencesQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('findAllSupplierQueryModel');
    			console.log(response);
    			$scope.ref.supplierList = response.data.resultSet;
    		}, function(errorResponse){
    			console.log(errorResponse);
			});
    	};
    	// Get Tag Reference
    	vm.getTagReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllTagQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('findAllTagQueryModel');
    			console.log(response);
    			$scope.ref.tagList = response.data.resultSet;
    		}, function(errorResponse){
    			console.log(errorResponse);
			});
    	};
    	
    	// Availability
    	vm.getAvailabilityReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllProductAvailabilityQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('findAllProductAvailabilityQueryModel');
    			console.log(response);
    			$scope.ref.availabilityList =  response.data.resultSet;
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	}
    	
    	vm.init();
    	
    	$scope.addToCart = function(product){
    		console.log("addToCart");
    		console.log(product);
    		
    		var data = {};
    		data.productID = product.id;
    		data.quantity = 1 // Default;
    		data.customerID = $rootScope.session['AUTHENTICATED_USER'].userID;
    		data.createdBy = $rootScope.session['AUTHENTICATED_USER'].username;
    		
    		console.log(data);
    		
    		var commandCode = "addItemToCartCommandHandler";
    		var url = "command/"+commandCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log(response);
    		}, function(errorResponse){
    			console.log(errorResponse);
			});
    		
    	}
    	
    	/*
    	 * 
    	 */
    	$scope.goToProductInfo = function(id){
    		$location.path('public/product/info/'+id);
    	}
	}]);
	
});