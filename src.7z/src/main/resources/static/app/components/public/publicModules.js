/**
 * 
 */
'use strict';
define(function(){
	var publicModules = angular.module('publicModules', ['ngTable', 'ui.bootstrap', 'ngAlertify']);
	console.log('publicModules');
	
	publicModules.config(['$controllerProvider',  
    	function ($controllerProvider) {
    		console.log('publicModules.config');
    		// Module Registration
    		publicModules.register = {
    				controller : $controllerProvider.register
    		};
    }]);
});