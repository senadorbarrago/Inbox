/**
 * 
 */
'use strict';
define(function(){
	var adminModules = angular.module('adminModules');
	console.log('Loading individualSignupFormController');
	
	adminModules.register.controller('individualSignupFormController', ['$rootScope', '$scope', 
		'$http', 'DataAccessService',  'alertify', '$location',
		function ($rootScope, $scope, $http, dataAccessService, alertify, $location){
    	console.log('adminModules.controller');
    	var vm = this;
    	
    	vm.init = function(){
    		console.log('individualSignupFormController.init()');
    		
    		$scope.formTitle = 'Client Individual Registration';
    		$scope.form = {};
    		$scope.form.sameAddress = false;
    		
    		$scope.reference = {};
    		vm.getCountryReferenceList();
    		vm.getRegionReferenceList();
    		
    	};
    	
    	vm.getCountryReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllCountryQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('QueryModel');
    			console.log(response);
    			$scope.reference.countryList = response.data.resultSet;
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	};
    	
    	vm.getRegionReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllRegionQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('findAllRegionQueryModel');
    			console.log(response);
    			$scope.reference.regionList = response.data.resultSet;
    		}, function(errorResponse){
    			console.log(errorResponse);
			});
    	};
    	
    	
    	vm.init();
    	
    	$scope.register = function(){
    		
			if(!$scope.form.username){
    			alertify.alert("Please enter your email");
    			return false;
    		}
    		if(!$scope.form.password){
    			alertify.alert("Please enter your password");
    			return false;
    		}
    		if(!$scope.form.firstname){
    			alertify.alert("Please enter your first name");
    			return false;
    		}
    		if(!$scope.form.lastname){
    			alertify.alert("Please enter your last name");
    			return false;
    		}
    		var answer = confirm('Please confirm your details and click OK');
    		
    		if(answer){
    			$scope.form.createdBy = "ADMINISTRATOR";
    			$scope.form.contextPath = $location.absUrl();
    		
        		
        		var data = $scope.form;
        		data.contextPath = $location.absUrl().substr(0, $location.absUrl().lastIndexOf("#"));
        		
        		var commandCode = "addIndividualCommandHandler";
        		var url = "command/"+commandCode;
        		
        		dataAccessService.doPostData(url, data, function(response){
        			console.log(response);
        			alertify.alert('Congratulations!!! You are now registered. Please check your email to activate your account.');
        			
        		$location.path('/public/security/login');
        		
        		}, function(errorResponse){
        			console.log(errorResponse);
    				alertify.alert(errorResponse.data.message);
    			});		
    		}
    	};
    	    	
	}]);
	
});