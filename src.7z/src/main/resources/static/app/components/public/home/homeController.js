/**
 * 
 */
'use strict'
define(function() {
	var publicModules = angular.module('publicModules');
	console.log('Loading homeController');

	publicModules.register.controller('homeController', [ '$rootScope',
			'$scope', '$location', '$uibModal', 'DataAccessService', 'alertify', '$filter', 
			function($rootScope, $scope, $location, $uibModal, dataAccessService, alertify, $filter) {
				console.log('Registering homeController...');

				var vm = this;

				vm.init = function() {

					$scope.form = {};
					vm.loadHomeAds();
					vm.loadFeaturedProducts();
					
					$scope.owlOptionsTestimonialsHomeAds = {
						autoPlay : 5000,
						stopOnHover: true,
						slideSpeed : 500,
						paginationSpeed : 600,
						items : 1,
						navigation : true,
						navigationText : [ "", "" ]
					}
					
					$scope.owlOptionsTestimonialsFeaturedAds = {
							autoPlay : 5000,
							stopOnHover: true,
							slideSpeed : 500,
							paginationSpeed : 600,
							items : 5
					}

				}

				vm.loadHomeAds = function() {
					var data = {};
					var queryCode = "findAllHomeAdsQueryModel";
					var url = "query/" + queryCode;

					dataAccessService.doPostData(url, data, function(response) {
						console.log('findAllHomeAdsQueryModel');
						console.log(response);
						$scope.form.homeAdsList = response.data.resultSet;
						
						angular.forEach($scope.form.homeAdsList, function(value, key){
							if(value.advertismentType === 'PRODUCT'){
								vm.getProduct(value.productID, value);
							}
							if(value.advertismentType === 'BRAND'){
								vm.getBrand(value.brandID, value);
							}
							if(value.advertismentType === 'SELLER'){
								vm.getSeller(value.sellerID, value);
							}
							
							console.log('ads: ');
							console.log(value);
						});
						
					}, function(errorResponse) {
						alertify.alert(response);
						console.log(errorResponse);
					});

				};
								
				vm.loadFeaturedProducts = function() {
					var data = {
									'pageIndex' : 1,
									'pageSize'	: 5000
								};
					var queryCode = "featuredProductListQueryModel";
					var url = "query/" + queryCode;

					dataAccessService.doPostData(url, data, function(response) {
						console.log('featuredProductListQueryModel');
						console.log(response);
						$scope.form.featuredProductsList = response.data.resultSet;

					}, function(errorResponse) {
						alertify.alert(response);
						console.log(errorResponse);
					});

				};
				
				vm.getProduct = function(id, attr){
		    		var data = {'id' : id};
		    		var queryCode = "productItemQueryModel";
		    		var url = "query/"+queryCode;
		    		
		    		dataAccessService.doPostData(url, data, function(response){
		    			console.log('productItemQueryModel');
		    			console.log(response);
		    			attr.product = response.data.resultSet[0];
		    		}, function(errorResponse){
						console.log(errorResponse);
					});
		    		
		    	};
				
		    	vm.getBrand = function(id, attr){
		    		var data = {'id' : id};
		    		var queryCode = "brandDetailsQueryModel";
		    		var url = "query/"+queryCode;
		    		
		    		dataAccessService.doPostData(url, data, function(response){
		    			console.log('brandDetailsQueryModel');
		    			console.log(response);
		    			attr.brand = response.data.resultSet[0];
		    		}, function(errorResponse){
						console.log(errorResponse);
					});
		    	};
				
		    	vm.getSeller = function(id, attr){
		    		var data = {'id' : id};
		    		var queryCode = "findSupplierByIDQueryModel";
		    		var url = "query/"+queryCode;
		    		
		    		dataAccessService.doPostData(url, data, function(response){
		    			console.log('QueryModel');
		    			console.log(response);
		    			attr.seller = response.data.resultSet[0];
		    		}, function(errorResponse){
						console.log(errorResponse);
					});
		    		
		    		
		    	};
		    	
				vm.init();
				
				$scope.addToCart = function(product){
					// Redirect to Buyer Registration Page when not authenticated
		    		if(!$rootScope.session['AUTHENTICATED'] || $rootScope.session['AUTHENTICATED'] === false){
		    			alertify.alert('Please register first in order to start shopping in Hotel Depot. Thank You!');
		    			$location.path('/public/client/individualSignup');
		    		}
					
		    		console.log(product);
		    		var data = {};
		    		data.productID = product.id;
		    		data.quantity = product.minimumOrder;
		    		data.customerID = $rootScope.session['AUTHENTICATED_USER'].userID;
		    		data.createdBy = $rootScope.session['AUTHENTICATED_USER'].username;
		    		
		    		console.log(data);
		    		
		    		var commandCode = "addItemToCartCommandHandler";
		    		var url = "command/"+commandCode;
		    		
		    		dataAccessService.doPostData(url, data, function(response){
		    			console.log(response);
		    			$rootScope.loadCartItemsCount();
		    		}, function(errorResponse){
						alertify.alert(errorResponse.data.message);
					});
				}
				
				$scope.askForQuotation = function(product){
					if($rootScope.session['AUTHENTICATED'] === false || 
						!$rootScope.session['AUTHENTICATED']){
						
						alertify.alert('You must log in before you can contact the seller of this product.<br/>'
								+'Please signup if you dont have a registered account.');
						
						$location.path('/public/security/login');
						
						return false;
					}
					
					console.log(product);
		    		
		    		var data = {};
		    		data.productCode = product.sku;
		    		data.productName = product.name;
		    		data.supplier =	product.supplierDesc;
		    		data.supplierEmail = product.supplierEmail;
		    		data.fullname = $rootScope.session['AUTHENTICATED_USER'].fullname;
		    		data.buyerEmail = $rootScope.session['AUTHENTICATED_USER'].email;
		    		data.username = $rootScope.session['AUTHENTICATED_USER'].username;
		    		
		    		console.log(data);
		    		
		    		var commandCode = "askForQuotationCommandHandler";
		    		var url = "command/"+commandCode;
		    		
		    		dataAccessService.doPostData(url, data, function(response){
		    			console.log(response);
		    		}, function(errorResponse){
						alertify.alert(response);
					});
		    	}
		    	
		    	// Open ask for Quote form
		    	$scope.openForm = function (selectedObject) {
		    		if($rootScope.session['AUTHENTICATED'] === false || 
							!$rootScope.session['AUTHENTICATED']){
							
							alertify.alert('You must log in before you can contact the seller of this product.<br/>'
									+'Please signup if you dont have a registered account.');
							
							$location.path('/public/security/login');
							
							return false;
						}
		    	    $uibModal.open({
		    	    	templateUrl  : 'app/components/private/order/quote/askForQuotationForm.html',
		    			controller   : 'askForQuotationFormController',
		    			backdrop	 : "static",
		    			close		 : 'close',
		    			size		 : "lg",
		    			resolve 	 : {
		    				load: ['$q', function($q){
				    					var defered = $q.defer();
				    					require(['app/components/private/order/quote/askForQuotationFormController.js'], function(){
				    						defered.resolve();
				    					});
				    			return defered.promise;
							}],
		    				params	 : function(){
		    					var params = {
		    							"id" 		   : selectedObject.id,
		    							"productCode"  : selectedObject.sku,
		    							"productName"  : selectedObject.name,
		    							"moq" 		   : selectedObject.minimumOrder,
		    							"sellingPrice" : selectedObject.sellingPrice,
		    							"supplierID"   : selectedObject.supplier 
		    					}
		    					return params;
		    				}
		    			}
		    	    })
		    	    .result.then(
			            //close
			            function (result) {
			                var a = result;
			                console.log('SUCCESS');
		            },
			            //dismiss
			            function (result) {
			                var a = result;
			                console.log('DISMISSED');
		            });
		    	    
		    	  };
		
	    	  /*
	      	 * 
	      	 */
	      	$scope.goToProductInfo = function(id){
	      		$location.path('public/product/info/'+id);
	      	} 
	      	
	      	$scope.getfeaturedProductPrice = function(product){
	    		if(product.discountedPrice && product.discountedPrice > 0){
	    			return $filter('number')(product.discountedPrice, 2);
	    		}else {
	    			return $filter('number')(product.regularPrice, 2);
	    		}
	    	}
	}]);
});