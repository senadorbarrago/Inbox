/**
 * 
 */
'use strict'
define(function(){
	var publicModules = angular.module('publicModules');
	console.log('Loading orderStatusController');
	
	publicModules.register.controller('orderStatusController', ['$rootScope', '$scope', '$location', '$routeParams', 'DataAccessService',
		function ($rootScope, $scope, $location, $routeParams, dataAccessService){
    	console.log('Registering orderStatusController...');    	
    	
    	var vm = this;
    	
    	vm.init = function(){
    		vm.orderNo = $routeParams.orderNo;
    		
    		vm.getOrderForm();
    	}
    	
    	vm.getOrderForm = function(){
    		var data = {
    						'orderNo' : vm.orderNo
    					}
    		var queryCode = "findOrderByOrderNoQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('OrderForm');
    			console.log(response);
    			$scope.form =  response.data.resultSet[0];
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	}
    	
    	vm.init();
    	
    	$scope.goToLogin = function(){
    		$location.path('/login');
    	}
    	
	}]);
	
});