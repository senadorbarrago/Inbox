/**
 * 
 */
'use strict';
define(function(){
	var adminModules = angular.module('adminModules');
	console.log('Loading secureAccessController');
	
	adminModules.register.controller('secureAccessController', ['$rootScope', '$scope', '$http', 
		'DataAccessService', 'alertify', '$location', '$cookies', '$uibModalInstance', 'data',
		function ($rootScope, $scope, $http, dataAccessService, alertify, $location, $cookies, $uibModalInstance, data){
    		console.log('secureAccessController.controller');
    		var vm = this;
    	
	    	vm.init = function(){
	    		console.log('secureAccessController.init()');
	    		
	    		$scope.formTitle = 'Login Form';
	    		$scope.form = {};
	    	};	    	
	    	
	    	vm.init();
	    	
	    	$scope.login = function(){
	    		
	    		if(!$scope.form.username){
	    			alertify.alert("Please enter your username");
	    			return false;
	    		}
	    		if(!$scope.form.password){
	    			alertify.alert("Please enter your password");
	    			return false;
	    		}
	    		
	    		var data = $('#loginFormId').serialize();
	    		console.log(data);
	    		
	    		var url = "login";
	    		
	    		dataAccessService.doPostTransformedData(url, data, function(response){
	    			console.log(response);
	    			
                    dataAccessService.doGetData("security/authenticatedUser", null, function(response){
                        console.log(response.data);
                        $rootScope.session = {};
                        $rootScope.session['AUTHENTICATED'] = true;
                        $rootScope.session['AUTHENTICATED_USER'] = response.data;
                        $cookies.put("AUTHENTICATED", true);
                        
                        $rootScope.loadCartItemsCount();
                        $uibModalInstance.close();
                    }, function(errorResponse){
                        console.log(errorResponse.header.ERROR_MESSAGE);
                        alertify.alert(errorResponse.headers("ERROR_MESSAGE"));
                    });
                    
	    		}, function(errorResponse){
	    			console.log(errorResponse);
	    			console.log(errorResponse.headers.ERROR_MESSAGE);
                    alertify.alert(errorResponse.headers("ERROR_MESSAGE"));
				});
	    		
	    	};
	    	
	    	/**
	    	 * 
	    	 */
	    	$scope.close = function(){
	    		console.log('close!');
	    		$uibModalInstance.close('close');
	    	}
	    	
	}]);
	
});