/**
 * 
 */
'use strict';
define(function(){
	var publicModules = angular.module('adminModules');
	console.log('Loading productListingController');
	
	publicModules.register.controller('secondaryCategoryController', ['$rootScope', '$scope', 'ngTableParams', 
		'$uibModal', '$http', 'DataAccessService', '$routeParams', 'crumble', function ($rootScope, $scope, ngTableParams, $uibModal, 
				$http, dataAccessService, $routeParams, crumble){
    	console.log('Registering secondaryCategoryController...');
    	var vm = this;
    	
    	vm.init = function(){
    		console.log('secondaryCategoryController.init()');
    		
    		console.log('$routeParams.queryMode: '+$routeParams.queryMode);
    		
    		var link = {};
            link.title = $routeParams.queryCode;
    		
            crumble.context = {'secondary':link};
            console.log(crumble);
    		crumble.update();
            $rootScope.crumble = crumble;
            
                		
    		$scope.breadcrumb = {};
    		$scope.breadcrumb.mode = $routeParams.queryMode;
    		
    		$scope.title = $routeParams.queryMode;
    		
    		$scope.subtitle = $routeParams.queryCode;
    		console.log($routeParams);
    		
    		$scope.form = {};
    		$scope.ref={};
    		
    		$scope.form.queryMode = $routeParams.queryMode;
    		$scope.form.queryCode = $routeParams.queryCode;
    		$scope.form.queryID = $routeParams.queryID;
    		
    		vm.getProductList();
    		
    		vm.getBrandReferenceList();
    		vm.getSupplierReferenceList();
    		vm.getTagReferenceList();
    	};
    	
    	// Get Search Result
    	vm.getProductList = function(){
    		var data = {
    					'queryMode'	: $scope.form.queryMode,
    					'queryCode'	: $scope.form.queryCode,
    					'queryID' 	: $scope.form.queryID,
    					'pageIndex' : 1,
    					'pageSize'	: 20
    					
    				   };
    		console.log(data);
    		var queryCode = "productPublicListQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('productSearchQueryModel');
    			console.log(response);
    			$scope.form.productlists = response.data.resultSet;
    			
    		}, function(errorResponse){
				console.log(errorResponse);
			});
    	}
    	
    	$scope.filterResults = function(){
    		console.log('filterResults()');

    		$scope.form.minPrice = angular.element('#minPrice').val();
    		$scope.form.maxPrice = angular.element('#maxPrice').val();
    			
    		var selectedBrandIds = [];
    		
    		angular.forEach($scope.form.brands, function(brand){
    			angular.forEach(brand, function(value, key){
    				if(key === 'id'){
    					selectedBrandIds.push(value);
    				}
    			});
    		});
    		
    		var selectedSupplierIds = [];
    		
    		angular.forEach($scope.form.suppliers, function(supplier){
    			angular.forEach(supplier, function(value, key){
    				if(key === 'id'){
    					selectedSupplierIds.push(value);
    				}
    			});
    		});
    		
    		var selectedTagIds = [];
    		
    		angular.forEach($scope.form.tags, function(tag){
    			angular.forEach(tag, function(value, key){
    				if(key === 'id'){
    					selectedTagIds.push(value);
    				}
    			});
    		});
    		
    		var data = {
    				'queryMode'			  : $scope.form.queryMode,
					'queryCode'			  : $scope.form.queryCode,
					'queryID' 			  : $scope.form.queryID,
					'selectedBrandIds'    : selectedBrandIds,
					'selectedSupplierIds' : selectedSupplierIds,
					'selectedTagIds' 	  : selectedTagIds,
					'minPrice'			  : $scope.form.minPrice,
					'maxPrice'			  : $scope.form.maxPrice,
					'quantityFrom' 		  : $scope.form.quantityFrom,
					'quantityTo' 		  : $scope.form.quantityTo,
					'pageIndex' 		  : 1,
					'pageSize'			  : 20
					
				   };
			console.log(data);
			var queryCode = "productPublicListQueryModel";
			var url = "query/"+queryCode;
			
			dataAccessService.doPostData(url, data, function(response){
				console.log('productSearchQueryModel');
				console.log(response);
				$scope.form.productlists = response.data.resultSet;
				
			}, function(errorResponse){
				console.log(errorResponse);
			});
    		
    	}
    	// Get Brand Reference
    	vm.getBrandReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllBrandQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('findAllBrandQueryModel');
    			console.log(response);
    			$scope.ref.brandList = response.data.resultSet;
    		}, function(errorResponse){
    			console.log(errorResponse);
			});
    	};
    	// Get Supplier Reference
    	vm.getSupplierReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllSupplierReferencesQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('findAllSupplierQueryModel');
    			console.log(response);
    			$scope.ref.supplierList = response.data.resultSet;
    		}, function(errorResponse){
    			console.log(errorResponse);
			});
    	};
    	// Get Tag Reference
    	vm.getTagReferenceList = function(){
    		var data = {};
    		var queryCode = "findAllTagQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('findAllTagQueryModel');
    			console.log(response);
    			$scope.ref.tagList = response.data.resultSet;
    		}, function(errorResponse){
    			console.log(errorResponse);
			});
    	};
	
    	vm.init();
    	
    	$scope.addToCart = function(product){
    		console.log("addToCart");
    		console.log(product);
    		
    		var data = {};
    		data.productID = product.id;
    		data.quantity = 1 // Default;
    		data.customerID = $rootScope.session['AUTHENTICATED_USER'].userID;
    		data.createdBy = $rootScope.session['AUTHENTICATED_USER'].username;
    		
    		console.log(data);
    		
    		var commandCode = "addItemToCartCommandHandler";
    		var url = "command/"+commandCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log(response);
    		}, function(errorResponse){
    			console.log(errorResponse);
			});
    		
    	}
    	
	}]);
	
});