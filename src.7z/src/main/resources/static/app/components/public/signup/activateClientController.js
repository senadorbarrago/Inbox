/**
 * 
 */
'use strict';
define(function(){
	var adminModules = angular.module('adminModules');
	console.log('Loading activateClientController');
	
	adminModules.register.controller('activateClientController', ['$rootScope', '$scope', 
		'$http', 'DataAccessService',  'alertify', '$location', '$routeParams',
		function ($rootScope, $scope, $http, dataAccessService, alertify, $location, $routeParams){
    	console.log('adminModules.controller');
    	var vm = this;
    	
    	vm.init = function(){
    		console.log('activateClientController.init()');	
    		
    		$scope.form = {};
    	
    		vm.loadForm($routeParams.username);	
    	};
    	
    	
    	vm.loadForm = function(id){
    		$scope.form.username = id;
    		
    		$scope.form.lastModifiedBy = "ADMINISTRATOR";
    		
    		var data = $scope.form;
    		
    		data.contextPath = $location.absUrl().substr(0, $location.absUrl().lastIndexOf("#"));
    		
        	var commandCode = "activateClientCommandHandler";
        	var url = "command/"+commandCode;
        		
        	dataAccessService.doPostData(url, data, function(response){
        		console.log(response);
        		alertify.alert(response.data.messageMap['SUCCESS_MESSAGE']);
        		
        	$location.path('/public/security/login');
        	
        	}, function(errorResponse){
        		console.log(errorResponse);
        		alertify.alert(errorResponse.data.message);
    		});		
    		
    	};
    	
    	vm.init();
    	    	
	}]);
	
});