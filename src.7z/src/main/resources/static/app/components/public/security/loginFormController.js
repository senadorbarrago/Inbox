/**
 * 
 */
'use strict';
define(function(){
	var adminModules = angular.module('adminModules');
	console.log('Loading loginController');
	
	adminModules.register.controller('loginController', ['$rootScope', '$scope', '$http', 
		'DataAccessService', 'alertify', '$location', '$cookies',
		function ($rootScope, $scope, $http, dataAccessService, alertify, $location, $cookies){
    		console.log('adminModules.controller');
    		var vm = this;
    	
	    	vm.init = function(){
	    		console.log('loginController.init()');
	    		
	    		$scope.formTitle = 'Login Form';
	    		$scope.form = {};
	    		
	    	};
	    	
	    	vm.getDefaultUrl = function(defaultSuccessUrl){
	    		console.log(defaultSuccessUrl);
	    		console.log($rootScope.session['AUTHENTICATED_USER']);
	    		var roleCode = $rootScope.session['AUTHENTICATED_USER'].role.code;
	    		
	    		$location.path(defaultSuccessUrl);
	    		
	    	}
	    	
	    	vm.init();
    	
	    	$scope.login = function(){
	    		
	    		if(!$scope.form.username){
	    			alertify.alert("Please enter your username");
	    			return false;
	    		}
	    		if(!$scope.form.password){
	    			alertify.alert("Please enter your password");
	    			return false;
	    		}
	    		
	    		var data = $('#loginFormId').serialize();
	    		console.log(data);
	    		
	    		var url = "login";
	    		
	    		dataAccessService.doPostTransformedData(url, data, function(response){
	    			console.log(response);
	    			var defaultSuccessUrl = response.headers("defaultSuccessUrl");
//                    if(!defaultSuccessUrl){
//                        defaultSuccessUrl = '/private/order/orderList';
//                    }
                    
                    defaultSuccessUrl = '/private/order/orderList';                    
                    $scope.defaultUrl = defaultSuccessUrl;
                    dataAccessService.doGetData("security/authenticatedUser", null, function(response){
                        console.log(response.data);
                        $rootScope.session = {};
                        $rootScope.session['AUTHENTICATED'] = true;
                        $rootScope.session['AUTHENTICATED_USER'] = response.data;
                        $cookies.put("AUTHENTICATED", true);
                        console.log($rootScope.session);
                        
                        if($rootScope.session['AUTHENTICATED_USER'].role.code === 'ADMIN'){
                        	let productID = $location.search().productID;
                        	let view = $location.search().view;
                        	
                        	console.log('productID: '+productID);
                        	console.log('view: '+view);
                        	
                        	if(view === 'productForm'){
                        		defaultSuccessUrl = 'private/admin/product/form/'+productID;
                        	}
                        	console.log(defaultSuccessUrl);
                        }
                        console.log(defaultSuccessUrl);
                        vm.getDefaultUrl(defaultSuccessUrl);
                        
                        $rootScope.watchTimeout();
                        $rootScope.loadCartItemsCount();
                    }, function(errorResponse){
                        console.log(errorResponse.header.ERROR_MESSAGE);
                        alertify.alert(errorResponse.headers("ERROR_MESSAGE"));
                    });
                    
	    		}, function(errorResponse){
	    			console.log(errorResponse);
	    			console.log(errorResponse.headers.ERROR_MESSAGE);
                    alertify.alert(errorResponse.headers("ERROR_MESSAGE"));
				});
	    		
	    	};
	    	
	    	$scope.reset = function(){
	    		if(!$scope.form.email){
	    			alert("Please enter valid email address");
	    			return false;
	    		}
	    		
	    		var answer = confirm('This will generate and email a temporary password for your account. Are you sure '+
				'you want to proceed?');
		
				if(answer){
					$scope.form.createdBy = "ADMINISTRATOR";
					$scope.form.contextPath =  $location.absUrl().substr(0, $location.absUrl().lastIndexOf("#"));
		    		
		    		var data = $scope.form;
		    		
		    		var commandCode = "forgotPasswordCommandHandler";
		    		var url = "command/"+commandCode;
		    		
		    		dataAccessService.doPostData(url, data, function(response){
		    			console.log(response);
		    			$location.path('/public/security/login');
		    			alertify.alert('A temporary password for your account has been sent. Please check your email and change your password. Thanks!');
		    		}, function(errorResponse){
		    			console.log(errorResponse);
	    				alert(errorResponse.data.message);
					});
		    		
		    		$location.path('/public/security/login');
				}
			};
			
			$scope.register = function(){
	    		
				if(!$scope.form.username){
	    			alertify.alert("Please enter your username");
	    			return false;
	    		}
	    		if(!$scope.form.password){
	    			alertify.alert("Please enter your password");
	    			return false;
	    		}

	    		var answer = confirm('This action will create your new account in HotelDepot. Are you sure '+
	    				'you want to proceed?');
	    		
	    		if(answer){
	    			$scope.form.createdBy = "ADMINISTRATOR";
	    			$scope.form.clientType = 2;
	        		
	        		var data = $scope.form;
	        		
	        		var commandCode = "addClientCommandHandler";
	        		var url = "command/"+commandCode;
	        		
	        		dataAccessService.doPostData(url, data, function(response){
	        			console.log(response);
	        			alertify.alert('Congratulations!!! You are now registered. Please login');
	        			$location.path('/public/security/login');
	        		}, function(errorResponse){
	        			console.log(errorResponse);
	    				alertify.alert(errorResponse.data.message);
	    			});
	        		
	        		
	    		}
	    	};
	    	
	    	vm.getClientDetails = function(id){
	    		var data = {'id' : id};
	    		var queryCode = "findClientByUserIDForLoginQueryModel";
	    		var url = "query/"+queryCode;
	    		
	    		console.log('Client Details');
	    		dataAccessService.doPostData(url, data, function(response){
	    			console.log(response);
	    			$scope.form.email = response.data.resultSet[0].email;
	    			$scope.form.isDetailsComple = response.data.resultSet[0].isDetailsComplete  ;
	    		}, function(errorResponse){
					console.log(errorResponse);
				});
	    	};
	    	
	    	$scope.signUpAsIndividual = function(){
	    		$location.path("/public/client/individualSignup");
	    	}
	    	
    	
	}]);
	
});