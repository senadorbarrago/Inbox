/**
 * 
 */
'use strict'
require.config({
//	baseUrl						: 'ecommerce',
	waitSeconds					:  0,
    paths: {
//    	jquery					: '../webjars/jquery/3.2.1/dist/jquery.min',	// commented in favor of jquery in assets folder -kiev
    	jquery					: '../assets/libs/jquery',
		// add paths start -kiev
    	jqueryUi				: '../assets/libs/jquery-ui.1.12.0.min',
    	jqueryLazy				: '../assets/libs/jquery.lazy.min',
    	elevateZoom				: '../assets/libs/jquery.elevateZoom-3.0.8.min',
    	owlCarousel				: '../assets/libs/owl.carousel',
		// add paths end -kiev
        angular					: '../webjars/angular/1.6.6/angular.min',
        angularRoute			: '../webjars/angular-route/1.6.6/angular-route.min',
        angularUiRouter			: '../webjars/angular-ui-router/1.0.6/release/angular-ui-router.min',
        angularUiBootstrap		: '../webjars/angular-ui-bootstrap/2.2.0/ui-bootstrap-tpls.min',
        ngTable					: '../webjars/ng-table/0.3.3/ng-table.min',
        angularCookies			: '../webjars/angular-cookies/1.6.6/angular-cookies.min',
        core					: '../app/core',
    	coreRunner				: '../app/corerunner',
    	adminModules		    : '../app/components/private/admin/adminModules',
    	utilitiesModule 	    : '../app/shared/utilities/utilitiesModule',
    	utilitiesServiceIndex   : '../app/shared/utilities/utilitiesServiceIndex',
    	utilitiesDirectiveIndex : '../app/shared/utilities/utilitiesDirectiveIndex',
    	alertify			    : '../assets/libs/alertifyjs/alertify.min',
    	ngAlertify				: '../assets/libs/alertifyjs/ngAlertify',
		publicModules	 	    : '../app/components/public/publicModules',
    	orderModule				: '../app/components/private/order/orderModule',
    	multiselect             : '../assets/libs/angular-bootstrap-multiselect.min',
    	ngBreadcrumbs           : '../assets/libs/ng-breadcrumbs.min',
    	payPalCheckOut			: 'https://www.paypalobjects.com/api/checkout',
    	crumble					: '../assets/libs/crumble',
    	angularIdle				: 'https://cdnjs.cloudflare.com/ajax/libs/ng-idle/1.3.2/angular-idle.min'
    		
    },
    shim: {    	
    	'jquery'				: {exports:'$'},
        'angular' 				: {
        							deps : ['jquery'],
        							exports: 'angular'
        						  },

		// add shim start -kiev
        'jqueryUi'				: {deps:['jquery']},        
        'jqueryLazy'			: {deps:['jquery']},
        'elevateZoom'			: {deps:['jquery']},
        'owlCarousel'			: {deps:['jquery']},
        // add shim end -kiev  
        'crumble'				: {deps:['angularUiRouter']},
        'payPalCheckOut'		: {deps:['angular']},
        'ngBreadcrumbs'			: {deps:['angular']},
        'angularRoute'			: {deps:['angular']},						  
        'angularUiRouter'     	: {deps:['angular']},
        'angularUiBootstrap'    : {deps:['angular']},
        'angularCookies'		: {deps:['angular']},
        'ngTable'				: {deps:['angular']},
        'alertify'				: {deps:['angular']},
        'ngAlertify'			: {deps:['alertify']},        
        'angularIdle'				: {deps:['angular']},
        'multiselect'			: {deps:['angular']},
        'publicModules'			: {deps:['angularRoute', 'angularUiRouter', 'angularUiBootstrap', 'angularCookies', 'angularIdle']},
        'adminModules'			: {deps:['angularRoute', 'angularUiRouter', 'angularUiBootstrap', 'angularCookies', 'angularIdle']},
        'orderModule'			: {deps:['angularRoute', 'angularUiRouter', 'angularUiBootstrap', 'angularCookies', 'angularIdle']},
        'utilitiesModule'		: {deps:['angularRoute', 'angularUiRouter', 'angularUiBootstrap', 'angularCookies', 'angularIdle']},
        'utilitiesServiceIndex' : {deps:['utilitiesModule']},
        'utilitiesDirectiveIndex' : {deps:['utilitiesModule', 'elevateZoom']},	// added dependency to elevateZoom -kiev
//        'core'					: {deps:['utilitiesServiceIndex', 'utilitiesDirectiveIndex', 'adminModules', 'publicModules', 'orderModule', 'ngTable', 'alertify', 'jqueryUi', 'jqueryLazy', 'owlCarousel', 'multiselect']}, // added dependency to jqueryLazy
        'core'					: {deps:['utilitiesServiceIndex', 'utilitiesDirectiveIndex', 'adminModules', 'publicModules', 'orderModule', 'ngTable', 'ngAlertify', 'jqueryUi', 'jqueryLazy', 'owlCarousel', 'multiselect', 'ngBreadcrumbs', 'payPalCheckOut', 'crumble']}, // added dependency to jqueryLazy
        'coreRunner'			: {deps:['core']}
    },
    deps : ['coreRunner']
});
