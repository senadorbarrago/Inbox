/**
 * 
 */
'use strict';
define([], function () {
    var core = angular.module('core', ['ng', 'ngRoute', 'ngCookies', 'ngIdle', 'publicModules', 'adminModules', 'utilitiesModule', 'orderModule', 'btorfs.multiselect', 'ng-breadcrumbs', 'paypal-button', 'crumble']);
    
    core.config([
    	'$routeProvider', 
    	'$locationProvider', 
    	'$httpProvider',
    	'$controllerProvider', 
    	'$compileProvider',
    	'$filterProvider', 
    	'$provide',
    	'$cookiesProvider',
    	'KeepaliveProvider',
    	'IdleProvider',
    	function ($routeProvider, $locationProvider, $httpProvider, $controllerProvider, 
    			$compileProvider, $filterProvider, $provide, $cookiesProvider, KeepaliveProvider, 
    			IdleProvider) {
    		
    		/**
    		 * Session Timeout Configuration
    		 * 
    		 * 580 sec before the idle state
    		 *  10 sec before timeout state
    		 *  60 sec server touches interval
    		 */
    		IdleProvider.idle(580);  
    		IdleProvider.timeout(10);
    		KeepaliveProvider.interval(60);
    		let healthCheckUrl = "/healthCheck";
    		KeepaliveProvider.http(healthCheckUrl);
    		
    		
    		// Module Registration
    		core.register = {
		        controller: $controllerProvider.register,
		        directive: $compileProvider.directive,
		        filter: $filterProvider.register,
		        factory: $provide.factory,
		        service: $provide.service
    		};
    		
		    // Core Route Map
		    $routeProvider
		    	.when('/', 
		    			{ 
		    				templateUrl	 : 'app/components/public/home/home.html',
		    				controller	 : 'homeController',
		    				resolve:{
			    				load : function($q, $rootScope){
			    					console.log(' resolve.load');
			    					return resolveDependencies($q, $rootScope, ['app/components/public/home/homeController.js']);
			    				}
			    			},
		                    label: 'Home'

		    			}
		    	 )
		    	 .when('/public/terms', 
			    		{ 
			    			templateUrl	 : 'app/components/public/terms/terms.html',
			    			controller	 : 'termsController',
			    			resolve:{
			    				load : function($q, $rootScope){
			    					console.log(' resolve.load');
			    					return resolveDependencies($q, $rootScope, ['app/components/public/terms/termsController.js']);
			    				}
			    			},
			    			parent : '/',
			    			label: 'terms'
			    		}
		    	 
			    )
			    .when('/public/about', 
			    		{ 
			    			templateUrl	 : 'app/components/public/about/about.html',
			    			controller	 : 'aboutController',
			    			resolve:{
			    				load : function($q, $rootScope){
			    					console.log(' resolve.load');
			    					return resolveDependencies($q, $rootScope, ['app/components/public/about/aboutController.js']);
			    				}
			    			},
			    			parent : '/',
			    			label: 'about'
			    		}
			    )
			    .when('/public/contact', 
			    		{
			    			templateUrl	 : 'app/components/public/contact/contact.html', 
			    			controller	 : 'contactController',
			    			resolve:{
			    				load : function($q, $rootScope){
			    					console.log(' resolve.load');
			    					return resolveDependencies($q, $rootScope, ['app/components/public/contact/contactController.js']);
			    				}
			    			},
			    			parent : '/',
			    			label: 'contact'
			    		}
			    )
                .when('/public/security/login',{
                    controller: 'loginController',
                    templateUrl: 'app/components/public/security/loginForm.html',
                    resolve:{
                        load: function($q, $rootScope) {
                            return resolveDependencies($q, $rootScope, ['app/components/public/security/loginFormController.js']);
                        }    
                    },
                    label: 'Login',
                	parent : '/'
                
                })

			    .when('/private/admin/product/list', 
			    		{
			    			templateUrl  : 'app/components/private/admin/product/productList.html',
			    			controller   : 'productListController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log(' resolve.load');
			    					return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/private/admin/product/productListController.js']);
			    				}
			    			}
			    
			    		}
			    )
			    .when('/private/admin/product/form/:productID', 
			    		{
			    			templateUrl  : 'app/components/private/admin/product/productForm.html',
			    			controller   : 'productFormController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log(' resolve.load');
			    					return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/private/admin/product/productFormController.js']);
			    				}
			    			}
			    
			    		}
			    )
			    .when('/private/admin/brand/list', 
			    		{
			    			templateUrl  : 'app/components/private/admin/brand/brandList.html',
			    			controller   : 'brandListController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log(' resolve.load');
			    					return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/private/admin/brand/brandListController.js']);
			    				}
			    			}
			    		}
			    )
			    .when('/private/admin/brand/form/:id', 
			    		{
			    			templateUrl  : 'app/components/private/admin/brand/brandForm.html',
			    			controller   : 'brandFormController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log(' resolve.load');
			    					return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/private/admin/brand/brandFormController.js']);
			    				}
			    			}
			    		}
			    )
			    .when('/private/admin/supplier/list', 
			    		{
			    			templateUrl  : 'app/components/private/admin/supplier/supplierList.html',
			    			controller   : 'supplierListController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log(' resolve.load');
			    					return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/private/admin/supplier/supplierListController.js']);
			    				}
			    			}
			    		}
			    )
			    .when('/private/admin/supplier/form/:supplierID', 
			    		{
			    			templateUrl  : 'app/components/private/admin/supplier/supplierForm.html',
			    			controller   : 'supplierFormController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log(' resolve.load');
			    					return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/private/admin/supplier/supplierFormController.js']);
			    				}
			    			}
			    		}
			    )
			    .when('/private/admin/primaryCategory/list', 
			    		{
			    			templateUrl  : 'app/components/private/admin/primarycategory/primaryCategoryList.html',
			    			controller   : 'primaryCategoryListController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log(' resolve.load');
			    					return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/private/admin/primarycategory/primaryCategoryListController.js']);
			    				}
			    			}
			    		}
			    )
			    .when('/private/admin/primaryCategory/form/:id', 
			    		{
			    			templateUrl  : 'app/components/private/admin/primarycategory/primaryCategoryForm.html',
			    			controller   : 'primaryCategoryFormController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log(' resolve.load');
			    					return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/private/admin/primarycategory/primaryCategoryFormController.js']);
			    				}
			    			}
			    		}
			    )
			    .when('/private/admin/secondaryCategory/list', 
			    		{
			    			templateUrl  : 'app/components/private/admin/secondarycategory/secondaryCategoryList.html',
			    			controller   : 'secondaryCategoryListController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log(' resolve.load');
			    					return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/private/admin/secondarycategory/secondaryCategoryListController.js']);
			    				}
			    			}
			    		}
			    )
			    .when('/private/admin/secondaryCategory/form/:id', 
			    		{
			    			templateUrl  : 'app/components/private/admin/secondarycategory/secondaryCategoryForm.html',
			    			controller   : 'secondaryCategoryFormController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log(' resolve.load');
			    					return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/private/admin/secondarycategory/secondaryCategoryFormController.js']);
			    				}
			    			}
			    		}
			    )
			    .when('/private/admin/category/list', 
			    		{
			    			templateUrl  : 'app/components/private/admin/category/categoryList.html',
			    			controller   : 'categoryListController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log(' resolve.load');
			    					return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/private/admin/category/categoryListController.js']);
			    				}
			    			}
			    		}
			    )
			    .when('/private/admin/category/form/:id', 
			    		{
			    			templateUrl  : 'app/components/private/admin/category/categoryForm.html',
			    			controller   : 'categoryFormController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log(' resolve.load');
			    					return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/private/admin/category/categoryFormController.js']);
			    				}
			    			}
			    		}
			    )
			    .when('/private/admin/section/list', 
			    		{
			    			templateUrl  : 'app/components/private/admin/section/sectionList.html',
			    			controller   : 'sectionListController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log(' resolve.load');
			    					return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/private/admin/section/sectionListController.js']);
			    				}
			    			}
			    		}
			    )
			    .when('/private/admin/section/form/:id', 
			    		{
			    			templateUrl  : 'app/components/private/admin/section/sectionForm.html',
			    			controller   : 'sectionFormController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log(' resolve.load');
			    					return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/private/admin/section/sectionFormController.js']);
			    				}
			    			}
			    		}
			    )
			    .when('/private/admin/advertisement/list', 
			    		{
			    			templateUrl  : 'app/components/private/admin/advertisement/advertisementList.html',
			    			controller   : 'advertisementListController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log(' resolve.load');
			    					return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/private/admin/advertisement/advertisementListController.js']);
			    				}
			    			}
			    		}
			    )
			    .when('/private/admin/advertisement/form/:id', 
			    		{
			    			templateUrl  : 'app/components/private/admin/advertisement/advertisementForm.html',
			    			controller   : 'advertisementFormController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log(' resolve.load');
			    					return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/private/admin/advertisement/advertisementFormController.js']);
			    				}
			    			}
			    		}
			    )
			    .when('/private/admin/user/list', 
			    		{
			    			templateUrl  : 'app/components/private/admin/user/userList.html',
			    			controller   : 'userListController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log(' resolve.load');
			    					return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/private/admin/user/userListController.js']);
			    				}
			    			}
			    		}
			    )
			    .when('/private/admin/user/form/:id', 
			    		{
			    			templateUrl  : 'app/components/private/admin/user/userForm.html',
			    			controller   : 'userFormController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log(' resolve.load');
			    					return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/private/admin/user/userFormController.js']);
			    				}
			    			}
			    		}
			    )
			    .when('/private/admin/role/list', 
			    		{
			    			templateUrl  : 'app/components/private/admin/role/roleList.html',
			    			controller   : 'roleListController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log(' resolve.load');
			    					return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/private/admin/role/roleListController.js']);
			    				}
			    			},
			    			label: 'Role',
			    			parent: '/'
			    		}
			    )
			    .when('/private/admin/role/form/:id', 
			    		{
			    			templateUrl  : 'app/components/private/admin/role/roleForm.html',
			    			controller   : 'roleFormController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log('resolve.load');
			    					return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/private/admin/role/roleFormController.js']);
			    				}
			    			}
			    		}
			    )
			    .when('/public/supplier/:supplierCode/:supplierID', 
			    		{
			    			templateUrl	 : 'app/components/public/supplier/supplier-brand.html', 
			    			controller	 : 'supplierBrandController',
			    			resolve:{
			    				load : function($q, $rootScope){
			    					console.log(' resolve.load');
			    					return resolveDependencies($q, $rootScope, ['app/components/public/supplier/supplierBrandController.js']);
			    				}
			    			},
			    			parent: '/',
		                    label: '{{link.title}}'
			    		}
			    )
			    .when('/public/brand/:brandCode/:brandID', 
			    		{
			    			templateUrl	 : 'app/components/public/brand/brand-product.html', 
			    			controller	 : 'brandProductController',
			    			resolve:{
			    				load : function($q, $rootScope){
			    					console.log(' resolve.load');
			    					return resolveDependencies($q, $rootScope, ['app/components/public/brand/brandProductController.js']);
			    				}
			    			},
			    			parent: '/',
		                    label: '{{link.title}}'
			    		}
			    )
			     .when('/public/secondarycategory/:secondaryCategoryCode/:secondaryCategoryID', 
			    		{
			    			templateUrl	 : 'app/components/public/product/secondarycategory/secondary-category.html', 
			    			controller	 : 'secondaryCategoryController',
			    			resolve:{
			    				load : function($q, $rootScope){
			    					console.log(' resolve.load');
			    					return resolveDependencies($q, $rootScope, ['app/components/public/product/secondarycategory/secondaryCategoryController.js']);
			    				}
			    			}
			    		}
			    )
			    .when('/public/search', 
			    		{
			    			templateUrl	 : 'app/components/public/search/search-result.html', 
			    			controller	 : 'searchResultController',
			    			resolve:{
			    				load : function($q, $rootScope){
			    					console.log(' resolve.load');
			    					return resolveDependencies($q, $rootScope, ['app/components/public/search/searchResultController.js']);
			    				}
			    			},
			    			parent: '/',
			                label: '{{link.title}}'
			    		}
			    )
			    .when('/public/category/:categoryCode/:categoryID', 
			    		{
			    			templateUrl	 : 'app/components/public/product/list/product-listing.html', 
			    			controller	 : 'productListingController',
			    			resolve:{
			    				load : function($q, $rootScope){
			    					console.log(' resolve.load');
			    					return resolveDependencies($q, $rootScope, ['app/components/public/product/list/productListingController.js']);
			    				}
			    			}
			    		}
			    )
			    .when('/public/buynow', 
			    		{
			    			templateUrl	 : 'app/components/public/buynow/buyNow.html', 
			    			controller	 : 'buyNowController',
			    			resolve:{
			    				load : function($q, $rootScope){
			    					console.log(' resolve.load');
			    					return resolveDependencies($q, $rootScope, ['app/components/public/buynow/buyNowController.js']);
			    				}
			    			},
			    			parent: '/',
		                    label: '{{link.title}}'

			    		}
			    )
			    .when('/public/product/list/:queryMode/:queryCode/:queryID', 
			    		{
			    			templateUrl	 : 'app/components/public/product/list/product-listing.html', 
			    			controller	 : 'productListingController',
			    			resolve:{
			    				load : function($q, $rootScope){
			    					console.log(' resolve.load');
			    					return resolveDependencies($q, $rootScope, ['app/components/public/product/list/productListingController.js']);
			    				}
			    			},
			    			parent: '/',
		                    label: '{{link.title}}'

			    		}
			    )
			    .when('/public/product/info/:productID', 
			    		{
			    			templateUrl	 : 'app/components/public/product/info/product-info-contents.html', 
			    			controller	 : 'productInfoController',
			    			resolve:{
			    				load : function($q, $rootScope){
			    					console.log(' resolve.load');
			    					return resolveDependencies($q, $rootScope, ['app/components/public/product/info/productInfoController.js']);
			    				}
			    			}
			    		}
			    )
			    .when('/private/admin/tag/list', 
			    		{
			    			templateUrl  : 'app/components/private/admin/tag/tagList.html',
			    			controller   : 'tagListController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log(' resolve.load');
			    					return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/private/admin/tag/tagListController.js']);
			    				}
			    			}
			    		}
			    )
			    .when('/private/admin/tag/form/:id', 
			    		{
			    			templateUrl  : 'app/components/private/admin/tag/tagForm.html',
			    			controller   : 'tagFormController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log(' resolve.load');
			    					return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/private/admin/tag/tagFormController.js']);
			    				}
			    			}
			    		}
			    )
			    .when('/private/admin/service/list', 
			    		{
			    			templateUrl  : 'app/components/private/admin/service/serviceList.html',
			    			controller   : 'serviceListController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log(' resolve.load');
			    					return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/private/admin/service/serviceListController.js']);
			    				}
			    			}
			    		}
			    )
			    .when('/private/admin/service/form/:serviceID', 
			    		{
			    			templateUrl  : 'app/components/private/admin/service/serviceForm.html',
			    			controller   : 'serviceFormController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log(' resolve.load');
			    					return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/private/admin/service/serviceFormController.js']);
			    				}
			    			}
			    		}
			    )
			    .when('/public/client/companySignup/:companyCode', 
			    		{
			    			templateUrl  : 'app/components/public/signup/companySignupForm.html',
			    			controller   : 'companySignupFormController',
			    			resolve:{
			    				load : function($q, $rootScope){
			    					console.log(' resolve.load');
			    					return resolveDependencies($q, $rootScope, ['app/components/public/signup/companySignupFormController.js']);
			    				}
			    			}
			    		}
			    )
			    .when('/public/client/individualSignup', 
			    		{
			    			templateUrl  : 'app/components/public/signup/individualSignupForm.html',
			    			controller   : 'individualSignupFormController',
			    			resolve:{
			    				load : function($q, $rootScope){
			    					console.log(' resolve.load');
			    					return resolveDependencies($q, $rootScope, ['app/components/public/signup/individualSignupFormController.js']);
			    				}
			    			}
			    		}
			    )
			    .when('/public/client/activateClient/:username', 
			    		{
			    			templateUrl  : 'app/components/public/security/loginForm.html',
			    			controller   : 'activateClientController',
			    			resolve:{
			    				load : function($q, $rootScope){
			    					console.log(' resolve.load');
			    					return resolveDependencies($q, $rootScope, ['app/components/public/signup/activateClientController.js']);
			    				}
			    			}
			    		}
			    )
			    .when('/public/orderstatus/:orderNo', 
			    		{
			    			templateUrl  : 'app/components/public/order/orderStatus.html',
			    			controller   : 'orderStatusController',
			    			resolve:{
			    				load : function($q, $rootScope){
			    					console.log(' resolve.load');
			    					return resolveDependencies($q, $rootScope, ['app/components/public/order/orderStatusController.js']);
			    				}
			    			}
			    		}
			    )
			     .when('/private/client/profile', 
			    		{
			    			templateUrl  : 'app/components/private/profile/individualProfileForm.html',
			    			controller   : 'individualProfileFormController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log(' resolve.load');
			    					return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/private/profile/individualProfileFormController.js']);
			    				}
			    			}
			    		}
			    )
			     .when('/private/client/companyprofile', 
			    		{
			    			templateUrl  : 'app/components/private/profile/companyProfileForm.html',
			    			controller   : 'companyProfileFormController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log(' resolve.load');
			    					return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/private/profile/companyProfileFormController.js']);
			    				}
			    			}
			    		}
			    )
			   .when('/private/client/profile/changepass', 
			    		{
			    			templateUrl  : 'app/components/private/profile/changepassForm.html',
			    			controller   : 'changepassFormController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log(' resolve.load');
			    					return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/private/profile/changepassFormController.js']);
			    				}
			    			}
			    		}
			    )
			    .when('/private/wishlist', 
			    		{
			    			templateUrl  : 'app/components/private/wishlist/wishlist.html',
			    			controller   : 'wishlistController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log(' resolve.load');
			    					return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/private/wishlist/wishlistController.js']);
			    				}
			    			}
			    		}
			    )
			    .when('/private/order/cart', 
			    		{
			    			templateUrl  : 'app/components/private/order/cart/cart.html',
			    			controller   : 'cartController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log(' resolve.load');
			    					return resolveDependencies($q, $rootScope, ['app/components/private/order/cart/cartController.js']);
			    				}
			    			},
			    			label: 'Cart',
			    			parent : '/'
			    		}
			    )
			    .when('/private/order/checkout', 
			    		{
			    			templateUrl  : 'app/components/private/order/checkout/checkoutForm.html',
			    			controller   : 'checkoutFormController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log(' resolve.load');
			    					return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/private/order/checkout/checkoutFormController.js']);
			    				}
			    			}
			    		}
			    )
			    .when('/private/order/orderList', 
			    		{
			    			templateUrl  : 'app/components/private/order/order/orderList.html',
			    			controller   : 'orderListController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log('/private/order/orderList');
			    					return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/private/order/order/orderListController.js']);
			    				}
			    			}
			    		}
			    )
			    .when('/private/order/orderForm/:id', 
			    		{
			    			templateUrl  : 'app/components/private/order/order/orderForm.html',
			    			controller   : 'orderFormController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log(' resolve.load');
			    					return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/private/order/order/orderFormController.js']);
			    				}
			    			}
			    		}
			    )
				// added route for file loading -kiev
			    .when('/private/admin/loadfile', 
			    		{
			    			templateUrl  : 'app/components/private/admin/loadfile/loadFileForm.html',
			    			controller   : 'loadFileFormController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log(' resolve.load');
			    					return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/private/admin/loadfile/loadFileFormController.js']);
			    				}
			    			}
			    		}
			    )
			    .when('/private/admin/country/list', 
			    		{
			    			templateUrl  : 'app/components/private/admin/country/countryList.html',
			    			controller   : 'countryListController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log(' resolve.load');
			    					return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/private/admin/country/countryListController.js']);
			    				}
			    			}
			    		}
			    )
			    .when('/private/admin/country/form/:id', 
			    		{
			    			templateUrl  : 'app/components/private/admin/country/countryForm.html',
			    			controller   : 'countryFormController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log(' resolve.load');
			    					return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/private/admin/country/countryFormController.js']);
			    				}
			    			}
			    		}
			    )
			    .when('/private/admin/region/list', 
			    		{
			    			templateUrl  : 'app/components/private/admin/region/regionList.html',
			    			controller   : 'regionListController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log(' resolve.load');
			    					return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/private/admin/region/regionListController.js']);
			    				}
			    			}
			    		}
			    )
			    .when('/private/admin/region/form/:id', 
			    		{
			    			templateUrl  : 'app/components/private/admin/region/regionForm.html',
			    			controller   : 'regionFormController',
			    			resolve:{
			    				load : function($q, $rootScope, $location){
			    					console.log(' resolve.load');
			    					return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/private/admin/region/regionFormController.js']);
			    				}
			    			}
			    		}
			    )
			    .otherwise({ redirectTo: '/' });
		    
		 // Resource access without authentication
   		 var resolveDependencies = function($q, $rootScope, dependencies){
		    	var defer = $q.defer();
		    	require(dependencies, function(){
		    		defer.resolve();
		    		$rootScope.$apply();
		    	});
		    	return defer.promise;
		    }
   		
   		 // Resource access with Authentication
         var resolveDependenciesWithAuthentication = function($q, $rootScope, $location, dependencies) {
             console.log('resolveDependenciesWithAuthentication'); 
           	 console.log('$rootScope.session: '+$rootScope.session['AUTHENTICATED']);
           	 console.log($rootScope.session['AUTHENTICATED']);
           	 var defer = $q.defer();
                if ($rootScope.session['AUTHENTICATED'] === true) {
                    require(dependencies, function() {
                        defer.resolve();
                        $rootScope.$apply();
                    });
                    return defer.promise;
                } else {
                    console.log("not authenticated")
                    $location.path("/");
                    return $q.reject("/");
                }
            };
		    
            $locationProvider.hashPrefix('');
            $locationProvider.html5Mode(true);
            
		    
		    
		    $httpProvider.defaults.headers.common["X-Requested-With"] = 'XMLHttpRequest';
            $httpProvider.defaults.headers.common["Cache-Control"] = "no-cache";
            $httpProvider.defaults.headers.common["Pragma"] = "no-cache";
    	}
    ]);
    
    core.run(['$rootScope', 'DataAccessService', '$location', 'alertify', '$cookies', 'crumble', '$uibModal', 'Idle',
    	function($rootScope, dataAccessService, $location, alertify, $cookies, crumble, $uibModal, Idle){
    	console.log('core.run()');
    	$rootScope.global = {};
    	$rootScope.session = {};
    	$rootScope.showSpinner = false;
    	
    	$rootScope.currentYear = new Date();
    	
    	$rootScope.isAuthenticated = function(){
    		if($rootScope.session['AUTHENTICATED_USER']){
    			console.log($rootScope.session['AUTHENTICATED_USER']);
    			return true;
    		}else{
    			return false;
    		}
    	}
    	
    	 var getParent = crumble.getParent;
         crumble.getParent = function (path) {
           var route = crumble.getRoute(path);
           console.log(path);
           console.log(route);
           return route && angular.isDefined(route.parent) ? route.parent : getParent(path);
         };
         
         $rootScope.$on('$routeChangeSuccess', function() {
           crumble.update();
         });
    	
    	// Permission
    	$rootScope.hasResourcePermission = function(resource){
    		if($rootScope.session['AUTHENTICATED_USER']){
    			var resourceList = $rootScope.session['AUTHENTICATED_USER'].role.resourceList;
    			var hasPermission = false;
    			var keep = true;
    			angular.forEach(resourceList, function(value, key){
    				if(keep){
	    				if(value.authority === resource){
	    					keep = false;
	    					hasPermission = true;
	    				}
    				}	
				});
    			
    			return hasPermission;
    		}
    	};
    	
    	// Monitor change in location path
		$rootScope.$on("$locationChangeStart", function(event, next, current) {
	         console.log("$locationChangeStart");
			 var i = next.indexOf("/", 10);
			 if ( i > -1) {
				 console.log(next.substring(i+1));
	             $cookies.put("CURRENT_PAGE", next.substring(i+1));
	         } else {
	             $cookies.put("CURRENT_PAGE", "/");
	         }
			 
//	         if(next.substring(i+1).indexOf('public/search') == -1){
//	        	 $rootScope.global.searchString = '';
//	        	 $location.search({});
//	         }
	    });
		
    	// Check User Session
    	$rootScope.checkUserSession = function(){
			console.log('checkUserSession()');
    		dataAccessService.doGetData("security/authenticatedUser", null, function(response){
	            // Empty session on $rootScope
    			if(response.headers('Content-Type').indexOf("application/json") == -1) {
	                $rootScope.session = {};
	                $cookies.remove("AUTHENTICATED");
                    $cookies.remove("CURRENT_PAGE");
	                $location.path('#/public/security/login');
	                //alertify.alert("Forbidden: Session already expired.");
	            }else{
	            	// Initialize session on $rootScope
	                $rootScope.session['AUTHENTICATED'] = true;
	                $rootScope.session['AUTHENTICATED_USER'] = response.data;
	                $cookies.put("AUTHENTICATED", true);
	                $location.path($cookies.get("CURRENT_PAGE"));
	                
	                console.log($rootScope.session['AUTHENTICATED_USER']);
	                console.log($rootScope.session['AUTHENTICATED']);
		        }
	   	 	}, function(errorResponse){
	   		 	$rootScope.session = {};
		   		$cookies.remove("AUTHENTICATED");
                $cookies.remove("CURRENT_PAGE");
	   		 	$location.path('#/public/security/login');
	            //alertify.alert("Forbidden: Session already expired.");
		    });   
    	};
    	
		$rootScope.loadPrimaryCategory = function(){
    		var data = {};
    		var queryCode = "findAllPrimaryCategoryQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('findAllPrimaryCategoryQueryModel');
    			console.log(response);
    			$rootScope.primaryCategoryModel = response.data.resultSet;
    		}, function(errorResponse){
    			console.log(errorResponse);
    		});
    	};
    	
    	$rootScope.loadSecondaryCategory = function(){
    		var data = {};
    		var queryCode = "findAllSecondaryCategoryQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('QueryModel : Secondary Category');
    			console.log(response);
    			$rootScope.secondaryCategoryModel = response.data.resultSet;
    		}, function(errorResponse){
    			console.log(errorResponse);
    		});
    	};
    	
    	// Category List
    	$rootScope.loadCategory = function(){
			var data = {};
			var queryCode = "findAllCategoryQueryModel";
			var url = "query/"+queryCode;
			
			dataAccessService.doPostData(url, data, function(response){
				console.log('findAllCategoryQueryModel');
				console.log(response);
				$rootScope.categoryModel = response.data.resultSet;
			}, function(errorResponse){
				console.log(errorResponse);
			});
		};										 
		
		// Initialize Category Levels
		$rootScope.loadPrimaryCategory();
		$rootScope.loadSecondaryCategory();
		$rootScope.loadCategory();
		
		// Cart items count
		$rootScope.loadCartItemsCount = function(){
    		var data = {};
    		var queryCode = "noOfCartItemsQueryModel";
    		var url = "query/"+queryCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log('noOfCartItemsQueryModel');
    			console.log(response);
    			$rootScope.noOfCartItems = response.data.resultSet[0].count;
    		}, function(errorResponse){
    			console.log(errorResponse);
    		});
    	};
		
    	// Check User Session
    	console.log('COOKIES: '+$cookies.get("AUTHENTICATED"));
    	if($cookies.get("AUTHENTICATED") === "true"){
    		console.log('COOKIES-AUTHENTICATED: true mod');
    		//$location.path($cookies.get("CURRENT_PAGE"));
            $rootScope.session['AUTHENTICATED']  = true;
    		$rootScope.checkUserSession();
    	}
    	
    	// Search Bar
		$rootScope.searchBar = function(searchString){
    		console.log(searchString);
    		if(searchString){
    			$location.path('/public/search').search({q : searchString});
    		}
    	}
		
			// Search Filter 2
		$rootScope.searchFilter = function(){
			var catId
			if($rootScope.category == null){
				catId = 0;
			}else{
				catId = $rootScope.category.id
			}
			
			var brandId
			if($rootScope.brand == null){
				brandId = 0
			}else{
				brandId = $rootScope.brand.id
			}
			
			var tagId
			if($rootScope.tag == null){
				tagId = 0
			}else{
				tagId = $rootScope.tag.id
			}

			$rootScope.minPrice = angular.element('#minPrice').val();
			$rootScope.maxPrice = angular.element('#maxPrice').val();
			console.log($rootScope.minPrice);
			console.log($rootScope.maxPrice);
    		
			var data = 
				{
					'catId': catId,
					'brandId': brandId,
					'tagId': tagId,
					'quantityTo' : $rootScope.quantityTo,
					'quantityFrom' : $rootScope.quantityFrom,
					'minPrice' : $rootScope.minPrice,
					'maxPrice' : $rootScope.maxPrice
			   };
			
    		
    		$location.path('/public/product/list').search(data);
    		
    		$rootScope.category = null;
    		$rootScope.brand = null;
    		$rootScope.tag = null;
    		$rootScope.quantityTo = null;
    		$rootScope.quantityFrom = null;
    		$rootScope.minPrice = null;
    		$rootScope.maxPrice = null;
    		
    	}
    	
		$rootScope.addToCart = function(productID, quantity){
    		console.log(productID);
    		console.log(quantity);
    		
    		var data = {};
    		data.productID = productID;
    		data.quantity = 1;
    		
    		console.log(data);
    		
    		var commandCode = "addItemToCartCommandHandler";
    		var url = "command/"+commandCode;
    		
    		dataAccessService.doPostData(url, data, function(response){
    			console.log(response);
    			$rootScope.loadCartItemsCount();
    		}, function(errorResponse){
				alertify.alert(errorResponse.data.message);
			});
    	}
		
		/**
		 * 
		 */
		let removeAllCookies = function(){
			let cookies = $cookies.getAll();
			angular.forEach(cookies, function(v, k){
				$cookies.remove(k);
			})
		};
		
    	/**
    	 * Logout
    	 */
        $rootScope.logout = function(message){
        	if(!message){
        		message = "You’ve signed out successfully."
        	}
            dataAccessService.doPostData("logout", null, function(response){
            	alertify.alert(message, function(){});
            	
            	$rootScope.session = {};
                $rootScope.noOfCartItems = null;
                $rootScope.unWatchTimeout();
                removeAllCookies();
                $rootScope.global.searchString = '';
	        	$location.search({});
                $location.path(response.headers('login_url'));
            },function(errorResponse){
                console.log(errorResponse);
            });
        }
		
    	$rootScope.toggleMobileMenu = function(){ 
			$uibModal.open({
				templateUrl  : 'app/shared/templates/mobileMenu.html',
				controller: function($scope, $uibModalInstance) {
					$scope.sample = 'hello';

			    	$scope.close = function(){
			    		console.log('Close');
			    		$uibModalInstance.close();
			    	}
				},
    			controllerAs: '$ctrl',
    			backdrop	 : "static",
				size		 : "lg",
			})
			.result.then(function(message){
                // success()
            },
            function() {                
            	// dismiss()
                console.log("dismissed");
            });
        };
        
        $rootScope.toggleProductListFilter = function(){ 
			$uibModal.open({
				templateUrl  : 'app/components/public/product/list/product-filter.html',
				controller: function($scope, $uibModalInstance) {
					$scope.sample = 'hello';

			    	$scope.close = function(){
			    		console.log('Close');
			    		$uibModalInstance.close();
			    	}
				},
    			controllerAs: '$ctrl',
    			backdrop	 : "static",
				size		 : "lg",
			})
			.result.then(function(message){
                // success()
            },
            function() {                
            	// dismiss()
                console.log("dismissed");
            });
        };
        
        /**
        * Session Timeout Watcher
        *
        */
        if($rootScope.session['AUTHENTICATED'] &&
        		$rootScope.session['AUTHENTICATED'] === true){
        	Idle.watch();
        }else{
        	Idle.unwatch();
        }

        $rootScope.watchTimeout = function(){
        	Idle.watch();
        }

        $rootScope.unWatchTimeout = function(){
        	Idle.unwatch();
        }

        let closeModals = function(){
        	if($rootScope.warning){
		        $rootScope.warning.close();
		        $rootScope.warning = null;
	        }
        }

        $rootScope.$on('IdleStart', function(){
	        closeModals();
	        $rootScope.warning = $uibModal.open({
		        templateUrl: 'warning-dialog.html',
		        windowsClass: 'modal-danger'
	        });
        });

        $rootScope.$on('IdleEnd', function(){
        	closeModals();
        });

        $rootScope.$on('IdleTimeout', function(){
	        closeModals();
	        $rootScope.logout("You’ve been signed out. Please login again to continue.");
	        Idle.watch();
        });

        $rootScope.$on('KeepAlive', function(){
        	alertify.alert('Im Alive!!!');
        });

        
    	
    }]);
    
});