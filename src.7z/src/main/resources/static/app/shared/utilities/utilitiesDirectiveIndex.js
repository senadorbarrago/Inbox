/**
 * 
 */
'use strict'
define([
    '../app/shared/utilities/directives/number/numberOnly',
    '../app/shared/utilities/directives/numberhiphen/numberHiphen',
    '../app/shared/utilities/directives/decimal/decimalOnly',
    '../app/shared/utilities/directives/owlCarousel/owlCarousel',
    '../app/shared/utilities/directives/zoom/zoom',				// added directive definition -kiev
    '../app/shared/utilities/directives/slider/slider',
    '../app/shared/utilities/directives/inputLimit/limitTo'
], function () {});