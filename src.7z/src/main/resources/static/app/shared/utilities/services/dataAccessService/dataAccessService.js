'use strict';

define(function(){
    angular.module("utilitiesModule").provider('DataAccessService', function(){
        this.$get =['$http', '$q', '$rootScope', function($http, $q, $rootScope){
            var service = {
                doGetData: function(url, data, successCallBack, errorCallBack) {
                            $rootScope.showSpinner = true;
                            return $http.get(url, data)
                                    .then(
                                            function(response){
                                                $rootScope.showSpinner = false;
                                                successCallBack(response);
                                            },
                                            function(errResponse){
                                                $rootScope.showSpinner = false;
                                                errorCallBack(errResponse);
                                            }
                                    );
                },
                doPostData: function(url, data, successCallBack, errorCallBack) {
                                $rootScope.showSpinner = true;
                                return $http.post(url, data)
                                    .then(
                                            function(response){
                                                $rootScope.showSpinner = false;
                                                successCallBack(response);
                                            },
                                            function(errResponse){
                                                $rootScope.showSpinner = false;
                                                errorCallBack(errResponse);
                                            }
                                    );
                },
                doPutData: function(url, data, successCallBack, errorCallBack) {
                    $rootScope.showSpinner = true;
                    return $http.put(url, data)
                        .then(
                                function(response){
                                    $rootScope.showSpinner = false;
                                    successCallBack(response);
                                },
                                function(errResponse){
                                    $rootScope.showSpinner = false;
                                    errorCallBack(errResponse);
                                }
                        );
                },
                doPostTransformedData: function(url, data, successCallBack, errorCallBack) {
                    $rootScope.showSpinner = true;
                        return $http.post(url, data, {
                                headers: {
                                    'Content-Type': 'application/x-www-form-urlencoded'
                                }
                            })
                            .then(
                                    function(response){
                                        $rootScope.showSpinner = false;
                                        successCallBack(response);
                                    },
                                    function(errResponse){
                                        $rootScope.showSpinner = false;
                                        errorCallBack(errResponse);
                                    }
                            );
                },
                doPostFileData: function(url, data, successCallBack, errorCallBack) {
                    $rootScope.showSpinner = true;
                        return $http.post(url, data, {
                        		transformRequest: angular.identity,
                        		headers: {
                        			'Content-Type': undefined
                        		}
                            })
                            .then(
                                    function(response){
                                        $rootScope.showSpinner = false;
                                        successCallBack(response);
                                    },
                                    function(errResponse){
                                        $rootScope.showSpinner = false;
                                        errorCallBack(errResponse);
                                    }
                            );
                },
                doQuery: function(queryCode, data, successCallBack, errorCallBack) {
                    $rootScope.showSpinner = true;
                    var url = 'qry/'+queryCode;
                    
                    return $http.post(url, data)
                    .then(
                        function(response){
                            $rootScope.showSpinner = false;
                            successCallBack(response);
                        },
                        function(errResponse){
                            $rootScope.showSpinner = false;
                            errorCallBack(errResponse);
                        }
                    );
                }
            }
            return service;
        }]
    });    
});