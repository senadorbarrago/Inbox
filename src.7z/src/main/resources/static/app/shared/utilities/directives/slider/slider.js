'use strict';

define(function(){
	var utilitiesModule = angular.module("utilitiesModule");
	utilitiesModule.directive('slider', function () {  
	    return {  
			restrict: 'A',
		    link: function(scope, element, attrs) {
			    attrs.$observe('slider', function() {
				    angular.element(element).slider({
					      range: true,
					      min: 0,
					      max: 10000,
					      values: [ 0, 5000 ],
					      slide: function( event, ui ) {
					        $( "#amount" ).val( "Php " + ui.values[ 0 ] + " - Php " + ui.values[ 1 ] );
						    $("#minPrice").val(ui.values[ 0 ]);
						    $("#maxPrice").val(ui.values[ 1 ]);
					      }
					    });
					    angular.element( "#amount" ).val( "Php " + angular.element(element).slider( "values", 0 ) +
							      " - Php " + angular.element(element).slider( "values", 1 ) );
					    angular.element("#minPrice").val(angular.element(element).slider( "values", 0 ));
					    angular.element("#maxPrice").val(angular.element(element).slider( "values", 1 ));
		    	});
		    }
	    } 
	});
});