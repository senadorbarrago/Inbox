'use strict';

define(function(){
	var utilitiesModule = angular.module("utilitiesModule");
	utilitiesModule.directive('elevateZoom', function() {
		return {
			restrict: 'A',
		    link: function(scope, element, attrs) {
			    attrs.$observe('zoomImage', function() {
			    	linkElevateZoom();
		    	});
	
			    function linkElevateZoom() {
			    	if (!attrs.zoomImage) return;
			        element.attr('data-zoom-image',attrs.zoomImage);
			        angular.element(element).elevateZoom({
//				  		zoomType: "inner",
				  		cursor: "crosshair"
			        });
			    }
	
			    linkElevateZoom();
		    }
		};
	}); 
});