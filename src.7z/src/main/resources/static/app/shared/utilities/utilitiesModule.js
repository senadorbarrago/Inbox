/**
 * 
 */
'use strict';
define(function(){
	var utilitiesModule = angular.module('utilitiesModule', []);
	console.log('utilitiesModule');
	
	utilitiesModule.config(['$controllerProvider', function ($controllerProvider) {
    		console.log('utilitiesModule.config');
    		// Module Registration
    		utilitiesModule.register = {
    				controller : $controllerProvider.register
    		};
    }]);
});