/**
 * 
 */
'use strict'
define([
    '../app/shared/utilities/services/dataAccessService/dataAccessService'
], function () {});