package com.core.ecommerce.web.application.configurations;

import java.util.Collections;
import java.util.Map;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.bdo.itd.util.cqrs.command.BasicCommandBus;
import com.bdo.itd.util.cqrs.command.ICommandBus;
import com.bdo.itd.util.cqrs.command.ICommandHandler;
import com.core.ecommerce.clientmanagement.domain.service.ClientStatusEmailServiceFactory;
import com.core.ecommerce.clientmanagement.domain.service.IClientStatusEmailService;
import com.core.ecommerce.ordermanagement.domain.service.IOrderEmailService;
import com.core.ecommerce.ordermanagement.domain.service.OrderEmailServiceFactory;

/**
 *
 * @author a014000098
 *
 */
@Configuration
public class CommandConfiguration implements BeanDefinitionRegistryPostProcessor {
        
    /**
     *
     */
    private ConfigurableListableBeanFactory beanFactory;
    
    /**
     *
     * @param commandHandlerMap
     * @return
     */
    @Bean
    public ICommandBus commandBus() {
        
        Map<String, ICommandHandler> commandBusMap = Collections.unmodifiableMap(
                beanFactory.getBeansOfType(ICommandHandler.class));
        
        for(String key : commandBusMap.keySet()){
        	System.out.println(String.format("Adding handler [%s] to command bus.", key));
        }
        
        return new BasicCommandBus(commandBusMap);
    }
    
    /**
	 * @return
	 */
	@Bean("orderEmailServiceFactory")
	public OrderEmailServiceFactory orderEmailServiceFactory(){
		Map<String, IOrderEmailService> orderEmailServiceBeanMap = Collections.unmodifiableMap(
                beanFactory.getBeansOfType(IOrderEmailService.class));
        
        for(String key : orderEmailServiceBeanMap.keySet()){
        	System.out.println(String.format("Adding orderEmailService [%s] to factory.", key));
        }
		
		return new OrderEmailServiceFactory(orderEmailServiceBeanMap);
		
	}
    
	/**
	 * @return
	 */
	@Bean("clientStatusEmailServiceFactory")
	public ClientStatusEmailServiceFactory clientStatusEmailServiceFactory(){
		Map<String, IClientStatusEmailService> clientStatusEmailServiceBeanMap = Collections.unmodifiableMap(
                beanFactory.getBeansOfType(IClientStatusEmailService.class));
        
        for(String key : clientStatusEmailServiceBeanMap.keySet()){
        	System.out.println(String.format("Adding clientStatusEmailService [%s] to factory.", key));
        }
		
		return new ClientStatusEmailServiceFactory(clientStatusEmailServiceBeanMap);
	}
	
    /**
     *
     */
    @Override
    public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry beanDefinitionRegistry)
            throws BeansException {
        
    }
    
    /**
     *
     */
    @Override
    public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory)
            throws BeansException {
        this.beanFactory =  beanFactory;        
    }
    
}
