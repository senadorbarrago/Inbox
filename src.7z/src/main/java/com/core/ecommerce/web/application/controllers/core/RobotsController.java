package com.core.ecommerce.web.application.controllers.core;

import java.io.IOException;
import java.io.InputStream;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.core.ecommerce.web.application.controllers.AbstractController;

/**
 * @author senadorbarrago
 *
 */
@RestController
public class RobotsController extends AbstractController {
    
    /**
     *
     */
    private final Logger logger = LoggerFactory.getLogger(RobotsController.class);
    
    /**
     *
     * @return
     */
    @RequestMapping(value = {"/robots", "/robot", "/robot.txt", "/robots.txt", "/null"})
    public void robot(HttpServletResponse response) throws IOException{     
        InputStream resourceAsStream = null;
        try {
            ClassLoader classLoader = this.getClass().getClassLoader();
            resourceAsStream = classLoader.getResourceAsStream("robots.txt");
     
            response.addHeader("Content-disposition", "filename=robots.txt");
            response.setContentType("text/plain");
            IOUtils.copy(resourceAsStream, response.getOutputStream());
            response.flushBuffer();
        } catch (Exception e) {
        	logger.error("Problem with displaying robot.txt", e);
        } finally {
        	resourceAsStream.close();
        }
    }
    
}
