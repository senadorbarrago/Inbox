package com.core.ecommerce.web.application.configurations;

import java.io.File;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.kduproj.util.fileloader.domain.configuration.LoadingProperties;
import com.kduproj.util.reader.configuration.FileInputSettingsFactory;
import com.kduproj.util.reader.configuration.FileSetting;
import com.kduproj.util.reader.service.ExcelFileReaderService;
import com.kduproj.util.writer.configuration.FileOutputSettings;
import com.kduproj.util.writer.configuration.FileOutputSettingsFactory;
import com.kduproj.util.writer.service.CSVFileWriterService;
//import com.core.util.email.IEmailService;


/**
 * @author senadorbarrago
 *
 */
@Configuration
public class FileLoadingConfig {

	/**
	 * 
	 */
	@Value("${settings.fileoutput}")
	private String fileOutputSettingsLocation;

	/**
	 * 
	 */
	@Value("${settings.fileinput}")
	private String fileInputSettingsLocation;
	/**
	 * 
	 */
	@Value("${settings.fileloading}")
	private String fileLoadingProperties;

	/**
	 * 
	 * @return
	 */
	@Bean
	public LoadingProperties loadingProperties() {
		return LoadingProperties.createInstance(
				new File(fileLoadingProperties));
	}
	
	/**
	 * 
	 * @return
	 */
	@Bean("ExcelFileReaderService")
	public ExcelFileReaderService excelFileReaderService(FileSetting fileSetting) {
		return new ExcelFileReaderService(fileSetting);	
	}
	
	/**
	 * 
	 * @return
	 */
	@Bean("CSVFileWriterService")
	public CSVFileWriterService csvFileWriterService(FileOutputSettings fileOutputSettings) {
		return new CSVFileWriterService(fileOutputSettings);
	}

	/**
	 * 
	 * @return
	 */
	@Bean
	public FileSetting fileSetting() {
		return FileInputSettingsFactory.createInstance(fileInputSettingsLocation)
				.getConfiguration("defaultExcelLoader"); 		// will come from request
	}

	/**
	 * 
	 * @return
	 */
	@Bean
	public FileOutputSettings fileOutputSettings() {
		return FileOutputSettingsFactory.createInstance(fileOutputSettingsLocation);
	}
	
}
