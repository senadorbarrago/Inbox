package com.core.ecommerce.web.application.configurations;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.core.ecommerce.ordermanagement.domain.model.MainStore;
import com.core.util.email.AEmailTemplate;
import com.core.util.email.BasicEmailTemplate;


/**
 * @author senadorbarrago
 *
 */
@Configuration
@EnableJpaRepositories({"com.core.ecommerce.productmanagement.infrastructure.repository",
	"com.core.ecommerce.marketingmanagement.infrastructure.repository",
	"com.core.ecommerce.usermanagement.infrastructure.repository",
	"com.core.ecommerce.clientmanagement.infrastructure.repository",
	"com.core.ecommerce.suppliermanagement.infrastructure.repository",			
	"com.core.ecommerce.ordermanagement.infrastructure.repository",
	// added entry -kiev
	"com.kduproj.util.fileloader.infrastructure.repositories"})
public class ApplicationConfig{
	
	/**
	 * 
	 */
	@Value("${email.template.askforquotation.subject}")
	private String askForQuotationSubject;
	
	/**
	 * 
	 */
	@Value("${email.template.askforquotation.header}")
	private String askForQuotationHeader;
	
	/**
	 * 
	 */
	@Value("${email.template.askforquotation.resource}")
	private String askForQuotationResource;
	
	/**
	 * 
	 */
	@Value("${email.template.registerindividual.subject}")
	private String registerIndividualSubject;
	
	/**
	 * 
	 */
	@Value("${email.template.registerindividual.header}")
	private String registerIndividualHeader;
	
	/**
	 * 
	 */
	@Value("${email.template.registerindividual.resource}")
	private String registerIndividualResource;
	
	/**
	 * 
	 */
	@Value("${email.template.buyerRegistrationConfirmation.subject}")
	private String buyerRegistrationConfirmationSubject;
	
	/**
	 * 
	 */
	@Value("${email.template.buyerRegistrationConfirmation.header}")
	private String buyerRegistrationConfirmationHeader;
	
	/**
	 * 
	 */
	@Value("${email.template.buyerRegistrationConfirmation.resource}")
	private String buyerRegistrationConfirmationResource;
	
	
	/**
	 * 
	 */
	@Value("${email.template.sellerRegistration.subject}")
	private String sellerRegistrationSubject;
	
	/**
	 * 
	 */
	@Value("${email.template.sellerRegistration.header}")
	private String sellerRegistrationHeader;
	
	/**
	 * 
	 */
	@Value("${email.template.sellerRegistration.resource}")
	private String sellerRegistrationResource;
	
	/**
	 * 
	 */
	@Value("${email.template.sellerRegistrationActivation.subject}")
	private String sellerRegistrationActivationSubject;
	
	/**
	 * 
	 */
	@Value("${email.template.sellerRegistrationActivation.header}")
	private String sellerRegistrationActivationHeader;
	
	/**
	 * 
	 */
	@Value("${email.template.sellerRegistrationActivation.resource}")
	private String sellerRegistrationActivationResource;
	
	/**
	 * 
	 */
	@Value("${email.template.sellerRegistrationConfirmation.subject}")
	private String sellerRegistrationConfirmationSubject;
	
	/**
	 * 
	 */
	@Value("${email.template.sellerRegistrationConfirmation.header}")
	private String sellerRegistrationConfirmationHeader;
	
	/**
	 * 
	 */
	@Value("${email.template.sellerRegistrationConfirmation.resource}")
	private String sellerRegistrationConfirmationResource;

	/**
	 * 
	 */
	@Value("${email.template.forgotpassword.subject}")
	private String forgotPasswordSubject;
	
	/**
	 * 
	 */
	@Value("${email.template.forgotpassword.header}")
	private String forgotPasswordHeader;
	
	/**
	 * 
	 */
	@Value("${email.template.forgotpassword.resource}")
	private String forgotPasswordResource;
	
	/**
	 * 
	 */
	@Value("${email.template.productForApprovalEmailTemplate.subject}")
	private String productForApprovalSubject;
	
	/**
	 * 
	 */
	@Value("${email.template.productForApprovalEmailTemplate.header}")
	private String productForApprovalHeader;
	
	/**
	 * 
	 */
	@Value("${email.template.productForApprovalEmailTemplate.resource}")
	private String productForApprovalResource;
	
	/**
	 * 
	 */
	@Value("${email.template.productUpdatedEmailTemplate.subject}")
	private String productUpdatedSubject;
	
	/**
	 * 
	 */
	@Value("${email.template.productUpdatedEmailTemplate.header}")
	private String productUpdatedHeader;
	
	/**
	 * 
	 */
	@Value("${email.template.productUpdatedEmailTemplate.resource}")
	private String productUpdatedResource;
	
	/**
	 * 
	 */
	@Value("${email.template.newAccountForRegistrationEmailTemplate.subject}")
	private String newAccountForRegistrationSubject;
	
	/**
	 * 
	 */
	@Value("${email.template.newAccountForRegistrationEmailTemplate.header}")
	private String newAccountForRegistrationHeader;
	
	/**
	 * 
	 */
	@Value("${email.template.newAccountForRegistrationEmailTemplate.resource}")
	private String newAccountForRegistrationResource;
	
	/**
	 * 
	 */
	@Value("${email.template.newAccountRegistrationConfirmedEmailTemplate.subject}")
	private String newAccountRegistrationConfirmedSubject;
	
	/**
	 * 
	 */
	@Value("${email.template.newAccountRegistrationConfirmedEmailTemplate.header}")
	private String newAccountRegistrationConfirmedHeader;
	
	/**
	 * 
	 */
	@Value("${email.template.newAccountRegistrationConfirmedEmailTemplate.resource}")
	private String newAccountRegistrationConfirmedResource;
	
	/**
	 * 
	 */
	@Value("${email.mainstore}")
	private String mainStoreEmail;
	
	/**
	 * 
	 */
	@Value("${email.template.awaitingForPaymentEmailTemplate.subject}")
	private String awaitingForPaymentEmailTemplateSubject;
	
	/**
	 * 
	 */
	@Value("${email.template.awaitingForPaymentEmailTemplate.header}")
	private String awaitingForPaymentEmailTemplateHeader;
	
	/**
	 * 
	 */
	@Value("${email.template.awaitingForPaymentEmailTemplate.resource}")
	private String awaitingForPaymentEmailTemplateResource;
	
	/**
	 * 
	 */
	@Value("${email.template.orderPaidEmailTemplate.subject}")
	private String orderPaidEmailTemplateSubject;
	
	/**
	 * 
	 */
	@Value("${email.template.orderPaidEmailTemplate.header}")
	private String orderPaidEmailTemplateHeader;
	
	/**
	 * 
	 */
	@Value("${email.template.orderPaidEmailTemplate.resource}")
	private String orderPaidEmailTemplateResource;
	
	/**
	 * 
	 */
	@Value("${email.template.newOrderEmailTemplate.subject}")
	private String newOrderEmailTemplateSubject;
	
	/**
	 * 
	 */
	@Value("${email.template.newOrderEmailTemplate.header}")
	private String newOrderEmailTemplateHeader;
	
	/**
	 * 
	 */
	@Value("${email.template.newOrderEmailTemplate.resource}")
	private String newOrderEmailTemplateResource;
	
	
	/**
	 * 
	 */
	@Value("${email.template.orderInStoreEmailTemplate.subject}")
	private String orderInStoreEmailTemplateSubject;
	
	/**
	 * 
	 */
	@Value("${email.template.orderInStoreEmailTemplate.header}")
	private String orderInStoreEmailTemplateHeader;
	
	/**
	 * 
	 */
	@Value("${email.template.orderInStoreEmailTemplate.resource}")
	private String orderInStoreEmailTemplateResource;
	
	/**
	 * 
	 */
	@Value("${email.template.orderShippedEmailTemplate.subject}")
	private String orderShippedEmailTemplateSubject;
	
	/**
	 * 
	 */
	@Value("${email.template.orderShippedEmailTemplate.header}")
	private String orderShippedEmailTemplateHeader;
	
	/**
	 * 
	 */
	@Value("${email.template.orderShippedEmailTemplate.resource}")
	private String orderShippedEmailTemplateResource;
	
	/**
	 * 
	 */
	@Value("${email.template.orderDeliveredEmailTemplate.subject}")
	private String orderDeliveredEmailTemplateSubject;
	
	/**
	 * 
	 */
	@Value("${email.template.orderDeliveredEmailTemplate.header}")
	private String orderDeliveredEmailTemplateHeader;
	
	/**
	 * 
	 */
	@Value("${email.template.orderDeliveredEmailTemplate.resource}")
	private String orderDeliveredEmailTemplateResource;
	
	/**
	 * 
	 */
	@Value("${email.template.attemptedDeliveryEmailTemplate.subject}")
	private String attemptedDeliveryEmailTemplateSubject;
	
	/**
	 * 
	 */
	@Value("${email.template.attemptedDeliveryEmailTemplate.header}")
	private String attemptedDeliveryEmailTemplateHeader;
	
	/**
	 * 
	 */
	@Value("${email.template.attemptedDeliveryEmailTemplate.resource}")
	private String attemptedDeliveryEmailTemplateResource;
	
	
	/**
	 * 
	 */
	@Value("${email.template.orderCancelledEmailTemplate.subject}")
	private String orderCancelledEmailTemplateSubject;
	
	/**
	 * 
	 */
	@Value("${email.template.orderCancelledEmailTemplate.header}")
	private String orderCancelledEmailTemplateHeader;
	
	/**
	 * 
	 */
	@Value("${email.template.orderCancelledEmailTemplate.resource}")
	private String orderCancelledEmailTemplateResource;
	
	
	/**
	 * 
	 */
	@Value("${email.template.contact.subject}")
	private String contactSubject;
	
	/**
	 * 
	 */
	@Value("${email.template.contact.header}")
	private String contactHeader;
	
	/**
	 * 
	 */
	@Value("${email.template.contact.resource}")
	private String contactResource;
	
	// Main Store:
	@Value("${mainstore.name}")
	private String storeName;
	
	@Value("${mainstore.address}")
	private String address;
	
	@Value("${mainstore.location}")
	private String location;
	
	@Value("${mainstore.contactPerson}")
	private String contactPerson;
	
	@Value("${mainstore.contactNo}")
	private String contactNo;
	
	@Value("${mainstore.website}")
	private String website;
	
	@Value("${mainstore.emailAddress}")
	private String emailAddress;
	
	@Value("${mainstore.facebook}")
	private String faceBook;
	
	@Value("${mainstore.instagram}")
	private String instagram;
	
	@Value("${mainstore.bankDetails.accountName}")
	private String accountName;
	
	@Value("${mainstore.bankDetails.accountNo}")
	private String accountNo;
	
	@Value("${mainstore.bankDetails.bankName}")
	private String bankName;
	
	/**
	 * @return
	 */
	@Bean
	public String mainStoreEmail(){
		return mainStoreEmail;
	}
	
	/**
	 * @return
	 */
	@Bean(name="mainStore")
	public MainStore mainStore(){
		System.out.println("mainStore()");
		MainStore mainStore = new MainStore();
		mainStore.setName(storeName);
		mainStore.setAddress(address);
		mainStore.setLocation(location);
		mainStore.setContactNo(contactNo);
		mainStore.setContactPerson(contactPerson);
		mainStore.setWebsite(website);
		mainStore.setEmailAddress(emailAddress);
		mainStore.setFaceBook(faceBook);
		mainStore.setInstagram(instagram);
		mainStore.setAccountName(accountName);
		mainStore.setAccountNo(accountNo);
		mainStore.setBankName(bankName);
		
		return mainStore;
	}
	
	/**
	 * @return
	 */
	@Bean(name="askForQuotationTemplate")
	public AEmailTemplate askForQuotationTemplate(){
		AEmailTemplate template = new BasicEmailTemplate();
		template.setSubject(askForQuotationSubject);
		template.setHeader(askForQuotationHeader);
		template.setResource(askForQuotationResource);
		
		return template;
	}
	
	/**
	 * @return
	 */
	@Bean(name="sellerRegistrationEmailTemplate")
	public AEmailTemplate sellerRegistrationEmailTemplate(){
		AEmailTemplate template = new BasicEmailTemplate();
		template.setSubject(sellerRegistrationSubject);
		template.setHeader(sellerRegistrationHeader);
		template.setResource(sellerRegistrationResource);
		
		return template;
	}
	
	/**
	 * @return
	 */
	@Bean(name="sellerRegistrationActivationEmailTemplate")
	public AEmailTemplate sellerRegistrationActivationEmailTemplate(){
		AEmailTemplate template = new BasicEmailTemplate();
		template.setSubject(sellerRegistrationActivationSubject);
		template.setHeader(sellerRegistrationActivationHeader);
		template.setResource(sellerRegistrationActivationResource);
		
		return template;
	}
	
	/**
	 * @return
	 */
	@Bean(name="sellerRegistrationConfirmationEmailTemplate")
	public AEmailTemplate sellerRegistrationConfirmationEmailTemplate(){
		AEmailTemplate template = new BasicEmailTemplate();
		template.setSubject(sellerRegistrationConfirmationSubject);
		template.setHeader(sellerRegistrationConfirmationHeader);
		template.setResource(sellerRegistrationConfirmationResource);
		
		return template;
	}
	
	/**
	 * @return
	 */
	@Bean(name="registerIndividualTemplate")
	public AEmailTemplate registerIndividualTemplate(){
		AEmailTemplate template = new BasicEmailTemplate();
		template.setSubject(registerIndividualSubject);
		template.setHeader(registerIndividualHeader);
		template.setResource(registerIndividualResource);
		
		return template;
	}
	
	/**
	 * @return
	 */
	@Bean(name="buyerRegistrationConfirmationEmailTemplate")
	public AEmailTemplate buyerRegistrationConfirmationEmailTemplate(){
		AEmailTemplate template = new BasicEmailTemplate();
		template.setSubject(buyerRegistrationConfirmationSubject);
		template.setHeader(buyerRegistrationConfirmationHeader);
		template.setResource(buyerRegistrationConfirmationResource);
		
		return template;
	}
	
	/**
	 * @return
	 */
	@Bean(name="forgotPasswordTemplate")
	public AEmailTemplate forgotPasswordTemplate(){
		AEmailTemplate template = new BasicEmailTemplate();
		template.setSubject(forgotPasswordSubject);
		template.setHeader(forgotPasswordHeader);
		template.setResource(forgotPasswordResource);
		
		return template;
	}
	
	/**
	 * @return
	 */
	@Bean(name="awaitingForPaymentEmailTemplate")
	public AEmailTemplate awaitingForPaymentEmailTemplate(){
		AEmailTemplate template = new BasicEmailTemplate();
		template.setSubject(awaitingForPaymentEmailTemplateSubject);
		template.setHeader(awaitingForPaymentEmailTemplateHeader);
		template.setResource(awaitingForPaymentEmailTemplateResource);
		
		return template;
	}
	
	/**
	 * @return
	 */
	@Bean(name="orderPaidEmailTemplate")
	public AEmailTemplate orderPaidEmailTemplate(){
		AEmailTemplate template = new BasicEmailTemplate();
		template.setSubject(orderPaidEmailTemplateSubject);
		template.setHeader(orderPaidEmailTemplateHeader);
		template.setResource(orderPaidEmailTemplateResource);
		
		return template;
	}
	
	/**
	 * @return
	 */
	@Bean(name="newOrderEmailTemplate")
	public AEmailTemplate newOrderEmailTemplate(){
		AEmailTemplate template = new BasicEmailTemplate();
		template.setSubject(newOrderEmailTemplateSubject);
		template.setHeader(newOrderEmailTemplateHeader);
		template.setResource(newOrderEmailTemplateResource);
		
		return template;
	}
	
	/**
	 * @return
	 */
	@Bean(name="orderInStoreEmailTemplate")
	public AEmailTemplate orderInStoreEmailTemplate(){
		AEmailTemplate template = new BasicEmailTemplate();
		template.setSubject(orderInStoreEmailTemplateSubject);
		template.setHeader(orderInStoreEmailTemplateHeader);
		template.setResource(orderInStoreEmailTemplateResource);
		
		return template;
	}
	
	/**
	 * @return
	 */
	@Bean(name="orderShippedEmailTemplate")
	public AEmailTemplate orderShippedEmailTemplate(){
		AEmailTemplate template = new BasicEmailTemplate();
		template.setSubject(orderShippedEmailTemplateSubject);
		template.setHeader(orderShippedEmailTemplateHeader);
		template.setResource(orderShippedEmailTemplateResource);
		
		return template;
	}
	
	/**
	 * @return
	 */
	@Bean(name="orderDeliveredEmailTemplate")
	public AEmailTemplate orderDeliveredEmailTemplate(){
		AEmailTemplate template = new BasicEmailTemplate();
		template.setSubject(orderDeliveredEmailTemplateSubject);
		template.setHeader(orderDeliveredEmailTemplateHeader);
		template.setResource(orderDeliveredEmailTemplateResource);
		
		return template;
	}
	
	/**
	 * @return
	 */
	@Bean(name="attemptedDeliveryEmailTemplate")
	public AEmailTemplate attemptedDeliveryEmailTemplate(){
		AEmailTemplate template = new BasicEmailTemplate();
		template.setSubject(attemptedDeliveryEmailTemplateSubject);
		template.setHeader(attemptedDeliveryEmailTemplateHeader);
		template.setResource(attemptedDeliveryEmailTemplateResource);
		
		return template;
	}
	
	/**
	 * @return
	 */
	@Bean(name="orderCancelledEmailTemplate")
	public AEmailTemplate orderCancelledEmailTemplate(){
		AEmailTemplate template = new BasicEmailTemplate();
		template.setSubject(orderCancelledEmailTemplateSubject);
		template.setHeader(orderCancelledEmailTemplateHeader);
		template.setResource(orderCancelledEmailTemplateResource);
		
		return template;
	}	
	
	/**
	 * @return
	 */
	@Bean(name="contactTemplate")
	public AEmailTemplate contactTemplate(){
		AEmailTemplate template = new BasicEmailTemplate();
		template.setSubject(contactSubject);
		template.setHeader(contactHeader);
		template.setResource(contactResource);
		
		return template;
	}
	
	/**
	 * @return
	 */
	@Bean(name="productForApprovalEmailTemplate")
	public AEmailTemplate productForApprovalEmailTemplate(){
		AEmailTemplate template = new BasicEmailTemplate();
		template.setSubject(productForApprovalSubject);
		template.setHeader(productForApprovalHeader);
		template.setResource(productForApprovalResource);
		
		return template;
	}
	
	/**
	 * @return
	 */
	@Bean(name="productUpdatedEmailTemplate")
	public AEmailTemplate productUpdatedEmailTemplate(){
		AEmailTemplate template = new BasicEmailTemplate();
		template.setSubject(productUpdatedSubject);
		template.setHeader(productUpdatedHeader);
		template.setResource(productUpdatedResource);
		
		return template;
	}
	
	/**
	 * @return
	 */
	@Bean(name="newAccountForRegistrationEmailTemplate")
	public AEmailTemplate newAccountForRegistrationEmailTemplate(){
		AEmailTemplate template = new BasicEmailTemplate();
		template.setSubject(newAccountForRegistrationSubject);
		template.setHeader(newAccountForRegistrationHeader);
		template.setResource(newAccountForRegistrationResource);
		
		return template;
	}
	
	/**
	 * @return
	 */
	@Bean(name="newAccountRegistrationConfirmedEmailTemplate")
	public AEmailTemplate newAccountRegistrationConfirmedEmailTemplate(){
		AEmailTemplate template = new BasicEmailTemplate();
		template.setSubject(newAccountRegistrationConfirmedSubject);
		template.setHeader(newAccountRegistrationConfirmedHeader);
		template.setResource(newAccountRegistrationConfirmedResource);
		
		return template;
	}
}