package com.core.ecommerce.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;

import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootApplication
@ComponentScan({"com.core.ecommerce", "com.core.util.email", 
	// added entry -kiev
	"com.kduproj.util"})
@EntityScan({"com.core.ecommerce.productmanagement.infrastructure.persistence",
	"com.core.ecommerce.marketingmanagement.infrastructure.persistence",
	"com.core.ecommerce.usermanagement.infrastructure.persistence",
	"com.core.ecommerce.clientmanagement.infrastructure.persistence",
	"com.core.ecommerce.suppliermanagement.infrastructure.persistence",
	"com.core.ecommerce.ordermanagement.infrastructure.persistence",
	// added entry -kiev
	"com.kduproj.util.fileloader.domain.model"})
public class EcommerceWebApplication extends SpringBootServletInitializer {
	
	public static void main(String[] args) {
		// Auto Detect All Properties
		ObjectMapper objectMapper = new ObjectMapper();
	    objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
	    
		SpringApplication.run(EcommerceWebApplication.class, args);
	}
	
	@Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(EcommerceWebApplication.class);
    }
}
		