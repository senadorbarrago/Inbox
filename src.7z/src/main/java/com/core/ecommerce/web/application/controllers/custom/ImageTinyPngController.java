package com.core.ecommerce.web.application.controllers.custom;


//import java.io.IOException;

//import com.tinify.Source;
//import com.tinify.Tinify;



public class ImageTinyPngController {
//	public static void main(String[] args) {
//	    Tinify.setKey("gtPnwrrUD7SZT_MciKKdv5OaVEkdkL4U");
//	    
//		try {
//			Source source = Tinify.fromUrl("https://tinypng.com/images/panda-happy.png");
//			source.toFile("optimized.png");
//			System.out.println("Done");
//		} catch (IOException e) {
//			System.out.println(e.getMessage());
//			e.printStackTrace();
//		}
//	    
//	    
//	  }
}
