package com.core.ecommerce.web.application.controllers.core;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.core.ecommerce.ordermanagement.infrastructure.report.IReportDataGenerator;
import com.core.ecommerce.ordermanagement.infrastructure.report.ReportDataGeneratorFactory;
import com.core.ecommerce.web.application.controllers.AbstractController;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRMapCollectionDataSource;
import net.sf.jasperreports.engine.util.JRLoader;

/**
 * @author senadorbarrago
 *
 */
@RestController
@RequestMapping(value = "/report")
public class ReportController extends AbstractController{
	
	/**
	 * 
	 */
	private ReportDataGeneratorFactory reportDataGeneratorFactory;
	
	/**
	 * @param commandBus
	 */
	@Inject
	public ReportController(ReportDataGeneratorFactory reportDataGeneratorFactory) {
		super();
		this.reportDataGeneratorFactory = reportDataGeneratorFactory;
	}
	
	/**
	 * @param commandCode
	 * @param data
	 * @param request
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value = "/{reportCode}/{orderNo}", method = RequestMethod.GET)
	public void doGenerate(@PathVariable(name = "reportCode") String reportCode, 
			@PathVariable(name = "orderNo") String orderNo, HttpServletRequest request,
				HttpServletResponse response) throws Exception{
		System.out.println(this.getClass()+": "+"doGenerate()");		
		System.out.println("reportCode: "+reportCode);
		
		IReportDataGenerator reportDataGenerator = reportDataGeneratorFactory.getReportDataGenerator(reportCode); 
		
		Map<String, Object> data = new HashMap<>();
		data.put("orderNo", orderNo);
		
		Map<String, Object> dataMap = reportDataGenerator.getDataMap(data);
		String reportTemplate = reportDataGenerator.getReportTemplate();
	    
		System.out.println("xxxxxxxxxxxxxxxxxxxx: " + ClassLoader.getSystemClassLoader().toString());
		InputStream jasperStream = this.getClass().getClassLoader().getResourceAsStream(reportTemplate); 
				//ClassLoader.getSystemClassLoader().getResourceAsStream(reportTemplate);
		System.out.println("jasperStream");
		System.out.println(jasperStream);
		JasperReport report = (JasperReport) JRLoader.loadObject(jasperStream);
		JRDataSource dataSource = new JRMapCollectionDataSource(
				(List) dataMap.get("records")); 

		JasperPrint jasperPrint = JasperFillManager.fillReport(report, dataMap, dataSource);
		
		String filename = dataMap.get("filename").toString();
		
	    response.setContentType("application/pdf");
	    response.setHeader("Content-disposition", "attachment; filename=\"" + filename + "\".pdf");

	    final OutputStream outStream = response.getOutputStream();
	    JasperExportManager.exportReportToPdfStream(jasperPrint, outStream);
	}
	
}
