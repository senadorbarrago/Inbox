package com.core.ecommerce.web.application.controllers.core;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class RedirectController {
	
	/**
	 * 
	 */
	private final Logger logger = LoggerFactory.getLogger(getClass());
	
	/**
	 * @return
	 */
	@RequestMapping("/**/{[path:[^\\.]*}")
	public String reRoutePublic(){
		logger.info("reRoutePublic()");
		return "/";
	}
	
//	/**
//	 * @return
//	 */
//	@RequestMapping("/private/**")
//	public String reRoutePrivate(){
//		logger.info("reRoutePrivate()");
//		return "/";
//	}
	
}
