package com.core.ecommerce.web.application.configurations;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.security.core.session.SessionRegistryImpl;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;
import org.springframework.security.web.session.HttpSessionEventPublisher;
import org.springframework.security.web.session.SessionManagementFilter;

import com.core.ecommerce.usermanagement.application.SpringSecurityAuthenticationProvider;
import com.core.ecommerce.usermanagement.infrastructure.authentication.handlers.CustomAuthenticationFailureHandler;
import com.core.ecommerce.usermanagement.infrastructure.authentication.handlers.CustomAuthenticationSuccessHandler;
import com.core.ecommerce.usermanagement.infrastructure.authentication.handlers.CustomLogoutHandler;
import com.core.ecommerce.usermanagement.infrastructure.crypto.ICrypto;
import com.core.ecommerce.usermanagement.infrastructure.crypto.JasyptCypto;
import com.core.ecommerce.web.infrastructure.filters.CorsFilter;

/**
 * @author senadorbarrago
 *
 */
@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
	
	/**
	 * 
	 */
	private static Logger logger = Logger.getLogger(CorsFilter.class);
	
	@Autowired
    private SpringSecurityAuthenticationProvider authenticationProvider;
	
    @Override
    protected void configure(HttpSecurity http) throws Exception {
    	logger.info("configure()");
        http
        	.addFilterBefore(corsFilter(), SessionManagementFilter.class)
        	.csrf().disable()
            .authorizeRequests()
            	.antMatchers("/webjars/**", "/app/**", "/assets/**", "/login*", "/", "/command/**", "/query/**", "/invalidSession", "/sessionTimeOut", "/report/**", "/public/**", "/robots*").permitAll()
                .anyRequest().authenticated()
                .and()
            .sessionManagement()
//                .maximumSessions(1)
//                .maxSessionsPreventsLogin(true)
//                .and()
                .enableSessionUrlRewriting(false)
                .sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED)
                .sessionFixation().migrateSession()
                //.invalidSessionUrl("/invalidSession")
                .sessionAuthenticationErrorUrl("/sessionTimeOut")
                .and()    
            .formLogin()
                .loginPage("/")
                .loginProcessingUrl("/login")
                .usernameParameter("username")
                .passwordParameter("password")
                .successHandler(customAuthenticationSuccessHandler())
                .failureHandler(customAuthenticationFailureHandler())
                .permitAll()
                .and()
            .logout()
            	.logoutSuccessHandler(logoutSuccessHandler())
            	.permitAll();
                
    }

    @Autowired
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        System.out.println(this.getClass()+"- configure(AuthenticationManagerBuilder auth)");
    	auth.authenticationProvider(authenticationProvider);
    }    
    
    /**
     * @return
     */
    @Bean
    public HttpSessionEventPublisher httpSessionEventPublisher(){
        return new HttpSessionEventPublisher();
    }
    
    /**
     * @return
     */
    @Bean
    public SessionRegistry sessionRegistry(){
        return new SessionRegistryImpl();
    }
    
    /**
     * @return
     */
    @Bean
    public ICrypto crypto(){
    	return new JasyptCypto(4, "HD", "PBEWithSHA1AndDESEDE");
    }
    
    /**
     * @return
     */
    @Bean
    public AuthenticationSuccessHandler customAuthenticationSuccessHandler(){
    	return new CustomAuthenticationSuccessHandler(200);
    }
    
    /**
     * @return
     */
    @Bean
    public AuthenticationFailureHandler customAuthenticationFailureHandler(){
    	return new CustomAuthenticationFailureHandler("/public/security/login", 401);
    }
    
    /**
     * @return
     */
    @Bean
    public LogoutSuccessHandler logoutSuccessHandler(){
    	return new CustomLogoutHandler("/public/security/login");
    }
    
    /**
     * @return
     */
    @Bean
    public CorsFilter corsFilter() {
    	logger.info("corsFilter()");
    	CorsFilter filter = new CorsFilter();
        
        return filter;
    }
}
