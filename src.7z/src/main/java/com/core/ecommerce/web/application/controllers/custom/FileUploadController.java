package com.core.ecommerce.web.application.controllers.custom;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.bdo.itd.util.cqrs.command.CommandFactory;
import com.bdo.itd.util.cqrs.command.CommandMessage;
import com.bdo.itd.util.cqrs.command.ICommand;
import com.bdo.itd.util.cqrs.command.ICommandBus;
import com.bdo.itd.util.cqrs.command.UnableToProcessCommandException;
import com.core.ecommerce.web.application.controllers.AbstractController;

/**
 * 
 * @author Kiev Umali
 */
@RestController
@RequestMapping(value = "/command")
public class FileUploadController extends AbstractController{

	/**
	 * 
	 */
	private final ICommandBus commandBus;
	
	/**
	 * @param commandBus
	 */
	@Inject
	public FileUploadController(ICommandBus commandBus) {
		super();
		this.commandBus = commandBus;
	}

	/**
	 * 
	 * @param file
	 * @param loadedBy
	 * @param request
	 * @return
	 */
	@RequestMapping(
			value = "/loadFileCommandHandler", 
			method = RequestMethod.POST//,
//			produces = MediaType.APPLICATION_OCTET_STREAM_VALUE
			)
//	@ResponseBody
	public Object doCommand( 
			@RequestParam(name="file") MultipartFile file,
			@RequestParam(name="loadedBy") String loadedBy,
			HttpServletRequest request){
		System.out.println(this.getClass()+": "+"doCommand()");
		
		Map<String, Object> data = new HashMap<>();
		try {
			data.put("fileStream", file.getInputStream());
		} catch (IOException e) {
			throw new UnableToProcessCommandException(e.getMessage(), e);
		}
		data.put("filename", file.getOriginalFilename());
		data.put("loadedBy", loadedBy);
		
		ICommand command = CommandFactory.create("loadFileCommandHandler", data);
		CommandMessage message = commandBus.doPublish(command);
		
		return message;
	}

}
