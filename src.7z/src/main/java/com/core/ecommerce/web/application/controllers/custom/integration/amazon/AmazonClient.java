package com.core.ecommerce.web.application.controllers.custom.integration.amazon;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.PutObjectRequest;

@Service
public class AmazonClient {
	
	private AmazonS3 s3Client;
	
	
	static {
	    //for localhost testing only
	    javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
	    new javax.net.ssl.HostnameVerifier(){

	        public boolean verify(String hostname,
	                javax.net.ssl.SSLSession sslSession) {
	            return true;
	        }
	    });
	}
	
	
	@Value("${amazonProperties.endPointUrl}")
	private String endpointUrl; 
	//https://hoteldepot-bucket.s3-ap-southeast-1.amazonaws.com/1518220480288-avatar.png
	//https://s3.us-east-2.amazonaws.com/hoteldepot-bucket/1518220480288-avatar.png
	
	
	@Value("${amazonProperties.bucketName}")
	private String bucketName;
	
	@Value("${amazonProperties.accessKey}")
	private String accessKey;
	
	@Value("${amazonProperties.secretKey}")
	private String secretKey;
	
	
	
	@PostConstruct
	private void initializeAmazon() {
		AWSCredentials credentials = new BasicAWSCredentials(this.accessKey, this.secretKey);
		this.s3Client = new AmazonS3Client(credentials);
	}
	
	private File convertMultipartToFile(MultipartFile file) throws IOException {
		System.out.println("MultipartFile: "+file.getOriginalFilename());
		
		File convFile = new File(file.getOriginalFilename());
		
		System.out.println("convFileAbsolutePath: "+convFile.getAbsolutePath());
		System.out.println("convFilePath: "+convFile.getPath());
		System.out.println("convFilePath: "+convFile.getName());
		
		FileOutputStream fos = new FileOutputStream(convFile);
		fos.write(file.getBytes());
		fos.close();
		
	    return convFile;
	}
	
	private String generateFileName(MultipartFile multiPart) {
	    return new Date().getTime() + "-" + multiPart.getOriginalFilename().replace(" ", "_");
	}
	
	private void uploadFileToS3bucket(String fileName, File file) {
	    s3Client.putObject(new PutObjectRequest(bucketName, fileName, file)
	            .withCannedAcl(CannedAccessControlList.PublicRead));
	}
	
	public String uploadFile(MultipartFile multipartFile, String folder) {

	    String fileUrl = "";
	    try {
	        File file = convertMultipartToFile(multipartFile);
	        String fileName = generateFileName(multipartFile);
	        fileUrl = endpointUrl + "/" + bucketName + "/" + folder + "/" + fileName;
	        uploadFileToS3bucket(folder+"/"+fileName, file);
	        file.delete();
	    } catch (Exception e) {
	       e.printStackTrace();
	    }
	    return fileUrl;
	}
	
	public String deleteFileFromS3Bucket(String fileUrl) {
	    String fileName = fileUrl.substring(fileUrl.substring(0, fileUrl.lastIndexOf("/")).lastIndexOf("/") + 1);
	    System.out.println("filename: "+ bucketName + "/" + fileName); 
	    s3Client.deleteObject(new DeleteObjectRequest(bucketName, fileName));
	    return "Successfully deleted";
	}

	public String getEndpointUrl() {
		return endpointUrl;
	}

	public void setEndpointUrl(String endpointUrl) {
		this.endpointUrl = endpointUrl;
	}

	public String getBucketName() {
		return bucketName;
	}

	public void setBucketName(String bucketName) {
		this.bucketName = bucketName;
	}

	public String getAccessKey() {
		return accessKey;
	}

	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}

	public String getSecretKey() {
		return secretKey;
	}

	public void setSecretKey(String secretKey) {
		this.secretKey = secretKey;
	}
	
	
	
	
}
