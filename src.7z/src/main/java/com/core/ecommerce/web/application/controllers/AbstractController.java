package com.core.ecommerce.web.application.controllers;

import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.bdo.itd.util.cqrs.command.CommandException;
import com.bdo.itd.util.cqrs.query.QueryException;

/**
 * @author senadorbarrago
 *
 */
public abstract class AbstractController {
	
	/**
	 * @param response
	 * @return
	 */
	@ExceptionHandler(CommandException.class)
	@ResponseStatus(value=HttpStatus.BAD_REQUEST)
	protected Object handleCommandException(HttpServletResponse response){
		return new Object();
	}
	
	/**
	 * @param response
	 * @return
	 */
	@ExceptionHandler(QueryException.class)
	@ResponseStatus(value=HttpStatus.BAD_REQUEST)
	protected Object handleQueryException(HttpServletResponse response){
		return new Object();
	}
	
	/**
	 * @param response
	 * @return
	 */
	@ExceptionHandler(Exception.class)
	@ResponseStatus(value=HttpStatus.INTERNAL_SERVER_ERROR)
	protected Object handleException(HttpServletResponse response){
		return new Object();
	}
}
