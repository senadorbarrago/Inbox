package com.core.ecommerce.web.application.controllers.core;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.userdetails.User;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.core.ecommerce.usermanagement.application.UserSession;

/**
 * @author senadorbarrago
 *
 */
@RestController
@RequestMapping(value = "/security")
public class UserSessionController {
	
	/**
	 * @return
	 */
	@RequestMapping(value = "/authenticatedUser", method = RequestMethod.GET)
	public User getAuthenticatedUser(HttpServletRequest request, HttpServletResponse response) {
		System.out.println(this.getClass()+"-"+request.getSession().getId());
		return UserSession.getUserProfile();
	}
	
	/**
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping(value = "/invalidSession", method = RequestMethod.GET)
	public void redirectToLogin(HttpServletRequest request, HttpServletResponse response) throws IOException{
		System.out.println(this.getClass()+"-"+request.getSession().getId());
		response.addHeader("LOGIN_PAGE", "/public/security/login");
	}
	
}
