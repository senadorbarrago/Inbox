package com.core.ecommerce.web.application.configurations;

import java.util.Collections;
import java.util.Map;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.bdo.itd.util.cqrs.query.IQuery;
import com.bdo.itd.util.cqrs.query.QueryModelProvider;

/**
 *
 * @author a014000098
 *
 */
@Configuration
public class QueryConfiguration implements BeanDefinitionRegistryPostProcessor {
    /**
     *
     */
    private ConfigurableListableBeanFactory beanFactory;
    
    /**
     *
     * @param queryModelMap
     * @return
     */
    @Bean
    public QueryModelProvider queryModelProvider() {
        
        Map<String, IQuery> queryModelMap = Collections.unmodifiableMap(
                beanFactory.getBeansOfType(IQuery.class));
        
        for (String key : queryModelMap.keySet()) {
            System.out.println(String.format("Adding query [%s] to query provider.", key));            
        }

        
        return new QueryModelProvider(queryModelMap);
    }

    /**
     *
     */
    @Override
    public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory)
            throws BeansException {
        this.beanFactory = beanFactory;
    }

    /**
     *
     */
    @Override
    public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry arg0)
            throws BeansException {
        
    }
    
}
