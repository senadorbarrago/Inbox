package com.core.ecommerce.web.application.command;

import java.io.InputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bdo.itd.util.cqrs.command.ACommandHandler;
import com.bdo.itd.util.cqrs.command.CommandMessage;
import com.bdo.itd.util.cqrs.command.ICommand;
import com.bdo.itd.util.cqrs.command.UnableToProcessCommandException;
import com.kduproj.util.fileloader.service.FileLoaderService;

/**
 * 
 * @author Kiev Umali
 */
@Service
public class LoadFileCommandHandler extends ACommandHandler {

	/**
	 * 
	 */
	private final FileLoaderService fileLoaderService;
	
	/**
	 * 
	 * @param fileLoaderService
	 */
	@Autowired
	public LoadFileCommandHandler(FileLoaderService fileLoaderService) {
		super();
		this.fileLoaderService = fileLoaderService;
	}

	@Override
	public CommandMessage doHandle(ICommand command) throws UnableToProcessCommandException {
		System.out.println(this.getClass()+": doHandle()");
		InputStream inputStream = command.getTypeValue("fileStream", InputStream.class);
		String filename = command.getStringValue("filename");
		String loadedBy = command.getStringValue("loadedBy");

		Object object = fileLoaderService.loadFile(
				filename,
				inputStream,
				loadedBy);
		//return object;
		return commandMessageFactory.createSuccessMessage("File successfully loaded.");
	}
	
}
