package com.core.ecommerce.web.application.configurations;

import java.util.Collections;
import java.util.Map;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.core.ecommerce.ordermanagement.infrastructure.report.IReportDataGenerator;
import com.core.ecommerce.ordermanagement.infrastructure.report.ReportDataGeneratorFactory;

/**
 *
 * @author a014000098
 *
 */
@Configuration
public class ReportConfiguration implements BeanDefinitionRegistryPostProcessor {
    /**
     *
     */
    private ConfigurableListableBeanFactory beanFactory;
        
    /**
     * @return
     */
    @Bean
    public ReportDataGeneratorFactory reportDataGeneratorFactory() {
        
    	Map<String, IReportDataGenerator> reportDataGeneratorMap = Collections.unmodifiableMap(
                beanFactory.getBeansOfType(IReportDataGenerator.class));
        
        for (String key : reportDataGeneratorMap.keySet()) {
            System.out.println(String.format("Adding query [%s] to ReportGeneratorFactory.", key));            
        }

        return new ReportDataGeneratorFactory(reportDataGeneratorMap);
    }

    /**
     *
     */
    @Override
    public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory)
            throws BeansException {
        this.beanFactory = beanFactory;
    }

    /**
     *
     */
    @Override
    public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry arg0)
            throws BeansException {
        
    }
    
}
