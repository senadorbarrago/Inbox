package com.bdo.itd.projects.bdocors.web;

//@RunWith(SpringRunner.class)
//@SpringBootTest
public class BdoCorsWebApplicationTests {

//	@Test
	public void contextLoads() {
	}

}
