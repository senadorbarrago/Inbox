'use strict';

define(function(){
	
	console.log('homeController.js loaded');
	var core = angular.module('core');
	
	core.registerController('homeController', ['$rootScope', '$scope', '$cookies', 'DataAccessService', 
		function($rootScope, $scope, $cookies, dataAccessService){
		$scope.title = 'This is the Home screen';
		$rootScope.screenName = 'Home'
	
		console.log('authenticated: '+$rootScope.session['AUTHENTICATED']);
		
		var vm = this;

		vm.init = function(){
			$rootScope.$broadcast("initializeAuthority");
		}
		
		// Initialize
		vm.init();
		
	}]);
	
});