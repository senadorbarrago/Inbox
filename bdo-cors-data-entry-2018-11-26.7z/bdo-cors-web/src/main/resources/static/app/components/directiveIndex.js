'use strict'

define(function(){
	return [
	        'app/shared/directives/tabset/tabSetDirective',
	        'app/shared/directives/tabset/tabDirective',
	        'app/shared/directives/datetime/dateTimeDirective',
	        'app/shared/directives/datagrid/simpleDataGridDirective',
	        'app/shared/directives/validators/isNumericValidatorDirective',
	        'app/shared/directives/validators/decimalPlacesDirective',
	        'app/shared/directives/validators/numberOnlyDirective',
	        'app/shared/directives/validators/moneyDirective',
	        'app/shared/directives/validators/restrictPatternDirective'
	        ]
});