'use strict';

define(function(){
	angular.module("reportFormModule").provider('ReportFormQueryService', function(){
		this.$get =['DataAccessService', function(dataAccessService){
			var service = {
				getEncodingUnits: function(successCallBack, errorCallBack){
					var url = 'references/encodingUnits'
					dataAccessService.doGetData(url, null, function(response){
						console.log(response.data);
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				}, 
				getGroupUsers: function(dataSetID, successCallBack, errorCallBack){
					var url = 'references/groupUsers/'+dataSetID;
					dataAccessService.doGetData(url, null, function(response){
						console.log(response.data);
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				}, 
				getUserCode: function(dataSetCode, successCallBack, errorCallBack){
					var url = 'references/userCode/'+dataSetCode;
					dataAccessService.doGetData(url, null, function(response){
						console.log(response.data);
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getTagTypes: function(dataSetCode, successCallBack, errorCallBack){
					var url = 'references/tagTypeByDataSetCode/'+dataSetCode;
					dataAccessService.doGetData(url, null, function(response){
						console.log(response.data);
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getInterfaceFiles: function(dataSetCode, PDEdata, successCallBack, errorCallBack){
					var url = 'references/interfaceFiles/'+dataSetCode;
					dataAccessService.doPostData(url, PDEdata, function(response){
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getCurrenciesByDataSetCode: function(dataSetCode, successCallBack, errorCallBack){
					var url = 'references/currencyByDataSetCode/'+dataSetCode;
					dataAccessService.doGetData(url, null, function(response){
						console.log(response.data);
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getCurrencyShortDesc: function(dataSetCode, successCallBack, errorCallBack){
					var url = 'references/currencyShortDesc/'+dataSetCode;
					dataAccessService.doGetData(url, null, function(response){
						console.log(response.data);
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getUserProcessInfo: function(dataSetCode, successCallBack, errorCallBack){
					var url = 'references/userProcessInfo/'+dataSetCode;
					dataAccessService.doGetData(url, null, function(response){
						console.log(response.data);
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getEffectiveMonths: function(dataSetCode, successCallBack, errorCallBack){
					var url = 'references/effectiveMonths/'+dataSetCode;
					dataAccessService.doGetData(url, null, function(response){
						console.log(response.data);
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				},
				getEffectiveYears: function(dataSetCode, successCallBack, errorCallBack){
					var url = 'references/effectiveYears/'+dataSetCode;
					dataAccessService.doGetData(url, null, function(response){
						console.log(response.data);
						successCallBack(response);
					},function(errorResponse){
						errorCallBack(errorResponse);
					});
				}
			}
			return service;
		}]
	});	
});