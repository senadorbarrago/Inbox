'use strict';

define(function(){
	var core = angular.module('core');
	
	core.registerController('fileLoadingController',['$rootScope','$scope', 'ngTableParams', 'DataAccessService', 
	    function($rootScope, $scope, ngTableParams, dataAccessService){

		// Title and Module Description
		var vm = this;
		$rootScope.screenName = 'File Loading';
		
		// Initialize Data
		vm.init = function(){
			$scope.data = {};
			$scope.data.dataSetCode = $rootScope.dataSetCode;
			
			// Table Header 
			$scope.tableHeader = ['Select', 'File Name', 'File Path', 'Size', 'Date Created'];
			$scope.fileHistoryHeader = ['Select', 'File Log ID', 'File Name', 'Date Loaded', 'Loaded By', 'Status'];
			
			// References
			vm.references = {};
			
			vm.checkFileTransferServiceConnection();
			vm.checkLoadServiceConnection();
			vm.doGetRemoteSourceFiles();
			vm.doGetDefaultSourceContents();
			vm.initDatePicker();
		};
		
		/**
		 * 
		 */
		vm.doGetRemoteSourceFiles = function(){
			console.log("vm.doGetRemoteSourceFiles()");
			var data = {};
			data.profile = "cloud_sftp_server";
			data.listSource = "REMOTE";
			
			dataAccessService.doQuery('remoteFilesQueryModel', data, function(response){
				console.log('remoteFilesQueryModel');
				console.log(response.data);
				vm.remoteSourceFileData = response.data.resultSet[0].connection;
				
			},function(errorResponse){
				console.log(errorResponse);
			});
		}
		
		/*
		 * 
		 */
		vm.doGetDefaultSourceContents = function(){
			console.log("vm.doGetDefaultSourceContents()");
			var data = {};
			data = angular.copy($scope.data);
			data.sourceFolderCode = "SRC";
			
			dataAccessService.doQuery('folderContentsQueryModel', data, function(response){
				vm.sourceFolderData = response.data;
				console.log(vm.sourceFolderData);
			},function(errorResponse){
				console.log(errorResponse);
			});
		}
        
		// UI Validations
		vm.checkIfHasSelection = function(list){
			for(var index = 0; index < list.length; index++){
				if(list[index]["Selected"]){
					return true;
				}
			}
			return false;
		}
		
		// DatePicker SetUp
		vm.initDatePicker = function(){
			console.log("vm.initDatePicker()");
			vm.datePicker = {};
			vm.dateOptions = {
					startingDay : 0,
					showWeeks : false,	
					format : "yyyy-MM-dd",
					timezone: 'UTC'
				};
			vm.dateFormat = "yyyy-MM-dd";
		}
		
		/**
		 * 
		 */
		vm.checkFileTransferServiceConnection = function(){
			console.log('vm.checkFileTransferServiceConnection():');
			var data = {};
			console.log(data);
			
			vm.fileTransfer = {};
			dataAccessService.doQuery('fileTransferServiceConnectionQueryModel', data, function(response){
				console.log('fileTransferServiceConnectionQueryModel');
				console.log(response.data);
				if(response.data.resultSet && response.data.resultSet[0].connection){
					vm.fileTransfer.serviceName = response.data.resultSet[0].connection.serviceName;
					vm.fileTransfer.serviceVersion = response.data.resultSet[0].connection.version;
					vm.fileTransfer.serviceStatus = response.data.resultSet[0].connection.status;
					vm.fileTransfer.serviceDetails = vm.fileTransfer.serviceName+"-"+vm.fileTransfer.serviceVersion+" | Connection Status: "+vm.fileTransfer.serviceStatus;
				}else{
					vm.fileTransfer.serviceDetails = "Not Connected";
				}
			},function(errorResponse){
				console.log(errorResponse);
				vm.fileTransfer.serviceDetails = "Not Connected";
			});
		}
		
		/**
		 * 
		 */
		vm.checkLoadServiceConnection = function(){
			console.log('vm.checkConnection():');
			var data = {};
			console.log(data);
			dataAccessService.doQuery('fileLoadingServiceConnectionQueryModel', data, function(response){
				console.log('fileLoadingServiceConnectionQueryModel');
				console.log(response.data);
				
				if(response.data.resultSet && response.data.resultSet[0].connection){
					vm.serviceName = response.data.resultSet[0].connection.serviceName;
					vm.serviceVersion = response.data.resultSet[0].connection.serviceVersion;
					vm.serviceStatus = response.data.resultSet[0].connection.serviceStatus;
					vm.serviceDetails = vm.serviceName+"-"+vm.serviceVersion+" | Connection Status: "+vm.serviceStatus;
				}else{
					vm.serviceDetails = "Not Connected";
				}
				
			},function(errorResponse){
				console.log(errorResponse);
				vm.serviceDetails = "Not Connected";
			});
		}

		/**
		 * 
		 */
		vm.doLoad = function(){
			var sourceFolderDataCopy = angular.copy(vm.sourceFolderData.resultSet);
			var hasSelection = vm.checkIfHasSelection(sourceFolderDataCopy);
			
			if(!hasSelection){
				alertify.alert("Please select a file to be loaded in order to proceed.");
				return false;
			}else{
				alertify.confirm("This action loads the selected files from the source folder. " +
								"Are you sure you want to proceed?", function(e){
				if(e){
						var sourceFileList = [];
						angular.forEach(sourceFolderDataCopy, function(value, key){
							if(value["Selected"]){
								var data = {};
								data.sourceFile = value["File Name"];
								
								dataAccessService.doPost("loadFileCommandHandler", data, function(response){
									console.log(response.data);
									alertify.alert(response.data.messageMap['SUCCESS_MESSAGE']);
									vm.doGetDefaultSourceContents();
								}, function(errorResponse){
									console.log(errorResponse);
									alertify.alert(errorResponse.data['ERROR_MESSAGE']);
								});
							}
						});
					}else{
						return false;
					}
				});
			}
		};
		
		/**
		 * 
		 */
		vm.doFileTransfer = function(){
			var remoteFolderDataCopy = angular.copy(vm.remoteSourceFileData.files);
			var hasSelection = vm.checkIfHasSelection(remoteFolderDataCopy);
			
			if(!hasSelection){
				alertify.alert("Please select file/s to be transfered in order to proceed.");
				return false;
			}else{
				alertify.confirm("This action transfers the selected file/s from the SFTP source server. " +
								"Are you sure you want to proceed?", function(e){
				if(e){
						var sourceFileList = [];
						angular.forEach(remoteFolderDataCopy, function(value, key){
							if(value["Selected"]){
								var data = {};
								data.profile = 'cloud_sftp_server';
								data.filename = value["name"];
								
								dataAccessService.doPost("transferFileCommandHandler", data, function(response){
									console.log(response.data);
									alertify.alert(response.data.messageMap['SUCCESS_MESSAGE']);
									vm.doGetDefaultSourceContents();
								}, function(errorResponse){
									console.log(errorResponse);
									alertify.alert(errorResponse.data['ERROR_MESSAGE']);
								});
							}
						});
					}else{
						return false;
					}
				});
			}
		};		
		
		/**
		 * 
		 */
		vm.doRemoveFiles = function(){
			var sourceFolderDataCopy = angular.copy(vm.sourceFolderData.resultSet);
			var hasSelection = vm.checkIfHasSelection(sourceFolderDataCopy);
			
			if(!hasSelection){
				alertify.alert("Please select file/s to be removed in order to proceed.");
				return false;
			}else{
				alertify.confirm("This action removes the selected file/s from the source folder. " +
								"Are you sure you want to proceed?", function(e){
				if(e){
						var sourceFileList = [];
						angular.forEach(sourceFolderDataCopy, function(value, key){
							if(value["Selected"]){
								var data = {};
								data.sourceFile = value["Path"]+"/"+value["File Name"];
								
								dataAccessService.doPost("removeSelectedFilesCommandHandler", data, function(response){
									console.log(response.data);
									alertify.alert(response.data.messageMap['SUCCESS_MESSAGE']);
									vm.doGetDefaultSourceContents();
								}, function(errorResponse){
									console.log(errorResponse);
									alertify.alert(errorResponse.data['ERROR_MESSAGE']);
								});
							}
						});
					}else{
						return false;
					}
				});
			}
		};
		/**
		 * 
		 */
		$scope.selectFile = function(element){
			console.log("selectFile()");
			var files = element.files;
			angular.forEach(files, function(file){
				console.log(file);
				vm.filename = file.name;
				vm.file = file;
			});
		};
		
		vm.uploadFile = function(){
			if(!vm.file){
				alertify.alert("Please select a file from your workstation in order to proceed.");
				return false;
			}
			
			
			alertify.confirm("This action uploads the selected file " +vm.filename+ " from your workstation. " +
					"Are you sure you want to proceed?", function(e){
				if(e){
					console.log("Sending file "+vm.filename+"...");
					var fileData = new FormData();
					fileData.append("file", vm.file);
					
					var url = "command/uploadFileCommandHandler";
					
					dataAccessService.doPostFileData(url, fileData, function(response){
						console.log(response);
						vm.doGetDefaultSourceContents();
						alertify.alert("The selected file "+vm.filename+" was successfully uploaded. " +
								"The file can now be processed for loading.");
						vm.clearUploadedFile();
					}, function(errorResponse){
						console.log(errorResponse);
						alertify.alert(errorResponse.data['ERROR_MESSAGE']);
					});	
				}
			});
		}
		
		vm.clearUploadedFile = function(){
			vm.filename = "";
			vm.file = "";
		}
		
		/**
		 * 
		 */
		vm.open = function(columnName, $event){
			$event.preventDefault();
			$event.stopPropagation();
			
			if (vm.datePicker[columnName]) {
				if (vm.datePicker[columnName].opened) {
					vm.datePicker[columnName].opened = false;
				}
			} else {
				vm.datePicker = {};
				vm.datePicker[columnName] = {};
				vm.datePicker[columnName].opened = true;
			}
		}
		
		/**
		 * Init
		 */
		vm.init();
	}]);
});