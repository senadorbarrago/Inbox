'use strict';

define(function(){
	
	console.log('logoutController.js loaded');
	var core = angular.module('core');
	
	core.registerController('logoutController', ['$location', '$rootScope', '$cookies', 'DataAccessService',
		function($location, $rootScope, $cookies, dataAccessService){
		
		// Logout
		$rootScope.logout = function(){
			dataAccessService.doPostData("logout", null, function(response){
				$rootScope.session['AUTHENTICATED'] = false;
				$rootScope.session['AUTHENTICATED_USER'] = null;
				$rootScope.session['CURRENT_PAGE'] = "";
				$rootScope.dataSetID = null;
				$rootScope.costCenterID = null;
				$cookies.remove("AUTHENTICATED");
				$cookies.remove("CURRENT_PAGE");
				$location.path('/');
			},function(errorResponse){
				console.log(errorResponse);
			});
		}
	}]);
});