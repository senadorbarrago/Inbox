'use strict';

define(function(){
	var core = angular.module('core');
	
	core.registerController('transactionPoolController',['$rootScope','$scope', '$uibModal', 'ngTableParams', 'DataAccessService', 
	    function($rootScope, $scope, $uibModal, ngTableParams, dataAccessService){

		// Title and Module Description
		var vm = this;
		$rootScope.screenName = 'Transaction Pool';
		
		// Initialize Data
		vm.init = function(){
			$scope.data = {};
			$scope.data.dataSetCode = $rootScope.dataSetCode;
			vm.searchCriteria = {};
			
			vm.references = {};
			vm.getBookReference();
			vm.getCurrencyReference();
			vm.getBranchReference();
			vm.getSourceSystemReference();
			vm.getStatusReference();
			
			vm.doGetTransactions();
			vm.initDatePicker();
		};
		
		// UI Validations
		vm.checkIfHasSelection = function(list){
			for(var index = 0; index < list.length; index++){
				if(list[index]["Selected"]){
					return true;
				}
			}
			return false;
		}
		
		// DatePicker SetUp
		vm.initDatePicker = function(){
			vm.datePicker = {};
			vm.dateOptions = {
					startingDay : 0,
					showWeeks : false,	
					format : "yyyy-MM-dd",
					timezone: 'UTC'
				};
			vm.dateFormat = "yyyy-MM-dd";
		}
		
		/**
		 * 
		 */
		vm.getBookReference = function(){
			console.log("vm.getBookReference()");
			var data = {
						"pageIndex" : 1,
						"pageSize" : 10000
				};
			
			dataAccessService.doQuery('bookListQueryModel', data, function(response){
				if(response.data.resultSet){ 
					vm.references.bookCdList = response.data.resultSet;
					console.log(vm.references.bookCdList);
				}
			},function(errorResponse){
				console.log(errorResponse);
			});
		};
		
		/**
		 * 
		 */
		vm.getCurrencyReference = function(){
			console.log("vm.getCurrencyReference()");
			var data = {
						"pageIndex" : 1,
						"pageSize" : 10000
				};
			
			dataAccessService.doQuery('currencyListQueryModel', data, function(response){
				if(response.data.resultSet){ 
					vm.references.curCde1List = response.data.resultSet;
					console.log(vm.references.curCde1List);
				}
			},function(errorResponse){
				console.log(errorResponse);
			});
		};
		
		/**
		 * 
		 */
		vm.getSourceSystemReference = function(){
			console.log("vm.getSourceSystemReference()");
			var data = {
						"pageIndex" : 1,
						"pageSize" : 10000
				};
			
			dataAccessService.doQuery('sourceSystemListQueryModel', data, function(response){
				if(response.data.resultSet){ 
					vm.references.ssCodeList = response.data.resultSet;
					console.log(vm.references.ssCodeList);
				}
			},function(errorResponse){
				console.log(errorResponse);
			});
		};
		
		/**
		 * 
		 */
		vm.getBranchReference = function(){
			console.log("vm.getBranchReference()");
			var data = {
						"pageIndex" : 1,
						"pageSize" : 10000
				};
			
			dataAccessService.doQuery('branchListQueryModel', data, function(response){
				if(response.data.resultSet){ 
					vm.references.brCodeList = response.data.resultSet;
					console.log(vm.references.brCodeList);
				}
			},function(errorResponse){
				console.log(errorResponse);
			});
		};		
		
		/**
		 * 
		 */
		vm.getStatusReference = function(){
			console.log("vm.getStatusReference()");
			var data = {
						"pageIndex" : 1,
						"pageSize" : 10000
				};
			
			dataAccessService.doQuery('statusListQueryModel', data, function(response){
				console.log("vm.getStatusReference()");
				console.log(response);
				if(response.data.resultSet){ 
					vm.references.statusList = response.data.resultSet;
					console.log(vm.references.statusList);
				}
			},function(errorResponse){
				console.log(errorResponse);
			});
		};	
		
		/**
		 * 
		 */
		vm.doGetTransactions = function(){
			console.log("vm.doGetTransactions()");
			vm.transactionPoolTable = new ngTableParams({
                page: 1,
                count: 25
            }, {
                getData: function ($defer, params) {
                	console.log("getData()");
                	var queryCode = "transactionPoolQueryModel";
                	var url = "query/"+queryCode;
                	
                	var data = {
            				'searchCriteria' : vm.searchCriteria,
            				'pageIndex' : params.page(),
        					'pageSize': params.count()
        		   	   	   };
                	
                	console.log(data);

                	return dataAccessService.doQuery(queryCode, data, function(response){
			        			console.log('doQuery()');
			        			console.log(response);
			        			vm.transactionPoolData = {};
			        			vm.transactionPoolData.resultSet = response.data.resultSet;
			        			vm.transactionPoolData.columns = response.data.columns;
			        			
			        			params.total(response.data.resultOverAllCount);
			        			$defer.resolve(vm.transactionPoolData.resultSet);
			        		}, function(errorResponse){
			    				console.log(errorResponse);
			    			});
                	
                }
            
            });
		};
		
		/**
		 * search
		 * 
		 */
		vm.doSearch = function(){
			console.log("vm.doSearch()");
			console.log(vm.searchCriteria);
			vm.transactionPoolTable.reload();
		}
		
		/**
		 * showAll
		 * 
		 */
		vm.doShowAll = function(){
			console.log("vm.doShowAll()");
			vm.searchCriteria = {};
			vm.transactionPoolTable.reload();
		}
		
		/**
		 * 
		 */
		vm.doShowScheduleForm = function(id, transactionID, schedule){
			console.log('doShowScheduleForm()');
			var modalInstance = $uibModal.open({
				animation: true,
				backdrop: 'static',
				templateUrl: 'app/components/transactions/forms/scheduleForm.html',
				controller: 'scheduleFormController',
				controllerAs: 'ctrl',
				size: 'md',
				resolve:{
					data:function(){
						var data = {};
						data.id = id;
						data.transactionID = transactionID;
						data.scheduleCode = schedule;
						console.log("data1");
						console.log(data);
						return data;
					},
					load: ['$q', function($q){
						var defered = $q.defer();
						require(['app/components/transactions/forms/scheduleFormController'], function(){
							defered.resolve();
						});
						return defered.promise;
					}]
				}
			});
			
			modalInstance.result.then(
				function(message) {
					//Reload Paginated Request
					vm.transactionPoolTable.reload();
				}, 
				function() {				
					// dismissed
					console.log("dismissed");
				}
			);
			
			return modalInstance.result;
		};
		
		/**
		 * 
		 */
		vm.doCreateNewScheduleData = function(){
			console.log('doCreateNewScheduleData()');
			var modalInstance = $uibModal.open({
				animation: true,
				backdrop: 'static',
				templateUrl: 'app/components/transactions/forms/scheduleForm.html',
				controller: 'scheduleFormController',
				controllerAs: 'ctrl',
				size: 'md',
				resolve:{
					data:function(){
						var data = {};
						return data;
					},
					load: ['$q', function($q){
						var defered = $q.defer();
						require(['app/components/transactions/forms/scheduleFormController'], function(){
							defered.resolve();
						});
						return defered.promise;
					}]
				}
			});
			
			modalInstance.result.then(
				function(message) {
					//Reload Paginated Request
					vm.transactionPoolTable.reload();
				}, 
				function() {				
					// dismissed
					console.log("dismissed");
				}
			);
			
			return modalInstance.result;
		};
		
		/**
		 * Init
		 */
		vm.init();
	}]);
});