'use strict';

define(function(){
	console.log('tabularMessageController.js loaded');
	var core = angular.module('core');
	
	core.registerController('tabularMessageController', [
		'$rootScope', 
		'$scope', 
		'$uibModalInstance',
		'data',
		function($rootScope, $scope, $uibModalInstance, data){
			$scope.title = 'Message';
			var vm = this;
		
			vm.init = function(){
				$scope.form = {};
				$scope.form.messageList = data.messageList; 
				console.log('$scope.form.messageList');
				console.log($scope.form.messageList);
			}
			
			// Close Tag for Referral Form
			$scope.close = function() {
				$uibModalInstance.dismiss();
			};
			
			vm.init();
	}]);
});