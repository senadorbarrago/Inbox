'use strict'

define(function(){
	console.log('numberOnlyDirective.js loaded');
	
	var core = angular.module('core');
	
	core.directive('numberOnly', function(){
		return function(scope, element, attrs) {
	        $(element[0]).numericInput({ allowFloat: false, min: 0 });
	    };
	});
	
	return core;
});