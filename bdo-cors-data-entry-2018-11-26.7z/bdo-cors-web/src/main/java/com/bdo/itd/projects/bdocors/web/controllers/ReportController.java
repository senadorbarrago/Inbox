package com.bdo.itd.projects.bdocors.web.controllers;

import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.projects.bdocors.report.application.command.IDownloadReportCommandHandler;
import com.bdo.itd.projects.bdocors.usermanagement.application.UserSession;
import com.bdo.itd.util.cqrs.command.CommandFactory;
import com.bdo.itd.util.cqrs.command.ICommand;

/**
 * @author senadorbarrago
 *
 */
@RestController
@RequestMapping(value = "/report")
public class ReportController extends AbstractController{
	
	/**
	 * 
	 */
	private static final Logger logger = LoggerFactory.getLogger(ReportController.class);
	
	/**
	 * 
	 */
	private final IDownloadReportCommandHandler downloadReportCommandHandler;
	
	/**
	 * @param downloadReportCommandHandler
	 */
	@Inject
	public ReportController(IDownloadReportCommandHandler downloadReportCommandHandler) {
		super();
		this.downloadReportCommandHandler = downloadReportCommandHandler;
	}

	/**
	 * @param commandCode
	 * @param data
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/{commandCode}", method = RequestMethod.GET)
	public Object doCommand(@PathVariable(name = "commandCode") String commandCode,
			@RequestParam String id, @RequestParam String targetFile, @RequestParam String reportCode, 
				HttpServletRequest request,	HttpServletResponse response){
		logger.info("doCommand()");
		
		Map<String, Object> data = new HashMap<>();
		
		if(SecurityContextHolder.getContext().getAuthentication() != null &&
				 SecurityContextHolder.getContext().getAuthentication().isAuthenticated() && 
				 //when Anonymous Authentication is enabled
				 !(SecurityContextHolder.getContext().getAuthentication() 
				          instanceof AnonymousAuthenticationToken) ){
			HttpSession session = request.getSession();
			
			data.put("institution", session.getAttribute("institution"));
			data.put("context", session.getAttribute("context"));
			data.put("datasetcode", "ITRS");
			data.put("authenticatedUser", UserSession.getUsername());
			data.put("membershipCode", UserSession.getActiveMembership().getCode());
			
			data.put("id", id);
			data.put("reportCode", reportCode);
			data.put("targetFile", targetFile);
		}
		
		logger.info("commandCode: "+commandCode);
		logger.info(data.toString());
		
		
		ICommand command = CommandFactory.create(commandCode, data);
		Map<String, Object> resultMap = downloadReportCommandHandler.doHandle(command);
		
		FileSystemResource fileSystemResource = (FileSystemResource) resultMap.get("fileSystemResource");
		response.setHeader("Content-Disposition", "attachment; filename=" + resultMap.get("filename"));
		response.setHeader("Content-Type", "application/octet-stream");
		response.setStatus(HttpStatus.OK.value());
		
		return fileSystemResource;
	}
	
}
