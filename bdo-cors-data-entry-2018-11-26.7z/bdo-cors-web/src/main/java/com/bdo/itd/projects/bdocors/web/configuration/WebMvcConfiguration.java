package com.bdo.itd.projects.bdocors.web.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.bdo.itd.projects.bdocors.auditmanagement.domain.ApplicationConfigFactory;
import com.bdo.itd.projects.bdocors.auditmanagement.infrastructure.interceptor.DefaultAuditInterceptor;
import com.bdo.itd.projects.bdocors.auditmanagement.infrastructure.interceptor.LocalAuditInterceptor;
import com.bdo.itd.projects.bdocors.web.controllers.CorsInterceptor;
import com.bdo.itd.util.cqrs.command.ICommandBus;

/**
 * 
 * @author a014000098
 *
 */
@Configuration
public class WebMvcConfiguration implements WebMvcConfigurer {
	
	/**
	 * 
	 */
	@Value("${audit.file.config}")
	private Resource auditConfigFile;
	
	/**
	 * 
	 */
	@Autowired
	private ICommandBus commandBus;
	
	/**
	 * @return
	 */
	private HandlerInterceptor auditInterceptor(){
		DefaultAuditInterceptor interceptor = new LocalAuditInterceptor();	
		interceptor.setCommandBus(commandBus);
		
		try {
			interceptor.setApplicationConfig(auditConfig());
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return interceptor;
	}
	
	/**
	 * @return
	 */
	private HandlerInterceptor corsInterceptor(){
		HandlerInterceptor interceptor = new CorsInterceptor("*");	
		
		return interceptor;
	}
	
	/**
	 * 
	 */
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(auditInterceptor());
		registry.addInterceptor(corsInterceptor()).addPathPatterns("/rmf/authenticate");
	}
	
	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	@Bean
	@Qualifier("auditConfig")
	public com.bdo.itd.projects.bdocors.auditmanagement.domain.ApplicationConfig auditConfig() throws Exception {
		return ApplicationConfigFactory.createInstance(auditConfigFile.getFile());		
	}
}

