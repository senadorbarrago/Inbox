package com.bdo.itd.projects.bdocors.web.security.filters;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

/**
 * @author c140618008
 *
 */
public class AdditionalAuthenticationDetailsFilter extends UsernamePasswordAuthenticationFilter {
	
	/**
	 * 
	 */
	private final static Logger logger = LoggerFactory.getLogger(AdditionalAuthenticationDetailsFilter.class);
	
	@Override
	public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response)
			throws AuthenticationException {
		final String context = request.getParameter("context");
        request.getSession().setAttribute("context", context);
        
        
        logger.info("context: "+context);
		return super.attemptAuthentication(request, response);
	}

	
	
}
