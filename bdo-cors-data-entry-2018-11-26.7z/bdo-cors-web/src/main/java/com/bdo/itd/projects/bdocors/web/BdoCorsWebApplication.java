package com.bdo.itd.projects.bdocors.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.PropertySource;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * @author c140618008
 *
 */
@SpringBootApplication
@EnableTransactionManagement
@PropertySource({"classpath:database.properties", "classpath:eua.properties"})
public class BdoCorsWebApplication {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SpringApplication.run(BdoCorsWebApplication.class, args);
	}
}
