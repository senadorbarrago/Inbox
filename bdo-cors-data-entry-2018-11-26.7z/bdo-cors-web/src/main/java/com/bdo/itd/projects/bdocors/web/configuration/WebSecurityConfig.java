package com.bdo.itd.projects.bdocors.web.configuration;

import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.security.core.session.SessionRegistryImpl;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.Http403ForbiddenEntryPoint;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.csrf.CsrfFilter;
import org.springframework.security.web.csrf.CsrfTokenRepository;
import org.springframework.security.web.csrf.HttpSessionCsrfTokenRepository;
import org.springframework.security.web.session.HttpSessionEventPublisher;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.interceptor.TransactionProxyFactoryBean;

import com.bdo.itd.projects.bdocors.usermanagement.application.SpringSecurityAuthenticationProvider;
import com.bdo.itd.projects.bdocors.usermanagement.domain.services.IAuthenticationService;
import com.bdo.itd.projects.bdocors.usermanagement.infrastructure.repository.IGroupEntityRepository;
import com.bdo.itd.projects.bdocors.usermanagement.infrastructure.repository.IMembershipEntityRepository;
import com.bdo.itd.projects.bdocors.usermanagement.infrastructure.repository.IResourceEntityRepository;
import com.bdo.itd.projects.bdocors.usermanagement.infrastructure.repository.IUserProfileEntityRepository;
import com.bdo.itd.projects.bdocors.usermanagement.infrastructure.services.authentication.EUAAuthenticationService;
import com.bdo.itd.projects.bdocors.web.security.filters.AdditionalAuthenticationDetailsFilter;
import com.bdo.itd.projects.bdocors.web.security.filters.CsrfHeaderFilter;
import com.bdo.itd.util.eua.authentication.EuaAuthenticationClient;
import com.bdo.itd.util.eua.authentication.EuaAuthenticationClientImpl;
import com.bdo.itd.util.eua.authentication.EuaAuthenticationConfig;
import com.bdo.itd.util.eua.inquiry.EuaInquiryClient;
import com.bdo.itd.util.eua.inquiry.EuaInquiryClientConfig;
import com.bdo.itd.util.eua.inquiry.EuaInquiryClientImpl;
import com.bdo.util.rest.http.client.RestClientFactory;

/**
 * @author c140618008
 *
 */
@EnableWebSecurity
@Configuration
public class WebSecurityConfig extends WebSecurityConfigurerAdapter{
	
	/**
	 * 
	 */
	private static final Logger logger = LoggerFactory.getLogger(WebSecurityConfig.class);
	
	/**
	 * 
	 */
	@Autowired
	private PlatformTransactionManager transactionManager;
	
	/**
	 * 
	 */
	@Autowired
	private IUserProfileEntityRepository userProfileEntityRepository;
	
	/**
	 * 
	 */
	@Autowired
	private IGroupEntityRepository groupRepository;
	
	/**
	 * 
	 */
	@Autowired
	private IMembershipEntityRepository membershipRepository;
	
	/**
	 * 
	 */
	@Autowired
	private IResourceEntityRepository resourceRepository;
	
	/**
	 * 
	 */
	@Autowired
	private AuthenticationSuccessHandler customAuthenticationSuccessHandler;
	
	/**
	 * 
	 */
	@Autowired
	private AuthenticationFailureHandler customAuthenticationFailureHandler;
	
	/**
	 * 
	 */
	@Value("${eua.enabled}")
	private Boolean euaEnabled;
	
	/**
	 * 
	 */
	@Value("${eua.authentication-url}")
	private String authenticationUrl;
	
	/**
	 * 
	 */
	@Value("${eua.inquiry-url}")
	private String inquiryUrl;
	
	/**
	 * 
	 */
	@Value("${eua.environment}")
	private String environment;
	
	/**
	 * 
	 */
	@Value("${eua.institution}")
	private String institution;
	
	/**
	 * 
	 */
	@Value("${eua.domain}")
	private String domain;
	
	/**
	 * 
	 */
	@Value("${eua.application-code}")
	private String applicationCode;
	
	/**
	 * 
	 */
	@Value("${eua.hostname}")
	private String hostname;
	
	/**
	 * 
	 */
	@Value("${eua.userid}")
	private String userid;
	
	/**
	 * 
	 */
	@Value("${eua.credentials}")
	private String credentials;
	
	/**
	 * 
	 */
	@Value("${eua.key}")
	private String key;
	
	/**
	 * 
	 */
	@Value("${eua.keyspecs}")
	private String keyspecs;
	
	/**
	 * 
	 */
	@Value("${eua.algorithm}")
	private String algorithm;
	
	/**
	 * 
	 */
	@Value("${eua.result-type}")
	private String resultType;
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http
			.authorizeRequests()
				.antMatchers("/webjars/**", "/app/**", "/assets/**", "/login", "/", "/#/**", "/rmf/**", "bdo-cors/").permitAll()
				.anyRequest().authenticated()
				.and()
			.csrf().csrfTokenRepository(this.csrfTokenRepository())
				.and()
			.addFilterAfter(new CsrfHeaderFilter(), CsrfFilter.class)
			.addFilterAfter(additionalAuthenticationDetailsFilter(), UsernamePasswordAuthenticationFilter.class)
			.sessionManagement()
				.maximumSessions(1)
				.maxSessionsPreventsLogin(true)
				.and()
				.enableSessionUrlRewriting(false)
				.sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED)
				.sessionFixation().migrateSession()
				.invalidSessionUrl("/")
				.sessionAuthenticationErrorUrl("/sessionTimeOut")
				.and()
			.formLogin()
				.loginPage("/")
				.loginProcessingUrl("/login")
				.usernameParameter("username")
				.passwordParameter("password")
				.successHandler(customAuthenticationSuccessHandler)
				.failureHandler(customAuthenticationFailureHandler)
				.and()
			.logout();
		
		http.exceptionHandling().authenticationEntryPoint(new Http403ForbiddenEntryPoint());
	}

	@Override
	@Autowired
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		AuthenticationProvider authenticationProvider = 
				new SpringSecurityAuthenticationProvider(this.euaAuthenticationService());
		
		TransactionProxyFactoryBean proxy = new TransactionProxyFactoryBean();

        // Inject transaction manager here
        proxy.setTransactionManager(transactionManager);

        // Define which object instance is to be proxied (your bean)
        proxy.setTarget(authenticationProvider);

        // Programmatically setup transaction attributes
        Properties transactionAttributes = new Properties();
        transactionAttributes.put("*", "PROPAGATION_REQUIRED");
        proxy.setTransactionAttributes(transactionAttributes);

        // Finish FactoryBean setup
        proxy.afterPropertiesSet();
		
        logger.info(proxy.getObjectType().getName());
        
		auth.authenticationProvider((AuthenticationProvider)proxy.getObject());
		logger.info(authenticationProvider.getClass().toString());
	}	
	
	/**
	 * @return
	 */
	private CsrfTokenRepository csrfTokenRepository(){
		HttpSessionCsrfTokenRepository repository = new HttpSessionCsrfTokenRepository();
		repository.setHeaderName("X-XSRF-TOKEN");
		
		return repository;
	}
	
	/**
	 * @return
	 */
	@Bean
	public HttpSessionEventPublisher httpSessionEventPublisher(){
		return new HttpSessionEventPublisher();
	}
	
	/**
	 * @return
	 */
	@Bean
	public SessionRegistry sessionRegistry(){
		return new SessionRegistryImpl();
	}
	
	/**
	 * @return
	 */
	@Bean
	public UsernamePasswordAuthenticationFilter additionalAuthenticationDetailsFilter(){
		UsernamePasswordAuthenticationFilter additionalAuthenticationFilter = new AdditionalAuthenticationDetailsFilter();
		
		try {
			additionalAuthenticationFilter.setAuthenticationManager(authenticationManager());
			additionalAuthenticationFilter.setAuthenticationSuccessHandler(customAuthenticationSuccessHandler);
			additionalAuthenticationFilter.setAuthenticationFailureHandler(customAuthenticationFailureHandler);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return additionalAuthenticationFilter;
	}
	
	/**
	 * @return
	 */
	private IAuthenticationService euaAuthenticationService() {
		return new EUAAuthenticationService(this.euaAuthenticationClient(), 
				userProfileEntityRepository, groupRepository, membershipRepository, resourceRepository, euaEnabled);
	}	
	
	/**
	 * @return
	 */
	private EuaAuthenticationClient euaAuthenticationClient() {
		EuaAuthenticationConfig euaAuthenticationConfig = new EuaAuthenticationConfig();
		euaAuthenticationConfig.setDomain(domain);
		euaAuthenticationConfig.setApplicationCode(applicationCode);
		euaAuthenticationConfig.setHostname(hostname);
		euaAuthenticationConfig.setUserid(userid);
		euaAuthenticationConfig.setCredentials(credentials);
		euaAuthenticationConfig.setKey(key);
		euaAuthenticationConfig.setKeyspecs(keyspecs);
		euaAuthenticationConfig.setAlgorithm(algorithm);
		
		logger.info("authenticationUrl: "+authenticationUrl);
		logger.info("domain: "+domain);
		logger.info("applicationCode: "+ applicationCode);
		logger.info("hostname: "+ hostname);
		logger.info("userid: "+ userid);
		logger.info("credentials: "+ credentials);
		logger.info("key: "+ key);
		logger.info("keyspecs: "+ keyspecs);
		logger.info("resultType: "+ resultType);
		logger.info("algorithm: "+ algorithm);
		
		EuaAuthenticationClient euaAuthenticationClient = new EuaAuthenticationClientImpl(authenticationUrl,
				euaAuthenticationConfig, RestClientFactory.createClient(), Enum.valueOf(
						com.bdo.itd.util.eua.authentication.enumerations.ResultType.class, resultType));
		
		return euaAuthenticationClient;
	}
	
	/**
	 * @return
	 */
	@SuppressWarnings("unused")
	private EuaInquiryClient euaInquiryClient() {
		EuaInquiryClientConfig euaInquiryClientConfig = new EuaInquiryClientConfig();
		euaInquiryClientConfig.setEnvironment(environment);
		euaInquiryClientConfig.setInstitution(institution);
		euaInquiryClientConfig.setDomain(domain);
		euaInquiryClientConfig.setApplicationCode(applicationCode);
		euaInquiryClientConfig.setHostname(hostname);
		euaInquiryClientConfig.setUserid(userid);
		euaInquiryClientConfig.setCredentials(credentials);
		euaInquiryClientConfig.setKey(key);
		euaInquiryClientConfig.setKeyspecs(keyspecs);
		euaInquiryClientConfig.setAlgorithm(algorithm);
		
		EuaInquiryClient euaInquiryClient = new EuaInquiryClientImpl(inquiryUrl,
				euaInquiryClientConfig, RestClientFactory.createClient(), Enum.valueOf(
						com.bdo.itd.util.eua.inquiry.enumerations.ResultType.class, resultType));
		
		return euaInquiryClient;
	}
	
	public static void main(String[] args) {
		System.out.println(Enum.valueOf(
						com.bdo.itd.util.eua.authentication.enumerations.ResultType.class, "XML"));
	}
}
