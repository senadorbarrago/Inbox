package com.bdo.itd.projects.bdocors.web.configuration;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.io.Resource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.bdo.itd.projects.bdocors.filetransfer.infrastructure.services.ITDFileTransferServiceCommunicator;
import com.bdo.itd.projects.bdocors.inboundinterface.infrastructure.services.IServiceCommunicator;
import com.bdo.itd.projects.bdocors.inboundinterface.infrastructure.services.ITDServiceCommunicator;
import com.bdo.itd.projects.bdocors.report.infrastructure.services.ITDReportServiceCommunicator;
import com.bdo.itd.projects.bdocors.rmf.infrastructure.services.ITDReferenceServiceCommunicator;
import com.bdo.itd.service.client.ServiceClient;
import com.bdo.itd.service.client.ServiceClientImpl;
import com.bdo.itd.service.client.model.ServiceDefinition;
import com.bdo.itd.service.client.model.ServiceDefinitionFactory;
import com.bdo.itd.util.crypt.Hmac;
import com.bdo.itd.util.crypt.HmacType;
import com.bdo.util.rest.http.client.ProtocolType;
import com.bdo.util.rest.http.client.RestClient;
import com.bdo.util.rest.http.client.RestClientFactory;

@Configuration
@ComponentScan({"com.bdo.itd.projects.bdocors"})
@EntityScan({"com.bdo.itd.projects.bdocors.inboundinterface.domain", 
			 "com.bdo.itd.projects.bdocors.report.infrastructure.persistence",
			 "com.bdo.itd.projects.bdocors.usermanagement.infrastructure.persistence",
			 "com.bdo.itd.projects.bdocors.auditmanagement.infrastructure.persistence",
			 "com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence"})
@EnableJpaRepositories({"com.bdo.itd.projects.bdocors.inboundinterface.infrastructure.repository",
						"com.bdo.itd.projects.bdocors.report.infrastructure.repository",
						"com.bdo.itd.projects.bdocors.usermanagement.infrastructure.repository",
						"com.bdo.itd.projects.bdocors.auditmanagement.infrastructure.repository",
						"com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence"
})
public class ApplicationConfig {
	
	/**
	 * 
	 */
	@Value("${itdservices.rest-client.protocol-type}")
	private ProtocolType protocolType;
	
	/**
	 * 
	 */
	@Value("${itdservices.hmac.type}")
	private HmacType hmacType;
	
	/**
	 * 
	 */
	@Value("${itdservices.load-service.secret-key}")
	private String loadServiceSecretKey;
	
	/**
	 * 
	 */
	@Value("${itdservices.load-service.service-definition}")
	private Resource loadServiceDefinition;
	
	/**
	 * 
	 */
	@Value("${itdservices.load-service.service-definition-property}")
	private Resource loadServiceDefinitionProperty;
	
	/**
	 * 
	 */
	@Value("${itdservices.report-service.secret-key}")
	private String reportServiceSecretKey;
	
	/**
	 * 
	 */
	@Value("${itdservices.report-service.service-definition}")
	private Resource reportServiceDefinition;
	
	/**
	 * 
	 */
	@Value("${itdservices.report-service.service-definition-property}")
	private Resource reportServiceDefinitionProperty;
	
	/**
	 * 
	 */
	@Value("${itdservices.file-transfer-service.secret-key}")
	private String fileTransferServiceSecretKey;
	
	/**
	 * 
	 */
	@Value("${itdservices.file-transfer-service.service-definition}")
	private Resource fileTransferServiceDefinition;
	
	/**
	 * 
	 */
	@Value("${itdservices.file-transfer-service.service-definition-property}")
	private Resource fileTransferServiceDefinitionProperty;
	
	/**
	 * 
	 */
	@Value("${itdservices.reference-maintenance-service.secret-key}")
	private String referenceMaintenanceServiceSecretKey;
	
	/**
	 * 
	 */
	@Value("${itdservices.reference-maintenance-service.service-definition}")
	private Resource referenceMaintenanceServiceDefinition;
	
	/**
	 * 
	 */
	@Value("${itdservices.reference-maintenance-service.service-definition-property}")
	private Resource referenceMaintenanceServiceDefinitionProperty;
	
	/**
	 * @return
	 */
	@Bean
	public IServiceCommunicator loadServiceCommunicator() throws IOException {
		RestClient restClient = RestClientFactory.createClient(protocolType);
		Hmac serviceHmac = Hmac.createInstance(hmacType, loadServiceSecretKey);
		ServiceDefinition serviceDefinition = ServiceDefinitionFactory.createInstance(loadServiceDefinition.getFile(), 
				loadServiceDefinitionProperty.getFile());
		
		ServiceClient serviceClient = new ServiceClientImpl(restClient, serviceHmac, serviceDefinition);
		
		return new ITDServiceCommunicator(serviceClient);
	}
	
	/**
	 * @return
	 */
	@Bean
	public com.bdo.itd.projects.bdocors.report.infrastructure.services.IServiceCommunicator 
		reportServiceCommunicator() throws IOException {
		RestClient restClient = RestClientFactory.createClient(protocolType);
		Hmac serviceHmac = Hmac.createInstance(hmacType, reportServiceSecretKey);
		ServiceDefinition serviceDefinition = ServiceDefinitionFactory.createInstance(reportServiceDefinition.getFile(), 
				reportServiceDefinitionProperty.getFile());
		
		ServiceClient serviceClient = new ServiceClientImpl(restClient, serviceHmac, serviceDefinition);
		
		return new ITDReportServiceCommunicator(serviceClient);
	}
	
	
	/**
	 * @return
	 */
	@Bean
	public com.bdo.itd.projects.bdocors.filetransfer.infrastructure.services.IServiceCommunicator 
		fileTransferServiceCommunicator() throws IOException {
		RestClient restClient = RestClientFactory.createClient(protocolType);
		Hmac serviceHmac = Hmac.createInstance(hmacType, fileTransferServiceSecretKey);
		ServiceDefinition serviceDefinition = ServiceDefinitionFactory.createInstance(fileTransferServiceDefinition.getFile(), 
				fileTransferServiceDefinitionProperty.getFile());
		
		ServiceClient serviceClient = new ServiceClientImpl(restClient, serviceHmac, serviceDefinition);
		
		return new ITDFileTransferServiceCommunicator(serviceClient);
	}
	
	/**
	 * 
	 * @return
	 * @throws IOException
	 */
	@Bean
	public com.bdo.itd.projects.bdocors.rmf.infrastructure.services.IServiceCommunicator
		referenceMaintenanceServiceCommunicator() throws IOException {
		
		RestClient restClient = RestClientFactory.createClient(protocolType);
		Hmac serviceHmac = Hmac.createInstance(hmacType, referenceMaintenanceServiceSecretKey);
		ServiceDefinition serviceDefinition = ServiceDefinitionFactory.createInstance(referenceMaintenanceServiceDefinition.getFile(), 
				referenceMaintenanceServiceDefinitionProperty.getFile());
		
		ServiceClient serviceClient = new ServiceClientImpl(restClient, serviceHmac, serviceDefinition);
		
		return new ITDReferenceServiceCommunicator(serviceClient);
	}
	
	/**
	 * 
	 * @return
	 */
	@Bean
	public Hmac referenceHmac() {
		 return Hmac.createInstance(hmacType, referenceMaintenanceServiceSecretKey);
	}
	
}
