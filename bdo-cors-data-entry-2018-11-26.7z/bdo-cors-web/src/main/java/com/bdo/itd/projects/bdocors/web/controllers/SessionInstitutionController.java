package com.bdo.itd.projects.bdocors.web.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


/**
 * @author c140618008
 *
 */
@RestController
public class SessionInstitutionController {		

	/**
	 * 
	 */
	private static final Logger logger = LoggerFactory.getLogger(SessionInstitutionController.class);
	
	/**
	 * @param request
	 * @return
	 */
	@RequestMapping(value="/sessioninstitution", method=RequestMethod.GET)
	public Object getSessionContext(HttpServletRequest request){
		HttpSession session = request.getSession();
		String sessionInstitution = String.valueOf(session.getAttribute("institution"));
		logger.info("SessionInstitution: "+sessionInstitution);
		
		return "{\"sessionInstitution\": \""+sessionInstitution+"\" }";
	}
	
}
