package com.bdo.itd.projects.bdocors.web.controllers;

import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.bdo.itd.projects.bdocors.usermanagement.application.UserSession;
import com.bdo.itd.util.cqrs.command.CommandFactory;
import com.bdo.itd.util.cqrs.command.CommandMessage;
import com.bdo.itd.util.cqrs.command.ICommand;
import com.bdo.itd.util.cqrs.command.ICommandBus;

/**
 * @author senadorbarrago
 *
 */
@RestController
@RequestMapping(value = "/command")
public class FileUploadCommandController extends AbstractController{
	
	/**
	 * 
	 */
	private static final Logger logger = LoggerFactory.getLogger(FileUploadCommandController.class);
	
	/**
	 * 
	 */
	private final ICommandBus commandBus;
	
	/**
	 * @param commandBus
	 */
	@Inject
	public FileUploadCommandController(ICommandBus commandBus) {
		super();
		this.commandBus = commandBus;
	}

	/**
	 * @param commandCode
	 * @param data
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/uploadFileCommandHandler", method = RequestMethod.POST)
	public Object doCommand(@RequestParam(name = "file") MultipartFile file, 
			HttpServletRequest request){
		logger.info("doCommand()");
		
		Map<String, Object> data = new HashMap<>();
		
		if(SecurityContextHolder.getContext().getAuthentication() != null &&
				 SecurityContextHolder.getContext().getAuthentication().isAuthenticated() && 
				 //when Anonymous Authentication is enabled
				 !(SecurityContextHolder.getContext().getAuthentication() 
				          instanceof AnonymousAuthenticationToken) ){
			HttpSession session = request.getSession();
			
			data.put("institution", session.getAttribute("institution"));
			data.put("context", session.getAttribute("context"));
			data.put("datasetcode", "ITRS");
			data.put("authenticatedUser", UserSession.getUsername());
			data.put("membershipCode", UserSession.getActiveMembership().getCode());
		}
		
		logger.info(data.toString());
		
		data.put("file", file);
		ICommand command = CommandFactory.create("uploadFileCommandHandler", data);
		CommandMessage message = commandBus.doPublish(command);
		
		return message;
	}
	
}
