package com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
@RequiredArgsConstructor
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Entity
@Table(name = "txn_data_missing")
public class TransactionMissingDataEntity extends BaseEntity {
	
	/**
	 * 
	 */
	@Column(name = "transactionid")
	@NonNull 
	private Long transactionid;
	
	/**
	 * 
	 */
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "fk_data_field")
	@NonNull
	private DataFieldEntity dataField;
	
}
