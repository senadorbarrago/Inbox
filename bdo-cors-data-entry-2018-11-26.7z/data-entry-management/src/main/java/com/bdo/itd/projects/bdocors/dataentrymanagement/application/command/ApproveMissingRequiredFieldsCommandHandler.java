package com.bdo.itd.projects.bdocors.dataentrymanagement.application.command;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ReflectionUtils;

import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models.TransactionDataEntity;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models.TransactionDataHistoryEntity;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.repository.ITransactionDataEntityRepository;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.repository.ITransactionDataHistoryEntityRepository;
import com.bdo.itd.util.cqrs.command.ACommandHandler;
import com.bdo.itd.util.cqrs.command.BasicCommand;
import com.bdo.itd.util.cqrs.command.CommandMessage;
import com.bdo.itd.util.cqrs.command.ICommand;
import com.bdo.itd.util.cqrs.command.UnableToProcessCommandException;
import com.bdo.itd.util.cqrs.query.QueryException;

/**
 * @author c140618008
 *
 */
@Service
public class ApproveMissingRequiredFieldsCommandHandler extends ACommandHandler {
	
	/**
	 * 
	 */
	private static final Logger logger = LoggerFactory.getLogger(ApproveMissingRequiredFieldsCommandHandler.class);
	
	/**
	 * 
	 */
	private final String FOR_APPROVAL_MISSING_REQUIRED_FIELDS_STATUS = "FOR APPROVAL-Missing Required Fields";
	
	/**
	 * 
	 */
	private final String VALID_STATUS = "VALID";
	
	/**
	 * 
	 */
	private final ITransactionDataEntityRepository transactionDataEntityRepository; 
	
	/**
	 * 
	 */
	private final ITransactionDataHistoryEntityRepository transactionDataHistoryEntityRepository;
	
	/**
	 *  
	 * @param transactionDataEntityRepository
	 */
	@Autowired
	public ApproveMissingRequiredFieldsCommandHandler(ITransactionDataEntityRepository transactionDataEntityRepository,
			ITransactionDataHistoryEntityRepository transactionDataHistoryEntityRepository) {
		super();
		this.transactionDataEntityRepository = transactionDataEntityRepository;
		this.transactionDataHistoryEntityRepository = transactionDataHistoryEntityRepository;
	}
	
	@Override
	public CommandMessage doHandle(ICommand command) throws UnableToProcessCommandException {
		// Extract command data
		BasicCommand basicCommand = (BasicCommand)command;
		logger.info(basicCommand.map().toString());

		TransactionDataEntity transactionDataEntity = this.getTransactionDataEntity(basicCommand);
		
		// Validate status
		this.validateStatus(transactionDataEntity.getStatus());
		
		// authenticatedUser
		String username = basicCommand.getStringValue("authenticatedUser");
				
		// Approve transaction data
		this.approve(transactionDataEntity, username);
		
		// Success message
		return commandMessageFactory.createSuccessMessage("Transaction successfully approved!");
	}	

	/**
	 * @param basicCommand
	 * @return
	 */
	private long geTransactionID(BasicCommand basicCommand) {
		Object transactionID = basicCommand.map().get("transactionID");
		
		if(!hasValue(transactionID)) {
			throw new QueryException("Transaction ID should not be null. Please logout and "
					+ "retry again. If this issue persists, coordinate with the system "
					+ "administrator.");
		}
		
		return basicCommand.getLongValue("transactionID");
	}
	
	/**
	 * @param basicCommand
	 * @return
	 */
	private TransactionDataEntity getTransactionDataEntity(BasicCommand basicCommand) {
		return transactionDataEntityRepository.findByTransactionid(this.geTransactionID(basicCommand));
	}
	
	/**
	 * @param object
	 * @return
	 */
	private boolean hasValue(Object object) {
		if(object != null && !object.toString().isEmpty()) {
			return true;
		}else {
			return false;
		}
	}	
	
	/**
	 * @param transactionEntity
	 * @param username
	 */
	private void approve(TransactionDataEntity transactionEntity, String username){
		transactionEntity.setStatus(VALID_STATUS);
		transactionEntity.setLastModifiedBy(username);
		transactionEntity.setDateLastModified(Calendar.getInstance().getTime());
		
		// save transactionDataEntity
		transactionDataEntityRepository.save(transactionEntity);	
		
		// save to history
		this.saveToHistory(transactionEntity);
	}
	
	/**
	 * @param transactionEntity
	 */
	private void saveToHistory(TransactionDataEntity transactionEntity) {		
		Class<?> current = TransactionDataEntity.class;
		List<Field> fieldList = new ArrayList<Field>();
		
		while(current.getSuperclass()!=null){
			fieldList.addAll(Arrays.asList(current.getDeclaredFields()));
			current = current.getSuperclass();
		}
		
		TransactionDataHistoryEntity transactionDataHistoryEntity = new TransactionDataHistoryEntity();
		for(Field field : fieldList) {
			System.out.println(field.getName());
			
			if(!field.getName().equalsIgnoreCase("id")) {
				Field transactionHistoryField = ReflectionUtils.findField(TransactionDataHistoryEntity.class, field.getName());
				transactionHistoryField.setAccessible(true);
				
				field.setAccessible(true);
				
				try {
					ReflectionUtils.setField(transactionHistoryField, transactionDataHistoryEntity, field.get(transactionEntity));
				}catch(IllegalAccessException ex) {
					throw new UnableToProcessCommandException("This action cannot be processed at the moment."
							+ " Please coordinate with the system administrator.", ex);
				}
			}
		}

		transactionDataHistoryEntityRepository.save(transactionDataHistoryEntity);
	}
	
	/**
	 * @param status
	 */
	private void validateStatus(String status) {
		if(!status.equalsIgnoreCase(FOR_APPROVAL_MISSING_REQUIRED_FIELDS_STATUS)) {
			throw new UnableToProcessCommandException("The current status of this transaction is "+status+". Only transactions with status "
					+ FOR_APPROVAL_MISSING_REQUIRED_FIELDS_STATUS+ " are allowed for this action.", null);
		}
	}	
}
