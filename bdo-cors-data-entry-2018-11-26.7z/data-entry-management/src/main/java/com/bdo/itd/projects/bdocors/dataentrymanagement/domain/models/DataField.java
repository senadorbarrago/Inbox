package com.bdo.itd.projects.bdocors.dataentrymanagement.domain.models;

import lombok.Value;

/**
 * @author c140618008
 *
 */
@Value
public class DataField {
	
	/**
	 * 
	 */
	private String code;
	
	/**
	 * 
	 */
	private DataType dataType;
	
	/**
	 * 
	 */
	private Integer length;
	
	/**
	 * 
	 */
	private Integer precision;
	
	/**
	 * 
	 */
	private Integer scale;
	
	/**
	 * 
	 */
	private String format;
	
}
