package com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
@RequiredArgsConstructor
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Entity
@Table(name = "ref_currency")
public class CurrencyEntity extends BaseEntity {
	
	/**
	 * 
	 */
	@Column(name = "code")
	@NonNull 
	private String code;
	
	/**
	 * 
	 */
	@Column(name = "alpha_code")
	@NonNull 
	private String alphaCode;
	
	/**
	 * 
	 */
	@Column(name = "description")
	@NonNull 
	private String description;
	
	/**
	 * 
	 */
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "fk_book_code")
	@NonNull
	private BookEntity bookEntity;
	
	/**
	 * 
	 */
	@Column(name = "with_bsp_rate")
	@NonNull 
	private Boolean withBspRate = true;
}
