package com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.services;

import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import lombok.NonNull;
import lombok.RequiredArgsConstructor;

/**
 * @author c140618008
 *
 */
@Service
@RequiredArgsConstructor
public class TransactionNativeQueryService implements IQueryService {
	
	/**
	 * 
	 */
	@PersistenceContext
	@NonNull
	private final EntityManager em;

	/**
	 * 
	 */
	private static Logger logger = LoggerFactory.getLogger(TransactionNativeQueryService.class);
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> doQuery(String queryString, Map<String, Object> params, int pageIndex, int pageSize) {		
		Query query = em.createNativeQuery(queryString);
		
		if(params != null && !params.isEmpty()) {
			for(String key : params.keySet()){
				query.setParameter(key, params.get(key));
			}
		}
		
		logger.info(query.toString());
		
		return query.setFirstResult(pageIndex).setMaxResults(pageSize).getResultList();
	}

}
