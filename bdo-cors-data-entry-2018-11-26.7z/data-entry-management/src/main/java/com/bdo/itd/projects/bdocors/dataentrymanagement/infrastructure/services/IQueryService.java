package com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.services;

import java.util.List;
import java.util.Map;

/**
 * @author c140618008
 *
 */
public interface IQueryService {
	
	/**
	 * @param query
	 * @param params
	 * @return
	 */
	public List<Object[]> doQuery(String query, Map<String, Object> params, int pageIndex, int pageSize);
	
}
