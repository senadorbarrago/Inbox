package com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
@RequiredArgsConstructor
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Entity
@Table(name = "sec_user_profile")
public class UserBasicEntity extends BaseEntity {
	
	/**
	 * 
	 */
	@Column(name = "username")
	@NonNull 
	private String username;
	
}
