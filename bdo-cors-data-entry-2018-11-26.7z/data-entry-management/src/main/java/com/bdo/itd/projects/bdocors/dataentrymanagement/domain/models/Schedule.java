package com.bdo.itd.projects.bdocors.dataentrymanagement.domain.models;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import lombok.Value;

/**
 * @author c140618008
 *
 */
@Value
public class Schedule {
	
	/**
	 * 
	 */
	private long id;
	
	/**
	 * 
	 */
	private String code;
	
	/**
	 * 
	 */
	private List<DataField> dataFieldList = new ArrayList<>();
	
	/**
	 * @return
	 */
	public List<DataField> getDataFieldList(){
		return Collections.unmodifiableList(this.dataFieldList);
	}
}
