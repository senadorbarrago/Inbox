package com.bdo.itd.projects.bdocors.dataentrymanagement.application.command;

import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models.DataFieldEntity;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models.ScheduleDataFieldEntity;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models.TransactionMissingDataEntity;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.repository.IScheduleDataFieldEntityRepository;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.repository.ITransactionDataMissingEntityRepository;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.services.IQueryService;
import com.bdo.itd.util.cqrs.command.ACommandHandler;
import com.bdo.itd.util.cqrs.command.BasicCommand;
import com.bdo.itd.util.cqrs.command.CommandMessage;
import com.bdo.itd.util.cqrs.command.ICommand;
import com.bdo.itd.util.cqrs.command.UnableToProcessCommandException;
import com.bdo.itd.util.cqrs.query.QueryException;

/**
 * @author c140618008
 *
 */
@Service
public class SyncMissingRequiredFieldsCommandHandler extends ACommandHandler {
	
	/**
	 * 
	 */
	private static final Logger logger = LoggerFactory.getLogger(SyncMissingRequiredFieldsCommandHandler.class);
	
	/**
	 * 
	 */
	private final int defaultPageIndex = 1;
	
	/**
	 * 
	 */
	private final int defaultPageSize = 50;
	
	/**
	 * 
	 */
	private final IScheduleDataFieldEntityRepository scheduleDataFieldEntityRepository;
	
	/**
	 * 
	 */
	private final ITransactionDataMissingEntityRepository transactioDataMissingEntityRepository;
	
	/**
	 * 
	 */
	private final IQueryService queryService;
	
	/**
	 * @param scheduleDataFieldEntityRepository
	 * @param transactioDatanMissingEntityRepository
	 */
	@Autowired
	public SyncMissingRequiredFieldsCommandHandler(
			IScheduleDataFieldEntityRepository scheduleDataFieldEntityRepository,
			ITransactionDataMissingEntityRepository transactioDataMissingEntityRepository,
			@Qualifier("transactionNativeQueryService")IQueryService queryService) {
		super();
		this.scheduleDataFieldEntityRepository = scheduleDataFieldEntityRepository;
		this.transactioDataMissingEntityRepository = transactioDataMissingEntityRepository;
		this.queryService = queryService;
	}

	@Override
	public CommandMessage doHandle(ICommand command) throws UnableToProcessCommandException {
		// Extract command data
		BasicCommand basicCommand = (BasicCommand)command;
		logger.info(basicCommand.map().toString());
		
		List<TransactionMissingDataEntity> transactionMissingDataEntityList = this.getTransactionMissingDataEntityList(basicCommand);
		Set<String> transactionMissingDataEntitySet = this.getTransactionMissingDataEntitySet(transactionMissingDataEntityList);
		
		List<ScheduleDataFieldEntity> scheduleDataFieldEntityList = this.getScheduleDataFieldEntityList(basicCommand);
		
		LinkedHashMap<String, Object> transactionData = this.getTransactionData(basicCommand, scheduleDataFieldEntityList);
		
		String username = basicCommand.getStringValue("authenticatedUser");
		
		// Check if all blank schedule required fields are present in transactionMissingDataEntityList
		for(ScheduleDataFieldEntity scheduleDataFieldEntity : scheduleDataFieldEntityList) {
			DataFieldEntity dataFieldEntity = scheduleDataFieldEntity.getDataField();
			String dataFieldCode = scheduleDataFieldEntity.getDataField().getCode();
			
			// if Required only
			if(scheduleDataFieldEntity.isRequired()) {
				// if transactionData has the field
				if(transactionData.keySet().contains(dataFieldCode)) {
					Object value = transactionData.get(dataFieldCode);
					// If the transaction data value is null or empty
					if(value == null || value.toString().trim().isEmpty()) {
						// if dataField is not existing in transactionMissingDataEntityList
						if(!transactionMissingDataEntitySet.contains(dataFieldCode)) {
							// Insert a new missing TransactionMissingDataEntity object
							this.saveTransactionMissingDataEntity(this.geTransactionID(basicCommand), dataFieldEntity, username);
						}
					}
				}
			}
		}
		
		// Check for extra field in transactionMissingDataEntityList
		for(TransactionMissingDataEntity transactionMissingDataEntity : transactionMissingDataEntityList) {
			DataFieldEntity dataFieldEntity = transactionMissingDataEntity.getDataField();
			
			boolean isContains = false;
			for(ScheduleDataFieldEntity scheduleDataFieldEntity : scheduleDataFieldEntityList) {
				if(scheduleDataFieldEntity.isRequired()) {
					String scheduleDataFieldCode = scheduleDataFieldEntity.getDataField().getCode();
					if(dataFieldEntity.getCode().equals(scheduleDataFieldCode)) {
						isContains = true;
						break;
					}
					
				}
			}
			if(isContains == false) {
				this.deleteTransactionMissingDataEntity(transactionMissingDataEntity, username);
			}
		}
		
		// Communicate with service
		return commandMessageFactory.createSuccessMessage("Missing required fields synced successfully!");
	}	
	
	/**
	 * @param basicCommand
	 * @return
	 */
	private long geTransactionID(BasicCommand basicCommand) {
		Long transactionID = basicCommand.getLongValue("transactionID");
		if(!hasValue(transactionID)) {
			throw new QueryException("Transaction ID should not be null. Please logout and "
					+ "retry again. If this issue persists, coordinate with the system "
					+ "administrator.");
		}
		
		return transactionID;
	}
	
	/**
	 * @param basicCommand
	 * @return
	 */
	private String getScheduleCode(BasicCommand basicCommand) {
		String scheduleCode = basicCommand.getStringValue("scheduleCode");
		if(!hasValue(scheduleCode)) {
			throw new QueryException("Schedule code should not be null. Please logout and "
					+ "retry again. If this issue persists, coordinate with the system "
					+ "administrator.");
		}
		
		return scheduleCode;
	}
	
	/**
	 * @param object
	 * @return
	 */
	private boolean hasValue(Object object) {
		if(object != null && !object.toString().isEmpty()) {
			return true;
		}else {
			return false;
		}
	}
	
	/**
	 * @param basicCommand
	 * @return
	 */
	private List<TransactionMissingDataEntity> getTransactionMissingDataEntityList(BasicCommand basicCommand) {
		Long transactionID = this.geTransactionID(basicCommand);
		
		List<TransactionMissingDataEntity> transactionMissingDataEntityList = 
				transactioDataMissingEntityRepository.findByTransactionid(transactionID);
		
		return transactionMissingDataEntityList;
	}
	
	/**
	 * @param transactionMissingDataEntityList
	 * @return
	 */
	private Set<String> getTransactionMissingDataEntitySet(List<TransactionMissingDataEntity> transactionMissingDataEntityList) {
		Set<String> missingDataFieldSet = new HashSet<>();
		
		for(TransactionMissingDataEntity entity :transactionMissingDataEntityList) {
			missingDataFieldSet.add(entity.getDataField().getCode());
		}
		
		return missingDataFieldSet;
	}
	
	/**
	 * @param basicCommand
	 * @return
	 */
	private List<ScheduleDataFieldEntity> getScheduleDataFieldEntityList(BasicCommand basicCommand) {
		String scheduleCode = this.getScheduleCode(basicCommand);
		List<ScheduleDataFieldEntity> scheduleDataFieldEntityList = 
				scheduleDataFieldEntityRepository.findBySchedule_codeAndIsDeleted(scheduleCode, false);
		
		return scheduleDataFieldEntityList;
	}
	
	/**
	 * @param basicCommand
	 * @param scheduleDataFieldEntityList
	 * @return
	 */
	private LinkedHashMap<String, Object> getTransactionData(BasicCommand basicCommand, 
			List<ScheduleDataFieldEntity> scheduleDataFieldEntityList) {
		
		Long transactionID = this.geTransactionID(basicCommand);
		
		StringBuilder queryBuilder = new StringBuilder("select ");
		// DynamicScheduleFields
		int count = 0;
		for(ScheduleDataFieldEntity entity : scheduleDataFieldEntityList) {
			DataFieldEntity dataFieldEntity = entity.getDataField();
			if(count > 0) {
				queryBuilder.append(", ");
			}
			queryBuilder.append(dataFieldEntity.getCode().toLowerCase());
			queryBuilder.append(" as ");
			queryBuilder.append(dataFieldEntity.getCode());
			
		}	
		
		queryBuilder.append(" from txn_data ");
		queryBuilder.append("where transactionid = :transactionID ");
		queryBuilder.append("and is_deleted = false");
		
		logger.info(queryBuilder.toString());
		
		Map<String, Object> parameterMap = new HashMap<>();
		parameterMap.put("transactionID", transactionID);
		
		List<Object[]> resultArray = queryService.doQuery(queryBuilder.toString(), parameterMap, defaultPageIndex - 1, defaultPageSize);
		
		LinkedHashMap<String, Object> resultSet = this.buildResultSet(resultArray, scheduleDataFieldEntityList);
		
		return resultSet;
	}
	
	/**
	 * @param result
	 * @param scheduleDataFieldEntityList
	 * @return
	 */
	private LinkedHashMap<String, Object> buildResultSet(List<Object[]> result, List<ScheduleDataFieldEntity> scheduleDataFieldEntityList){
		LinkedHashMap<String, Object> row = new LinkedHashMap<>();
		
		for(Object[] objectList : result) {
			int count = 0;
			// DynamicScheduleFields
			for(ScheduleDataFieldEntity entity : scheduleDataFieldEntityList) {
				DataFieldEntity dataFieldEntity = entity.getDataField();
				row.put(dataFieldEntity.getCode(), objectList[count]);
				count++;
			}
			// expecting 1 record only;
			break;
		}
		
		return row;
	}
	
	/**
	 * @param transactionID
	 * @param dataFieldEntity
	 * @param username
	 */
	private void saveTransactionMissingDataEntity(long transactionID, DataFieldEntity dataFieldEntity, String username) {
		TransactionMissingDataEntity transactionMissingDataEntity = new TransactionMissingDataEntity(transactionID, dataFieldEntity);
		transactionMissingDataEntity.setCreatedBy(username);
		transactionMissingDataEntity.setDateCreated(Calendar.getInstance().getTime());
		
		transactioDataMissingEntityRepository.save(transactionMissingDataEntity);
	}
	
	/**
	 * @param transactionMissingDataEntity
	 * @param username
	 */
	private void deleteTransactionMissingDataEntity(TransactionMissingDataEntity transactionMissingDataEntity, String username) {
		transactioDataMissingEntityRepository.deleteById(transactionMissingDataEntity.getId());
	}
}
