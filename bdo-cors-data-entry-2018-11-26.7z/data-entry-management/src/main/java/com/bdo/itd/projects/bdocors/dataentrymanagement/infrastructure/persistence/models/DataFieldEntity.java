package com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
@RequiredArgsConstructor
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Entity
@Table(name = "conf_data_field")
public class DataFieldEntity extends BaseEntity {
	
	/**
	 * 
	 */
	@Column(name = "code")
	@NonNull 
	private String code;
	
	/**
	 * 
	 */
	@Column(name = "description")
	@NonNull 
	private String description;
	
	/**
	 * 
	 */
	@Column(name = "field_length")
	@NonNull
	private Integer length;
	
	/**
	 * 
	 */
	@Column(name = "field_precision")
	private Integer precision;
	
	/**
	 * 
	 */
	@Column(name = "field_scale")
	private Integer scale;
	
	/**
	 * 
	 */
	@Column(name = "field_format")
	private String format;
	
	/**
	 * 
	 */
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "fk_datatype")
	@NonNull
	private DataTypeEntity dataType;
	
	/**
	 * 
	 */
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "fk_report_field_data_type")
	@NonNull
	private DataTypeEntity reportFieldDataType;
}
