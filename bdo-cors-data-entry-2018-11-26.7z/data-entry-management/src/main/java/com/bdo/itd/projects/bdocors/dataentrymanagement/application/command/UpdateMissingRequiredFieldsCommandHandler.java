package com.bdo.itd.projects.bdocors.dataentrymanagement.application.command;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.ReflectionUtils;

import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models.DataFieldEntity;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models.ScheduleDataFieldEntity;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models.SourceSystemDataFieldEntity;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models.TransactionDataEntity;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models.TransactionDataHistoryEntity;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models.TransactionMissingDataEntity;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.repository.IScheduleDataFieldEntityRepository;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.repository.ISourceSystemDataFieldEntityRepository;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.repository.ITransactionDataEntityRepository;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.repository.ITransactionDataHistoryEntityRepository;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.repository.ITransactionDataMissingEntityRepository;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.services.IQueryService;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.utilities.DateConverterUtility;
import com.bdo.itd.util.cqrs.command.ACommandHandler;
import com.bdo.itd.util.cqrs.command.BasicCommand;
import com.bdo.itd.util.cqrs.command.CommandMessage;
import com.bdo.itd.util.cqrs.command.ICommand;
import com.bdo.itd.util.cqrs.command.UnableToProcessCommandException;
import com.bdo.itd.util.cqrs.query.QueryException;

/**
 * @author c140618008
 *
 */
@Service
public class UpdateMissingRequiredFieldsCommandHandler extends ACommandHandler {
	
	/**
	 * 
	 */
	private static final Logger logger = LoggerFactory.getLogger(UpdateMissingRequiredFieldsCommandHandler.class);
	
	/**
	 * 
	 */
	private final int defaultPageIndex = 1;
	
	/**
	 * 
	 */
	private final int defaultPageSize = 50;
	
	/**
	 * 
	 */
	@Value("${data-format.date.default}")
	private String dateFormat;
	
	/**
	 * 
	 */
	@Value("${data-format.datetime.default}")
	private String dateTimeFormat;
	
	/**
	 * 
	 */
	@Value("${data-format.amount.default}")
	private String amountFormat;
	
	/**
	 * 
	 */
	@Value("${data-format.float.default}")
	private String floatFormat;
	
	/**
	 * 
	 */
	private final String MISSING_REQUIRED_FIELDS_STATUS = "INVALID-Missing Required Fields";
	
	/**
	 * 
	 */
	private final String FOR_APPROVAL_MISSING_REQUIRED_FIELDS_STATUS = "FOR APPROVAL-Missing Required Fields";
	
	/**
	 * 
	 */
	private final IScheduleDataFieldEntityRepository scheduleDataFieldEntityRepository;
	
	/**
	 * 
	 */
	private final ITransactionDataMissingEntityRepository transactioDataMissingEntityRepository;
	
	/**
	 * 
	 */
	private final ITransactionDataEntityRepository transactionDataEntityRepository; 
	
	/**
	 * 
	 */
	private final ITransactionDataHistoryEntityRepository transactionDataHistoryEntityRepository;
	
	/**
	 * 
	 */
	private final ISourceSystemDataFieldEntityRepository sourceSystemDataFieldEntityRepository;
	
	/**
	 * 
	 */
	private final IQueryService queryService;
	
	/**
	 * @param scheduleDataFieldEntityRepository
	 * @param transactioDataMissingEntityRepository
	 * @param transactionDataEntityRepository
	 * @param transactionDataHistoryEntityRepository
	 * @param sourceSystemDataFieldEntityRepository
	 * @param queryService
	 */
	@Autowired
	public UpdateMissingRequiredFieldsCommandHandler(
			IScheduleDataFieldEntityRepository scheduleDataFieldEntityRepository,
			ITransactionDataMissingEntityRepository transactioDataMissingEntityRepository,
			ITransactionDataEntityRepository transactionDataEntityRepository,
			ITransactionDataHistoryEntityRepository transactionDataHistoryEntityRepository,
			ISourceSystemDataFieldEntityRepository sourceSystemDataFieldEntityRepository, 
			@Qualifier("transactionNativeQueryService")IQueryService queryService) {
		super();
		this.scheduleDataFieldEntityRepository = scheduleDataFieldEntityRepository;
		this.transactioDataMissingEntityRepository = transactioDataMissingEntityRepository;
		this.transactionDataEntityRepository = transactionDataEntityRepository;
		this.transactionDataHistoryEntityRepository = transactionDataHistoryEntityRepository;
		this.sourceSystemDataFieldEntityRepository = sourceSystemDataFieldEntityRepository;
		this.queryService = queryService;
	}
	
	@Override
	public CommandMessage doHandle(ICommand command) throws UnableToProcessCommandException {
		// Extract command data
		BasicCommand basicCommand = (BasicCommand)command;
		logger.info(basicCommand.map().toString());
		
		// Load schedule required fields
		List<ScheduleDataFieldEntity> scheduleDataFieldEntityList = this.getScheduleDataFieldEntityList(basicCommand);
		logger.info(scheduleDataFieldEntityList.toString());
		
		// Load missing required fields
		List<TransactionMissingDataEntity> transactionMissingDataEntityList = this.getTransactionMissingDataEntityList(basicCommand);
		logger.info(transactionMissingDataEntityList.toString());
		
		// Load transaction data
		LinkedHashMap<String, Object> transactionData = this.getTransactionData(basicCommand, scheduleDataFieldEntityList);
		logger.info(transactionData.toString());
		
		// Validate status
		this.validateStatus(String.valueOf(transactionData.get("status")));
		
		// authenticatedUser
		String username = basicCommand.getStringValue("authenticatedUser");
		
		
		List<SourceSystemDataFieldEntity> sourceSystemFieldList = this.getSourceSystemDataFieldEntityList(String.valueOf(transactionData.get("sscode")));
		
		// Update fields
		this.saveUpdatedData(basicCommand, transactionMissingDataEntityList, sourceSystemFieldList, transactionData, username);
		
		// Communicate with service
		return commandMessageFactory.createSuccessMessage("Missing required fields updated successfully!");
	}	

	/**
	 * @param basicCommand
	 * @return
	 */
	private long geTransactionID(BasicCommand basicCommand) {
		Object transactionID = basicCommand.map().get("transactionID");
		
		if(!hasValue(transactionID)) {
			throw new QueryException("Transaction ID should not be null. Please logout and "
					+ "retry again. If this issue persists, coordinate with the system "
					+ "administrator.");
		}
		
		return basicCommand.getLongValue("transactionID");
	}
	
	/**
	 * @param basicCommand
	 * @return
	 */
	private TransactionDataEntity getTransactionDataEntity(BasicCommand basicCommand) {
		return transactionDataEntityRepository.findByTransactionid(this.geTransactionID(basicCommand));
	}
	
	/**
	 * @param basicCommand
	 * @return
	 */
	private String getScheduleCode(BasicCommand basicCommand) {
		Object scheduleCode = basicCommand.map().get("scheduleCode");
		if(!hasValue(scheduleCode)) {
			throw new QueryException("Schedule code should not be null. Please logout and "
					+ "retry again. If this issue persists, coordinate with the system "
					+ "administrator.");
		}
		
		return basicCommand.getStringValue("scheduleCode");
	}
	
	/**
	 * @param object
	 * @return
	 */
	private boolean hasValue(Object object) {
		if(object != null && !object.toString().isEmpty()) {
			return true;
		}else {
			return false;
		}
	}
	
	/**
	 * @param basicCommand
	 * @return
	 */
	private List<TransactionMissingDataEntity> getTransactionMissingDataEntityList(BasicCommand basicCommand) {
		Long transactionID = this.geTransactionID(basicCommand);
		
		List<TransactionMissingDataEntity> transactionMissingDataEntityList = 
				transactioDataMissingEntityRepository.findByTransactionid(transactionID);
		
		return transactionMissingDataEntityList;
	}
	
	/**
	 * @param basicCommand
	 * @return
	 */
	private List<ScheduleDataFieldEntity> getScheduleDataFieldEntityList(BasicCommand basicCommand) {
		String scheduleCode = this.getScheduleCode(basicCommand);
		List<ScheduleDataFieldEntity> scheduleDataFieldEntityList = 
				scheduleDataFieldEntityRepository.findBySchedule_codeAndIsDeleted(scheduleCode, false);
		
		return scheduleDataFieldEntityList;
	}
	
	/**
	 * @param sourceSystemCode
	 * @return
	 */
	private List<SourceSystemDataFieldEntity> getSourceSystemDataFieldEntityList(String sourceSystemCode) {
		List<SourceSystemDataFieldEntity> sourceSystemDataFieldEntityList = 
				sourceSystemDataFieldEntityRepository.findBySourceSystem_codeAndIsDeleted(sourceSystemCode, false);
		
		return sourceSystemDataFieldEntityList;
	}
	
	/**
	 * @param basicCommand
	 * @param transactionMissingDataEntityList
	 * @return
	 */
	private LinkedHashMap<String, Object> getTransactionData(BasicCommand basicCommand, 
			List<ScheduleDataFieldEntity> scheduleDataFieldEntityList) {
		
		Long transactionID = this.geTransactionID(basicCommand);
		
		StringBuilder queryBuilder = new StringBuilder("select ");
		queryBuilder.append("sscode as sscode, ");
		queryBuilder.append("brcode as brcode, ");
		queryBuilder.append("status as status");
		
		// DynamicScheduleFields
		for(ScheduleDataFieldEntity entity : scheduleDataFieldEntityList) {
			DataFieldEntity dataFieldEntity = entity.getDataField();
			queryBuilder.append(", ");
			queryBuilder.append(dataFieldEntity.getCode().toLowerCase());
			queryBuilder.append(" as ");
			queryBuilder.append(dataFieldEntity.getCode().toLowerCase());
		}	
		
		queryBuilder.append(" from txn_data ");
		queryBuilder.append("where transactionid = :transactionID ");
		queryBuilder.append("and is_deleted = false");
		
		logger.info(queryBuilder.toString());
		
		Map<String, Object> parameterMap = new HashMap<>();
		parameterMap.put("transactionID", transactionID);
		
		List<Object[]> resultArray = queryService.doQuery(queryBuilder.toString(), parameterMap, defaultPageIndex - 1, defaultPageSize);
		
		LinkedHashMap<String, Object> resultSet = this.buildResultSet(resultArray, scheduleDataFieldEntityList);
		
		return resultSet;
	}
	
	/**
	 * @param result
	 * @param transactionMissingDataEntityList
	 * @return
	 */
	private LinkedHashMap<String, Object> buildResultSet(List<Object[]> result, List<ScheduleDataFieldEntity> scheduleDataFieldEntityList){
		LinkedHashMap<String, Object> row = new LinkedHashMap<>();
		
		for(Object[] objectList : result) {
			int count = 3;

			row.put("sscode", objectList[0]);
			row.put("brcode", objectList[1]);
			row.put("status", objectList[2]);

			// DynamicScheduleFields
			for(ScheduleDataFieldEntity entity : scheduleDataFieldEntityList) {
				DataFieldEntity dataFieldEntity = entity.getDataField();
				row.put(dataFieldEntity.getCode(), objectList[count]);
				count++;
			}
			// expecting 1 record only;
			break;
		}
		
		return row;
	}
	
	/**
	 * @param command
	 * @return
	 */
	private void saveUpdatedData(BasicCommand command, List<TransactionMissingDataEntity> transactionMissingDataEntityList,
		List<SourceSystemDataFieldEntity> sourceSystemFieldList, LinkedHashMap<String, Object>transactionData, String username){
		
		Map<String, Object> data = new HashMap<>();
		Map<String, Object> dataType = new HashMap<>();
		
		for(TransactionMissingDataEntity entity : transactionMissingDataEntityList) {
			DataFieldEntity dataFieldEntity = entity.getDataField();
			
			// Validate fields
			this.validateDataType(dataFieldEntity, command.map().get(dataFieldEntity.getCode()));
			this.validateFieldLength(dataFieldEntity, command.map().get(dataFieldEntity.getCode()));
			
			data.put(dataFieldEntity.getCode().toLowerCase(), command.map().get(dataFieldEntity.getCode()));
			dataType.put(dataFieldEntity.getCode().toLowerCase(), dataFieldEntity.getDataType().getCode());
		}
		
		for(SourceSystemDataFieldEntity entity : sourceSystemFieldList) {
			DataFieldEntity dataFieldEntity = entity.getDataField();
			
			// Validate fields
			this.validateDataType(dataFieldEntity, command.map().get(dataFieldEntity.getCode()));
			this.validateFieldLength(dataFieldEntity, command.map().get(dataFieldEntity.getCode()));
			
			data.put(dataFieldEntity.getCode().toLowerCase(), command.map().get(dataFieldEntity.getCode()));
			dataType.put(dataFieldEntity.getCode().toLowerCase(), dataFieldEntity.getDataType().getCode());
		}
		
		logger.info(data.toString());
		
		TransactionDataEntity transactionEntity = this.getTransactionDataEntity(command);
		
		for(String key : data.keySet()) {
			System.out.println(key);
			Field field = ReflectionUtils.findField(TransactionDataEntity.class, key);
			field.setAccessible(true);
			
			try {
				ReflectionUtils.setField(field, transactionEntity, formatData(String.valueOf(data.get(key)), 
						String.valueOf(dataType.get(key)), 0));
			}catch(ParseException paex) {
				throw new UnableToProcessCommandException(paex.getMessage(), paex);
			}
		}
		
		transactionEntity.setStatus(FOR_APPROVAL_MISSING_REQUIRED_FIELDS_STATUS);
		transactionEntity.setLastModifiedBy(username);
		transactionEntity.setDateLastModified(Calendar.getInstance().getTime());
		
		// save transactionDataEntity
		transactionDataEntityRepository.save(transactionEntity);
		
		// save to history
		this.saveToHistory(transactionEntity);
	}
	
	/**
	 * @param transactionEntity
	 */
	private void saveToHistory(TransactionDataEntity transactionEntity) {		
		Class<?> current = TransactionDataEntity.class;
		List<Field> fieldList = new ArrayList<Field>();
		
		while(current.getSuperclass()!=null){
			fieldList.addAll(Arrays.asList(current.getDeclaredFields()));
			current = current.getSuperclass();
		}
		
		TransactionDataHistoryEntity transactionDataHistoryEntity = new TransactionDataHistoryEntity();
		for(Field field : fieldList) {
			System.out.println(field.getName());
			
			if(!field.getName().equalsIgnoreCase("id")) {
				Field transactionHistoryField = ReflectionUtils.findField(TransactionDataHistoryEntity.class, field.getName());
				transactionHistoryField.setAccessible(true);
				
				field.setAccessible(true);
				
				try {
					ReflectionUtils.setField(transactionHistoryField, transactionDataHistoryEntity, field.get(transactionEntity));
				}catch(IllegalAccessException ex) {
					throw new UnableToProcessCommandException("This action cannot be processed at the moment."
							+ " Please coordinate with the system administrator.", ex);
				}
			}
		}

		transactionDataHistoryEntityRepository.save(transactionDataHistoryEntity);
	}

	/**
	 * @param data
	 * @param dataType
	 * @return
	 */
	private Object formatData(Object data, String dataType, Integer scale) throws ParseException{
		Object formattedData = data != null ? String.valueOf(data): null;
		
		logger.info("data: "+data);
		logger.info("dataType: "+dataType);
		logger.info("scale: "+scale);
		
		if(data != null) {
			switch (dataType) {
				case "BOOLEAN":
					formattedData = Boolean.parseBoolean(String.valueOf(data));
					
					break;
				case "INT":
					formattedData = Integer.parseInt(String.valueOf(data));
					
					break;
				case "BIGINT":
					formattedData = Long.parseLong(String.valueOf(data));
					
					break;
				case "NUMERIC":
					formattedData = new BigDecimal(String.valueOf(data));
					
					break;
				case "TEXT":
					formattedData = String.valueOf(data);
					
					break;
				case "TIMESTAMP":
					formattedData = DateConverterUtility.toDate(data.toString(), dateTimeFormat);
					
					break;
				case "DATE":
					formattedData = DateConverterUtility.toDate(data.toString(), dateFormat);
					
					break;					
				default:
					return String.valueOf(data);
			}
		}
		
		logger.info("formattedData: "+formattedData);
		
		return formattedData;
	}	
	
	/**
	 * @param status
	 */
	private void validateStatus(String status) {
		if(!status.equalsIgnoreCase(MISSING_REQUIRED_FIELDS_STATUS)) {
			throw new UnableToProcessCommandException("The current status of this transaction is "+status+". Only transactions with status "
					+ MISSING_REQUIRED_FIELDS_STATUS+ " are allowed for this action.", null);
		}
	}	
	
	/**
	 * @param dataFieldEntity
	 * @param data
	 */
	private void validateDataType(DataFieldEntity dataFieldEntity, Object data) {
		String dataStr = String.valueOf(data).trim();
		String dataFieldName = dataFieldEntity.getCode().toLowerCase();
		String dataType = dataFieldEntity.getDataType().getCode();
		try {
			switch (dataType) {
				case "BOOLEAN":
					if(!dataStr.equalsIgnoreCase("true") && !dataStr.equalsIgnoreCase("false")) {
						throw new IllegalArgumentException();
					}
	
					break;
				case "INT":
					Integer.parseInt(dataStr);
					
					break;
				case "BIGINT":
					Long.parseLong(dataStr);
					
					break;
				case "NUMERIC":
					dataStr = dataStr.replace(",", "");
					new BigDecimal(dataStr);
					
					break;
				case "TEXT":
					String.valueOf(data);
					
					break;
				case "TIMESTAMP":
					DateConverterUtility.toDate(data.toString(), dateTimeFormat);
					
					break;
				case "DATE":
					DateConverterUtility.toDate(data.toString(), dateFormat);
					
					break;					
				default:
					String.valueOf(data);
					break;
			}
			
		}catch(IllegalArgumentException | ParseException ex) {
			throw new UnableToProcessCommandException("Data field "+dataFieldName+" "+data
					+ " is not a valid "+dataType+" value", ex);
		}
	}
	
	
	/**
	 * @param dataFieldEntity
	 * @param data
	 */
	private void validateFieldLength(DataFieldEntity dataFieldEntity, Object data) {
		String dataStr = String.valueOf(data).trim();
		
		String dataFieldName = dataFieldEntity.getCode().toLowerCase();
		String dataType = dataFieldEntity.getDataType().getCode();
		
		Integer fieldLength = dataFieldEntity.getLength();
		Integer fieldPrecision = dataFieldEntity.getPrecision();
		Integer fieldScale = dataFieldEntity.getScale();
		
		try {
			switch (dataType) {
				case "BOOLEAN":
					if(dataStr.length() > fieldLength) {
						throw new IllegalArgumentException();
					}
	
					break;
				case "INT":
					if(dataStr.length() > fieldLength) {
						throw new IllegalArgumentException();
					}
					
					break;
				case "BIGINT":
					if(dataStr.length() > fieldLength) {
						throw new IllegalArgumentException();
					}
					
					break;
				case "NUMERIC":
					dataStr = dataStr.replace(",", "");
					if(dataStr.contains(".")) {
						String wholePart = dataStr.substring(0, dataStr.indexOf("."));
						String decimalPart = dataStr.substring(dataStr.indexOf(".")+1, dataStr.length());
						
						int overAllFieldLength = wholePart.length() + decimalPart.length();
						
						if(overAllFieldLength > fieldPrecision) {
							throw new IllegalArgumentException();
						}
						
						if(decimalPart.length() > fieldScale) {
							throw new IllegalArgumentException();
						}
					}else {
						if(dataStr.length() > fieldLength) {
							throw new IllegalArgumentException();
						}
					}
					
					break;
				case "TEXT":
					if(dataStr.length() > fieldLength) {
						throw new IllegalArgumentException();
					}
					
					break;
				case "TIMESTAMP":
					dataStr = dataStr.replace("-", "");
					if(dataStr.length() > fieldLength) {
						throw new IllegalArgumentException();
					}
					
					break;
				case "DATE":
					dataStr = dataStr.replace("-", "");
					if(dataStr.length() > fieldLength) {
						throw new IllegalArgumentException();
					}
					
					break;					
				default:
					if(dataStr.length() > fieldLength) {
						throw new IllegalArgumentException();
					}
					break;
			}
			
		}catch(IllegalArgumentException ex) {
			throw new UnableToProcessCommandException("Data field "+dataFieldName+" "+data
					+ " exceeds the maximum field length limit of "+fieldLength+" character/digit", ex);
		}
	}
}
