package com.bdo.itd.projects.bdocors.dataentrymanagement.application.query;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models.QTransactionDataEntity;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models.QUserBranchEntity;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models.TransactionDataEntity;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.repository.ITransactionDataEntityRepository;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.utilities.DateConverterUtility;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.utilities.DecimalConverterUtility;
import com.bdo.itd.util.cqrs.query.APageableQueryModel;
import com.bdo.itd.util.cqrs.query.IQuery;
import com.bdo.itd.util.cqrs.query.QueryException;
import com.bdo.itd.util.cqrs.query.QueryParam;
import com.bdo.itd.util.cqrs.query.ResultModel;
import com.querydsl.core.BooleanBuilder;
import com.querydsl.core.types.Predicate;
import com.querydsl.jpa.JPAExpressions;

@Service
public class TransactionPoolQueryModel extends APageableQueryModel implements IQuery {
	
	/**
	 * 
	 */
	private final int defaultPageIndex = 1;
	
	/**
	 * 
	 */
	private final int defaultPageSize = 50;
	
	/**
	 * 
	 */
	private final String VALID_STATUS = "VALID";
	
	/**
	 * 
	 */
	@Value(value = "${data-format.date.default}")
	private String dateFormat;
	
	/**
	 * 
	 */
	@Value(value = "${data-format.datetime.default}")
	private String dateTimeFormat;
	
	/**
	 * 
	 */
	@Value(value = "${data-format.amount.default}")
	private String amountFormat;
	
	/**
	 * 
	 */
	private final ITransactionDataEntityRepository transactionDataEntityRepository;
	
	/**
	 * @param transactionDataEntryRepository
	 */
	@Autowired
	public TransactionPoolQueryModel(ITransactionDataEntityRepository transactionDataEntityRepository) {
		super();
		this.transactionDataEntityRepository = transactionDataEntityRepository;
	}

	@Override
	public ResultModel doQuery(QueryParam queryParam) throws QueryException {
		try {
			Predicate predicate = this.buildPredicate(queryParam);
			
			int pageIndex = this.getPagination(queryParam.getParam("pageIndex"), defaultPageIndex);
			int pageSize = this.getPagination(queryParam.getParam("pageSize"), defaultPageSize);
			
			return query(predicate, pageIndex, pageSize);
			
		}catch(ParseException ex) {
			throw new QueryException(ex);
		}
	}
	
	
	/**
	 * @param queryParam
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private Predicate buildPredicate(QueryParam queryParam) throws ParseException{
		BooleanBuilder builder = new BooleanBuilder();
		QTransactionDataEntity qtransactionDataEntity = new QTransactionDataEntity("transactionDataEntity");
		QUserBranchEntity quserBranchEntity = new QUserBranchEntity("userBranchEntity"); 
		
		Map<String, Object> searchCriteria =  (Map<String, Object>)queryParam.getParam("searchCriteria");
		
		// Per User Branch
		String username = String.valueOf(queryParam.getParam("authenticatedUser"));
		builder.and(qtransactionDataEntity.brcode.in(
			JPAExpressions.selectFrom(quserBranchEntity).
				where(quserBranchEntity.userProfile.username.equalsIgnoreCase(username).
						and(quserBranchEntity.branch.isDeleted.eq(false)).
						and(quserBranchEntity.isDeleted.eq(false))).
						select(quserBranchEntity.branch.code)));
		
		// Only valid transactions
		builder.and(qtransactionDataEntity.status.equalsIgnoreCase(VALID_STATUS));
		
		if(searchCriteria != null && !searchCriteria.isEmpty()) {
			if(hasValue(searchCriteria.get("BKCODE"))) {
				int bkcode = Integer.parseInt(String.valueOf(searchCriteria.get("BKCODE")));
				
				builder.and(qtransactionDataEntity.bkcode.eq(bkcode));
			}
			
			if(hasValue(searchCriteria.get("TRDATEFROM"))) {
				Date transactionDateFrom = DateConverterUtility.toDate(searchCriteria.get("TRDATEFROM").toString(), dateFormat);
				builder.and(qtransactionDataEntity.trdate.goe(transactionDateFrom));
			}
			
			if(hasValue(searchCriteria.get("TRDATETO"))) {
				Date transactionDateTo = DateConverterUtility.toDate(searchCriteria.get("TRDATETO").toString(), dateFormat);
				// Add 23 Hour, 59 minutes, and 59 seconds
				Calendar c = Calendar.getInstance();
		        c.setTime(transactionDateTo);
				
		        c.add(Calendar.HOUR, 23);
		        c.add(Calendar.MINUTE, 59);
		        c.add(Calendar.SECOND, 59);
		        
				builder.and(qtransactionDataEntity.trdate.loe(c.getTime()));
			}
			
			if(hasValue(searchCriteria.get("TRCODE"))) {
				String trcode = String.valueOf(searchCriteria.get("TRCODE"));
				
				builder.and(qtransactionDataEntity.trcode.startsWith(trcode));
			}
			
			if(hasValue(searchCriteria.get("BOOKCD"))) {
				int bookcd = Integer.parseInt(String.valueOf(searchCriteria.get("BOOKCD")));

				builder.and(qtransactionDataEntity.bookcd.eq(bookcd));
			}
			
			if(hasValue(searchCriteria.get("CURCDE1"))) {
				String curcde1 = String.valueOf(searchCriteria.get("CURCDE1"));

				builder.and(qtransactionDataEntity.curcde1.equalsIgnoreCase(curcde1));
			}
			
			if(hasValue(searchCriteria.get("AMTORIG1FROM"))) {
				String amtorig1from = String.valueOf(searchCriteria.get("AMTORIG1FROM"));
				
				builder.and(qtransactionDataEntity.amtorig1.goe(new BigDecimal(amtorig1from)));
			}
			
			if(hasValue(searchCriteria.get("AMTORIG1TO"))) {
				String amountorig1to = String.valueOf(searchCriteria.get("AMTORIG1TO"));
				
				builder.and(qtransactionDataEntity.amtorig1.loe(new BigDecimal(amountorig1to)));
			}
			
			if(hasValue(searchCriteria.get("BRCODE"))) {
				String brcode = String.valueOf(searchCriteria.get("BRCODE"));
				
				builder.and(qtransactionDataEntity.brcode.equalsIgnoreCase(brcode));
			}
			
			if(hasValue(searchCriteria.get("SSCODE"))) {
				String sourceSystem = String.valueOf(searchCriteria.get("SSCODE"));
				
				builder.and(qtransactionDataEntity.sscode.equalsIgnoreCase(sourceSystem));
			}
			
		}
		
		builder.and(qtransactionDataEntity.isDeleted.eq(false));
		
		return builder.getValue();
	}
	
	/**
	 * @param object
	 * @return
	 */
	private boolean hasValue(Object object) {
		if(object != null && !object.toString().isEmpty()) {
			return true;
		}else {
			return false;
		}
	}
	
	/**
	 * @param object
	 * @param defaultValue
	 * @return
	 */
	private int getPagination(Object object, int defaultValue) {
		if(hasValue(object)) {
			return Integer.parseInt(object.toString());
		}else {
			return defaultValue;
		}
	}
	
	/**
	 * @param predicate
	 * @param pageIndex
	 * @param pageSize
	 * @return
	 */
	private ResultModel query(Predicate predicate, int pageIndex, int pageSize) {
		Iterable<TransactionDataEntity> transactionDataEntityList = transactionDataEntityRepository.findAll(predicate, gotoPage(pageIndex, pageSize, Sort.Direction.DESC, 
				"dateCreated"));
		
		long overAllCount = transactionDataEntityRepository.count(predicate);
		
		List<LinkedHashMap<String, Object>> resultSet = new ArrayList<>();
		
		for(TransactionDataEntity entity : transactionDataEntityList) {
			LinkedHashMap<String, Object> row = new LinkedHashMap<>();
			row.put("id", entity.getId());
			
			row.put("transactionID", entity.getTransactionid());
			row.put("BKCODE", entity.getBkcode());
			row.put("TRDATE", DateConverterUtility.toString(entity.getTrdate(), dateFormat));
			row.put("TRCODE", entity.getTrcode());
			row.put("BOOKCD", entity.getBookcd());
			row.put("CURCDE1", entity.getCurcde1());
			row.put("AMTORIG1", DecimalConverterUtility.toString(entity.getAmtorig1(), amountFormat));
			row.put("Schedule", this.getScheduleCode(entity.getTrcode()));
			row.put("Status", entity.getStatus());
			row.put("Remarks", entity.getRemarks());
			row.put("Source", entity.getSscode());
			row.put("Created", entity.getCreatedBy());
			row.put("Date Created", DateConverterUtility.toString(entity.getDateCreated(), dateTimeFormat));
			
			resultSet.add(row);
		}		
		
		
		return new ResultModel(resultSet, overAllCount);
	}
	
	/**
	 * @param transactionCode
	 * @return
	 */
	private String getScheduleCode(String transactionCode) {
		return "D"+transactionCode.substring(0, 2);
	}
	
}
