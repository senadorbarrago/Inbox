package com.bdo.itd.projects.bdocors.dataentrymanagement.application.query.reference;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models.BranchEntity;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models.QBranchEntity;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.repository.IBranchEntityRepository;
import com.bdo.itd.util.cqrs.query.APageableQueryModel;
import com.bdo.itd.util.cqrs.query.IQuery;
import com.bdo.itd.util.cqrs.query.QueryException;
import com.bdo.itd.util.cqrs.query.QueryParam;
import com.bdo.itd.util.cqrs.query.ResultModel;
import com.querydsl.core.BooleanBuilder;
import com.querydsl.core.types.Predicate;

@Service
public class BranchListQueryModel extends APageableQueryModel implements IQuery {
	
	/**
	 * 
	 */
	private final int defaultPageIndex = 1;
	
	/**
	 * 
	 */
	private final int defaultPageSize = 50;
	
	/**
	 * 
	 */
	private final IBranchEntityRepository branchEntityRepository;
	
	/**
	 * @param branchEntityRepository
	 */
	@Autowired
	public BranchListQueryModel(IBranchEntityRepository branchEntityRepository) {
		super();
		this.branchEntityRepository = branchEntityRepository;
	}

	@Override
	public ResultModel doQuery(QueryParam queryParam) throws QueryException {
		try {
			Predicate predicate = this.buildPredicate(queryParam);
			
			int pageIndex = this.getPagination(queryParam.getParam("pageIndex"), defaultPageIndex);
			int pageSize = this.getPagination(queryParam.getParam("pageSize"), defaultPageSize);
			
			return query(predicate, pageIndex, pageSize);
			
		}catch(ParseException ex) {
			throw new QueryException(ex);
		}
	}
	
	/**
	 * @param queryParam
	 * @return
	 * @throws ParseException
	 */
	private Predicate buildPredicate(QueryParam queryParam) throws ParseException{
		BooleanBuilder builder = new BooleanBuilder();
		QBranchEntity qbranchEntity = new QBranchEntity("branchEntity");
		
		builder.and(qbranchEntity.isDeleted.eq(false));
		
		return builder.getValue();
	}
	
	/**
	 * @param object
	 * @return
	 */
	private boolean hasValue(Object object) {
		if(object != null && !object.toString().isEmpty()) {
			return true;
		}else {
			return false;
		}
	}
	
	/**
	 * @param object
	 * @param defaultValue
	 * @return
	 */
	private int getPagination(Object object, int defaultValue) {
		if(hasValue(object)) {
			return Integer.parseInt(object.toString());
		}else {
			return defaultValue;
		}
	}
	
	/**
	 * @param predicate
	 * @param pageIndex
	 * @param pageSize
	 * @return
	 */
	private ResultModel query(Predicate predicate, int pageIndex, int pageSize) {
		Iterable<BranchEntity> branchEntityList = branchEntityRepository.findAll(predicate, gotoPage(pageIndex, pageSize, Sort.Direction.ASC, 
				"description"));
		
		long overAllCount = branchEntityRepository.count(predicate);
		
		List<LinkedHashMap<String, Object>> resultSet = new ArrayList<>();
		
		for(BranchEntity entity : branchEntityList) {
			LinkedHashMap<String, Object> row = new LinkedHashMap<>();
			row.put("id", entity.getId());
			row.put("code", entity.getCode());
			row.put("description", entity.getDescription());
			
			resultSet.add(row);
		}		
		
		return new ResultModel(resultSet, overAllCount);
	}
}
