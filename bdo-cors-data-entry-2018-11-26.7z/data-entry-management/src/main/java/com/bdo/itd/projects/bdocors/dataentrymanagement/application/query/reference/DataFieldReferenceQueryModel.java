package com.bdo.itd.projects.bdocors.dataentrymanagement.application.query.reference;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models.ScheduleDataFieldEntity;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.repository.IScheduleDataFieldEntityRepository;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.services.IQueryService;
import com.bdo.itd.util.cqrs.query.APageableQueryModel;
import com.bdo.itd.util.cqrs.query.IQuery;
import com.bdo.itd.util.cqrs.query.QueryException;
import com.bdo.itd.util.cqrs.query.QueryParam;
import com.bdo.itd.util.cqrs.query.ResultModel;

/**
 * @author c140618008
 *
 */
@Service
public class DataFieldReferenceQueryModel extends APageableQueryModel implements IQuery {
	
	/**
	 * 
	 */
	private final int defaultPageIndex = 1;
	
	/**
	 * 
	 */
	private final int defaultPageSize = 50;
	
	/**
	 * 
	 */
	private final IScheduleDataFieldEntityRepository scheduleDataFieldEntityRepository;
	
	/**
	 * 
	 */
	private final IQueryService queryService;
	
	/**
	 * @param queryService
	 */
	@Autowired
	public DataFieldReferenceQueryModel(IScheduleDataFieldEntityRepository scheduleDataFieldEntityRepository, 
			@Qualifier("transactionNativeQueryService")IQueryService queryService) {
		super();
		this.scheduleDataFieldEntityRepository = scheduleDataFieldEntityRepository;
		this.queryService = queryService;
	}

	@Override
	public ResultModel doQuery(QueryParam queryParam) throws QueryException {
		try {			
			ScheduleDataFieldEntity scheduleDataFieldEntity = this.getScheduleDataFieldEntity(queryParam);
			
			int pageIndex = this.getPagination(queryParam.getParam("pageIndex"), defaultPageIndex);
			int pageSize = this.getPagination(queryParam.getParam("pageSize"), defaultPageSize);
			
			return query(scheduleDataFieldEntity, queryParam, pageIndex, pageSize);
			
		}catch(Exception ex) {
			throw new QueryException(ex);
		}
	}
	
	/**
	 * @param queryParam
	 * @return
	 */
	private ScheduleDataFieldEntity getScheduleDataFieldEntity(QueryParam queryParam) {
		if(!hasValue(queryParam.getParam("scheduleCode"))) {
			throw new QueryException("Schedule should not be null. Please select a schedule and "
					+ "retry again.");
		}
		
		String scheduleCode = String.valueOf(queryParam.getParam("scheduleCode"));
		
		if(!hasValue(queryParam.getParam("code"))){
			throw new IllegalArgumentException("Data field code is required. Please coordinate with the"
					+ " system administrator.");
		}
		
		String code = String.valueOf(queryParam.getParam("code"));
		
		ScheduleDataFieldEntity scheduleDataFieldEntity = scheduleDataFieldEntityRepository.findBySchedule_codeAndDataField_codeAndIsDeleted(scheduleCode, code, false);
		
		if(scheduleDataFieldEntity == null) {
			throw new EntityNotFoundException("Data Field with code "+code+" and for Schedule "+scheduleCode+" is not existing or not active. "
					+ "Please coordinate with the system administrator.");
		}
		
		return scheduleDataFieldEntity;
	}
	
	
	/**
	 * @param object
	 * @return
	 */
	private boolean hasValue(Object object) {
		if(object != null && !object.toString().trim().isEmpty()) {
			return true;
		}else {
			return false;
		}
	}
	
	/**
	 * @param object
	 * @param defaultValue
	 * @return
	 */
	private int getPagination(Object object, int defaultValue) {
		if(hasValue(object)) {
			return Integer.parseInt(object.toString());
		}else {
			return defaultValue;
		}
	}
	
	/**
	 * @param predicate
	 * @param pageIndex
	 * @param pageSize
	 * @return
	 */
	private ResultModel query(ScheduleDataFieldEntity scheduleDataFieldEntity, QueryParam queryParam, int pageIndex, int pageSize) {
		boolean hasSource = scheduleDataFieldEntity.getHasSource();
		
		// No source
		if(hasSource == false) {
			return new ResultModel(new ArrayList<>(), 0L);
		}
		
		String queryString = scheduleDataFieldEntity.getSourceQuery();
		String[] paramKeys = null; 
		
		if(hasValue(scheduleDataFieldEntity.getSourceParams())){ 
			paramKeys = scheduleDataFieldEntity.getSourceParams().trim().split(","); 
		}
		
		Map<String, Object> params = new HashMap<>();
		if(paramKeys != null && paramKeys.length > 0){
			for(String key : paramKeys) {
				params.put(key, queryParam.getParam(key));
			}
		}
		
		List<Object[]> resultRaw = queryService.doQuery(queryString, params, pageIndex - 1, pageSize);
		
		List<LinkedHashMap<String, Object>> resultSet = new ArrayList<>();
		
		for(Object[] object : resultRaw) {
			LinkedHashMap<String, Object> row = new LinkedHashMap<>();
			row.put("id", object[0]);
			row.put("code", object[1]);
			row.put("description", object[2]);			
			
			resultSet.add(row);
		}		
		
		return new ResultModel(resultSet, resultSet.size());
	}	
}
