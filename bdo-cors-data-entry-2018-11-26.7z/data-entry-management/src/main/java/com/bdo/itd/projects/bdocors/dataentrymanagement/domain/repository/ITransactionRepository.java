package com.bdo.itd.projects.bdocors.dataentrymanagement.domain.repository;

public interface ITransactionRepository {

}
