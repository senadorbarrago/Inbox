package com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
@RequiredArgsConstructor
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Entity
@Table(name = "txn_data")
public class TransactionDataEntity extends BaseEntity {
	
	/**
	 * 
	 */
	@Column(name = "transactionid")
	@NonNull 
	private Long transactionid;
	
	/**
	 * 
	 */
	@Column(name = "bkcode")
	@NonNull 
	private Integer bkcode;
	
	/**
	 * 
	 */
	@Column(name = "trdate")
	@NonNull 
	private Date trdate;
	
	/**
	 * 
	 */
	@Column(name = "trcode")
	@NonNull 
	private String trcode;
	
	/**
	 * 
	 */
	@Column(name = "bookcd")
	@NonNull 
	private Integer bookcd;
	
	/**
	 * 
	 */
	@Column(name = "bsrate")	
	private BigDecimal bsrate;
	
	/**
	 * 
	 */
	@Column(name = "curcde1")
	@NonNull
	private String curcde1;
	
	/**
	 * 
	 */
	@Column(name = "amtorig1")
	@NonNull
	private BigDecimal amtorig1;
	
	/**
	 * 
	 */
	@Column(name = "curcde2")	
	private String curcde2;
	
	/**
	 * 
	 */
	@Column(name = "amtorig2")	
	private BigDecimal amtorig2;
	
	/**
	 * 
	 */
	@Column(name = "ctrycd")
	private String ctrycd;
	
	/**
	 * 
	 */
	@Column(name = "dealdt")	
	private Date dealdt;
	
	/**
	 * 
	 */
	@Column(name = "dealcd")	
	private Integer dealcd;
	
	/**
	 * 
	 */
	@Column(name = "expcde")	
	private Integer expcde;
	
	/**
	 * 
	 */
	@Column(name = "dbtcde")	
	private Integer dbtcde;
	
	/**
	 * 
	 */
	@Column(name = "remnme")
	private String remnme;
	
	/**
	 * 
	 */
	@Column(name = "invrnme")	
	private String invrnme;
	
	/**
	 * 
	 */
	@Column(name = "tin1")
	private String tin1;
	
	/**
	 * 
	 */
	@Column(name = "secrn01")	
	private String secrn01;
	
	/**
	 * 
	 */
	@Column(name = "dtirn01")
	private String dtirn01;
	
	/**
	 * 
	 */
	@Column(name = "psic1")	
	private String psic1;
	
	/**
	 * 
	 */
	@Column(name = "impcde")	
	private Integer impcde;
	
	/**
	 * 
	 */
	@Column(name = "crdcde")
	private Integer crdcde;
	
	/**
	 * 
	 */
	@Column(name = "benenme")
	private String benenme;
	
	/**
	 * 
	 */
	@Column(name = "invsnme")
	private String invsnme;
	
	/**
	 * 
	 */
	@Column(name = "tin2")
	private String tin2;
	
	/**
	 * 
	 */
	@Column(name = "secrn02")
	private String secrn02;
	
	/**
	 * 
	 */
	@Column(name = "dtirn02")	
	private String dtirn02;
	
	/**
	 * 
	 */
	@Column(name = "psic2")
	private String psic2;
	
	/**
	 * 
	 */
	@Column(name = "comcde")
	private String comcde;
	
	/**
	 * 
	 */
	@Column(name = "modpay")	
	private Integer modpay;
	
	/**
	 * 
	 */
	@Column(name = "hctrycd")
	private String hctrycd;
	
	/**
	 * 
	 */
	@Column(name = "impscd")
	private Integer impscd;
	
	/**
	 * 
	 */
	@Column(name = "lcno")
	private String lcno;
	
	/**
	 * 
	 */
	@Column(name = "brn")
	private String brn;
	
	/**
	 * 
	 */
	@Column(name = "bildte")	
	private Date bildte;
	
	/**
	 * 
	 */
	@Column(name = "omatdte")
	private Date omatdte;
	
	/**
	 * 
	 */
	@Column(name = "nmatdte")
	private Date nmatdte;
	
	/**
	 * 
	 */
	@Column(name = "remchlcde")
	private Integer remchlcde;
	
	/**
	 * 
	 */
	@Column(name = "prvcde")
	private String prvcde;
	
	/**
	 * 
	 */
	@Column(name = "owncde")	
	private Integer owncde;
	
	/**
	 * 
	 */
	@Column(name = "bsrdno")
	private String bsrdno;
	
	/**
	 * 
	 */
	@Column(name = "cirno")
	private String cirno;
	
	/**
	 * 
	 */
	@Column(name = "ttfno")
	private String ttfno;
	
	/**
	 * 
	 */
	@Column(name = "listcde")
	private Integer listcde;
	
	/**
	 * 
	 */
	@Column(name = "regtypcde")
	private Integer regtypcde;
	
	/**
	 * 
	 */
	@Column(name = "isin")
	private String isin;
	
	/**
	 * 
	 */
	@Column(name = "secnme")
	private String secnme;
	
	/**
	 * 
	 */
	@Column(name = "resdnce")
	private Integer resdnce;
	
	/**
	 * 
	 */
	@Column(name = "ctpbcd")
	private Integer ctpbcd;
	
	/**
	 * 
	 */
	@Column(name = "ctpnme")
	private String ctpnme;
	
	/**
	 * 
	 */
	@Column(name = "ctptypcde")
	private Integer ctptypcde;
	
	/**
	 * 
	 */
	@Column(name = "svldte")
	private Date svldte;
	
	/**
	 * 
	 */
	@Column(name = "sfrate")
	private BigDecimal sfrate;
	
	/**
	 * 
	 */
	@Column(name = "ffxdte")
	private Date ffxdte;
	
	/**
	 * 
	 */
	@Column(name = "fvldte")
	private Date fvldte;
	
	/**
	 * 
	 */
	@Column(name = "ffxrate")
	private BigDecimal ffxrate;
	
	/**
	 * 
	 */
	@Column(name = "bspdan")
	private String bspdan;
	
	/**
	 * 
	 */
	@Column(name = "cfccode")
	private String cfccode;
	
	/**
	 * 
	 */
	@Column(name = "psic3")
	private String psic3;
	
	/**
	 * 
	 */
	@Column(name = "sscode")
	private String sscode;
	
	/**
	 * 
	 */
	@Column(name = "refno")
	private String refno;
	
	/**
	 * 
	 */
	@Column(name = "indcode")
	private String indcode;
	
	/**
	 * 
	 */
	@Column(name = "rescode")
	private Integer rescode;
	
	/**
	 * 
	 */
	@Column(name = "brcode")
	private String brcode;
	
	/**
	 * 
	 */
	@Column(name = "rcrdtype")
	private String rcrdtype;
	
	/**
	 * 
	 */
	@Column(name = "glcode")
	private String glcode;
	
	/**
	 * 
	 */
	@Column(name = "acctno")
	private String acctno;
	
	/**
	 * 
	 */
	@Column(name = "filename")
	private String filename;
	
	/**
	 * 
	 */
	@Column(name = "filelogid")
	private Long filelogid;
	
	/**
	 * 
	 */
	@Column(name = "status")
	@NonNull 
	private String status;
	
	/**
	 * 
	 */
	@Column(name = "remarks")
	private String remarks;
	
	/**
	 * 
	 */
	@Column(name = "ln_int")
	private BigDecimal lnInt;
	
	/**
	 * 
	 */
	@Column(name = "ln_escrw1")
	private BigDecimal lnEscrw1;
	
	/**
	 * 
	 */
	@Column(name = "ln_escrw2")
	private BigDecimal lnEscrw2;
	
	/**
	 * 
	 */
	@Column(name = "ln_late")
	private BigDecimal lnLate;
	
	/**
	 * 
	 */
	@Column(name = "productcode")
	private String productCode;
	
	/**
	 * 
	 */
	@Column(name = "trcode_icbs")
	private String trcodeIcbs;
	
	/**
	 * 
	 */
	@Column(name = "cfccode1")
	private String cfccode1;
	
}
