package com.bdo.itd.util.validation;

/**
 * 
 * @author a014000098
 *
 */
public class ValidationException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	public ValidationException() {
		super();
	}

	/**
	 * 
	 * @param arg0
	 */
	public ValidationException(String arg0) {
		super(arg0);
	}

	/**
	 * 
	 * @param arg0
	 */
	public ValidationException(Throwable arg0) {
		super(arg0);
	}

	/**
	 * 
	 * @param arg0
	 * @param arg1
	 */
	public ValidationException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

}
