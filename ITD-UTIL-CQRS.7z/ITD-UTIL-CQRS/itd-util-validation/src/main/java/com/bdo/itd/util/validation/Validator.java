package com.bdo.itd.util.validation;

import java.io.File;
import java.util.Collection;
import java.util.Map;

/**
 * 
 * @author a014000098
 *
 */
public class Validator {

	/**
	 * 
	 * @param object
	 */
	public static void validateNotNull(Object object) {
		validateNotNull(object, "Object is null.");
	}
	
	/**
	 * 
	 * @param object
	 */
	public static void validateNotNull(Object object, String message) {
		if (null==object) {
			throw new ValidationException(message);
		}
	}

	/**
	 * 
	 * @param string
	 */
	public static void validateNotNullOrEmpty(String string) {
		validateNotNullOrEmpty(string, "String cannot be null or empty.");
	}
	
	/**
	 * 
	 * @param string
	 */
	public static void validateNotNullOrEmpty(String string, String message) {
		validateNotNull(string, message);
		validateNotEmpty(string, message);
	}
	
	/**
	 * 
	 * @param string
	 */
	public static void validateNotEmpty(String string) {
		validateNotEmpty(string, "String cannot be empty");
	}
	
	/**
	 * 
	 * @param string
	 */
	public static void validateNotEmpty(String string, String message) {
		validateNotNull(string);
		if (string.isEmpty()) {
			throw new ValidationException(message);
		}
	}
	
	/**
	 * 
	 * @param collection
	 */
	public static void validateNotNullOrEmpty(Collection<?> collection) {
		validateNotNullOrEmpty(collection, "Collection cannot be null or empty.");
	}
	
	/**
	 * 
	 * @param collection
	 * @param message
	 */
	public static void validateNotNullOrEmpty(Collection<?> collection, String message) {
		validateNotNull(collection, message);
		validateNotEmpty(collection, message);
	}
	
	/**
	 * 
	 * @param collection
	 */
	public static void validateNotEmpty(Collection<?> collection) {
		validateNotEmpty(collection, "Collection cannot be empty");
	}
	
	/**
	 * 
	 * @param collection
	 * @param message
	 */
	public static void validateNotEmpty(Collection<?> collection, String message) {
		validateNotNull(collection);
		if (collection.isEmpty()) {
			throw new ValidationException(message);
		}
	}
	
	
	/**
	 * 
	 * @param collection
	 */
	public static void validateNotNullOrEmpty(Map<?,?> map) {
		validateNotNullOrEmpty(map, "Map cannot be null or empty.");
	}
	
	/**
	 * 
	 * @param collection
	 * @param message
	 */
	public static void validateNotNullOrEmpty(Map<?,?> map, String message) {
		validateNotNull(map, message);
		validateNotEmpty(map, message);
	}
	
	/**
	 * 
	 * @param collection
	 */
	public static void validateNotEmpty(Map<?,?> map) {
		validateNotEmpty(map, "Map cannot be empty");
	}
	
	/**
	 * 
	 * @param map
	 * @param message
	 */
	private static void validateNotEmpty(Map<?, ?> map, String message) {
		validateNotNull(map);
		if (map.isEmpty()) {
			throw new ValidationException(message);
		}
	}

	/**
	 * 
	 * @param collection
	 */
	public static void validateString(Object object) {
		validateString(object, "Object is not a string.");
	}
	
	/**
	 * 
	 * @param collection
	 */
	public static void validateString(Object object, String message) {
		validateNotNull(object);
		if (!(object instanceof String)) {
			throw new ValidationException(message);
		}
	}
	
	/**
	 * 
	 * @param collection
	 */
	public static void validateTrue(boolean status) {
		validateTrue(status, "Status resulted to false.");
	}
	
	/**
	 * 
	 * @param collection
	 */
	public static void validateTrue(boolean status, String message) {
		if (!status) {
			throw new ValidationException(message);
		}
	}
	
	/**
	 * 
	 * @param collection
	 */
	public static void validateFalse(boolean status) {
		validateFalse(status, "Status resulted to true.");
	}
	
	/**
	 * 
	 * @param collection
	 */
	public static void validateFalse(boolean status, String message) {
		if (status) {
			throw new ValidationException(message);
		}
	}
	
	/**
	 * 
	 * @param file
	 */
	public static void validateFileExists(File file) {
		validateNotNull(file);
		validateFileExists(file, "File not exists: " + file.getAbsolutePath());
	}
	
	/**
	 * 
	 * @param collection
	 */
	public static void validateFileExists(File file, String message) {
		validateNotNull(file);
		if (!file.exists()) {
			throw new ValidationException(message);
		}
	}
	
	/**
	 * 
	 * @param file
	 */
	public static void validateFileNotExists(File file) {
		validateFileNotExists(file, "File should not exist: " + file.getAbsolutePath());
	}
	
	/**
	 * 
	 * @param file
	 * @param string
	 */
	private static void validateFileNotExists(File file, String message) {
		validateNotNull(file);
		if (file.isFile()) {
			throw new ValidationException(message);
		}
	}

	/**
	 * 
	 * @param file
	 */
	public static void validateIsFile(File file) {
		validateIsFile(file, "File is not a file: " + file.getAbsolutePath());
	}
	
	/**
	 * 
	 * @param file
	 * @param string
	 */
	private static void validateIsFile(File file, String message) {
		validateNotNull(file);
		validateFileExists(file);
		if (!file.isFile()) {
			throw new ValidationException(message);
		}
	}

	/**
	 * 
	 * @param file
	 */
	public static void validateIsDirectory(File file) {
		validateIsDirectory(file, "File is not a directory: " + file.getAbsolutePath());
	}
	
	/**
	 * 
	 * @param file
	 * @param message
	 */
	public static void validateIsDirectory(File file, String message) {
		validateNotNull(file);
		validateFileExists(file);
		if (!file.isDirectory()) {
			throw new ValidationException(message);
		}
	}
}
