package com.bdo.itd.util.persistence;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.LinkedHashMap;

import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author c140703001
 */
public final class GenericRowMapper implements RowMapper<Object> {
    
	/**
	 * 
	 */
    public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
        LinkedHashMap<String, Object> row = new LinkedHashMap<String, Object>();

        ResultSetMetaData rsmeta =  rs.getMetaData();
        int columnCount = rsmeta.getColumnCount();

        for( int x = 1 ; x <= columnCount; x++ ){
            String lbl = rsmeta.getColumnLabel(x);
            row.put((lbl == null || lbl.isEmpty())? rsmeta.getColumnName(x):lbl, rs.getObject(x));
        }
       return row;
    }

}
