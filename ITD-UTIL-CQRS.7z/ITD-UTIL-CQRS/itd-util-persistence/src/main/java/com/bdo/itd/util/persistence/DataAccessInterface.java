package com.bdo.itd.util.persistence;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.RowMapper;

/**
 * This interface supports JDBC, Hibernate, and other ORM services
 * 
 * @author SENADOR BARRAGO
 */
@SuppressWarnings("rawtypes")
public interface DataAccessInterface {
    
    /**
     * Execute database search functionality with or without direct input parameters
     * @param sql - SQL statement 
     * @return List<LinkedHashMap<String, Object>> - list of rows
     */
    public List<LinkedHashMap<String, Object>>executeSQLQuery(String sql);
    
    /**
     * Execute database search functionality with direct input parameters
     * @param sql - SQL statement with input parameter place holder(e.g. ?)
     * @param parameterList - an array of input parameters
     * @return List<LinkedHashMap<String, Object>> - list of rows
     */
    public List<LinkedHashMap<String, Object>>executeSQLQuery(
    		String sql, 
    		Object[] parameterList);
    
    /**
     * Execute database search functionality with direct input parameters
     * @param sql - SQL statement with input parameter place holder(e.g. ?)
     * @param parameterList - an array of input parameters
     * @param dataAccessObjectClass - object model of a set
     * @param labelAttribute - map of property labels
     * @return List - list of rows
     */
    public List executeSQLQuery(
    		String sql, 
    		Object[] parameterList,
    		Class dataAccessObjectClass, 
    		Map labelAttribute);
    
    /**
     * Execute stored procedure for querying
     * @param storedProcedure - Stored Procedure name
     * @param parameterValues - an array of stored procedure arguments
     * @return List - list of rows
     */
    public List<LinkedHashMap<String, Object>>executeSQLStoredProcedure(
    		String storedProcedure, 
    		Object[] parameterValues);
    
    /**
     * 
     * @param storedProcName - Stored Procedure name
     * @param parameterValues - an array of stored procedure arguments
     * @param rowMapper - provides custom row mapping mechanism
     * @return List<LinkedHashMap<String, Object>> - list of rows
     */
    public List executeSQLStoredProcedure(
    		String storedProcName, 
    		Object[] parameterValues, 
    		RowMapper rowMapper);
    
    /**
     * Execute database insert or update functionality with or without direct input parameters
     * @param sql - SQL statement
     * @return int - SQL code
     */
    public int executeSQLUpdate(String sql);
    
    /**
     * Execute database insert or update functionality with direct input parameters
     * @param sql - SQL statement
     * @param parameterList - an array of input parameters
     * @return int - SQL code
     */
    public int executeSQLUpdate(String sql, Object[] parameterList);
    

}
