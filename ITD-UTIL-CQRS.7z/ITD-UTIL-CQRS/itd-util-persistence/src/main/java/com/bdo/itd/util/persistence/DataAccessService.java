package com.bdo.itd.util.persistence;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

/**
 * This class is an implementation of DataAccessInterface that supports JDBCTemplate
 * in executing database operations. This variation of data access uses LinkedHashMap
 * that sorts result set according to the sequence of data insertion
 * 
 * @author SENADOR BARRAGO
 */
@SuppressWarnings({"unchecked", "rawtypes"})
public class DataAccessService extends JdbcDaoSupport implements DataAccessInterface {

	/**
	 * 
	 */
    public List<LinkedHashMap<String, Object>> executeSQLQuery(String sql) {
        List<LinkedHashMap<String, Object>> ret = null;
		try {
			ret = SQLResultParser.parseRowSet(getTemplate().queryForRowSet(sql));
		} catch (Exception e) {
			throw new DataAccessException(e);
		}
        return ret;
    }

    /**
     * 
     */
    public List<LinkedHashMap<String, Object>> executeSQLQuery(String sql, Object[] parameterList) {
        List<LinkedHashMap<String, Object>> ret = null;
		try {
			ret = SQLResultParser.parseRowSet(getTemplate().queryForRowSet(sql, parameterList));
		} catch (Exception e) {
			throw new DataAccessException(e);
		}
        return ret;
    }

    /**
     * 
     */
    public List executeSQLQuery(String sql, Object[] parameterList, Class dataAccessObjectClass, Map labelAttribute) {
        List result = null;
        try {
            result = SQLResultParser.parseRowSetDto(getTemplate().queryForRowSet(sql, parameterList), dataAccessObjectClass, labelAttribute);
        } catch (Exception e) {
        	throw new DataAccessException(e);
        }
        return result;
    }

    /**
     * 
     */
    public List<LinkedHashMap<String, Object>> executeSQLStoredProcedure(String storedProcedure, Object[] parameterValues){
    	List<LinkedHashMap<String, Object>> result = null;
		try {
			result = getTemplate().query(storedProcedure, parameterValues, new DASRowMapper());
		} catch (Exception e) {
			throw new DataAccessException(e);
		}
        return result;
    }
    
    /**
     * 
     */
    public List executeSQLStoredProcedure(String storedProcName, Object[] parameterValues, RowMapper rowMapper){
        List result;
		try {
			result = getTemplate().query(storedProcName, parameterValues, rowMapper);
		} catch (Exception e) {
			throw new DataAccessException(e);
		}
        return result;
    }
    
    /**
     * 
     */
    public int executeSQLUpdate(String sql) {
        try {
			return getTemplate().update(sql);
		} catch (Exception e) {
			throw new DataAccessException(e);
		}
    }

    /**
     * 
     */
    public int executeSQLUpdate(String sql, Object[] parameterList) {
        try {
			return getTemplate().update(sql, parameterList);
		} catch (Exception e) {
			throw new DataAccessException(e);
		}
    }

    /**
     * 
     * @return
     */
    private JdbcTemplate getTemplate() {
        return super.getJdbcTemplate();
    }
    
    /**
     * 
     * @author a014000098
     *
     */
    protected static final class DASRowMapper implements RowMapper {

        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
            LinkedHashMap<String, Object> row = new LinkedHashMap<String, Object>();

            ResultSetMetaData rsmeta =  rs.getMetaData();
            int columnCount = rsmeta.getColumnCount();

            for( int x = 1 ; x <= columnCount; x++ ){
                String lbl = rsmeta.getColumnLabel(x);
                row.put((lbl == null || lbl.isEmpty())? rsmeta.getColumnName(x):lbl, rs.getObject(x));
            }
           return row;
        }

    }
    
}
