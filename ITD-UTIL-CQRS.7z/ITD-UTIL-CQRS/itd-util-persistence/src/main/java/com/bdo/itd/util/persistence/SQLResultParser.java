package com.bdo.itd.util.persistence;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.PropertyUtils;
import org.springframework.beans.BeanInstantiationException;
import org.springframework.beans.BeanUtils;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.jdbc.support.rowset.SqlRowSetMetaData;

/**
 * This is a helper class to DataAccessService in parsing SQL results.
 * This class provides transparent object to data set mappings and LinkedHashMap
 * per row set mappings
 * 
 * @author SENADOR BARRAGO
 */
@SuppressWarnings({"rawtypes", "unchecked"})
public class SQLResultParser {

	/**
	 * 
	 * @param sqlRowSet
	 * @return
	 */
	public static List parseRowSet(SqlRowSet sqlRowSet) {
        ArrayList result = new ArrayList();

        SqlRowSetMetaData sqlMeta = sqlRowSet.getMetaData();
        int columnCount = sqlMeta.getColumnCount();

        while (sqlRowSet.next()) {
            LinkedHashMap<String, Object> row = new LinkedHashMap<String, Object>();
            for (int i = 1; i <= columnCount; i++) {
                String colName = sqlMeta.getColumnLabel(i);

                colName = (colName == null || colName.isEmpty())
                        ? sqlMeta.getColumnName(i) : colName;

                row.put(colName, sqlRowSet.getObject(colName));
            }
            result.add(row);
        }
        return result;
    }

	/**
	 * 
	 * @param sqlRowSet
	 * @param dataAccessObjectClass
	 * @param labelAttribMap
	 * @return
	 * @throws SQLException
	 */
    public static List parseRowSetDto(
    		SqlRowSet sqlRowSet, 
    		Class dataAccessObjectClass, 
    		Map labelAttribMap) throws SQLException {
        ArrayList result = new ArrayList();

        while (sqlRowSet.next()) {
            Object retObj = mapRow(sqlRowSet, dataAccessObjectClass, labelAttribMap);
            result.add(retObj);
        }
        return result;
    }

    /**
     * 
     * @param sqlRowSet
     * @param dataAccessObjectClass
     * @param labelAttribMap
     * @return
     * @throws SQLException
     */
    private static Object mapRow(
    		SqlRowSet sqlRowSet, 
    		Class dataAccessObjectClass, 
    		Map labelAttribMap) throws SQLException {
        String label = null;
        Object dtoObject = null;
        try {
            SqlRowSetMetaData rsmd = sqlRowSet.getMetaData();
            int columnCount = rsmd.getColumnCount();
            dtoObject = BeanUtils.instantiateClass(dataAccessObjectClass);

            for (int x = 1; x <= columnCount; x++) {
                String lbl = rsmd.getColumnLabel(x);
                lbl = (lbl == null || lbl.isEmpty()) ? rsmd.getColumnName(x) : lbl;
                label = (String) labelAttribMap.get(lbl);
                PropertyUtils.setProperty(dtoObject, label, sqlRowSet.getObject(x));
            }
        } catch (BeanInstantiationException biex) {

            ArrayList errObj = new ArrayList();
            errObj.add(dataAccessObjectClass.getName());

            /* TODO: assign error code message for DTO not found */
            throw new SQLException("[EXCEPTION] - DTO Not Found", biex);
        } catch (NoSuchMethodException nsmex) {
            ArrayList errObj = new ArrayList();
            errObj.add(label);

            /* TODO: assign error code message for DTO method not defined */
            throw new SQLException("[EXCEPTION] - DTO Method Not Defined", nsmex);
        } catch (Exception ex) {
            throw new SQLException("[EXCEPTION] - Exception Occured", ex);
        }
        return dtoObject;
    }
}
