package com.bdo.itd.util.cqrs.command;

import static org.junit.Assert.*;
import static org.junit.matchers.JUnitMatchers.hasItem;
import static org.hamcrest.CoreMatchers.*;

import java.util.Map;

import org.junit.Before;
import org.junit.Test;

/**
 * 
 * @author a014000098
 *
 */
public class CommandMessageFactoryTest {

	/**
	 * 
	 */
	private CommandMessageFactory factory;
	
	/**
	 * 
	 */
	private String message = "message";

	/**
	 * 
	 */
	private CommandMessage commandMessage;

	/**
	 * 
	 */
	private Map<String, String> messageMap;
	
	/**
	 * 
	 */
	@Before
	public void setup() {
		factory = new CommandMessageFactory();
	}
	
	@Test
	public void shouldReturnCustomMessage() {
		commandMessage = factory.createCustomMessage(message);
		messageMap = commandMessage.getMessageMap();
		assertNotNull(commandMessage);
		assertNotNull(messageMap);
		
		assertNotNull(messageMap.get("CUSTOM_MESSAGE"));		
	}
	
	@Test
	public void shouldReturnSuccessMessage() {
		commandMessage = factory.createSuccessMessage(message);
		messageMap = commandMessage.getMessageMap();
		assertNotNull(commandMessage);
		assertNotNull(messageMap);
		
		assertNotNull(messageMap.get("SUCCESS_MESSAGE"));		
	}
	
	@Test
	public void shouldReturnInfoMessage() {
		commandMessage = factory.createInfoMessage(message);
		messageMap = commandMessage.getMessageMap();
		assertNotNull(commandMessage);
		assertNotNull(messageMap);
		
		assertNotNull(messageMap.get("INFO_MESSAGE"));		
	}
	
	@Test
	public void shouldReturnWarningMessage() {
		commandMessage = factory.createWarningMessage(message);
		messageMap = commandMessage.getMessageMap();
		assertNotNull(commandMessage);
		assertNotNull(messageMap);
		
		assertNotNull(messageMap.get("WARNING_MESSAGE"));		
	}
	
	@Test
	public void shouldReturnErrorMessage() {
		commandMessage = factory.createErrorMessage(message);
		messageMap = commandMessage.getMessageMap();
		assertNotNull(commandMessage);
		assertNotNull(messageMap);
		
		assertNotNull(messageMap.get("ERROR_MESSAGE"));		
	}
	
	@Test
	public void shouldReturnSpecifiedMessageType() {
		commandMessage = factory.createMessage(CommandMessageType.CUSTOM_MESSAGE, message);
		messageMap = commandMessage.getMessageMap();
		assertNotNull(commandMessage);
		assertNotNull(messageMap);
		
		assertNotNull(messageMap.get("CUSTOM_MESSAGE"));		
	}
	
	

}
