package com.bdo.itd.util.cqrs.command;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

import com.bdo.itd.util.validation.ValidationException;

public class CommandFactoryTest {

	/**
	 * 
	 */
	private String name;
	
	/**
	 * 
	 */
	private Map<String, Object> parameters;

	/**
	 * 
	 */
	private ICommand command;

	/**
	 * 
	 */
	private Class type;

	/**
	 * 
	 */
	@Test(expected=ValidationException.class)
	public void shouldThrowExceptionWhenNameIsNull() {
		name = null;
		parameters = null;
		CommandFactory.create(name, parameters);
	}
	
	/**
	 * 
	 */
	@Test(expected=ValidationException.class)
	public void shouldThrowExceptionWhenNameIsEmpty() {
		name = "";
		parameters = null;
		CommandFactory.create(name, parameters);
	}
	
	/**
	 * 
	 */
	@Test(expected=ValidationException.class)
	public void shouldThrowExceptionWhenParametersIsNull() {
		name = "commandNmae";
		parameters = null;
		CommandFactory.create(name, parameters);
	}
	
	/**
	 * 
	 */
	@Test
	public void shouldReturnCommandInstance() {
		name = "commandNmae";
		parameters = new HashMap<String, Object>();
		command = CommandFactory.create(name, parameters);
		
		assertNotNull(command);
	}
	
	/**
	 * 
	 */
	@Test(expected=ValidationException.class)
	public void type_shouldThrowExceptionWhenNameIsNull() {
		name = null;
		parameters = null;
		type = null;
		CommandFactory.create(name, parameters, type);
	}
	
	/**
	 * 
	 */
	@Test(expected=ValidationException.class)
	public void type_shouldThrowExceptionWhenNameIsEmpty() {
		name = "";
		parameters = null;
		type = null;
		CommandFactory.create(name, parameters, type);
	}
	
	/**
	 * 
	 */
	@Test(expected=ValidationException.class)
	public void type_shouldThrowExceptionWhenParametersIsNull() {
		name = "commandNmae";
		parameters = null;
		type = null;
		CommandFactory.create(name, parameters, type);
	}
	
	/**
	 * 
	 */
	@Test(expected=ValidationException.class)
	public void type_shouldThrowExceptionWhenTypeIsNull() {
		name = "commandNmae";
		parameters = new HashMap<String, Object>();
		type = null;
		CommandFactory.create(name, parameters, type);
	}
	
//	/**
//	 * 
//	 */
//	@Test
//	public void type_shouldReturnCommandInstance() {
//		name = "commandNmae";
//		parameters = new HashMap<String, Object>();
//		type = BasicCommand.class;
//		command = CommandFactory.create(name, parameters, type);
//		
//		assertNotNull(command);
//	}

}
