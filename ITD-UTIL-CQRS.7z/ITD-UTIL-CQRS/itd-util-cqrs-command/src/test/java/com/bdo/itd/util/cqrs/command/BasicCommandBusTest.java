package com.bdo.itd.util.cqrs.command;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 
 * @author a014000098
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class BasicCommandBusTest {

	/**
	 * 
	 */
	private ICommandBus commandBus;
	
	/**
	 * 
	 */
	@Mock
	private Map<String, ICommandHandler> commandHandlerMap;

	/**
	 * 
	 */
	@Mock
	private ICommand command;

	/**
	 * 
	 */
	@Mock
	private ICommandHandler commandHandler;

	/**
	 * 
	 */
	@Mock
	private CommandMessage commandMessage;
	
	/**
	 * 
	 */
	@Before
	public void setup() {
		commandBus = new BasicCommandBus(commandHandlerMap);
	}
	
	/**
	 * 
	 */
	@Test(expected=IllegalStateException.class)
	public void shouldThrowExceptionWhenHanderIsNull() {
		commandBus = new BasicCommandBus(null);
	}
	
	/**
	 * 
	 */
	@Test(expected=IllegalStateException.class)
	public void shouldThrowExceptionWhenHanderIsEmpty() {
		commandBus = new BasicCommandBus(new HashMap<String, ICommandHandler>());
	}
	
	/**
	 * 
	 */
	@Test(expected=NoAvailableHandlerForCommandException.class)
	public void shouldThrowNoAvailableHandlerForCommandException() {
		when(command.getName()).thenReturn("commandName");
		
		commandBus.doPublish(command);
	}
	
	/**
	 * 
	 */
	@Test(expected=UnableToProcessCommandException.class)
	public void shouldThrowUnableToProcessCommandException() {
		when(command.getName()).thenReturn("commandName");
		when(commandHandlerMap.containsKey("commandName")).thenReturn(true);
		when(commandHandlerMap.get("commandName")).thenReturn(commandHandler);
		when(commandHandler.doHandle(command)).thenThrow(new UnableToProcessCommandException(null, null));
		
		commandBus.doPublish(command);
	}
	
	/**
	 * 
	 */
	@Test
	public void shouldReturnCommandMessage() {
		when(command.getName()).thenReturn("commandName");
		when(commandHandlerMap.containsKey("commandName")).thenReturn(true);
		when(commandHandlerMap.get("commandName")).thenReturn(commandHandler);
		when(commandHandler.doHandle(command)).thenReturn(commandMessage);
		
		CommandMessage msg = commandBus.doPublish(command);
		
		assertNotNull(msg);
		
		
	}
	
	
}
