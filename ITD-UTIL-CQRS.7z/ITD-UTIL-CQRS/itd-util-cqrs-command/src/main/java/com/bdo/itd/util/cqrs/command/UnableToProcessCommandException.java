package com.bdo.itd.util.cqrs.command;

/**
 * 
 * @author c140618008
 *
 */
public class UnableToProcessCommandException extends CommandException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4817446267529678484L;
	
	/**
	 * 
	 * @param message
	 * @param cause
	 */
	public UnableToProcessCommandException(String message, Throwable cause) {
		super(message, cause);
	}
}
