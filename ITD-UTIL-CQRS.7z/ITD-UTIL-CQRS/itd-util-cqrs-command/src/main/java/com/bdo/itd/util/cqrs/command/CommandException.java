package com.bdo.itd.util.cqrs.command;

/**
 * 
 * @author c140618008
 *
 */
public abstract class CommandException extends RuntimeException {
  
	/**
	 * 
	 */
	private static final long serialVersionUID = -2699701760152759398L;
	
	/**
	 * 
	 */
	private final Throwable cause;
	
	/**
	 * 
	 */
    private final String message;
    
    /**
     * 
     * @param message
     * @param cause
     */
    public CommandException(String message, Throwable cause){
        super(message, cause);
        this.cause = cause;
        this.message = message;
    }
    
    /**
     * 
     */
    @Override
    public String getMessage() {
        return this.message;
    }
    
    /**
     * 
     */
    @Override
    public Throwable getCause() {
        return this.cause;
    }
    
}
