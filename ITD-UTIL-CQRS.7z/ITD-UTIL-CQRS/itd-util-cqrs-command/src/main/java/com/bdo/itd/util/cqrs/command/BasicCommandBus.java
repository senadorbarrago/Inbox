package com.bdo.itd.util.cqrs.command;

import java.util.Map;

import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * 
 * @author c140618008
 *
 */
public class BasicCommandBus implements ICommandBus {
	
	/**
	 * 
	 */
	private final Map<String, ICommandHandler> commandHandlerMap;	
	
	/**
	 * 
	 * @param commandHandlerMap
	 */
	public BasicCommandBus(Map<String, ICommandHandler> commandHandlerMap) throws IllegalStateException {
		this.commandHandlerMap = commandHandlerMap;
		afterPropertiesSet();
	}
	
	/**
	 * 
	 */
	@Override
    @Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public CommandMessage doPublish(ICommand command) throws NoAvailableHandlerForCommandException, UnableToProcessCommandException{
        return getCommandHandler(command).doHandle(command);
	}

	/**
	 * 
	 * @param command
	 * @return
	 */
	private ICommandHandler getCommandHandler(ICommand command) {
		if(!commandHandlerMap.containsKey(command.getName())){
        	throw new NoAvailableHandlerForCommandException("No available CommandHandler for the supplied "
        			+ "Command name: " + command.getName(), null);
        }
        
		return commandHandlerMap.get(command.getName());
	}
	
	/**
	 * 
	 * @throws Exception
	 */
	private void afterPropertiesSet() throws IllegalStateException {
		if(commandHandlerMap == null || commandHandlerMap.isEmpty()){
			throw new IllegalStateException("commandHandlerMap should not be null or empty");
		}
	}
}
