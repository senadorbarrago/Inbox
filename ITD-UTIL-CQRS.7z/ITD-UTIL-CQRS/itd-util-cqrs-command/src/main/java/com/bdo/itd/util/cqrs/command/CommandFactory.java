package com.bdo.itd.util.cqrs.command;

import static com.bdo.itd.util.validation.Validator.*;

import java.util.Map;

/**
 * 
 * @author c140618008
 *
 */
public class CommandFactory {
	
	/**
	 * 
	 * @param name
	 * @param parameters
	 * @return
	 */
	public static ICommand create(String name, Map<String, Object> parameters){
		validateNotNullOrEmpty(name);
		validateNotNull(parameters);
		
		return new BasicCommand(name, parameters);
	}
	
	/**
	 * 
	 * @param name
	 * @param parameters
	 * @param t
	 * @return
	 * @throws UnableToCreateCommandInstanceException
	 */
	public static <T extends ICommand> ICommand create(
			String name, Map<String, Object> parameters, 
			Class<T> t) 
			throws UnableToCreateCommandInstanceException{
		
			validateNotNullOrEmpty(name);
			validateNotNull(parameters);
			validateNotNull(t);
		
		ICommand command;
		
		try {
			command = t.newInstance();
		} catch (InstantiationException | IllegalAccessException e) {
			throw new UnableToCreateCommandInstanceException(e.getMessage(), e);
		}
		
		command.setParameters(parameters);
		command.setName(name);
		
		return command;
	}
}
