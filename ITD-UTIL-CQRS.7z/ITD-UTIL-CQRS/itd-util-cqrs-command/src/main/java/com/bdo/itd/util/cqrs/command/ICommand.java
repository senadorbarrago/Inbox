package com.bdo.itd.util.cqrs.command;

import java.util.Map;

/**
 * 
 * @author c140618008
 *
 */
public interface ICommand {
	
	/**
	 * 
	 * @return
	 */
	public String getName();
	
	/**
	 * 
	 * @param name
	 */
	public void setName(String name);
	
	/**
	 * 
	 * @param parameters
	 */
	public void setParameters(Map<String, Object> parameters);
	
	/**
	 * 
	 * @param key
	 * @param value
	 */
	public void addParameter(String key, Object value);
	
	/**
	 * 
	 * @param key
	 * @return
	 */
	public int getIntValue(String key);
	
	/**
	 * 
	 * @param key
	 * @return
	 */
	public long getLongValue(String key);
	
	/**
	 * 
	 * @param key
	 * @return
	 */
	public float getDecimalValue(String key);
	
	/**
	 * 
	 * @param key
	 * @return
	 */
	public String getStringValue(String key);
	
	/**
	 * 
	 * @param key
	 * @return
	 */
	public boolean getBooleanValue(String key);
	
	/**
	 * 
	 * @param key
	 * @param type
	 * @return
	 */
	public <T>T getTypeValue(String key, Class<T> type);

	/**
	 * 
	 * @return
	 */
	public Map<String, Object> map();
	
}
	