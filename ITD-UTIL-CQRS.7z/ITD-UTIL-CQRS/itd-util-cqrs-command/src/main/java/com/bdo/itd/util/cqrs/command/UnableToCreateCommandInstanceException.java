package com.bdo.itd.util.cqrs.command;

/**
 * 
 * @author c140618008
 *
 */
public class UnableToCreateCommandInstanceException extends CommandException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6007959426708804104L;

	/**
	 * 	
	 * @param message
	 * @param cause
	 */
	public UnableToCreateCommandInstanceException(String message, Throwable cause) {
		super(message, cause);
	}
}
