package com.bdo.itd.util.cqrs.command;

/**
 * 
 * @author c140618008
 *
 */
public class NoAvailableHandlerForCommandException extends CommandException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7038354498095144245L;
	
	/**
	 * 
	 * @param message
	 * @param cause
	 */
	public NoAvailableHandlerForCommandException(String message, Throwable cause) {
		super(message, cause);
	}
	
}	
