package com.bdo.itd.util.cqrs.command;

/**
 * 
 * @author c140618008
 *
 */
public abstract class ACommandHandler implements ICommandHandler{
	
	/**
	 * 
	 */
	protected CommandMessageFactory commandMessageFactory;
	
	/**
	 * 
	 */
	public ACommandHandler() {
		super();
		this.commandMessageFactory = new CommandMessageFactory();
	}

}
