package com.bdo.itd.util.cqrs.command;

/**
 * 
 * @author c140618008
 *
 */
public class CommandMessageFactory {
	
	/**
	 * 
	 */
	CommandMessageFactory() {
		super();
	}

	/**
	 * 
	 * @param commandMessageType
	 * @param message
	 * @return
	 */
	public CommandMessage createMessage(
			CommandMessageType commandMessageType,	
			String message){
		return new CommandMessage(commandMessageType, message);
	}
	
	/**
	 * 
	 * @param message
	 * @return
	 */
	public CommandMessage createSuccessMessage(String message){
		return new CommandMessage(CommandMessageType.SUCCESS_MESSAGE, message);
	}
	
	/**
	 * 
	 * @param message
	 * @return
	 */
	public CommandMessage createInfoMessage(String message){
		return new CommandMessage(CommandMessageType.INFO_MESSAGE, message);
	}
	
	/**
	 * 
	 * @param message
	 * @return
	 */
	public CommandMessage createWarningMessage(String message){
		return new CommandMessage(CommandMessageType.WARNING_MESSAGE, message);
	}
	
	/**
	 * 
	 * @param message
	 * @return
	 */
	public CommandMessage createErrorMessage(String message){
		return new CommandMessage(CommandMessageType.ERROR_MESSAGE, message);
	}
	
	/**
	 * 
	 * @param message
	 * @return
	 */
	public CommandMessage createCustomMessage(String message){
		return new CommandMessage(CommandMessageType.CUSTOM_MESSAGE, message);
	}
	
}
