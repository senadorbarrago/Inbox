package com.bdo.itd.util.cqrs.command;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * 
 * @author c140618008
 *
 */
public class BasicCommand implements ICommand {
	
	/**
	 * 
	 */
	private String name; 
	
	/**
	 * 
	 */
	private Map<String, Object> parameters;
	
	/**
	 * 
	 * @param name
	 * @param parameters
	 */
	protected BasicCommand(String name, Map<String, Object> parameters) {
		super();
		this.name = name;
		this.parameters = parameters;
	}
	
	/**
	 * 
	 */
	@Override
	public String getName() {
		return this.name;
	}
	
	/**
	 * 
	 */
	@Override
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * 
	 */
	@Override
	public void setParameters(Map<String, Object> parameters) {
		this.parameters = parameters;
	}

	/**
	 * 
	 */
	@Override
	public void addParameter(String key, Object value) {
		if(this.parameters == null){
			this.parameters = new HashMap<String, Object>();
		}
		this.parameters.put(key, value);
	}
	
	/**
	 * 
	 */
	@Override
	public int getIntValue(String key) {
		return (Integer)this.parameters.get(key);
	}
	
	/**
	 * 
	 */
	@Override
	public long getLongValue(String key) {
		return (Long)this.parameters.get(key);
	}
	
	/**
	 * 
	 */
	@Override
	public float getDecimalValue(String key) {
		return (Float)this.parameters.get(key);
	}
	
	/**
	 * 
	 */
	@Override
	public String getStringValue(String key) {
		return (String)this.parameters.get(key);
	}
	
	/**
	 * 
	 */
	@Override
	public boolean getBooleanValue(String key) {
		return (Boolean)this.parameters.get(key);
	}
	
	/**
	 * 
	 */
	@SuppressWarnings("unchecked")
	@Override
	public <T> T getTypeValue(String key, Class<T> type) {
		return (T)this.parameters.get(key);
	}

	/**
	 * 
	 */
	@Override
	public Map<String, Object> map() {
		return Collections.unmodifiableMap(parameters);
	}
}
