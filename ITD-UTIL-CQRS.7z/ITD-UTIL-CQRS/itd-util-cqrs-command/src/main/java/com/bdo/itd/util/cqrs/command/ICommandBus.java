package com.bdo.itd.util.cqrs.command;

/**
 * 
 * @author c140618008
 *
 */
public interface ICommandBus {
	
	/**
	 * 
	 * @param command
	 * @return
	 * @throws NoAvailableHandlerForCommandException
	 * @throws UnableToProcessCommandException
	 */
	public CommandMessage doPublish(ICommand command) 
			throws NoAvailableHandlerForCommandException, UnableToProcessCommandException; 
	
}
