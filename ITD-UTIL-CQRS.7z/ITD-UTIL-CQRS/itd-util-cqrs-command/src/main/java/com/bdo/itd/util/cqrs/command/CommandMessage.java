package com.bdo.itd.util.cqrs.command;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * 
 * @author c140618008
 *
 */
public class CommandMessage { 
    
	/**
	 * 
	 */
    private Map<String, String> messageMap;
    
    /**
     * 
     * @param messageType
     * @param message
     */
	CommandMessage(CommandMessageType messageType, String message){
        if(messageMap == null){
        	messageMap = new HashMap<String, String>();
        }
		messageMap.put(messageType.name(), message);
    }
    
	/**
	 * 
	 * @param key
	 * @return
	 */
	public String getMessage(CommandMessageType messageType){
		return this.messageMap.get(messageType);
	}
	
	/**
	 * 
	 * @return
	 */
    public Map<String, String> getMessageMap() {
        return Collections.unmodifiableMap(messageMap);
    }

}
