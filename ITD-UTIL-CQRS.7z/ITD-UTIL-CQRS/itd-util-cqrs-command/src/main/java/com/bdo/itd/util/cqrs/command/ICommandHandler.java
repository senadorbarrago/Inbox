package com.bdo.itd.util.cqrs.command;

/**
 * 
 * @author c140618008
 *
 */
public interface ICommandHandler {
	
	/**
	 * 
	 * @param command
	 * @return
	 * @throws UnableToProcessCommandException
	 */
	public CommandMessage doHandle(ICommand command) throws UnableToProcessCommandException;
	
}
