package com.bdo.itd.util.cqrs.command;

/**
 * 
 * @author c140618008
 *
 */
public enum CommandMessageType {
	
	/**
	 * 
	 */
	SUCCESS_MESSAGE,
	
	/**
	 * 
	 */
	INFO_MESSAGE,
	
	/**
	 * 
	 */
	WARNING_MESSAGE,
	
	/**
	 * 
	 */
	ERROR_MESSAGE,
	
	/**
	 * 
	 */
	CUSTOM_MESSAGE
	
}
