/**
 * 
 */
/**
 * @author a014000098
 *
 */
package com.bdo.itd.util.cqrs.command;