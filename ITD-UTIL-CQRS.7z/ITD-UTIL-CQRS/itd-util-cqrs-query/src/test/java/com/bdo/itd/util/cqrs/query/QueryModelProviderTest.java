package com.bdo.itd.util.cqrs.query;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.bdo.itd.util.validation.ValidationException;

/**
 * 
 * @author a014000098
 *
 */
public class QueryModelProviderTest {

	
	/**
	 * 
	 */
	private IQueryModelProvider queryModelProvider;
	
	/**
	 * 
	 */
	private Map<String, IQuery> queryModelMap;
	
	/**
	 * 
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {
		setupQueryModelMap();		
		queryModelProvider = new QueryModelProvider(queryModelMap);
	}

	/**
	 * 
	 */
	private void setupQueryModelMap() {
		queryModelMap = new HashMap<String, IQuery>();
		queryModelMap.put("Query1", Mockito.mock(IQuery.class));
	}

	/**
	 * 
	 */
	@Test(expected=ValidationException.class)
	public void shouldThrowExceptionWhenQueryModelMapIsNull() {
		queryModelProvider = new QueryModelProvider(null);
	}
	
	/**
	 * 
	 */
	@Test(expected=ValidationException.class)
	public void shouldThrowExceptionWhenQueryModelMapIsEmpty() {
		queryModelProvider = new QueryModelProvider(new HashMap<String, IQuery>());
	}
	
	/**
	 * 
	 */
	@Test(expected=QueryModelNotFoundException.class)
	public void shouldThrowException() {
		queryModelProvider.getQuerymodel("notExist");
	}

	/**
	 * 
	 */
	@Test
	public void test() {
		assertNotNull(queryModelProvider.getQuerymodel("Query1"));
	}
}
