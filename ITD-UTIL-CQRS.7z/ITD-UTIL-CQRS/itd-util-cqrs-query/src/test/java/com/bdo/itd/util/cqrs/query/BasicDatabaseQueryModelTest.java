package com.bdo.itd.util.cqrs.query;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.bdo.itd.util.persistence.DataAccessException;
import com.bdo.itd.util.persistence.DataAccessInterface;
import com.bdo.itd.util.validation.ValidationException;

/**
 * 
 * @author a014000098
 *
 */
public class BasicDatabaseQueryModelTest {

	/**
	 * 
	 */
	private DataAccessInterface dataAccessService;
	
	/**
	 * 
	 */
	private BasicDatabaseQueryModel queryModel;
	
	/**
	 * 
	 */
	private String query;

	/**
	 * 
	 */
	private List<String> paramKeys;

	/**
	 * 
	 */
	private QueryParam queryParam;

	/**
	 * 
	 */
	private ResultModel resultModel;
	
	
	/**
	 * 
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {
		dataAccessService = Mockito.mock(DataAccessInterface.class);
		paramKeys = new ArrayList<String>();
		paramKeys.add("param1");
		paramKeys.add("param2");
		query = "asdgasdgasd ?, ?";
		queryModel = new BasicDatabaseQueryModel(
				dataAccessService, 
				query, 
				paramKeys);
	}
	
	/**
	 * 
	 */
	@Test(expected=ValidationException.class)
	public void shouldThrowExceptionWhenDataAccessServiceIsNull() {
		new BasicDatabaseQueryModel(null, query, paramKeys);
	}
	
	/**
	 * 
	 */
	@Test(expected=ValidationException.class)
	public void shouldThrowExceptionWhenQueryIsNull() {
		new BasicDatabaseQueryModel(dataAccessService, null, paramKeys);
	}
	
	/**
	 * 
	 */
	@Test(expected=ValidationException.class)
	public void shouldThrowExceptionWhenQueryIsEmpty() {
		new BasicDatabaseQueryModel(dataAccessService, "", paramKeys);
	}


	/**
	 * 
	 */
	@Test(expected=ValidationException.class)
	public void shouldThrowExceptionWhenParamKeysIsNull() {
		new BasicDatabaseQueryModel(dataAccessService, query, null);
	}

	/**
	 * 
	 */
	@Test(expected=ValidationException.class)
	public void doQueryShouldThrowExceptionWhenQueryParamIsNull() {
		queryModel.doQuery(null);
	}
	
	/**
	 * 
	 */
	@Test(expected=QueryException.class)
	public void doQueryShouldThrowDataAccessException() {
		queryParam = new QueryParam();
		queryParam.addParam("param1", "param1");
		queryParam.addParam("param2", "param2");
		
		Mockito
			.when(dataAccessService.executeSQLQuery(Mockito.anyString(), Mockito.any()))
			.thenThrow(new DataAccessException());
		
		queryModel.doQuery(queryParam);
	}
	
	
	/**
	 * 
	 */
	@Test
	public void doQueryShouldReturnEmptyResultModelInstance() {
		queryParam = new QueryParam();
		queryParam.addParam("param1", "param1");
		queryParam.addParam("param2", "param2");
		
		List<LinkedHashMap<String, Object>> resultSet = new ArrayList<LinkedHashMap<String, Object>>(); 
				
		Mockito
			.when(dataAccessService.executeSQLQuery(Mockito.anyString(), Mockito.any()))
			.thenReturn(resultSet);
		
		resultModel = queryModel.doQuery(queryParam);
		
		assertEquals(0L, resultModel.getResultOverAllCount().longValue());
	}
	
	
	/**
	 * 
	 */
	@Test
	public void doQueryShouldReturnNonEmptyResultModelInstance() {
		Map<String, Object> param = new HashMap<>();
		param.put("param1", "param1");
		param.put("param2", "param2");
		
		queryParam = new QueryParam(param);
		
		
		LinkedHashMap<String, Object> resultItem1 = new LinkedHashMap<String, Object>();
		resultItem1.put("firstname", "jojo");
		resultItem1.put("lastname", "pagador");
		
		LinkedHashMap<String, Object> resultItem2 = new LinkedHashMap<String, Object>();
		resultItem2.put("firstname", "joyson");
		resultItem2.put("lastname", "barrago");
		
		List<LinkedHashMap<String, Object>> resultSet = new ArrayList<LinkedHashMap<String, Object>>();
		
		resultSet.add(resultItem1);
		resultSet.add(resultItem2);
				
		Mockito
			.when(dataAccessService.executeSQLQuery(Mockito.anyString(), Mockito.any()))
			.thenReturn(resultSet);
		
		resultModel = queryModel.doQuery(queryParam);
		Set<String> columns = resultModel.getColumns();
		List<LinkedHashMap<String, Object>> returnedResultSet = resultModel.getResultSet();
		
		assertEquals(2L, resultModel.getResultOverAllCount().longValue());		
		assertEquals(2, columns.size());
		assertEquals(2, returnedResultSet.size());
	}
	
}
