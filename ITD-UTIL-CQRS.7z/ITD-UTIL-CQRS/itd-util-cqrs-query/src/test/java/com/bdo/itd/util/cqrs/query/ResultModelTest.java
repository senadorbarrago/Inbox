package com.bdo.itd.util.cqrs.query;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.junit.Test;

import com.bdo.itd.util.validation.ValidationException;

/**
 * 
 * @author a014000098
 *
 */
public class ResultModelTest {

	/**
	 * 
	 */
	private ResultModel resultModel;
	
	/**
	 * 
	 */
	private List<LinkedHashMap<String, Object>> resultSet;

	/**
	 * 
	 */
	private long resultOverAllCount;
	
	/**
	 * 
	 */
	@Test(expected=ValidationException.class)
	public void shouldThrowExceptionWhenResultOverAllCountIsNegative() {
		resultSet = null;
		resultOverAllCount = -1;
		
		resultModel = new ResultModel(resultSet, resultOverAllCount);		
	}
	
	/**
	 * 
	 */
	@Test
	public void shouldReturnEmptyResultModelWhenResultSetIsNull() {
		resultSet = null;
		resultOverAllCount = 0;
		
		resultModel = new ResultModel(resultSet, resultOverAllCount);
		
		assertTrue(resultModel.getColumns().isEmpty());
		assertTrue(resultModel.getResultSet().isEmpty());
		assertEquals(0L, resultModel.getResultOverAllCount().longValue());
	}

	/**
	 * 
	 */
	@Test
	public void shouldReturnEmptyResultModelWhenResultSetIsEmpty() {
		resultSet = new ArrayList<LinkedHashMap<String, Object>>();
		resultOverAllCount = 0;
		
		resultModel = new ResultModel(resultSet, resultOverAllCount);
		
		assertTrue(resultModel.getColumns().isEmpty());
		assertTrue(resultModel.getResultSet().isEmpty());
		assertEquals(0L, resultModel.getResultOverAllCount().longValue());
	}
	
	/**
	 * 
	 */
	@Test
	public void shouldReturnNonEmptyResultModelWhenResultSetIsNotEmpty() {
		LinkedHashMap<String, Object> item = new LinkedHashMap<String, Object>();
		item.put("firstname", "jojo");
		item.put("lastname", "pagador");
		
		resultSet = new ArrayList<LinkedHashMap<String, Object>>();
		resultSet.add(item);
		
		resultOverAllCount = 1;
		
		resultModel = new ResultModel(resultSet, resultOverAllCount);
		
		assertEquals(1, resultModel.getResultSet().size());
		assertEquals(2, resultModel.getColumns().size());
		assertEquals(1, resultModel.getResultOverAllCount().longValue());
	}
	
}
