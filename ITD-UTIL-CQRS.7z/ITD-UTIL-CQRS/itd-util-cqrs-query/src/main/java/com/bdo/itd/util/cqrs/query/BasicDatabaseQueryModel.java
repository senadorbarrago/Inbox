package com.bdo.itd.util.cqrs.query;

import static com.bdo.itd.util.validation.Validator.*;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;

import com.bdo.itd.util.persistence.DataAccessInterface;


/**
 * 
 * @author c140618008
 *
 */
public class BasicDatabaseQueryModel extends AQueryModel {
	
	/**
	 * 
	 */
	private final DataAccessInterface dataAccessService;
	
	/**
	 * 
	 */
	private final String query;
	
	/**
	 * 
	 * @param dataAccessService
	 * @param query
	 * @param paramKeys
	 */
	public BasicDatabaseQueryModel(
			DataAccessInterface dataAccessService, 
			String query,
			List<String> paramKeys) {
		
		super(paramKeys);
		
		validateNotNull(dataAccessService);
		validateNotNullOrEmpty(query);
		
		this.query = query;
		this.dataAccessService = dataAccessService;
	}
	
	/**
	 * 
	 */
	@Override
	public ResultModel doQuery(QueryParam queryParam) throws QueryException {
		validateNotNull(queryParam);
		
		try {
			return createResultModel(
					dataAccessService.executeSQLQuery(
							query, createParameterList(queryParam)));	
		} catch(Exception ex) {
			throw new QueryException(ex);
		}
	}

	/**
	 * 
	 * @param queryParam
	 * @return
	 */
	private Object[] createParameterList(QueryParam queryParam) {
		List<Object> paramList = new LinkedList<>();			
		for (String key : paramKeys) {
			System.out.println(String.format("key: %s, value: %s", key, queryParam.getParam(key)));
			paramList.add(queryParam.getParam(key));
		}		
		return paramList.toArray();
	}

	/**
	 * 
	 * @param result
	 * @return
	 */
	private ResultModel createResultModel(List<LinkedHashMap<String, Object>> result) {
		if (result.size() > 0){
			return new ResultModel(result, result.size());
		}		
		return new ResultModel(new ArrayList<LinkedHashMap<String, Object>>(), 0L);
	}
	
}
