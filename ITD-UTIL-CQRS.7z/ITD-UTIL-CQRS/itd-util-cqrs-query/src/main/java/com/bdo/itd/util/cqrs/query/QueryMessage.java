package com.bdo.itd.util.cqrs.query;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * This class serves as a wrapper class for both message detail and message key
 * used by the registered controllers
 * 
 * @author SENADORBARRAGO
 */
public class QueryMessage { 
    
	/**
	 * 
	 */
	private static final String ERROR_MSG = "errorMsg";

	/**
	 * 
	 */
	private static final String WARNING_MSG = "warningMsg";

	/**
	 * 
	 */
	private static final String INFO_MSG = "infoMsg";

	/**
	 * 
	 */
	private static final String SUCCESS_MSG = "successMsg";
	
	/**
	 * 
	 */
    private final Map<String, String> messageMap = new HashMap<>();
    
    /**
     * 
     */
    public QueryMessage() {}

    /**
     * 
     * @param key
     * @param message
     */
	public QueryMessage(String key, String message){
        messageMap.put(key, message);
    }
    
	/**
	 * 
	 * @param message
	 */
    public void doStoreSuccessMessage(String message){
        messageMap.put(SUCCESS_MSG, message);
    }
    
    /**
     * 
     * @param message
     */
    public void doStoreInfoMessage(String message){
        messageMap.put(INFO_MSG, message);
    }
    
    /**
     * 
     * @param message
     */
    public void doStoreWarningMessage(String message){
        messageMap.put(WARNING_MSG, message);
    }
    
    /**
     * 
     * @param message
     */
    public void doStoreErrorMessage(String message){
        messageMap.put(ERROR_MSG, message);
    }
    
    /**
     * 
     * @param key
     * @param message
     */
    public void doStoreCustomMessage(String key, String message){
        messageMap.put(key, message);
    }
    
    /**
     * 
     * @return
     */
    public String getSuccessMessage(){
    	return messageMap.get(SUCCESS_MSG);
    }
    
    /**
     * 
     * @return
     */
    public String getInfoMessage(){
    	return messageMap.get(INFO_MSG);
    }
    
    /**
     * 
     * @return
     */
    public String getWarningMessage(){
    	return messageMap.get(WARNING_MSG);
    }
    
    /**
     * 
     * @return
     */
    public String getErrorMessage(){
    	return messageMap.get(ERROR_MSG);
    }
    
    /**
     * 
     * @param key
     * @return
     */
    public String getCustomMessage(String key){
    	return messageMap.get(key);
    }
    
    /**
     * 
     * @return
     */
    public Map<String, String> getMessageMap() {
        return Collections.unmodifiableMap(messageMap);
    }

}
