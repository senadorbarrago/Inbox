package com.bdo.itd.util.cqrs.query;

/**
 * 
 * @author c140618008
 *
 */
public interface IQuery {
	
	/**
	 * 
	 * @param queryParam
	 * @return
	 * @throws QueryException
	 */
	public ResultModel doQuery(QueryParam queryParam) throws QueryException;
	
}
