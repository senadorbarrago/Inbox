package com.bdo.itd.util.cqrs.query;

import java.util.Map;

import static com.bdo.itd.util.validation.Validator.*;

/**
 * 
 * @author c140618008
 *
 */
public class QueryModelProvider implements IQueryModelProvider {
	
	/**
	 * 
	 */
	private final Map<String, IQuery> queryModelMap;
	
	/**
	 * 
	 * @param queryModelMap
	 */
	public QueryModelProvider(Map<String, IQuery> queryModelMap) {
		super();
		validateNotNullOrEmpty(queryModelMap);
		this.queryModelMap = queryModelMap;
	}
	
	/**
	 * 
	 */
	@Override
	public IQuery getQuerymodel(String queryModelCode) throws QueryModelNotFoundException {
		throwExceptionIfQueryModelNotFound(queryModelCode);
		
		return queryModelMap.get(queryModelCode);
	}

	/**
	 * 
	 * @param queryModelCode
	 */
	private void throwExceptionIfQueryModelNotFound(String queryModelCode) {
		if (!queryModelMap.containsKey(queryModelCode)) {
			throw new QueryModelNotFoundException(
					String.format("Query model code not found [%s]", queryModelCode));
		}
	}

}
