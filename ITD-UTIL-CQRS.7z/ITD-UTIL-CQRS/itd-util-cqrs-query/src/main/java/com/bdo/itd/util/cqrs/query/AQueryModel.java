package com.bdo.itd.util.cqrs.query;

import java.util.List;

import com.bdo.itd.util.validation.Validator;

/**
 * 
 * @author c140618008
 *
 */
public abstract class AQueryModel implements IQuery {
	
	/**
	 * 
	 */
	protected final List<String> paramKeys;
	
	/**
	 * 
	 * @param paramKeys
	 */
	public AQueryModel(List<String> paramKeys) {
		super();
		Validator.validateNotNull(paramKeys);
		this.paramKeys = paramKeys;
	}

}
