package com.bdo.itd.util.cqrs.query;

import java.util.HashMap;
import java.util.Map;

/**
 * 
 * @author c140618008
 *
 */
public class QueryParam {
	
	/**
	 * 
	 */
	private final Map<String, Object> map = new HashMap<>();
    
	/**
	 * 
	 */
	public QueryParam(){};
	
	/**
	 * 
	 * @param map
	 */
	public QueryParam(Map<String, Object> map) {
		super();
		this.map.putAll(map);
	}

	/**
	 * 
	 * @param key
	 * @param value
	 */
    public void addParam(String key, Object value){
        map.put(key, value);
    }
    
    /**
     * 
     * @param key
     * @return
     */
    public Object getParam(String key){
        return map.get(key);
    }
	
}
