package com.bdo.itd.util.cqrs.query;

import static com.bdo.itd.util.validation.Validator.validateTrue;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * 
 * @author c140618008
 *
 */
public class ResultModel {
	
	/**
	 * 
	 */
	private List<LinkedHashMap<String, Object>>resultSet = new ArrayList<>();
    
	/**
	 * 
	 */
	private Set<String> columns = new LinkedHashSet<>();
    
	/**
	 * 
	 */
	private Long resultOverAllCount = 0L;
    
    /**
     * 
     * @param resultSet
     * @param resultOverAllCount
     */
	public ResultModel(List<LinkedHashMap<String, Object>>resultSet, long resultOverAllCount){
		validateTrue(0<=resultOverAllCount);
        if(resultSet != null && !resultSet.isEmpty()){
            this.resultSet = resultSet;
            this.resultOverAllCount = resultOverAllCount;
            columns = resultSet.get(0).keySet();
        }
    }

	/**
	 * 
	 * @return
	 */
    public List<LinkedHashMap<String, Object>> getResultSet() {
        return new ArrayList<>(resultSet);
    }
    
    /**
     * 
     * @return
     */
    public Long getResultOverAllCount() {
        return resultOverAllCount;
    }

    /**
     * 
     * @return
     */
    public Set<String> getColumns() {
        return new LinkedHashSet<String>(columns);
    }
	
}
