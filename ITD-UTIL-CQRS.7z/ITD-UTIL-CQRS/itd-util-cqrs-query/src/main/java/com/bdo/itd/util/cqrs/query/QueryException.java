package com.bdo.itd.util.cqrs.query;

/**
 * 
 * @author c140618008
 *
 */
public class QueryException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 
	 */
	private Throwable cause;
    
	/**
	 * 
	 */
	private String message;
    
	/**
	 * 
	 */
	private final QueryMessage queryMessage = new QueryMessage();
    
    /**
     * 
     */
	public QueryException() {
        super();
    }
    
	/**
	 * 
	 * @param message
	 */
    public QueryException(String message) {
        super(message);
        this.message = (message == null)? "" : message;
        this.queryMessage.doStoreErrorMessage(this.message);
    }
    
    /**
     * 
     * @param cause
     */
    public QueryException(Throwable cause) {
        super(cause);
        this.cause = cause;
        this.message = (cause.getMessage() == null)? "" : cause.getMessage();
        this.queryMessage.doStoreErrorMessage(this.message);
    }   
    
    /**
     * 
     * @param message
     * @param cause
     */
    public QueryException(String message, Throwable cause){
        super(message, cause);
        this.cause = cause;
        this.message = (message == null)? "" : message;
        this.queryMessage.doStoreErrorMessage(this.message);
    }

    /**
     * 
     * @return
     */
    public QueryMessage getQueryMessage() {
        return queryMessage;
    }
    
    /**
     * 
     */
    @Override
    public String getMessage() {
        return this.message;
    }

    /**
     * 
     */
    @Override
    public Throwable getCause() {
        return this.cause;
    }
}
