package com.bdo.itd.util.cqrs.query;

/**
 * 
 * @author c140618008
 *
 */
public interface IQueryModelProvider {
	
	/**
	 * 
	 * @param queryModelCode
	 * @return
	 * @throws QueryModelNotFoundException
	 */
	public IQuery getQuerymodel(String queryModelCode) throws QueryModelNotFoundException; 
	
}
