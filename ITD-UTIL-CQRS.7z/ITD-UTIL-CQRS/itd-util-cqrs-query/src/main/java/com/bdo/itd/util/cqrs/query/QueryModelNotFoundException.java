package com.bdo.itd.util.cqrs.query;

/**
 * 
 * @author c140618008
 *
 */
public class QueryModelNotFoundException extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2092521580968561049L;

	/**
	 * 
	 * @param message
	 */
    public QueryModelNotFoundException(String message) {
        super(message);
    }
    
    /**
     * 
     * @param cause
     */
    public QueryModelNotFoundException(Throwable cause) {
        super(cause);
    }   
    
    /**
     * 
     * @param message
     * @param cause
     */
    public QueryModelNotFoundException(String message, Throwable cause){
        super(message, cause);
    }
    
}
