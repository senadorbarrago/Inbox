package com.bdo.itd.projects.bdocors.dataentrymanagement.application.query;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models.DataFieldEntity;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models.DataTypeEntity;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models.QScheduleDataFieldEntity;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models.ScheduleDataFieldEntity;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.repository.IScheduleDataFieldEntityRepository;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.services.IQueryService;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.utilities.DateConverterUtility;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.utilities.DecimalConverterUtility;
import com.bdo.itd.util.cqrs.query.APageableQueryModel;
import com.bdo.itd.util.cqrs.query.IQuery;
import com.bdo.itd.util.cqrs.query.QueryException;
import com.bdo.itd.util.cqrs.query.QueryParam;
import com.bdo.itd.util.cqrs.query.ResultModel;
import com.querydsl.core.BooleanBuilder;
import com.querydsl.core.types.Predicate;

/**
 * @author c140618008
 *
 */
@Service
public class TransactionDataQueryModel extends APageableQueryModel implements IQuery {
	
	/**
	 * 
	 */
	private static final Logger logger = LoggerFactory.getLogger(TransactionDataQueryModel.class);
	
	/**
	 * 
	 */
	private final int defaultPageIndex = 1;
	
	/**
	 * 
	 */
	private final int defaultPageSize = 50;
	
	/**
	 * 
	 */
	private final IScheduleDataFieldEntityRepository scheduleDataFieldEntityRepository;
	
	/**
	 * 
	 */
	private final IQueryService queryService;
	
	/**
	 * 
	 */
	@Value("${data-format.date.default}")
	private String dateFormat;
	
	/**
	 * 
	 */
	@Value("${data-format.datetime.default}")
	private String dateTimeFormat;
	
	/**
	 * 
	 */
	@Value("${data-format.amount.default}")
	private String amountFormat;
	
	/**
	 * 
	 */
	@Value("${data-format.float.default}")
	private String floatFormat;
	
	/**
	 * @param serviceCommunicator
	 */
	@Autowired
	public TransactionDataQueryModel(IScheduleDataFieldEntityRepository scheduleDataFieldEntityRepository,
			@Qualifier("transactionNativeQueryService")IQueryService queryService) {
		super();
		this.scheduleDataFieldEntityRepository = scheduleDataFieldEntityRepository;
		this.queryService = queryService;
	}

	@Override
	public ResultModel doQuery(QueryParam queryParam) throws QueryException {
		try {
			Predicate predicate = this.buildPredicate(queryParam);
			
			int pageIndex = this.getPagination(queryParam.getParam("pageIndex"), defaultPageIndex);
			int pageSize = this.getPagination(queryParam.getParam("pageSize"), defaultPageSize);
			
			return query(queryParam, predicate, pageIndex, pageSize);
			
		}catch(ParseException ex) {
			throw new QueryException(ex);
		}
	}
	
	/**
	 * @param object
	 * @return
	 */
	private boolean hasValue(Object object) {
		if(object != null && !object.toString().isEmpty()) {
			return true;
		}else {
			return false;
		}
	}
	
	/**
	 * @param object
	 * @param defaultValue
	 * @return
	 */
	private int getPagination(Object object, int defaultValue) {
		if(hasValue(object)) {
			return Integer.parseInt(object.toString());
		}else {
			return defaultValue;
		}
	}
	
	/**
	 * @param queryParam
	 * @return
	 */
	private Predicate buildPredicate(QueryParam queryParam) throws ParseException{
		BooleanBuilder builder = new BooleanBuilder();
		QScheduleDataFieldEntity qscheduleDataFieldEntity = new QScheduleDataFieldEntity("scheduleDataFieldEntity");
		
		if(!hasValue(queryParam.getParam("scheduleCode"))) {
			throw new QueryException("Schedule should not be null. Please select a schedule and "
					+ "retry again.");
		}
		
		String scheduleCode = String.valueOf(queryParam.getParam("scheduleCode"));
		
		builder.and(qscheduleDataFieldEntity.schedule.code.eq(scheduleCode));
		builder.and(qscheduleDataFieldEntity.isDeleted.eq(false));
		
		return builder.getValue();
	}
	
	/**
	 * @param predicate
	 * @param pageIndex
	 * @param pageSize
	 * @return
	 */
	private ResultModel query(QueryParam queryParam, Predicate predicate, int pageIndex, int pageSize) {
		Iterable<ScheduleDataFieldEntity> scheduleDataFieldEntityList = scheduleDataFieldEntityRepository.findAll(predicate, gotoPage(pageIndex, pageSize, Sort.Direction.DESC, 
				"dateCreated"));
		
		StringBuilder queryBuilder = new StringBuilder("select ");
		
		// DefaultFields
		queryBuilder.append("brcode as brcode, ");
		queryBuilder.append("sscode as sscode, ");
		queryBuilder.append("date_created as datecreated, ");
		queryBuilder.append("created_by as createdby, ");
		queryBuilder.append("last_modified_by as modifiedby, ");
		queryBuilder.append("date_last_modified as datemodified, ");
		queryBuilder.append("status as status, ");
		queryBuilder.append("remarks as remarks ");
		
		// DynamicScheduleFields
		for(ScheduleDataFieldEntity entity : scheduleDataFieldEntityList) {
			DataFieldEntity dataFieldEntity = entity.getDataField();
			queryBuilder.append(", ");
			queryBuilder.append(dataFieldEntity.getCode().toLowerCase());
			queryBuilder.append(" as ");
			queryBuilder.append(dataFieldEntity.getCode());
			
		}	
		
		queryBuilder.append(" from txn_data ");
		queryBuilder.append("where id = :id ");
		queryBuilder.append("and is_deleted = false");
		
		logger.info(queryBuilder.toString());
		
		Map<String, Object> parameterMap = new HashMap<>();
		parameterMap.put("id", queryParam.getParam("id"));

		List<Object[]> resultArray = queryService.doQuery(queryBuilder.toString(), parameterMap, pageIndex - 1, pageSize);
		
		List<LinkedHashMap<String, Object>> resultSet = this.buildResultSet(resultArray, scheduleDataFieldEntityList);
		
		return new ResultModel(resultSet, resultSet.size());
	}
	
	/**
	 * @param result
	 * @param scheduleDataFieldEntityList
	 * @return
	 */
	private List<LinkedHashMap<String, Object>> buildResultSet(List<Object[]> result, Iterable<ScheduleDataFieldEntity> scheduleDataFieldEntityList){
		List<LinkedHashMap<String, Object>> resultSet = new ArrayList<>();
		
		for(Object[] objectList : result) {
			int count = 8;
			LinkedHashMap<String, Object> row = new LinkedHashMap<>();
			
			// DefaultFields
			row.put("brcode", objectList[0]);
			row.put("sscode", objectList[1]);
			row.put("datecreated", objectList[2]);
			row.put("createdby", objectList[3]);
			row.put("lastmodifiedby", objectList[4]);
			row.put("datelastmodified", objectList[5]);
			row.put("status", objectList[6]);
			row.put("remarks", objectList[7]);
			
			// DynamicScheduleFields
			for(ScheduleDataFieldEntity entity : scheduleDataFieldEntityList) {
				DataFieldEntity dataFieldEntity = entity.getDataField();
				DataTypeEntity dataTypeEntity = dataFieldEntity.getDataType();
				
				row.put(dataFieldEntity.getCode(), this.formatData(objectList[count],
						dataTypeEntity.getCode(), dataFieldEntity.getScale()));
				count++;
			}
			
			resultSet.add(row);
		}
		
		return resultSet;
	}
	
	/**
	 * @param data
	 * @param dataType
	 * @return
	 */
	private Object formatData(Object data, String dataType, Integer scale) {
		Object formattedData = data != null ? String.valueOf(data): null;
		
		logger.info("data: "+data);
		logger.info("dataType: "+dataType);
		logger.info("scale: "+scale);
		
		if(data != null) {
			switch (dataType) {
				case "NUMERIC":
					logger.info("NUMERIC");
					String convertedFormat = scale != null && scale > 2 ? floatFormat : amountFormat;
					
					logger.info("convertedFormat: "+convertedFormat);
					
					BigDecimal amountData = new BigDecimal(String.valueOf(data));
					formattedData = DecimalConverterUtility.toString(amountData, convertedFormat);
					
					break;
				case "DATE":
					logger.info("DATE");
					Calendar dateCalendar = Calendar.getInstance();
					dateCalendar.setTime((Date)data);
					
					formattedData = DateConverterUtility.toString(dateCalendar.getTime(), dateFormat);
					logger.info("convertedFormat: "+formattedData);
					
					break;
				case "DATETIME":
					logger.info("DATETIME");
					Long dateTimeInMilliSeconds = Long.parseLong(String.valueOf(data));
					Date dateTime = Calendar.getInstance().getTime();
					
					dateTime.setTime(dateTimeInMilliSeconds);
					
					formattedData = DateConverterUtility.toString(dateTime, dateTimeFormat);
					logger.info("convertedFormat: "+formattedData);
					
					break;
				default:
					return String.valueOf(data);
			}
		}
		
		logger.info("formattedData: "+formattedData);
		
		return formattedData;
	}	
}
