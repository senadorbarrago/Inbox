package com.bdo.itd.projects.bdocors.dataentrymanagement.domain.models;

/**
 * @author c140618008
 *
 */
public enum DataType {
	
	/**
	 * 
	 */
	BOOLEAN,
	
	/**
	 * 
	 */
	INT,
	
	/**
	 * 
	 */
	BIGINT,
	
	/**
	 * 
	 */
	NUMERIC,
	
	/**
	 * 
	 */
	TEXT,
	
	/**
	 * 
	 */
	TIMESTAMP,
	
	/**
	 * 
	 */
	DATE
	
}
