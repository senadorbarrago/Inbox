package com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.repository;

import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.querydsl.binding.QuerydslBinderCustomizer;
import org.springframework.data.querydsl.binding.QuerydslBindings;
import org.springframework.data.querydsl.binding.SingleValueBinding;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models.QScheduleEntity;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models.ScheduleEntity;
import com.querydsl.core.types.dsl.StringExpression;
import com.querydsl.core.types.dsl.StringPath;

/**
 * @author c140618008
 *
 */
@Repository
public interface IScheduleEntityRepository extends PagingAndSortingRepository<ScheduleEntity, Long>, 
	QuerydslPredicateExecutor<ScheduleEntity>, QuerydslBinderCustomizer<QScheduleEntity> {
	
	/**
	 * 
	 */
	default public void customize(QuerydslBindings bindings, QScheduleEntity root) {
		bindings.bind(String.class).first((SingleValueBinding<StringPath, String>) StringExpression::containsIgnoreCase);
		bindings.excluding(root.id);
	}
	
}
