package com.bdo.itd.projects.bdocors.dataentrymanagement.domain.models;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import lombok.Value;

/**
 * @author c140618008
 *
 */
@Value
public class TransactionData {
	
	/**
	 * 
	 */
	private Long id;
	
	/**
	 * 
	 */
	private Map<String, Object> dataMap = new HashMap<>();
	
	/**
	 * @return
	 */
	public Map<String, Object> map(){
		return Collections.unmodifiableMap(dataMap);
	}
	
	/**
	 * @param key
	 * @return
	 */
	public Object getData(String key) {
		return dataMap.get(key);
	}
}
