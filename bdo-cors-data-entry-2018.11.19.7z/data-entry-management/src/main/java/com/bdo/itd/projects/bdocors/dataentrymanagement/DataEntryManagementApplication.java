package com.bdo.itd.projects.bdocors.dataentrymanagement;

import org.springframework.boot.SpringApplication;

//@SpringBootApplication
public class DataEntryManagementApplication {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SpringApplication.run(DataEntryManagementApplication.class, args);
	}
}
