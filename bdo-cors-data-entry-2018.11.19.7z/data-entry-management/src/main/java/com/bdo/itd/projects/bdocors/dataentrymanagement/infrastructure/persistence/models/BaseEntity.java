package com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.Version;

import lombok.Data;

/**
 * @author c140618008
 *
 */
@Data
@MappedSuperclass
public abstract class BaseEntity {
	
	/**
	 * 
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", updatable = false, nullable = false)
	protected Long id;
	
	/**
	 * 
	 */
	@Version
	@Column(name = "version", columnDefinition = "integer DEFAULT 0", nullable = false)
	protected int version;
	
	/**
	 * 
	 */
	@Column(name = "date_created", nullable = false)
	protected Date dateCreated;
	
	/**
	 * 
	 */
	@Column(name = "created_by", nullable = false)
	protected String createdBy;
	
	/**
	 * 
	 */
	@Column(name = "date_last_modified")
	protected Date dateLastModified;
	
	/**
	 * 
	 */
	@Column(name = "last_modified_by")
	protected String lastModifiedBy;
	
	/**
	 * 
	 */
	@Column(name = "is_deleted", columnDefinition = "boolean DEFAULT false", nullable = false)
	protected boolean isDeleted;
	
	/**
	 * 
	 */
	@Column(name = "is_system_protected", columnDefinition = "boolean DEFAULT false", nullable = false)
	protected boolean isSystemProtected;
	
}
