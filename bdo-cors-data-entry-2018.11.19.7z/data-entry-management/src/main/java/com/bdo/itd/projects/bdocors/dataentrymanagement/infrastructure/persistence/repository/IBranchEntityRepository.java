package com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.repository;

import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.querydsl.binding.QuerydslBinderCustomizer;
import org.springframework.data.querydsl.binding.QuerydslBindings;
import org.springframework.data.querydsl.binding.SingleValueBinding;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models.BranchEntity;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models.QBranchEntity;
import com.querydsl.core.types.dsl.StringExpression;
import com.querydsl.core.types.dsl.StringPath;

/**
 * @author c140618008
 *
 */
@Repository
public interface IBranchEntityRepository extends PagingAndSortingRepository<BranchEntity, Long>, 
	QuerydslPredicateExecutor<BranchEntity>, QuerydslBinderCustomizer<QBranchEntity> {
	
	/**
	 * 
	 */
	default public void customize(QuerydslBindings bindings, QBranchEntity root) {
		bindings.bind(String.class).first((SingleValueBinding<StringPath, String>) StringExpression::containsIgnoreCase);
		bindings.excluding(root.id);
	}
	
}
