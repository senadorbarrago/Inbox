package com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.utilities;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.ParseException;



/**
 * @author c140618008
 *
 */
public class DecimalConverterUtility {
	
	/**
	 * @param input
	 * @return
	 */
	public static BigDecimal toBigDecimal(String input){
		return input != null && !input.isEmpty() ? new BigDecimal(input) : BigDecimal.ZERO;
	}
	
	/**
	 * @param input
	 * @param format
	 * @return
	 */
	public static String toString(BigDecimal input, String format) {
		DecimalFormat formatter = new DecimalFormat(format);
		
		return input != null ? formatter.format(input) : "";
	}
}
