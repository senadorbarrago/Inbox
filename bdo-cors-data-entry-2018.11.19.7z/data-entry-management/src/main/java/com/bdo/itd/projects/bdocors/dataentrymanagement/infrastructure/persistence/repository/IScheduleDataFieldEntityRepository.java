package com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.repository;

import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.querydsl.binding.QuerydslBinderCustomizer;
import org.springframework.data.querydsl.binding.QuerydslBindings;
import org.springframework.data.querydsl.binding.SingleValueBinding;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models.QScheduleDataFieldEntity;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models.ScheduleDataFieldEntity;
import com.querydsl.core.types.dsl.StringExpression;
import com.querydsl.core.types.dsl.StringPath;

/**
 * @author c140618008
 *
 */
@Repository
public interface IScheduleDataFieldEntityRepository extends PagingAndSortingRepository<ScheduleDataFieldEntity, Long>, 
	QuerydslPredicateExecutor<ScheduleDataFieldEntity>, QuerydslBinderCustomizer<QScheduleDataFieldEntity> {
	
	/**
	 * @param scheduleCode
	 * @param dataFieldCode
	 * @param isDeleted
	 * @return
	 */
	ScheduleDataFieldEntity findBySchedule_codeAndDataField_codeAndIsDeleted(String scheduleCode, String dataFieldCode, boolean isDeleted);
	
	/**
	 * 
	 */
	default public void customize(QuerydslBindings bindings, QScheduleDataFieldEntity root) {
		bindings.bind(String.class).first((SingleValueBinding<StringPath, String>) StringExpression::containsIgnoreCase);
		bindings.excluding(root.id);
	}
	
}
