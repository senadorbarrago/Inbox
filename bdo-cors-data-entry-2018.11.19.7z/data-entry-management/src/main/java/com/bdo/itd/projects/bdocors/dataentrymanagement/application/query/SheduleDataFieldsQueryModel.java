package com.bdo.itd.projects.bdocors.dataentrymanagement.application.query;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models.DataFieldEntity;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models.QScheduleDataFieldEntity;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models.ScheduleDataFieldEntity;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models.SourceSystemDataFieldEntity;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models.TransactionDataEntity;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models.TransactionMissingDataEntity;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.repository.IScheduleDataFieldEntityRepository;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.repository.ISourceSystemDataFieldEntityRepository;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.repository.ITransactionDataEntityRepository;
import com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.repository.ITransactionDataMissingEntityRepository;
import com.bdo.itd.util.cqrs.query.APageableQueryModel;
import com.bdo.itd.util.cqrs.query.IQuery;
import com.bdo.itd.util.cqrs.query.QueryParam;
import com.bdo.itd.util.cqrs.query.ResultModel;
import com.querydsl.core.BooleanBuilder;
import com.querydsl.core.QueryException;
import com.querydsl.core.types.Predicate;

/**
 * @author c140618008
 *
 */
@Service
public class SheduleDataFieldsQueryModel extends APageableQueryModel implements IQuery {
	
	/**
	 * 
	 */
	private static final Logger logger = LoggerFactory.getLogger(SheduleDataFieldsQueryModel.class);
	
	/**
	 * 
	 */
	private final int defaultPageIndex = 1;
	
	/**
	 * 
	 */
	private final int defaultPageSize = 50;
	
	/**
	 * 
	 */
	private final IScheduleDataFieldEntityRepository scheduleDataFieldEntityRepository;
	
	/**
	 * 
	 */
	private final ITransactionDataEntityRepository transactionDataEntityRepository; 
	
	/**
	 * 
	 */
	private final ITransactionDataMissingEntityRepository transactioDatanMissingEntityRepository;
	
	/**
	 * 
	 */
	private final ISourceSystemDataFieldEntityRepository sourceSystemDataFieldEntityRepository;
	
	
	/**
	 * @param scheduleDataFieldEntityRepository
	 * @param transactionDataEntityRepository
	 * @param transactioDatanMissingEntityRepository
	 * @param sourceSystemDataFieldEntityRepository
	 */
	@Autowired
	public SheduleDataFieldsQueryModel(IScheduleDataFieldEntityRepository scheduleDataFieldEntityRepository,
			ITransactionDataEntityRepository transactionDataEntityRepository,
				ITransactionDataMissingEntityRepository transactioDatanMissingEntityRepository,
				ISourceSystemDataFieldEntityRepository sourceSystemDataFieldEntityRepository) {
		super();
		this.scheduleDataFieldEntityRepository = scheduleDataFieldEntityRepository;
		this.transactionDataEntityRepository = transactionDataEntityRepository;
		this.transactioDatanMissingEntityRepository = transactioDatanMissingEntityRepository;
		this.sourceSystemDataFieldEntityRepository = sourceSystemDataFieldEntityRepository;
	}

	@Override
	public ResultModel doQuery(QueryParam queryParam) throws QueryException {
		try {
			Predicate predicate = this.buildPredicate(queryParam);
			
			int pageIndex = this.getPagination(queryParam.getParam("pageIndex"), defaultPageIndex);
			int pageSize = this.getPagination(queryParam.getParam("pageSize"), defaultPageSize);
			
			return query(queryParam, predicate, pageIndex, pageSize);
			
		}catch(ParseException ex) {
			throw new QueryException(ex);
		}
	}
	
	/**
	 * @param queryParam
	 * @return
	 */
	private Predicate buildPredicate(QueryParam queryParam) throws ParseException{
		BooleanBuilder builder = new BooleanBuilder();
		QScheduleDataFieldEntity qscheduleDataFieldEntity = new QScheduleDataFieldEntity("scheduleDataFieldEntity");
		
		if(!hasValue(queryParam.getParam("scheduleCode"))) {
			throw new QueryException("Schedule should not be null. Please select a schedule and "
					+ "retry again.");
		}
		
		String scheduleCode = String.valueOf(queryParam.getParam("scheduleCode"));
		
		builder.and(qscheduleDataFieldEntity.schedule.code.eq(scheduleCode));
		builder.and(qscheduleDataFieldEntity.isDeleted.eq(false));
		
		return builder.getValue();
	}
	
	/**
	 * @param object
	 * @return
	 */
	private boolean hasValue(Object object) {
		if(object != null && !object.toString().isEmpty()) {
			return true;
		}else {
			return false;
		}
	}
	
	/**
	 * @param object
	 * @param defaultValue
	 * @return
	 */
	private int getPagination(Object object, int defaultValue) {
		if(hasValue(object)) {
			return Integer.parseInt(object.toString());
		}else {
			return defaultValue;
		}
	}
	
	/**
	 * @param predicate
	 * @param pageIndex
	 * @param pageSize
	 * @return
	 */
	private ResultModel query(QueryParam queryParam, Predicate predicate, int pageIndex, int pageSize) {
		Iterable<ScheduleDataFieldEntity> scheduleDataFieldEntityList = scheduleDataFieldEntityRepository.findAll(predicate, gotoPage(pageIndex, pageSize, Sort.Direction.ASC, 
				"dataField.id"));
		
		Set<String> enabledDataFieldSet = this.getListOfEnabledFields(queryParam, scheduleDataFieldEntityList);
		
		long overAllCount = scheduleDataFieldEntityRepository.count(predicate);
		
		List<LinkedHashMap<String, Object>> resultSet = new ArrayList<>();
		
		for(ScheduleDataFieldEntity entity : scheduleDataFieldEntityList) {
			LinkedHashMap<String, Object> row = new LinkedHashMap<>();
			DataFieldEntity dataFieldEntity = entity.getDataField();
			
			row.put("code", dataFieldEntity.getCode());
			row.put("description", dataFieldEntity.getDescription());
			row.put("dataType", dataFieldEntity.getDataType().getCode());
			row.put("length", dataFieldEntity.getLength());
			row.put("precision", dataFieldEntity.getPrecision());
			row.put("scale", dataFieldEntity.getScale());
			row.put("format", dataFieldEntity.getFormat());
			row.put("hasSource", entity.getHasSource());
			row.put("isRequired", entity.isRequired());
			row.put("enabled", enabledDataFieldSet.contains(dataFieldEntity.getCode()) ?
					true : false);
			
			resultSet.add(row);
		}		
		return new ResultModel(resultSet, overAllCount);
	}
	
	/**
	 * @param queryParam
	 * @return
	 */
	private TransactionDataEntity getTransactionDataEntity(QueryParam queryParam) {
		if(hasValue(queryParam.getParam("transactionID"))) {
			long transactionID = Long.parseLong(String.valueOf(queryParam.getParam("transactionID")));
			TransactionDataEntity transactionDataEntity = transactionDataEntityRepository.findByTransactionid(transactionID);
			if(transactionDataEntity == null) {
				throw new QueryException("The supplied transaction id "+transactionID+" does not exists "
						+ "or is currently inactive. Please supply active transaction id only and "
						+ "retry again.");
			}
			return transactionDataEntity;
		}
		
		return null;
	}
	
	/**
	 * @param transactionID
	 * @return
	 */
	private List<TransactionMissingDataEntity> getTransactionMissingDataEntityList(Long transactionID) {
		List<TransactionMissingDataEntity> transactionMissingDataEntityList = 
				transactioDatanMissingEntityRepository.findByTransactionid(transactionID);
		
		return transactionMissingDataEntityList;
	}
	
	/**
	 * @param sourceSystemCode
	 * @return
	 */
	private List<SourceSystemDataFieldEntity> getSourceSystemDataFieldEntityList(String sourceSystemCode) {
		List<SourceSystemDataFieldEntity> sourceSystemDataFieldEntityList = 
				sourceSystemDataFieldEntityRepository.findBySourceSystem_codeAndIsDeleted(sourceSystemCode, false);
		
		return sourceSystemDataFieldEntityList;
	}
	
	/**
	 * @param queryParam
	 * @param scheduledDataFieldEntityList
	 * @return
	 */
	private Set<String> getListOfEnabledFields(QueryParam queryParam, 
			Iterable<ScheduleDataFieldEntity> scheduledDataFieldEntityList){
		
		TransactionDataEntity transactionDataEntity = this.getTransactionDataEntity(queryParam);
		
		if(transactionDataEntity != null) {
			return this.getListOfEnabledFieldsWithTransactionData(transactionDataEntity, scheduledDataFieldEntityList);
		}else {
			return this.getListOfDefaultEnabedFields(scheduledDataFieldEntityList);
		}
	}
	
	/**
	 * @param transactionDataEntity
	 * @param scheduledDataFieldEntityList
	 * @return
	 */
	private Set<String> getListOfEnabledFieldsWithTransactionData(TransactionDataEntity transactionDataEntity, 
			Iterable<ScheduleDataFieldEntity> scheduledDataFieldEntityList){
		String status = transactionDataEntity.getStatus();
		
		Set<String> enabledDataFieldSet = new HashSet<>(); 
		
		switch (status) {
			case "INVALID-Missing Required Fields":
				List<TransactionMissingDataEntity> missingDataFieldList =  this.getTransactionMissingDataEntityList(transactionDataEntity.getTransactionid());
				for(TransactionMissingDataEntity entity : missingDataFieldList) {
					enabledDataFieldSet.add(entity.getDataField().getCode());
				}
				
				List<SourceSystemDataFieldEntity> sourceSystemFieldList = this.getSourceSystemDataFieldEntityList(transactionDataEntity.getSscode());
				for(SourceSystemDataFieldEntity entity : sourceSystemFieldList) {
					enabledDataFieldSet.add(entity.getDataField().getCode());
				}
				
				break;
			case "FOR APPROVAL-Missing Required Fields":
				List<TransactionMissingDataEntity> missingDataFieldList2 =  this.getTransactionMissingDataEntityList(transactionDataEntity.getTransactionid());
				for(TransactionMissingDataEntity entity : missingDataFieldList2) {
					enabledDataFieldSet.add(entity.getDataField().getCode());
				}
				
				List<SourceSystemDataFieldEntity> sourceSystemFieldList2 = this.getSourceSystemDataFieldEntityList(transactionDataEntity.getSscode());
				for(SourceSystemDataFieldEntity entity : sourceSystemFieldList2) {
					enabledDataFieldSet.add(entity.getDataField().getCode());
				}
				
				break;
			case "FOR UPDATE":
				for(ScheduleDataFieldEntity entity : scheduledDataFieldEntityList) {
					enabledDataFieldSet.add(entity.getDataField().getCode());
				}
				
				break;
			default:
				break;
		}
		
		return enabledDataFieldSet;
	}
	
	/**
	 * @param scheduledDataFieldEntityList
	 * @return
	 */
	private Set<String> getListOfDefaultEnabedFields(Iterable<ScheduleDataFieldEntity> scheduledDataFieldEntityList){
		Set<String> enabledDataFieldSet = new HashSet<>(); 
		
		for(ScheduleDataFieldEntity entity : scheduledDataFieldEntityList) {
			enabledDataFieldSet.add(entity.getDataField().getCode());
		}

		return enabledDataFieldSet;
	}
}
