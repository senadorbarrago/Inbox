package com.bdo.itd.projects.bdocors.dataentrymanagement.infrastructure.persistence.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
@RequiredArgsConstructor
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Entity
@Table(name = "ref_map_schedule_data_field")
public class ScheduleDataFieldEntity extends BaseEntity {
	
	/**
	 * 
	 */
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "fk_schedule")
	@NonNull
	private ScheduleEntity schedule;
	
	/**
	 * 
	 */
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "fk_data_field")
	@NonNull
	private DataFieldEntity dataField;
	
	/**
	 * 
	 */
	@Column(name = "is_required", nullable = false)
	private boolean isRequired = true;
	
	/**
	 * 
	 */
	@Column(name = "has_source")
	private Boolean hasSource = false;
	
	/**
	 * 
	 */
	@Column(name = "source_params")
	private String sourceParams;
	
	/**
	 * 
	 */
	@Column(name = "source_query")
	private String sourceQuery;
	
}
