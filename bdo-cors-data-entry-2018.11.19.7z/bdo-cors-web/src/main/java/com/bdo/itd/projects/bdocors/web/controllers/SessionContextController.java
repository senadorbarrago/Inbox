package com.bdo.itd.projects.bdocors.web.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


/**
 * @author c140618008
 *
 */
@RestController
public class SessionContextController {		

	/**
	 * 
	 */
	private static final Logger logger = LoggerFactory.getLogger(SessionContextController.class);
	
	/**
	 * @param request
	 * @return
	 */
	@RequestMapping(value="/sessioncontext", method=RequestMethod.GET)
	public Object getSessionContext(HttpServletRequest request){
		HttpSession session = request.getSession();
		String sessionContext = String.valueOf(session.getAttribute("context"));
		logger.info("SessionContext: "+sessionContext);
		
		return "{\"sessionContext\": \""+sessionContext+"\" }";
	}
	
}
