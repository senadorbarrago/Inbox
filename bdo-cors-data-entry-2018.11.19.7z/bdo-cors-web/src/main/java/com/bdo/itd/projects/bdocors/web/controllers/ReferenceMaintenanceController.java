/**
 * 
 */
package com.bdo.itd.projects.bdocors.web.controllers;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.projects.bdocors.usermanagement.application.UserSession;
import com.bdo.itd.util.cqrs.query.IQuery;
import com.bdo.itd.util.cqrs.query.QueryParam;
import com.bdo.itd.util.cqrs.query.ResultModel;
import com.bdo.itd.util.logger.LoggerUtility;
import com.bdo.itd.util.logger.LoggerUtilityFactory;

/**
 * @author c150819004
 *
 */
@RestController
public class ReferenceMaintenanceController {

	/**
	 * 
	 */
	private static final LoggerUtility logger = 
			LoggerUtilityFactory.createLoggerUtility(ReferenceMaintenanceController.class);
	
	@Autowired
	@Qualifier("referenceServiceTransitionQueryModel")
	private IQuery referenceServiceTransitionQueryModel;
	

	@SuppressWarnings("unchecked")
	@RequestMapping("/rmf")
	public Map<String, Object> doGet(
			HttpServletRequest request,
			HttpServletResponse response) throws Exception{
		
		logger.info("RMF");
		
		Map<String, Object> authenticationData = new LinkedHashMap<String, Object>();
		
		authenticationData.put("username", UserSession.getUsername());
		authenticationData.put("membershipId", UserSession.getActiveMembership().getId());
		authenticationData.put("sessionId", request.getSession().getId());
		
		QueryParam queryParam = new QueryParam();
		queryParam.addParam("username", UserSession.getUsername());
		queryParam.addParam("membershipId", UserSession.getActiveMembership().getId());
		queryParam.addParam("sessionId", request.getSession().getId());
		queryParam.addParam("context", request.getSession().getAttribute("context"));
		
		ResultModel resultModel = referenceServiceTransitionQueryModel.doQuery(queryParam);
		
		Map<String, Object> resultMap = (LinkedHashMap<String, Object>) resultModel.getResultSet().get(0).get("connection");
		
		return resultMap;
	}
	
}
