package com.bdo.itd.projects.bdocors.web.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.projects.bdocors.auditmanagement.application.command.AuditParamKey;
import com.bdo.itd.projects.bdocors.usermanagement.application.UserSession;


/**
 * @author c140618008
 *
 */
@RestController
public class AuthenticatedUserController {		

	/**
	 * 
	 */
	private static final Logger logger = LoggerFactory.getLogger(AuthenticatedUserController.class);
	
	/**
	 * @param request
	 * @return
	 */
	@RequestMapping(value="/authenticatedUser", method=RequestMethod.GET)
	public Object getAutheticatedUser(HttpServletRequest request){
		HttpSession session = request.getSession();
		session.setAttribute(AuditParamKey.USERNAME, UserSession.getUsername());
		session.setAttribute(AuditParamKey.FULLNAME, UserSession.getFullname());
		session.setAttribute(AuditParamKey.MEMBERSHIP, UserSession.getActiveMembership().getCode());
		
		return UserSession.getUserProfile();
	}
	
	/**
	 * @param request
	 * @param response
	 */
	@RequestMapping(value="/sessionTimeOut", method=RequestMethod.GET)
	public void getSessionTimeOut(HttpServletRequest request, HttpServletResponse response){
		logger.info("getSessionTimeOut(HttpServletRequest request, HttpServletResponse response)");
		response.setStatus(HttpStatus.FORBIDDEN.value());
	}
}
