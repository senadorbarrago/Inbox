package com.bdo.itd.projects.bdocors.web.security.customhandlers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.logout.LogoutHandler;

import com.bdo.itd.util.logger.LoggerUtility;
import com.bdo.itd.util.logger.LoggerUtilityFactory;

/**
 * 
 * @author a014000098
 *
 */
public class CustomLogoutHandler implements LogoutHandler {

	/**
	 * 
	 */
	private static final LoggerUtility LOGGER = 
			LoggerUtilityFactory.createLoggerUtility(CustomLogoutHandler.class);
	
	/**
	 * 
	 */
	@Override
	public void logout(
			HttpServletRequest request, 
			HttpServletResponse response,
			Authentication authentication) {

		LOGGER.info("Logging out user [" + authentication.getPrincipal().toString() + "]");
		
	}


}
