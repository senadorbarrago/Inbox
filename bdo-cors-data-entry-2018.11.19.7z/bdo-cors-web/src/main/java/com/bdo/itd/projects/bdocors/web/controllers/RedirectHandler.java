/**
 * 
 */
package com.bdo.itd.projects.bdocors.web.controllers;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.util.crypt.Hmac;
import com.bdo.itd.util.map.ResultMap;
import com.bdo.itd.util.map.ResultMapBuilder;

/**
 * @author c150819004
 *
 */

@RestController
@RequestMapping("/rmf")
public class RedirectHandler {
	
	/**
	 * 
	 */
	@Autowired
	private Hmac referenceHmac;
	
	@Inject
	public RedirectHandler(
			@Named("referenceHmac")Hmac referenceHmac) {
		super();
		this.referenceHmac = referenceHmac;
	}

	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	@RequestMapping(
			value="/authenticate",
			method=RequestMethod.OPTIONS,
			produces="application/json")
	public ResponseEntity handle() throws Exception {
		return new ResponseEntity(HttpStatus.NO_CONTENT);
	}
	
	@RequestMapping(
			value="/authenticate",
			method=RequestMethod.GET,			
			produces="application/json")
	public Object authenticate(
			@RequestParam("RMF_USERNAME") String username,
			@RequestParam("RMF_CLIENT_SESSIONID") String sessionId,
			@RequestParam("RMF_TRANSITION_URL") String transitionUrl,
			@RequestParam("RMF_REDIRECT_URL") String redirectUrl,
			@RequestParam("RMF_RND") String random,
			@RequestParam("RMF_HASH") String hash,
			HttpServletRequest request, 
			HttpServletResponse response
			) throws Exception{
		
		//TODO: validate username and sessionId
		
		String queryString = request.getQueryString();
		
		System.out.println(queryString);
		
		queryString = queryString.substring(0, queryString.indexOf("&RMF_HASH="));
		System.out.println(queryString);
		System.out.println("hash=" + hash);
		System.out.println(referenceHmac.hash(queryString));
		
		ResultMap result = null;
		
		if (hash.equals(referenceHmac.hash(queryString))) {
			System.out.println("hash validated");
			
			String url = "RMF_REDIRECT_URL=" + redirectUrl.replaceAll("#", "%23") + "&RMF_RND=" + random;
			String rhash = "&RMF_HASH=" + referenceHmac.hash(url);
			transitionUrl = transitionUrl + "?" + url + rhash;
			
			result = ResultMapBuilder.instance()
					.add("success", true)
					.add("transitionUrl", transitionUrl)
					.build();	
			response.setStatus(HttpStatus.OK.value());
		} else {
			result = ResultMapBuilder.instance()
					.add("success", false)
					.build();
			response.setStatus(HttpStatus.FORBIDDEN.value());
		}
		
		return result.map();
	}
	
	@RequestMapping(
			value="/transition",
			method=RequestMethod.GET,
			produces="application/json")
	public void transition(
			@RequestParam("RMF_REDIRECT_URL") String redirectUrl,
			@RequestParam("RMF_RND") String random,
			@RequestParam("RMF_HASH") String hash,
			HttpServletRequest request, 
			HttpServletResponse response) throws Exception{
		
		//TODO: validate username and sessionId
		
		String queryString = request.getQueryString();
		
		System.out.println("transition");
		System.out.println(queryString);
		
		hash = hash.replaceAll(" ", "+");
		
		queryString = queryString.substring(0, queryString.indexOf("&RMF_HASH="));
		System.out.println(queryString);
		System.out.println("hash=" + hash);
		System.out.println(referenceHmac.hash(queryString));
		
		if (hash.equals(referenceHmac.hash(queryString))) {
			response.sendRedirect(redirectUrl);
			response.setStatus(HttpStatus.OK.value());
		} else {
			response.sendRedirect("/");
			response.setStatus(HttpStatus.FORBIDDEN.value());
		}
	}
}
