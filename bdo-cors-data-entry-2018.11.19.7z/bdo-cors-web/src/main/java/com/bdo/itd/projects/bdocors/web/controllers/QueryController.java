package com.bdo.itd.projects.bdocors.web.controllers;

import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.projects.bdocors.usermanagement.application.UserSession;
import com.bdo.itd.util.cqrs.query.IQueryModelProvider;
import com.bdo.itd.util.cqrs.query.QueryParam;
import com.bdo.itd.util.cqrs.query.ResultModel;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping(value = "/query")
public class QueryController extends AbstractController {
	
	/**
	 * 
	 */
	private static final Logger logger = LoggerFactory.getLogger(QueryController.class);
	
	/**
	 * 
	 */
	private final IQueryModelProvider queryModelProvider;

	/**
	 * @param queryModelProvider
	 */
	@Inject
	public QueryController(IQueryModelProvider queryModelProvider) {
		super();
		this.queryModelProvider = queryModelProvider;
	}
	
	/**
	 * @param commandCode
	 * @param data
	 * @param request
	 * @return
	 * @throws JsonProcessingException 
	 */
	@RequestMapping(value = "/{queryCode}", method = RequestMethod.POST)
	public Object doQuery(@PathVariable(name = "queryCode") String queryCode, 
			@RequestBody Map<String, Object> data, HttpServletRequest request) throws JsonProcessingException{
		logger.info("doQuery()");
		
		if(SecurityContextHolder.getContext().getAuthentication() != null &&
				 SecurityContextHolder.getContext().getAuthentication().isAuthenticated() && 
				 //when Anonymous Authentication is enabled
				 !(SecurityContextHolder.getContext().getAuthentication() 
				          instanceof AnonymousAuthenticationToken) ){
			HttpSession session = request.getSession();
			
			data.put("institution", session.getAttribute("institution"));
			data.put("context", session.getAttribute("context"));
			data.put("datasetcode", "ITRS");
			data.put("authenticatedUser", UserSession.getUsername());
			data.put("membershipCode", UserSession.getActiveMembership().getCode());
		}
		
		ResultModel resultModel = queryModelProvider.getQuerymodel(queryCode)
				.doQuery(new QueryParam(data));
		
		ObjectMapper mapper = new ObjectMapper();
		
		String jsonObject = mapper.writeValueAsString(resultModel);
		logger.info(jsonObject);
		
		return jsonObject;
	}
	
}
	