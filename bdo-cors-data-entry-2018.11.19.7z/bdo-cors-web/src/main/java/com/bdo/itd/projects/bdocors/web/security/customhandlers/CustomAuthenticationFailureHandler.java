package com.bdo.itd.projects.bdocors.web.security.customhandlers;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.stereotype.Service;

import com.bdo.itd.projects.bdocors.auditmanagement.application.command.AuditParamKey;
import com.bdo.itd.projects.bdocors.auditmanagement.infrastructure.utilities.HTTPServletUtils;
import com.bdo.itd.util.cqrs.command.BasicCommand;
import com.bdo.itd.util.cqrs.command.CommandFactory;
import com.bdo.itd.util.cqrs.command.ICommandBus;

/**
 * @author c140618008
 *
 */
@Service
public class CustomAuthenticationFailureHandler implements AuthenticationFailureHandler {
	
	/**
	 * 
	 */
	private static final Logger logger = LoggerFactory.getLogger(CustomAuthenticationFailureHandler.class);
	
	/**
	 * 
	 */
	@Autowired
	private ICommandBus commandBus;
	
	/**
	 * 
	 */
	private static final HTTPServletUtils ipUtil = new HTTPServletUtils();
	
	/**
	 * 
	 */
	@Value("${application.name}")
	private String applicationName;
	
	/**
	 * 
	 */
	@Value("${institution.name}")
	private String institution;
	
	/**
	 * 
	 */
	private String defaultFailureUrl = "/";
		
	/**
	 * 
	 */
	private String action = "Login";
	
	/**
	 * 
	 */
	private String status = "FAILED";
	
	/**
	 * 
	 */
	private int responseStatusCode = 401;
	
	/**
	 * 
	 */
	@Override
	public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response, AuthenticationException authEx)
			throws IOException, ServletException {
		logger.info("onAuthenticationFailure()");
		StringBuilder errorMessage = new StringBuilder(authEx.getMessage());
		
		BasicCommand command = this.initializeAuditData(request, response, authEx);
		saveAuditData(command);
		
		response.setHeader("ERROR_MESSAGE", errorMessage.toString());
		response.setHeader("defaultFailureUrl", defaultFailureUrl);
		response.setStatus(responseStatusCode);
	}
	
	/**
	 * 
	 * @return
	 */
	private BasicCommand initializeAuditData(HttpServletRequest request, 
			HttpServletResponse response, AuthenticationException aex) {
		Map<String, Object> paramMap = new HashMap<>();
		
		BasicCommand command = (BasicCommand)CommandFactory.create("writeAuditCommandHandler", paramMap);
		
		command.addParameter(AuditParamKey.APPLICATION, applicationName);
		command.addParameter(AuditParamKey.CONTEXT, request.getParameter(AuditParamKey.CONTEXT));
		command.addParameter(AuditParamKey.INSTITUTION, institution);
		command.addParameter(AuditParamKey.USERNAME, request.getParameter((AuditParamKey.USERNAME)));
		command.addParameter(AuditParamKey.FULLNAME, "");
		command.addParameter(AuditParamKey.MEMBERSHIP, "");
		command.addParameter(AuditParamKey.IPADDRESS, ipUtil.getRemoteAddr(request));
		command.addParameter(AuditParamKey.WORKSTATION, ipUtil.getRemoteAddr(request));
		command.addParameter(AuditParamKey.DATA, aex.getMessage());
		command.addParameter(AuditParamKey.AUDIT_TYPE, action);
		command.addParameter(AuditParamKey.STATUS, status);
		
		logger.info(command.map().toString());
		
		return command;
	}
	
	/**
	 * 
	 * @param command
	 */
	private void saveAuditData(BasicCommand command) {
		commandBus.doPublish(command);
	}
	
}
