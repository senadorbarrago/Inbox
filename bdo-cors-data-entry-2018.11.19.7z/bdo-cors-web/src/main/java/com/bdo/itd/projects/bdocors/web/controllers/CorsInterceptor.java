package com.bdo.itd.projects.bdocors.web.controllers;

import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.http.HttpStatus;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

/**
 * 
 * @author a014000098
 *
 */
public class CorsInterceptor extends HandlerInterceptorAdapter implements InitializingBean {


	/**
	 * 
	 */
	private static final String REQUEST_ORIGIN_NAME ="Origin";

	
	/**
	 * 
	 */
	private static final String CREDENTIALS_NAME ="Access-Control-Allow-Credentials";
	
	/**
	 * 
	 */
	private static final String ORIGIN_NAME ="Access-Control-Allow-Origin";
	
	/**
	 * 
	 */
	private static final String METHODS_NAME ="Access-Control-Allow-Methods";
	
	/**
	 * 
	 */
	private static final String HEADERS_NAME ="Access-Control-Allow-Headers";
	
	/**
	 * 
	 */
	private static final String MAX_AGE_NAME ="Access-Control-Allow-Max-Age";
	
	/**
	 * 
	 */
	private List<String> allowedOrigins;
	
	private boolean allowAll = false;
	
	/**
	 * 
	 * @param origins
	 */
	public CorsInterceptor(String allowedOrigins) {
		allowAll = "*".equalsIgnoreCase(allowedOrigins);
		this.allowedOrigins = Arrays.asList(allowedOrigins.trim().split("( )*,( )*"));
		System.out.println(allowedOrigins);
	}
	
	/**
	 * 
	 */
	@Override
	public boolean preHandle(
			HttpServletRequest request,
			HttpServletResponse response, 
			Object handler) throws Exception {
		response.setHeader(CREDENTIALS_NAME, "true");
		response.setHeader(METHODS_NAME, "GET, OPTIONS, POST, PUT, DELETE");
		response.setHeader(HEADERS_NAME, "Origin, X-Requested-With, Content-Type, Accept,cache-control,pragma,rmf_application,rmf_client_sessionid,rmf_role,rmf_sessionid,rmf_user,rmf_username");
		response.setHeader(MAX_AGE_NAME, "3600");
		
		boolean isAllowed = true;
		String origin = request.getHeader(REQUEST_ORIGIN_NAME);
		if ((allowAll)) {
			System.out.println("Skipped checking of origin...");
		} else {
			System.out.println("origin=" + origin);
			if (allowedOrigins.contains(origin)) {
				System.out.println("ALLOWED");
			} else {
				System.out.println("NOT ALLOWED");
				//origin = allowedOrigins.iterator().next();
				response.setStatus(HttpStatus.FORBIDDEN.value());
				isAllowed = false;
			}	
		}
		response.setHeader(ORIGIN_NAME, origin);
		return isAllowed;
		
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		// TODO Auto-generated method stub
		
	}
	
}