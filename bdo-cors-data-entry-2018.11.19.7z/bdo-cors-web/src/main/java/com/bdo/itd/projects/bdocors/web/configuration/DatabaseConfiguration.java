package com.bdo.itd.projects.bdocors.web.configuration;

import javax.sql.DataSource;

import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.encryption.pbe.config.EnvironmentStringPBEConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.bdo.itd.util.persistence.DataAccessInterface;
import com.bdo.itd.util.persistence.jdbcdaosupport.DataAccessService;
import com.zaxxer.hikari.HikariDataSource;

/**
 * 
 * @author a014000098
 *
 */
@Configuration
public class DatabaseConfiguration {

	/**
	 * 
	 */
	@Value("${jasypt.pbeConfig.algorithm}")
	private String algorithm;
	
	/**
	 * 
	 */
	@Value("${jasypt.pbeConfig.passwordEnvName}")
	private String passwordEnvName;
	
	/**
	 * 
	 */
	@Value("${jasypt.pbeConfig.poolSize}")
	private int poolSize;

	/**
	 * 
	 */
	@Value("${jasypt.pbeEncryptor.password}")
	private String password;
	
	
	/**
	 * 
	 */
	@Value("${dataSource.url}")
	private String databaseUrl;
	
	/**
	 * 
	 */
	@Value("${dataSource.driverClassName}")
	private String databaseDriverClassName;
	
	/**
	 * 
	 */
	@Value("${dataSource.username}")
	private String databaseUsername;
	
	/**
	 * 
	 */
	@Value("${dataSource.password}")
	private String databasePassword;
	
	/**
	 * 
	 */
	@Value("${dataSource.connection-timeout}")
	private Integer databaseConnectionTimeOut;
	
	/**
	 * 
	 */
	@Value("${dataSource.maximum-pool-size}")
	private Integer databaseMaximumPoolSize;
	
	/**
	 * 
	 * @return
	 */
	@Bean
	public EnvironmentStringPBEConfig environmentStringPBEConfig() {
		EnvironmentStringPBEConfig config = new EnvironmentStringPBEConfig();
		config.setAlgorithm(algorithm);
		config.setPasswordEnvName(passwordEnvName);
		config.setPoolSize(poolSize);
		return config;
	}
	
	/**
	 * 
	 * @param environmentStringPBEConfig
	 * @return
	 */
	@Bean
	public StandardPBEStringEncryptor standardPBEStringEncryptor(
			EnvironmentStringPBEConfig environmentStringPBEConfig) {
		StandardPBEStringEncryptor stringEncryptor = new StandardPBEStringEncryptor();
		stringEncryptor.setPassword(password);
		stringEncryptor.setConfig(environmentStringPBEConfig);
		return stringEncryptor;
	}
	
	
	/**
	 * 
	 * @param standardPBEStringEncryptor
	 * @param dataSourceProperties
	 * @return
	 */
	@Bean
	public DataSource dataSource(
			StandardPBEStringEncryptor standardPBEStringEncryptor) {
		final HikariDataSource dataSource = new HikariDataSource();
		dataSource.setMaximumPoolSize(databaseMaximumPoolSize);
		dataSource.setConnectionTimeout(databaseConnectionTimeOut);
		dataSource.setDriverClassName(databaseDriverClassName); 
		dataSource.setJdbcUrl(databaseUrl);
		dataSource.setUsername(standardPBEStringEncryptor.decrypt(databaseUsername));
		dataSource.setPassword(standardPBEStringEncryptor.decrypt(databasePassword));
		
		return dataSource;
	}

	/**
	 * 
	 * @param dataSource
	 * @return
	 */
	@Bean
	public DataAccessInterface dataAccessService(DataSource dataSource) {
		DataAccessService dataAccessService = new DataAccessService(dataSource);
		return dataAccessService;
	}
}
