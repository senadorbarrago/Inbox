package com.bdo.itd.projects.bdocors.web.controllers;

import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bdo.itd.projects.bdocors.usermanagement.application.UserSession;
import com.bdo.itd.util.cqrs.command.CommandFactory;
import com.bdo.itd.util.cqrs.command.CommandMessage;
import com.bdo.itd.util.cqrs.command.ICommand;
import com.bdo.itd.util.cqrs.command.ICommandBus;

/**
 * @author senadorbarrago
 *
 */
@RestController
@RequestMapping(value = "/command")
public class CommandController extends AbstractController{
	
	/**
	 * 
	 */
	private static final Logger logger = LoggerFactory.getLogger(CommandController.class);
	
	/**
	 * 
	 */
	private final ICommandBus commandBus;
	
	/**
	 * @param commandBus
	 */
	@Inject
	public CommandController(ICommandBus commandBus) {
		super();
		this.commandBus = commandBus;
	}

	/**
	 * @param commandCode
	 * @param data
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/{commandCode}", method = RequestMethod.POST)
	public Object doCommand(@PathVariable(name = "commandCode") String commandCode, 
			@RequestBody Map<String, Object> data, HttpServletRequest request){
		logger.info("doCommand()");
		
		if(SecurityContextHolder.getContext().getAuthentication() != null &&
				 SecurityContextHolder.getContext().getAuthentication().isAuthenticated() && 
				 //when Anonymous Authentication is enabled
				 !(SecurityContextHolder.getContext().getAuthentication() 
				          instanceof AnonymousAuthenticationToken) ){
			HttpSession session = request.getSession();
			
			data.put("institution", session.getAttribute("institution"));
			data.put("context", session.getAttribute("context"));
			data.put("datasetcode", "ITRS");
			data.put("authenticatedUser", UserSession.getUsername());
			data.put("membershipCode", UserSession.getActiveMembership().getCode());
		}
		
		logger.info("commandCode: "+commandCode);
		logger.info(data.toString());
		
		ICommand command = CommandFactory.create(commandCode, data);
		CommandMessage message = commandBus.doPublish(command);
		
		return message;
	}
	
}
