package com.bdo.itd.projects.bdocors.web.controllers;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.bdo.itd.util.cqrs.command.CommandException;
import com.bdo.itd.util.cqrs.query.QueryException;

/**
 * @author c140618008
 *
 */
public abstract class AbstractController {
	
	/**
	 * @param response
	 * @param ex
	 * @return
	 */
	@ExceptionHandler(CommandException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	public Object handleCommandException(HttpServletResponse response, CommandException ex){
		Map<String, String> messageMap = new HashMap<>();
		messageMap.put("ERROR_MESSAGE", ex.getMessage());
		
		return messageMap;
	}
	
	/**
	 * @param response
	 * @param ex
	 * @return
	 */
	@ExceptionHandler(QueryException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	public Object handleQueryException(HttpServletResponse response, QueryException ex){
		Map<String, String> messageMap = new HashMap<>();
		messageMap.put("ERROR_MESSAGE", ex.getMessage());
		
		return messageMap;
	}
	
	/**
	 * @param response
	 * @param ex
	 * @return
	 */
	@ExceptionHandler(Exception.class)
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public Object handlegGenericException(HttpServletResponse response, Exception ex){
		Map<String, String> messageMap = new HashMap<>();
		messageMap.put("ERROR_MESSAGE", ex.getMessage());
		
		return messageMap;
	}
	
}
