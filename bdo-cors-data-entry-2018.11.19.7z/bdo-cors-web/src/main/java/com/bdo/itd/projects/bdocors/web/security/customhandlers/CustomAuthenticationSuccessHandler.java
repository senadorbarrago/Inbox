package com.bdo.itd.projects.bdocors.web.security.customhandlers;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Service;

import com.bdo.itd.projects.bdocors.auditmanagement.application.command.AuditParamKey;
import com.bdo.itd.projects.bdocors.auditmanagement.infrastructure.utilities.HTTPServletUtils;
import com.bdo.itd.projects.bdocors.usermanagement.application.UserSession;
import com.bdo.itd.util.cqrs.command.BasicCommand;
import com.bdo.itd.util.cqrs.command.CommandFactory;
import com.bdo.itd.util.cqrs.command.ICommandBus;

/**
 * @author c140618008
 *
 */
@Service
public class CustomAuthenticationSuccessHandler implements AuthenticationSuccessHandler {
	
	/**
	 * 
	 */
	private static final Logger logger = LoggerFactory.getLogger(CustomAuthenticationSuccessHandler.class);
	
	@Autowired
	private ICommandBus commandBus;
	
	/**
	 * 
	 */
	private static final HTTPServletUtils ipUtil = new HTTPServletUtils();
	
	/**
	 * 
	 */
	@Value("${application.name}")
	private String applicationName;
	
	/**
	 * 
	 */
	@Value("${institution.name}")
	private String institution;
	
	/**
	 * 
	 */
	private String defaultSuccessUrl = "/home";
		
	/**
	 * 
	 */
	private String action = "Login";
	
	/**
	 * 
	 */
	private String status = "SUCCESS";
	
	/**
	 * 
	 */
	private int successStatusCode = 200;

	@Override
	public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, 
			Authentication authentication)
			throws IOException, ServletException {
		logger.info("onAuthenticationSuccess()");
		
		BasicCommand command = this.initializeAuditData(request, response);
		saveAuditData(command);
		
		this.setSessionContext(request);
		this.setSessionInstitution(request);
		
		response.setHeader("defaultSuccessUrl", defaultSuccessUrl);
		response.setStatus(successStatusCode);
	}
	
	/**
	 * 
	 * @return
	 */
	private BasicCommand initializeAuditData(HttpServletRequest request, 
			HttpServletResponse response) {
		
		Map<String, Object> paramMap = new HashMap<>();
		
		BasicCommand command = (BasicCommand)CommandFactory.create("writeAuditCommandHandler", paramMap);
		
		command.addParameter(AuditParamKey.APPLICATION, applicationName);
		command.addParameter(AuditParamKey.CONTEXT, request.getParameter(AuditParamKey.CONTEXT));
		command.addParameter(AuditParamKey.INSTITUTION, institution);
		command.addParameter(AuditParamKey.USERNAME, UserSession.getUsername());
		command.addParameter(AuditParamKey.FULLNAME, UserSession.getFullname());
		command.addParameter(AuditParamKey.MEMBERSHIP, UserSession.getActiveMembership().getCode());
		command.addParameter(AuditParamKey.IPADDRESS, ipUtil.getRemoteAddr(request));
		command.addParameter(AuditParamKey.WORKSTATION, ipUtil.getRemoteAddr(request));
		command.addParameter(AuditParamKey.DATA, UserSession.getUsername());
		command.addParameter(AuditParamKey.AUDIT_TYPE, action);
		command.addParameter(AuditParamKey.STATUS, status);
		
		logger.info(command.map().toString());
		
		return command;
	}
	
	/**
	 * 
	 * @param command
	 */
	private void saveAuditData(BasicCommand command) {
		commandBus.doPublish(command);
	}
	
	/**
	 * @param request
	 */
	private void setSessionContext(HttpServletRequest request) {
		String context = request.getParameter(AuditParamKey.CONTEXT);
		request.getSession().setAttribute(AuditParamKey.CONTEXT, context);
	}
	
	/**
	 * @param request
	 */
	private void setSessionInstitution(HttpServletRequest request) {
		request.getSession().setAttribute(AuditParamKey.INSTITUTION, institution);
	}
}
