'use strict';

define(function(){
		// Create core module
		var core = angular.module('core', ['ngRoute', 'ngCookies', 'ui.bootstrap', 'ui.select', 'ngSanitize', 'ngTable', 'ngIdle', 'reportFormModule', 'ngmodel.format']);
		
		core.directive("scrollGroup", function() {
			return function(scope, element, attrs) {
				element.bind("scroll", function(e) {
					var prop = "[scroll-group-header='" + attrs.scrollGroup + "']";
					var hdrs = angular.element(document.querySelectorAll(prop));
					angular.forEach(hdrs, function(value, key) {
						value.scrollLeft = element[0].scrollLeft;
					});
				});
			};			
		});
		
		core.config(['$routeProvider', '$httpProvider', '$controllerProvider', '$cookiesProvider', '$locationProvider', 'KeepaliveProvider', 'IdleProvider',
			function($routeProvider, $httpProvider, $controllerProvider, $cookiesProvider, $locationProvider, KeepaliveProvider, IdleProvider){
			console.log('core.config');
			
			IdleProvider.idle(840);
			IdleProvider.timeout(10);
			KeepaliveProvider.interval(300);
			KeepaliveProvider.http('/bdo-cors/healthCheck');
			
			// ControllerProvider Configuration
//			core.register = {
//					controller : $controllerProvider.register
//			};
			
			core.registerController = $controllerProvider.register;
			
			// Route Configuration
			$routeProvider
				.when('/',{
					controller: 'loginController',
					controllerAs: 'loginCtrl',
					templateUrl: 'app/components/security/login.html',
					resolve:{
						load: function($q, $rootScope) {
							return resolveDependencies($q, $rootScope, ['app/components/security/loginController']);
						}	
					}				
				})
				.when('/home', {
					controller: 'homeController',
					controllerAs: 'homeCtrl',
					templateUrl: 'app/components/home/home.html',
					resolve:{
						load: function($q, $rootScope, $location) {
							return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/home/homeController']);
						}
					}
				})
				.when('/fileloading', {
					controller: 'fileLoadingController',
					controllerAs: 'fileloadingCtrl',
					templateUrl: 'app/components/inbound/fileloading/fileLoading.html',
					resolve:{
						load: function($q, $rootScope, $location) {
							return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/inbound/fileloading/fileLoadingController']);
						}
					}
				})
				.when('/filelog', {
					controller: 'fileLogController',
					controllerAs: 'fileLogCtrl',
					templateUrl: 'app/components/inbound/filelog/fileLog.html',
					resolve:{
						load: function($q, $rootScope, $location) {
							return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/inbound/filelog/fileLogController']);
						}
					}
				})
				.when('/reporting', {
					controller: 'reportsController',
					controllerAs: 'reportsCtrl',
					templateUrl: 'app/components/reports/reports.html',
					resolve:{
						load: function($q, $rootScope, $location) {
							return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/reports/reportsController']);
						}
					}
				})
				.when('/downloads', {
					controller: 'downloadsController',
					controllerAs: 'downloadsCtrl',
					templateUrl: 'app/components/downloads/downloads.html',
					resolve:{
						load: function($q, $rootScope, $location) {
							return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/downloads/downloadsController']);
						}
					}
				})
				// 2.0.0
				.when('/transactionpool', {
					controller: 'transactionPoolController',
					controllerAs: 'transactionPoolCtrl',
					templateUrl: 'app/components/transactions/transactionPool.html',
					resolve:{
						load: function($q, $rootScope, $location) {
							return resolveDependenciesWithAuthentication($q, $rootScope, $location, ['app/components/transactions/transactionPoolController']);
						}
					}
				})
				.otherwise("/home");
			
			// Resource access with Authentication
			var resolveDependenciesWithAuthentication = function($q, $rootScope, $location, dependencies) {
				var defer = $q.defer();
				if ($rootScope.session['AUTHENTICATED'] === true) {
					require(dependencies, function() {
						defer.resolve();
						$rootScope.$apply();
					});
					return defer.promise;
				} else {
					console.log("not authenticated")
					$location.path("/");
					return $q.reject("/");
				}
			};
			// Resource access without Authentication
			var resolveDependencies = function($q, $rootScope, dependencies) {
				var defer = $q.defer();
				require(dependencies, function() {
					defer.resolve();
					$rootScope.$apply();
				});
				return defer.promise;
			};
			
			//$locationProvider.html5Mode(true);
			//$locationProvider.hashPrefix('');
			
			$httpProvider.defaults.headers.common["X-Requested-With"] = 'XMLHttpRequest';
			$httpProvider.defaults.headers.common["Cache-Control"] = "no-cache";
			$httpProvider.defaults.headers.common["Pragma"] = "no-cache";
		}]);
		
		core.run(['$rootScope', '$uibModal', '$uibModalStack', '$location', '$cookies', '$window', 'DataAccessService', 'Idle',
			function($rootScope, $uibModal, $uibModalStack, $location, $cookies, $window, dataAccessService, Idle){
			
			// Initialize Session
			$rootScope.session = {};
			console.log($rootScope.session);
			$rootScope.showSpinner = false;
			
			// App Information
			dataAccessService.doGetData("app/appinfo.json", null, function(response){
				$rootScope.appInfo = response.data;
			},function(errorResponse){
				console.log(errorResponse);
			});
			
			// Menu Resources
			dataAccessService.doGetData("app/config/menuConfig.json", null, function(response){
				console.log(response);
				$rootScope.menus = response.data.menu;
			},function(errorResponse){
				console.log(errorResponse);
			});
			
			// Context List
			dataAccessService.doGetData("app/config/context-list.json", null, function(response){
				console.log(response);
				$rootScope.contextList = response.data.contextList;
			},function(errorResponse){
				console.log(errorResponse);
			});
		
			// Default Values
			dataAccessService.doGetData("app/config/default-values.json", null, function(response){
				console.log(response);
				$rootScope.defaultValues = response.data.defaultValues;
			},function(errorResponse){
				console.log(errorResponse);
			});
			
			// RMF
			$rootScope.doRMF = function(){
				dataAccessService.doGetData("rmf", null, function(response){
					console.log("Reference Maintenance");
					console.log(response.data);
					window.location.href= response.data.redirectUrl;
				},function(errorResponse){
					console.log(errorResponse);
				});
			};
			
			// Resource Permission
			$rootScope.hasResourcePermission = function(resourceID){
				if($rootScope.session['AUTHENTICATED_USER']){
					var resourceList = $rootScope.session['AUTHENTICATED_USER'].activeMembership.resourceList;
					for(var i = 0; i < resourceList.length; i++){
						if(resourceList[i].securedItemCode === resourceID){
							return true;
						}
					}
				}
			};	

			$rootScope.$on("initializeAuthority", function() {
				console.log("initializeAuthority");
				$rootScope.httpException = false;
				
			});
			
			$rootScope.$on("$locationChangeStart", function(event, next, current) {
				var i = next.lastIndexOf("#"); 
				if ( i > -1) {
					$cookies.put("CURRENT_PAGE", next.substring(i+1));
					$rootScope.currentPage = next.substring(i+1);
					$uibModalStack.dismissAll();
				} else {
					$cookies.put("CURRENT_PAGE", "/home");
					$rootScope.currentPage = "/home";
					$uibModalStack.dismissAll();
				}
				
				console.log("$rootScope.currentPage: "+$rootScope.currentPage);
			});	
			
			
			$rootScope.$on("$locationChangeSuccess", function(event, next, current) {
				if (next.indexOf("/reference") !== -1) {
					window.location.href= "#/maintenance/bcas";
				}
			});		
			
			/**
			 * 
			 */
			let removeAllCookies = function(){
				var cookies = $cookies.getAll();
				angular.forEach(cookies, function (v, k) {
				    $cookies.remove(k);
				});
			}
			
			/**
			 * 
			 */
			let getAuthenticatedUser = function(){
				dataAccessService.doGetData("authenticatedUser", null, function(response){
					if(response.headers('Content-Type').indexOf("application/json") == -1) {
						$rootScope.session = {};
						removeAllCookies();
						$location.path('/');
						alertify.fail("Forbidden: Session already expired.Y");
					}else{
						console.log(response.data);
						$rootScope.session['AUTHENTICATED_USER'] = response.data;
						$rootScope.session['CURRENT_PAGE'] = $cookies.get("CURRENT_PAGE");
						$location.path($cookies.get("CURRENT_PAGE"));
					}
				},function(errorResponse){
					$rootScope.session = {};
					removeAllCookies();
					$location.path('/');
					alertify.fail("Forbidden: Session already expired!");
				});
			}
			
			/**
			 * Get Session Institution
			 */
			$rootScope.getSessionInstitution = function(){
				dataAccessService.doGetData("sessioninstitution", null, function(response){
					console.log("SessionInstitution");
					console.log(response);
					$rootScope.session["sessionInstitution"] = response.data.sessionInstitution;
				},function(errorResponse){
					console.log(errorResponse);
				});
			};
			
			/**
			 * Get Session Context
			 */
			$rootScope.getSessionContext = function(){
				dataAccessService.doGetData("sessioncontext", null, function(response){
					console.log("SessionContext");
					var sessionContext = response.data.sessionContext;
					if(!$rootScope.contexList){
						// Context List
						dataAccessService.doGetData("app/config/context-list.json", null, function(response){
							console.log(response);
							$rootScope.contextList = response.data.contextList;
							angular.forEach($rootScope.contextList, function(value, key){
								if(value.id == sessionContext){
									$rootScope.session["sessionContext"] = value;
								}
							});
						},function(errorResponse){
							console.log(errorResponse);
						});
					}else{
						angular.forEach($rootScope.contextList, function(value, key){
							if(value.id == response.data.sessionContext){
								$rootScope.session["sessionContext"] = value;
							}
						});
					}
				},function(errorResponse){
					console.log(errorResponse);
				});
			};
			
			// Restores session data from cookie repository during after page request
			if($cookies.get("AUTHENTICATED") === "true"){
				$location.path($cookies.get("CURRENT_PAGE"));
				$rootScope.session['AUTHENTICATED']  = true;
				getAuthenticatedUser();
				$rootScope.getSessionInstitution();
				$rootScope.getSessionContext();
			}
			
			// Logout
			$rootScope.logout = function(){
				dataAccessService.doPostData("logout", null, function(response){
					$rootScope.unWatchTimeout();
					$uibModalStack.dismissAll();
					alertify.alert("You have successfully logged out from BDO-CORS", function(e){
						removeAllCookies();
						$rootScope.session = {};
						$location.path('/');
					});					
				},function(errorResponse){
					console.log(errorResponse);
				});
			}
			
			/**
			 *  Session Timeout Watcher
			 * 
			 */
			if($rootScope.session['AUTHENTICATED'] &&
					$rootScope.session['AUTHENTICATED'] === true){
				Idle.watch();
			}else{
				Idle.unwatch();
			}
			
			$rootScope.watchTimeout = function(){
				Idle.watch();
			}
			
			$rootScope.unWatchTimeout = function(){
				Idle.unwatch();
			}
			
			let closeModals = function(){
				if($rootScope.warning){
					$rootScope.warning.close();
					$rootScope.warning = null;
				}
			}
			
			$rootScope.$on('IdleStart', function(){
				closeModals();
				$rootScope.warning = $uibModal.open({
					templateUrl: 'warning-dialog.html',
					windowsClass: 'modal-danger'
				});
			});
			
			$rootScope.$on('IdleEnd', function(){
				closeModals();
			});
			
			$rootScope.$on('IdleTimeout', function(){
				closeModals();
				$rootScope.logout();
				Idle.watch();
			});
			
			$rootScope.$on('KeepAlive', function(){
				alertify.alert('Im Alive!!!');
			});
			
			
			Number.prototype.toFixedSpecial = function(n) {
				console.log('Number.prototype.toFixedSpecial: '+n);
				var str = this.toFixed(n);
			    if (str.indexOf('e+') < 0)
			        return str;
			    	
			    // if number is in scientific notation, pick (b)ase and (p)ower
			    return str.replace('.', '').split('e+').reduce(function(p, b) {
			        return p + Array(b - p.length + 2).join(0);
			    }) + '.' + Array(n + 1).join(0);
			};
		}]);
		
		// Load Dependencies
		require(['serviceIndex', 'directiveIndex'], function(serviceIndex, directiveIndex){
			console.log('core.require');
			require(serviceIndex, function(){
				require(directiveIndex, function(){
					angular.bootstrap(document, ['core']);
				});
			});
		});
		
});
