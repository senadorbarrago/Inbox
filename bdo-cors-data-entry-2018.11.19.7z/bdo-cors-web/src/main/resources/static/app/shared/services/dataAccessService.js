'use strict';

define(function(){
	angular.module("utility").provider('DataAccessService', function(){
		this.$get =['$http', '$q', '$rootScope', '$location', '$cookies', 
			function($http, $q, $rootScope, $location, $cookies){
			
			/**
			 * For invalid session
			 * 
			 */
			function checkSession(response){
				return true;
			};
			
			/**
			 * 
			 */
			var service = {
				
				/**
				 * 
				 */
				doGetData: function(url, data, successCallBack, errorCallBack) {
					$rootScope.showSpinner = true;
					return $http.get(url, data)
							.then(
									function(response){
										$rootScope.showSpinner = false;
										checkSession(response);
										successCallBack(response);
									}, 
									function(errResponse){
										$rootScope.showSpinner = false;
										checkSession(errResponse);
										errorCallBack(errResponse);
									}
							);
				},
				
				/**
				 * 
				 */
				doPostData: function(url, data, successCallBack, errorCallBack) {
					$rootScope.showSpinner = true;
					return $http.post(url, data)
						.then(
								function(response){
									$rootScope.showSpinner = false;
									checkSession(response);
									successCallBack(response);
								}, 
								function(errResponse){
									$rootScope.showSpinner = false;
									checkSession(errResponse);
									errorCallBack(errResponse);
								}
						);
				},
				
				/**
				 * 
				 */
				doPutData: function(url, data, successCallBack, errorCallBack) {
					$rootScope.showSpinner = true;
					return $http.put(url, data)
						.then(
								function(response){
									$rootScope.showSpinner = false;
									checkSession(response);
									successCallBack(response);
								}, 
								function(errResponse){
									$rootScope.showSpinner = false;
									checkSession(errResponse);
									errorCallBack(errResponse);
								}
						);
				},
				
				/**
				 * 
				 */
				doPostTransformedData: function(url, data, successCallBack, errorCallBack) {
					$rootScope.showSpinner = true;
						return $http.post(url, data, {
								headers: {
									'Content-Type': 'application/x-www-form-urlencoded'
								}
							})
							.then(
									function(response){
										$rootScope.showSpinner = false;
										checkSession(response);
										successCallBack(response);
									}, 
									function(errResponse){
										$rootScope.showSpinner = false;
										checkSession(errResponse);
										errorCallBack(errResponse);
									}
							);
				},
				
				/**
				 * 
				 */
				doPostFileData: function(url, data, successCallBack, errorCallBack) {
					$rootScope.showSpinner = true;
						return $http.post(url, data, {
								transformRequest: angular.identity,
								headers: {
									'Content-Type': undefined
								}
							})
							.then(
									function(response){
										$rootScope.showSpinner = false;
										checkSession(response);
										successCallBack(response);
									}, 
									function(errResponse){
										$rootScope.showSpinner = false;
										checkSession(errResponse);
										errorCallBack(errResponse);
									}
							);
				},
				
				/**
				 * 
				 */
				doQuery: function(queryCode, data, successCallBack, errorCallBack) {
					$rootScope.showSpinner = true;
					var url = 'query/'+queryCode;
					
						return $http.post(url, data)
						.then(
							function(response){
								$rootScope.showSpinner = false;
								checkSession(response);
								successCallBack(response);
							}, 
							function(errResponse){
								$rootScope.showSpinner = false;
								checkSession(errResponse);
								errorCallBack(errResponse);
							}
						);
				},
				/**
				 * 
				 */
				doPost: function(commandCode, data, successCallBack, errorCallBack) {
					$rootScope.showSpinner = true;
					var url = 'command/'+commandCode;
					
						return $http.post(url, data)
						.then(
							function(response){
								$rootScope.showSpinner = false;
								checkSession(response);
								successCallBack(response);
							}, 
							function(errResponse){
								$rootScope.showSpinner = false;
								checkSession(errResponse);
								errorCallBack(errResponse);
							}
						);
				},
				/**
				 * 
				 */
				doDownloadReport: function(url, data, successCallBack, errorCallBack) {
					$rootScope.showSpinner = true;
						return $http.get(url, {
								headers: {
									'Accept': 'application/octet-stream'
								}
							})
							.then(
									function(response){
										$rootScope.showSpinner = false;
										checkSession(response);
										successCallBack(response);
									}, 
									function(errResponse){
										$rootScope.showSpinner = false;
										checkSession(errResponse);
										errorCallBack(errResponse);
									}
							);
				}
				
			};
			return service;
		}]
	});	
});