'use strict'
define(function(){
	var core = angular.module('utility');
	core.directive('dateTime', function($interval){
		return{
			restrict: 'E',
			replace : true,
			template: '<div>{{today | date: format}}</div>',
			scope: {
				format: '@',
				today: '@'
			},
			controller: function($scope){				
				$scope.today = new Date();
				$interval(function(){
					$scope.today = new Date();
				}, 1000);
				
			}
		}
	});
	return core;
});