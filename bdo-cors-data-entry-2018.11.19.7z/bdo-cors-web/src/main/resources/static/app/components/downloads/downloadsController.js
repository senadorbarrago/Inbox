'use strict';

define(function(){
	console.log('downloadsController.js loaded');
	var core = angular.module('core');
	
	core.registerController('downloadsController', ['$rootScope', '$scope', 'ngTableParams', 'DataAccessService', 
		function($rootScope, $scope, ngTableParams, dataAccessService){

		// Title and Module Description
		var vm = this;
		$rootScope.screenName = 'Downloads';
		
		/**
		 * 
		 */
		vm.init = function () {
			console.log("vm.init()");
			vm.initData();
			vm.getDownloadProcesses();
		};
		
		/**
		 * 
		 */
		vm.initData = function(){
			vm.data = {};
		}		
		
		/**
		 * 
		 */
		vm.getDownloadProcesses = function(){
			console.log("vm.getDownloadProcesses()");
			
			vm.downloadProcessTable = new ngTableParams({
                page: 1,
                count: 10
            }, {
                getData: function ($defer, params) {
                	console.log("getData()");
                	var queryCode = "reportProcessingDetailsQueryModel";
                	console.log('params.count(): '+ params.count());
                	console.log('params.page(): '+ params.page());
                	
                	var data = {
                				'pageIndex' : params.page(),
        						'pageSize': params.count()
        			   	   	   };
                	
                	console.log(data);

                	return dataAccessService.doQuery(queryCode, data, function(response){
			        			console.log('doQuery()');
			        			console.log(response);
			        			vm.downloadProcessData = {};
			        			vm.downloadProcessData.resultSet = response.data.resultSet;
			        			vm.downloadProcessData.columns = response.data.columns;
			        			
			        			params.total(response.data.resultOverAllCount);
			        			$defer.resolve(vm.downloadProcessData.resultSet);
			        		}, function(errorResponse){
			    				console.log(errorResponse);
			    			});
                	
                }
            });
		};		
		
		/**
		 * 
		 */
		vm.doCheckTaskStatus = function(id, taskId){
			console.log("doCheckTaskStatus()");
			console.log(vm.data);
			
			var data = {};
			data.id = id;
			data.taskId  = taskId;
			
			console.log(data);
			
			dataAccessService.doPost('updateReportTaskStatusCommandHandler', data, function(response){
				console.log(response.data);
				vm.downloadProcessTable.reload();
			},function(errorResponse){
				console.log(errorResponse);
				alertify.alert(errorResponse.data['ERROR_MESSAGE']);
				vm.doDeleteTaskStatus(data.id);
			});
		};
		
		/**
		 * 
		 */
		vm.doDownload = function(id, reportCode, targetFile){
			console.log("doDownload()");
			console.log(vm.data);
			
			var data = {};
			var url = "report/downloadReportCommandHandler?id="+id+"&reportCode="+reportCode+"&targetFile="+targetFile;
			
			dataAccessService.doDownloadReport(url, data, function(response){
				console.log(response);
				
				var reportData = new File([response.data], targetFile, {'type': 'application/octet-stream'});
				var reportUrl = window.URL.createObjectURL(reportData);
				window.location.href = reportUrl;
				vm.downloadProcessTable.reload();
			},function(errorResponse){
				console.log(errorResponse);
				alertify.alert(errorResponse.data['ERROR_MESSAGE']);
				vm.doDeleteTaskStatus(id);
			});
		};
		
		/**
		 * 
		 */
		vm.doDeleteTaskStatus = function(id){
			console.log("doDeleteTaskStatus()");
			console.log(vm.data);
			
			var data = {};
			data.id = id;
			
			console.log(data);
			
			dataAccessService.doPost('deleteReportTaskStatusCommandHandler', data, function(response){
				console.log(response.data);
				vm.downloadProcessTable.reload();
				alertify.alert(response.data.messageMap['SUCCESS_MESSAGE']);
			},function(errorResponse){
				console.log(errorResponse);
				alertify.alert(errorResponse.data['ERROR_MESSAGE']);
			});
		};		
		
		/**
		 * 
		 */
		vm.init();
		
	}]);
	
});