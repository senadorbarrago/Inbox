'use strict';

define(function(){
	console.log('scheduleFormController.js loaded');
	var core = angular.module('core');
	
	core.registerController('scheduleFormController', ['$rootScope', '$scope', '$filter', '$uibModalInstance', 'DataAccessService', 'data',
		function($rootScope, $scope, $filter, $uibModalInstance, dataAccessService, data){

		// Title and Module Description
		var vm = this;
		vm.screenName = 'Schedule Form';
		
		/**
		 * 
		 */
		vm.init = function () {
			console.log("vm.init()");
			vm.initData();
			vm.initDatePicker();
			
			if(data){
				vm.initData = data;
				console.log("data: ");
				console.log(vm.initData);
				vm.data.scheduleCode = data.scheduleCode;
				vm.getSheduleFields();
				vm.getTransactionData();
				
			}
		};
		
		/**
		 * 
		 */
		vm.initData = function(){
			vm.references = {};
			vm.references.dataFieldReferences = {};
			vm.data = {};
			vm.data.fieldMap = {};
			vm.getScheduleReference();
			vm.getBranchReference();
		}
		
		/**
		 * 
		 */
		vm.initDatePicker = function(){
			vm.datePicker = {};
			
			vm.dateOptions = {
					startingDay : 1,
					showWeeks : false,	
					format : "yyyy-MM-dd",
					timezone: 'UTC'
				};
			
			vm.dateFormat = "yyyy-MM-dd";
		}
		
		/**
		 * 
		 */
		vm.open = function(columnName, $event){
			$event.preventDefault();
			$event.stopPropagation();
			
			if (vm.datePicker[columnName]) {
				if (vm.datePicker[columnName].opened) {
					vm.datePicker[columnName].opened = false;
				}
			} else {
				vm.datePicker = {};
				vm.datePicker[columnName] = {};
				vm.datePicker[columnName].opened = true;
			}
		}
		
		/**
		 * 
		 */
		vm.getTransactionData = function(){
			console.log("vm.getTransactionData()");
			var data = {
							"id" : vm.initData.id,
							"scheduleCode" : vm.initData.scheduleCode
			};
			
			dataAccessService.doQuery('transactionDataQueryModel', data, function(response){
				console.log("vm.getTransactionData()");
				console.log(response);
				var record = response.data.resultSet[0];
				var columns = response.data.columns;
				
				angular.forEach(columns, function(element){
					if(element === 'TRDATE'){
						vm.data.fieldMap[element] = new Date(record[element]);
					}else if(element === 'datecreated' || element === 'datemodified'){
						vm.data.fieldMap[element] = $filter('date')(new Date(record[element]),'yyyy-MM-dd hh:mm:ss a');
					}else{
						vm.data.fieldMap[element] = record[element];
					}
				});
			},function(errorResponse){
				console.log(errorResponse);
			});
		};
		
		/**
		 * 
		 */
		vm.getScheduleReference = function(){
			console.log("vm.getScheduleReference()");
			var data = {
						"scheduleCode" : vm.data.scheduleCode
			};
			
			dataAccessService.doQuery('scheduleListQueryModel', data, function(response){
				if(response.data.resultSet){ 
					vm.references.scheduleList = response.data.resultSet;
					console.log(vm.references.scheduleList);
				}
			},function(errorResponse){
				console.log(errorResponse);
			});
		};
		
		/**
		 * 
		 */
		vm.getBranchReference = function(){
			console.log("vm.getBranchReference()");
			var data = {
						"pageIndex" : 1,
						"pageSize" : 10000
				};
			
			dataAccessService.doQuery('branchListQueryModel', data, function(response){
				if(response.data.resultSet){ 
					vm.references.branchList = response.data.resultSet;
					console.log(vm.references.branchList);
				}
			},function(errorResponse){
				console.log(errorResponse);
			});
		};
		
		/**
		 * 
		 */
		vm.getSheduleFields = function(){
			console.log("vm.getSheduleFields");
			var data = {
						"transactionID" : vm.initData.transactionID,
						"scheduleCode"  : vm.data.scheduleCode
			};
			
			dataAccessService.doQuery('sheduleDataFieldsQueryModel', data, function(response){
				console.log(response);
				if(response.data.resultSet){ 
					vm.references.dataFieldList = response.data.resultSet;
					console.log(vm.references.dataFieldList);
					
					// References
					vm.getDataFieldReference();
				}
			},function(errorResponse){
				console.log(errorResponse);
			});
		};
		
		/**
		 * 
		 */
		vm.getDataFieldReference = function(){
			console.log("vm.getDataFieldReference()");
			
			angular.forEach(vm.references.dataFieldList, function(value, key){
				if(value.hasSource === true){
					var data = { 
									"scheduleCode" : vm.data.scheduleCode,
									"code" : value.code,
									"pageIndex" : 1,
									"pageSize" : 10000
								};
					console.log(data);
					dataAccessService.doQuery('dataFieldReferenceQueryModel', data, function(response){
						vm.references.dataFieldReferences[value.code] = response.data.resultSet;
						console.log(vm.references.dataFieldReferences);
					},function(errorResponse){
						console.log(errorResponse);
					});
				}
			});
		};	
		
		/**
		 * 
		 */
		vm.close = function(){
			$uibModalInstance.dismiss();
		};
		
		/**
		 * 
		 */
		vm.init();
		
	}]);
	
});