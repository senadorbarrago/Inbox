'use strict';

define(function(){
	console.log('loginController.js loaded');
	var core = angular.module('core');
	
	core.registerController('loginController', ['$scope', '$location', '$rootScope', '$cookies', '$uibModal', 'DataAccessService', 
		function($scope, $location, $rootScope, $cookies, $uibModal, dataAccessService){		
		console.log('core.register.controller');
		
		$scope.title = 'Login';
		
		var vm = this;
		
		/**
		 * 
		 */
		vm.init = function(){
			// Default values
			vm.defaultSuccessUrl = $rootScope.defaultValues.defaultSuccessUrl;
			// Initialize context
			if($rootScope.contextList.length === 1){
				vm.context = $rootScope.contextList[0].id;
			}
		}
		
		/**
		 * 
		 */
		vm.interceptEnterKey = function(event){
			if(event.which === 13){
				vm.loginUser(event);
			}
		}		
		
		/**
		 * 
		 */
		vm.loginUser = function(event){
			event.preventDefault();
			if(!vm.isValidLoginDetails()){
				alertify.alert("Please completely fill up authentication fields");
				return false;
			}else{
				var authenticationDetails = "username="+vm.username+"&"+"password="+vm.password+"&context="+vm.context;
				
				dataAccessService.doPostTransformedData("login", authenticationDetails, function(response){
					if(response.headers("defaultSuccessUrl")){
						vm.defaultSuccessUrl = response.headers("defaultSuccessUrl");
					}
					
					dataAccessService.doGetData("authenticatedUser", null, function(response){
						console.log(response.data);
						$rootScope.watchTimeout();
						
						$rootScope.session['AUTHENTICATED'] = true;
						$rootScope.session['AUTHENTICATED_USER'] = response.data;
						$rootScope.session['CURRENT_PAGE'] = $scope.defaultUrl;
						$cookies.put("AUTHENTICATED", true);
						$cookies.put("CURRENT_PAGE", $scope.defaultUrl);
						
						$rootScope.getSessionInstitution();
						$rootScope.getSessionContext();
						
						$location.path(vm.defaultSuccessUrl);
					}, function(errorResponse){
						alertify.fail(errorResponse.headers("ERROR_MESSAGE"));
					});
				},function(errorResponse){
					console.log(errorResponse);
					alertify.fail(errorResponse.headers("ERROR_MESSAGE"));
				});
			}
		};
		
		/**
		 * 
		 */
		vm.isValidLoginDetails = function(){
			if(vm.username && vm.username.trim() !== '' && 
				vm.password && vm.password.trim() !== '' &&
					vm.context){
				return true;
			}else{
				return false;
			}
		}
		
		/**
		 * Control Center
		 */
		vm.keyDown = function(value){			
		    if(value.keyCode == 19) {
		        var modalInstance = $uibModal.open({
					animation: true,
					templateUrl: 'app/shared/controlcenter/controlCenter.html',
					controller: 'controlCenterController',
					size: 'lg',
					keyboard: false,
					resolve:{
						load: ['$q', function($q){
							var defered = $q.defer();
							require(['app/shared/controlcenter/controlCenterController'], function(){
								defered.resolve();
							});
							return defered.promise;
						}]
					}
				});
				return modalInstance.result;
		    }
		};
		
		// Initialize
		vm.init();
	}]);
	
});