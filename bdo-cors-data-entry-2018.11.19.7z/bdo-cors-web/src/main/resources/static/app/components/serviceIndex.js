'use strict'

define(function(){
	return [
	        'app/shared/services/dataAccessService'
	        ]
});