'use strict';

define(function(){
	var core = angular.module('core');
	
	core.registerController('transactionPoolController',['$rootScope','$scope', '$uibModal', 'ngTableParams', 'DataAccessService', 
	    function($rootScope, $scope, $uibModal, ngTableParams, dataAccessService){

		// Title and Module Description
		var vm = this;
		$rootScope.screenName = 'Transaction Pool';
		
		// Initialize Data
		vm.init = function(){
			$scope.data = {};
			$scope.data.dataSetCode = $rootScope.dataSetCode;
			vm.searchCriteria = {};
			
			vm.doGetTransactions();
			vm.initDatePicker();
		};
		
		// UI Validations
		vm.checkIfHasSelection = function(list){
			for(var index = 0; index < list.length; index++){
				if(list[index]["Selected"]){
					return true;
				}
			}
			return false;
		}
		
		// DatePicker SetUp
		vm.initDatePicker = function(){
			vm.datePicker = {};
			vm.dateOptions = {
					startingDay : 0,
					showWeeks : false,	
					format : "yyyy-MM-dd",
					timezone: 'UTC'
				};
			vm.dateFormat = "yyyy-MM-dd";
		}
		
		/**
		 * 
		 */
		vm.doGetTransactions = function(){
			console.log("vm.doGetTransactions()");
			vm.transactionPoolTable = new ngTableParams({
                page: 1,
                count: 25
            }, {
                getData: function ($defer, params) {
                	console.log("getData()");
                	var queryCode = "transactionPoolQueryModel";
                	var url = "query/"+queryCode;
                	
                	var data = {
            				'searchCriteria' : vm.searchCriteria,
            				'pageIndex' : params.page(),
        					'pageSize': params.count()
        		   	   	   };
                	
                	console.log(data);

                	return dataAccessService.doQuery(queryCode, data, function(response){
			        			console.log('doQuery()');
			        			console.log(response);
			        			vm.transactionPoolData = {};
			        			vm.transactionPoolData.resultSet = response.data.resultSet;
			        			vm.transactionPoolData.columns = response.data.columns;
			        			
			        			params.total(response.data.resultOverAllCount);
			        			$defer.resolve(vm.transactionPoolData.resultSet);
			        		}, function(errorResponse){
			    				console.log(errorResponse);
			    			});
                	
                }
            
            });
		};
		
		/**
		 * search
		 * 
		 */
		vm.doSearch = function(){
			console.log("vm.doSearch()");
			vm.transactionPoolTable.reload();
		}
		
		/**
		 * showAll
		 * 
		 */
		vm.doShowAll = function(){
			console.log("vm.doShowAll()");
			vm.searchCriteria = {};
			vm.transactionPoolTable.reload();
		}
		
		/**
		 * 
		 */
		vm.doShowScheduleForm = function(id, transactionID, schedule){
			console.log('doShowScheduleForm()');
			var modalInstance = $uibModal.open({
				animation: true,
				backdrop: 'static',
				templateUrl: 'app/components/transactions/forms/scheduleForm.html',
				controller: 'scheduleFormController',
				controllerAs: 'ctrl',
				size: 'md',
				resolve:{
					data:function(){
						var data = {};
						data.id = id;
						data.transactionID = transactionID;
						data.scheduleCode = schedule;
						console.log("data1");
						console.log(data);
						return data;
					},
					load: ['$q', function($q){
						var defered = $q.defer();
						require(['app/components/transactions/forms/scheduleFormController'], function(){
							defered.resolve();
						});
						return defered.promise;
					}]
				}
			});
			
			modalInstance.result.then(
				function(message) {
					//Reload Paginated Request
					vm.transactionPoolTable.reload();
				}, 
				function() {				
					// dismissed
					console.log("dismissed");
				}
			);
			
			return modalInstance.result;
		};
		
		/**
		 * Init
		 */
		vm.init();
	}]);
});