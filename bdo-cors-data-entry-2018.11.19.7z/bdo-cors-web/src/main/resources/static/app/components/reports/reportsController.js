'use strict';

define(function(){
	console.log('reportsController.js loaded');
	var core = angular.module('core');
	
	core.registerController('reportsController', ['$rootScope', '$scope', 'ngTableParams', 'DataAccessService', 
		function($rootScope, $scope, ngTableParams, dataAccessService){

		// Title and Module Description
		var vm = this;
		$rootScope.screenName = 'Reporting';
		
		/**
		 * 
		 */
		vm.init = function () {
			vm.initData();
			vm.initDatePicker();
			vm.checkReportServiceConnection();
			vm.getReportReference();
		};
		
		/**
		 * 
		 */
		vm.initData = function(){
			vm.references = {};
			vm.references.reportParamReferences = {};
			vm.data = {};
		}
		
		/**
		 * 
		 */
		vm.initDatePicker = function(){
			vm.datePicker = {};
			
			vm.dateOptions = {
					startingDay : 1,
					showWeeks : false,	
					format : "yyyy-MM-dd",
					timezone: 'UTC'
				};
			
			vm.dateFormat = "yyyy-MM-dd";
		}
		
		/**
		 * 
		 */
		vm.open = function(columnName, $event){
			$event.preventDefault();
			$event.stopPropagation();
			
			if (vm.datePicker[columnName]) {
				if (vm.datePicker[columnName].opened) {
					vm.datePicker[columnName].opened = false;
				}
			} else {
				vm.datePicker = {};
				vm.datePicker[columnName] = {};
				vm.datePicker[columnName].opened = true;
			}
		}
		
		/**
		 * 
		 */
		vm.checkReportServiceConnection = function(){
			console.log('vm.checkConnection():');
			var data = {};
			console.log(data);
			dataAccessService.doQuery('reportServiceConnectionQueryModel', data, function(response){
				console.log('reportServiceConnectionQueryModel');
				console.log(response.data);
				
				if(response.data.resultSet && response.data.resultSet[0].connection){
					vm.serviceName = response.data.resultSet[0].connection.serviceName;
					vm.serviceVersion = response.data.resultSet[0].connection.serviceVersion;
					vm.serviceStatus = response.data.resultSet[0].connection.serviceStatus;
					vm.serviceDetails = vm.serviceName+"-"+vm.serviceVersion+" | Connection Status: "+vm.serviceStatus;
				}else{
					vm.serviceDetails = "Not Connected";
				}
				
			},function(errorResponse){
				console.log(errorResponse);
				vm.serviceDetails = "Not Connected";
			});
		}
		
		/**
		 * 
		 */
		vm.getReportReference = function(){
			console.log("vm.getReportReference()");
			var data = {};
			
			dataAccessService.doQuery('reportProfileQueryModel', data, function(response){
				if(response.data.resultSet){ 
					vm.references.reportList = response.data.resultSet.filter(function(report){
													return $rootScope.hasResourcePermission(report.code);
												});
					console.log(vm.references.reportList);
				}
			},function(errorResponse){
				console.log(errorResponse);
			});
		};
		
		/**
		 * 
		 */
		vm.getReportParams = function(){
			console.log("vm.getReportParams()");
			var data = {"reportProfileID": vm.data.report.id};
			console.log(data);
			dataAccessService.doQuery('reportParameterQueryModel', data, function(response){
				vm.references.reportParamList = response.data.resultSet;
				console.log(vm.references.reportParamList);
				vm.getReportParamReference();
				vm.initReportParams();
			},function(errorResponse){
				console.log(errorResponse);
			});
		};
		
		/**
		 * 
		 */
		vm.getReportParamReference = function(){
			console.log("vm.getReportParamReference()");
			
			angular.forEach(vm.references.reportParamList, function(value, key){
				if(value.parameterType === 'REFERENCE' && !value.parentID){
					var data = { 
									"id" : value.id,
									"pageIndex" : 0,
									"pageSize" : 100
								};
					console.log(data);
					dataAccessService.doQuery('reportParameterReferenceQueryModel', data, function(response){
						vm.references.reportParamReferences[value.code] = response.data.resultSet;
						console.log(vm.references.reportParamReferences);
					},function(errorResponse){
						console.log(errorResponse);
					});
				}
			});
		};		
		
		/**
		 * 
		 */
		vm.doClearReportParameters = function(){
			vm.data.reportParams = {};
		};
		
		/**
		 * 
		 */
		vm.doGenerateReport = function(){
			console.log("doGenerateReport()");
			console.log(vm.data);
			
			if(vm.isValid() === false){
				alertify.alert("Select a report to generate in order to proceed.");
				return false;
			}
			
			var data = {};
			data.reportCode   = vm.data.report.code;
			data.reportParams =	vm.data.reportParams;
			
			console.log(data);
			
			dataAccessService.doPost('generateReportCommandHandler', data, function(response){
				console.log(response.data);
				alertify.alert(response.data.messageMap['SUCCESS_MESSAGE']);
			},function(errorResponse){
				console.log(errorResponse);
				alertify.alert(errorResponse.data.messageMap['ERROR_MESSAGE']);
			});
		};
		
		/**
		 * 
		 */
		vm.initReportParams = function(){
			console.log('vm.initReportParams()');
			vm.data.reportParams = {};
			angular.forEach(vm.references.reportParamList, function(value, key){
				console.log(value);
				vm.data.reportParams[value.code] = '';
			});
		}
		
		/**
		 * 
		 */
		vm.isValid = function(){
			 if(!vm.data.report){
				 return false;
			 }
			 
			 return true;
		}
		
		/**
		 * 
		 */
		vm.init();
		
	}]);
	
});