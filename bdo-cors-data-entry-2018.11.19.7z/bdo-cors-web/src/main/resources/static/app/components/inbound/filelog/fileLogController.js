'use strict';

define(function(){
	var core = angular.module('core');
	
	core.registerController('fileLogController',['$rootScope','$scope', 'ngTableParams', 'DataAccessService', 
	    function($rootScope, $scope, ngTableParams, dataAccessService){

		// Title and Module Description
		var vm = this;
		$rootScope.screenName = 'File Logs and Prooflist';
		
		// Initialize Data
		vm.init = function(){
			$scope.data = {};
			$scope.data.dataSetCode = $rootScope.dataSetCode;
			
			// Table Header 
			$scope.tableHeader = ['Select', 'File Name', 'File Path', 'Size', 'Date Created'];
			$scope.fileHistoryHeader = ['Select', 'File Log ID', 'File Name', 'Date Loaded', 'Loaded By', 'Status'];
			
			// References
			vm.references = {};
			vm.getFileLogStatusReference();
			vm.getSourceSystemReference();
			vm.searchCriteria = {};
			
			vm.doGetFileLogHistory();
			vm.initDatePicker();
		};
		
		/**
		 * 
		 */
		vm.doGetFileLogHistory = function(){
			console.log("doGetFileLogHistory()");

			vm.fileLogHistoryTable = new ngTableParams({
                page: 1,
                count: 10
            }, {
                getData: function ($defer, params) {
                	console.log("getData()");
                	var queryCode = "fileLogQueryModel";
                	var url = "query/"+queryCode;
                	console.log('params.count(): '+ params.count());
                	console.log('params.page(): '+ params.page());
                	
                	var data = {
                				'searchCriteria' : vm.searchCriteria,
                				'pageIndex' : params.page(),
        						'pageSize': params.count()
        			   	   	   };
                	
                	console.log(data);

                	return dataAccessService.doQuery(queryCode, data, function(response){
			        			console.log('doQuery()');
			        			console.log(response);
			        			vm.fileLogHistoryData = {};
			        			vm.fileLogHistoryData.resultSet = response.data.resultSet;
			        			vm.fileLogHistoryData.columns = response.data.columns;
			        			
			        			params.total(response.data.resultOverAllCount);
			        			$defer.resolve(vm.fileLogHistoryData.resultSet);
			        		}, function(errorResponse){
			    				console.log(errorResponse);
			    			});
                	
                }
            
            });
		};		
        
		// UI Validations
		vm.checkIfHasSelection = function(list){
			for(var index = 0; index < list.length; index++){
				if(list[index]["Selected"]){
					return true;
				}
			}
			return false;
		}
		
		// DatePicker SetUp
		vm.initDatePicker = function(){
			console.log("vm.initDatePicker()");
			vm.datePicker = {};
			vm.dateOptions = {
					startingDay : 0,
					showWeeks : false,	
					format : "yyyy-MM-dd",
					timezone: 'UTC'
				};
			vm.dateFormat = "yyyy-MM-dd";
		}
		
		/**
		 * getSourceSystemReference()
		 * 
		 */
		vm.getSourceSystemReference = function(){
			console.log("vm.getSourceSystemReference()");
			var data = {};
			
			dataAccessService.doQuery('sourceSystemQueryModel', data, function(response){
				vm.references.sourceSystemList = response.data.resultSet;
				console.log(vm.references.sourceSystemList);
			},function(errorResponse){
				console.log(errorResponse);
			});
		}
		
		/**
		 * getSourceSystemReference()
		 * 
		 */
		vm.getFileLogStatusReference = function(){
			console.log("vm.getFileLogStatusReference()");
			var data = {};
			
			dataAccessService.doQuery('fileLogStatusQueryModel', data, function(response){
				vm.references.fileLogStatusList = response.data.resultSet;
				console.log(vm.references.fileLogStatusList);
			},function(errorResponse){
				console.log(errorResponse);
			});
		}
		
		
		/**
		 * 
		 */
		vm.doUndoLoad = function(){
			var fileLogHistoryData = angular.copy(vm.fileLogHistoryData.resultSet);
			var hasSelection = vm.checkIfHasSelection(fileLogHistoryData);
			
			if(!hasSelection){
				alertify.alert("Please select a file to be unloaded in order to proceed.");
				return false;
			}else{
				alertify.confirm("This action undo loads the selected file/s and its corresponding transactions from the system. " +
								"Are you sure you want to proceed?", function(e){
				if(e){
						var fileLogList = [];
						angular.forEach(fileLogHistoryData, function(value, key){
							if(value["Selected"]){
								var data = {};
								data.fileLogId = value["fileLogID"];
								data.sourceProfile = value["Source Profile"];
								
								dataAccessService.doPost("undoLoadFileCommandHandler", data, function(response){
									console.log(response.data);
									alertify.alert(response.data.messageMap['SUCCESS_MESSAGE']);
									vm.doGetFileLogHistory();
								}, function(errorResponse){
									console.log(errorResponse);
									alertify.alert(errorResponse.data['ERROR_MESSAGE']);
								});
							}
						});
					}else{
						return false;
					}
				});
			}
		};		
		
		/**
		 * 
		 */
		vm.doGenerateReport = function(selectedRecord){
			console.log("doGenerateReport()");

			var data = {};
			data.reportParams =	{};
			
			data.reportCode   = selectedRecord['reportCode'];
			data.reportParams.filelogId = selectedRecord['fileLogID']+"";
			data.reportParams.jobinstance = selectedRecord['jobinstance'];
			data.reportParams.sourcefile = selectedRecord['File Name'];
			data.reportParams.sourceprofile = selectedRecord['Source Profile'];
			
			console.log(data);
			
			dataAccessService.doPost('generateReportCommandHandler', data, function(response){
				console.log(response.data);
				alertify.alert(response.data.messageMap['SUCCESS_MESSAGE']);
			},function(errorResponse){
				console.log(errorResponse);
				alertify.alert(errorResponse.data.messageMap['ERROR_MESSAGE']);
			});
		};
		
		/**
		 * 
		 */
		vm.open = function(columnName, $event){
			$event.preventDefault();
			$event.stopPropagation();
			
			if (vm.datePicker[columnName]) {
				if (vm.datePicker[columnName].opened) {
					vm.datePicker[columnName].opened = false;
				}
			} else {
				vm.datePicker = {};
				vm.datePicker[columnName] = {};
				vm.datePicker[columnName].opened = true;
			}
		}
		
		/**
		 * search
		 * 
		 */
		vm.doSearch = function(){
			console.log("vm.doSearch()");
			vm.fileLogHistoryTable.reload();
		}
		
		/**
		 * showAll
		 * 
		 */
		vm.doShowAll = function(){
			console.log("vm.doShowAll()");
			vm.searchCriteria = {};
			vm.fileLogHistoryTable.reload();
		}
		
		/**
		 * Init
		 */
		vm.init();
	}]);
});