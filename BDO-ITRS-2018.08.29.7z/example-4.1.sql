/*
UPDATE ibstrnmodeldata
	SET itmdmodelvalue = ''
WHERE itmdmodelcolumn = 'remarks'
AND itmdjobinstance = 'a1662773-a66c-4b05-812e-a779dcc9d9d4';

UPDATE ibstrnmodeldata
	SET itmdmodelvalue = 'VALID'
WHERE itmdmodelcolumn = 'status'
AND itmdjobinstance = 'a1662773-a66c-4b05-812e-a779dcc9d9d4'

SELECT FROM sp_ibs_validate_data_field_type('SRC-PROFILE-015', 'c', 'ITRS', 'C140618008');
SELECT FROM sp_ibs_validate_execute('FRS_ITRS_20180803_conso.csv','SRC-PROFILE-015', 'a1662773-a66c-4b05-812e-a779dcc9d9d4', 'ITRS', 'C140618008');
*/

SELECT * FROM ibstrnmodeldata a
WHERE a.itmdjobinstance = 'a1662773-a66c-4b05-812e-a779dcc9d9d4'
AND itmdtransid IN(1535457715420, 1535457715421)
AND a.itmdrecordtype = '2'
ORDER BY a.itmdtransid, a.itmdmodelcolumn

-- '1535457715420'; '1535457715421'
UPDATE ibstrnmodeldata
	SET itmdmodelvalue = '2018080z'
WHERE 
	itmdjobinstance = 'a1662773-a66c-4b05-812e-a779dcc9d9d4' AND
	itmdtransid = 1535457715420 AND
	itmdmodelcolumn = 'trdate';

UPDATE ibstrnmodeldata
	SET itmdmodelvalue = 'y'
WHERE 
	itmdjobinstance = 'a1662773-a66c-4b05-812e-a779dcc9d9d4' AND
	itmdtransid = 1535457715420 AND
	itmdmodelcolumn = 'amtorig1'

UPDATE ibstrnmodeldata
	SET itmdmodelvalue = 'M'
WHERE 
	itmdjobinstance = 'a1662773-a66c-4b05-812e-a779dcc9d9d4' AND
	itmdtransid = 1535457715421 AND
	itmdmodelcolumn = 'amtorig1'

SELECT * FROM conf_data_field

SELECT 
	b.code as recordProfileCode,
	c.code as dataFieldCode,
	a.label as dataFieldLabel,
	e.code as dataTypeCode,
	c.field_length as Length,
	c.field_precision as Precision,
	c.field_scale as Scale,
	c.field_format as Format,
	a.sequence_no SeqNo
FROM conf_map_record_profile_data_field a
JOIN conf_record_profile b ON
	b.id = a.fk_record_profile AND
	b.is_deleted = false
JOIN conf_data_field c ON
	c.id = a.fk_data_field AND
	c.is_deleted = false
JOIN conf_data_type e ON
	e.id = c.fk_datatype AND
	e.is_deleted = false
WHERE 
	a.is_deleted = false
	AND b.code = 'ITRS-002'
ORDER BY a.sequence_no

SELECT * FROM sp_report_itrs_output_extract('ITRS', 'c140618008', 'HO', 'ITRS-002', '', '', 1, 100000);
SELECT * FROM sp_report_itrs_output_extract_count('ITRS', 'c140618008', 'HO', 'ITRS-002', '', '');
SELECT * FROM sp_report_itrs_output_extract('ITRS', 'c140618008', 'HO', 'ITRS-002', '', '2018-07-09', 1, 100000);
SELECT * FROM sp_report_itrs_output_extract_count('ITRS', 'c140618008', 'HO', 'ITRS-002', '', '2018-07-09');
SELECT * FROM sp_report_itrs_output_extract('ITRS', 'c140618008', 'HO', 'ITRS-002', '2018-07-09', '', 1, 100000);
SELECT * FROM sp_report_itrs_output_extract_count('ITRS', 'c140618008', 'HO', 'ITRS-002', '2018-07-09', '');
SELECT * FROM sp_report_itrs_output_extract('ITRS', 'c140618008', 'HO', 'ITRS-002', '2018-08-03', '2018-08-03', 1, 100000);
SELECT * FROM sp_report_itrs_output_extract_count('ITRS', 'c140618008', 'HO', 'ITRS-002', '2018-08-03', '2018-08-03');
